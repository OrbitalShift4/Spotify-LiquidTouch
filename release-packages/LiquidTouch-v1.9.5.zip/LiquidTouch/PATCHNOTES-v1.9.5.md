# LiquidTouch v1.9.5

3 November 2026

## Player and history

- With lyrics off, the artwork and control column now share a vertical center. The song title and artist are centered within the control column. Larger artwork still flows below the header and can push content down; player scrollbars stay hidden.
- Listening history uses LiquidTouch’s on-screen keyboard when its search field is touched and the local keyboard setting is enabled. Typing filters the journal; Enter hides the keyboard and keeps history open. The system keyboard remains available when the local keyboard is disabled.

## Touch navigation

- Horizontal tab and edge-Back gestures reveal the incoming LiquidTouch page while dragging, with the navigation selection following progress. Releasing beyond the configured threshold commits the change; short or cancelled gestures return to the current page.
- Back inside nested action menus previews the previous menu. Dismissing history/action sheets exposes the page underneath as the sheet moves. Quick Search previews its incoming field before committing. Existing player, track-artwork and Settings gestures retain their independent thresholds and speeds.
- Incoming pages are inert previews: they cannot intercept taps, start playback or share duplicate element IDs. They use bounded card/track previews and cached metadata; navigation commits without waiting for an extra network fetch.
- Hold menus now animate from the selected card or artwork and anchor beside it on wider displays. Narrow displays use a bottom-docked menu. Holding, moving or cancelling does not also play/open the item. Existing Surface/menu speed and Reduce Motion settings apply.

## Song Radio and search

- **Go to song radio** resolves Spotify’s generated Song Radio playlist, opens it in LiquidTouch, places the selected song first and starts that song in the playlist’s playback context. It no longer starts a generic track station. Unavailable radio playlists show an inline error.
- Full and Quick Search keep their own route while Spotify finishes startup. A stale host Home event cannot replace the first results page.
- Failed startup searches get one bounded retry, re-reading client search bindings before falling back to the authenticated catalog service. Valid empty results are not retried. Persistent failures keep an explicit Retry action.

## Optional Low-RAM mode

- Settings → **Appearance & glass → Low-RAM mode** keeps fewer cached pages, images, searches, lyrics and details, reduces artwork concurrency, avoids adjacent-artwork preloading and releases blurred image backgrounds.
- The interface retains touch navigation and artwork but simplifies blur effects. Some pages may reload. This is an optional reduction of LiquidTouch’s own retained resources, not a fixed RAM saving for Spotify.
- Listening history, limits, lyric timing, settings and update-feed preferences remain saved. Turning the mode off restores the regular effects and caching policy.

## Gallery and documentation

- The repository README explains the theme/extension’s purpose, touchscreen features, accessibility, installation and updates, with a dedicated screenshot gallery.
- A separate **LiquidTouch-Gallery.html** demonstrates the production UI with randomly selected real songs, verified artist/album metadata and actual covers. It is self-contained and simulates playback without audio or an account connection. The fictional test preview remains available for repeatable automated checks.
- Gallery recordings: Dreams — Fleetwood Mac; Three Little Birds — Bob Marley & The Wailers; On Melancholy Hill — Gorillaz; Clocks — Coldplay; Feather (feat. Cise Starr & Akin) — Nujabes; No Ordinary Love — Sade. Artwork/catalog credits are included.

## Updating

Existing compatible installations: **Settings → Updates → Check now**, then choose Update. New users should install the full ZIP with Spotify desktop and compatible Spicetify. Normal updates preserve settings and local listening history. Installer scripts are unchanged.

Validation uses simulated Spotify services and Windows bridges in Chromium. A signed-in Windows Spotify client and physical touchscreen were unavailable. See VALIDATION.md for exact checks.
