# LiquidTouch updates

## First installation of 1.9.0

Extract the full package and run its normal installer once:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-Windows.ps1
```

This installs the stable loader, bundled fallback interface and theme bootstrap.
Versions before 1.9 cannot import update files. Keep the extracted files together
while running the installer. A Spotify or Spicetify compatibility problem still
requires the usual client/patch repair; runtime updates cannot repair that layer.

## Future updates: one file

1. Get a newer `LiquidTouch-Update-vX.Y.Z.json` from a source you trust.
2. Open Settings → Updates → Import update file and select it.
3. Read the version, short notes and Full patch notes. Choose Update or Later.
4. A successful update replaces the running interface and styles together. No
   Spotify restart, manual file replacement or Spicetify apply is needed for
   these compatible runtime updates. The first launch shows brief patch notes.

The update is kept in Spotify's local browser storage and survives restarts.
Preferences, lyric timing and listening history retain their existing keys.
Clearing app/browser data removes cached updates. Settings → Restore installed
version removes the runtime update and loads the normally installed fallback.
Updates that need new loader/installer behavior require a normal installation.

Before approval, imports are parsed and verified but never executed. A failed
cache write keeps the existing UI intact. A runtime that fails to mount restores
the prior cached/bundled version. Verification detects altered or mismatched
bytes; it is not a publisher signature. Only use files/feeds you trust.

Some Spotify builds may block dynamic code compilation or network requests.
The installed fallback runs without dynamic compilation; if in-app updates are
blocked, the UI explains that a normal installer is needed. Live Windows/Electron
behavior is not established by the simulated browser tests.

## Update notifications

From v1.9.2, the official release feed is prefilled:

`https://raw.githubusercontent.com/OrbitalShift4/Spotify-LiquidTouch/main/latest.json`

A nonempty custom feed and a disabled Check for updates setting are preserved.
For v1.9.0–1.9.1, enter this address once to receive update offers.

### Custom feeds

To use your own update host, publish a release feed and its update file, then enter its
HTTPS URL under Settings → Updates → Release feed URL. Leave Check for updates
on. The app checks at launch and about every six hours while running; Check now
also works manually. It asks Update / Later and never installs in the background.

Prompts wait while the player, Settings, history or a gesture is active. The first
successful launch after an update shows brief notes once, with an in-app Full
patch notes link. Opening full notes for a remote release downloads and verifies
the update data to read those notes; it does not execute the code. Later cancels
the prompt without changing the installation.

## Publishing a feed

1. Change the app `VERSION` in `source/liquid-touch-app.js` and release metadata
   in `updates/release.json`. Edit `Themes/LiquidTouch/runtime.css` for styles.
   The full notes field is plain text, not HTML.
2. Run `node tools/build-preview.cjs`, then the browser/installer checks described
   in VALIDATION.md. The builder generates the installed extension, preview,
   update JSON and `updates/latest.example.json` from the same source.
3. Host the generated update JSON and a copy of `latest.example.json` named
   `latest.json` in the same HTTPS directory. Publish the update file first,
   then atomically replace the manifest. Its `bundleURL` is relative to itself.
4. Serve JSON with `Content-Type: application/json`, suitable cache headers and
   CORS allowing the Spotify browser origin. Public credential-free feeds may
   use `Access-Control-Allow-Origin: *`. Requests omit cookies and credentials.
5. Use the `latest.json` URL in Settings. Test Update and Later before sharing it.

The manifest carries the schema, app, version, bundle URL, full-file SHA-256 and
brief summary. The update JSON contains its own SHA-256 over JavaScript, a NUL
separator and CSS. Bundles must remain on the manifest's host; cross-host
redirects, oversized responses, unsupported schemas, checksum failures and
newer minimum-loader requirements are rejected. Network requests time out.

`Extensions/liquid-touch.js` is generated: do not edit it directly. Keep the
loader version unchanged for compatible app/style releases; a change that needs
loader features must raise the minimum-loader requirement and ship a package.
