/* Compact lyric options, uncluttered lyrics, and the published 1.9.1 upgrade path. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
const base=path.resolve(__dirname,'..'),feed='https://raw.githubusercontent.com/OrbitalShift4/Spotify-LiquidTouch/main/latest.json';let origin,passed=0;
async function open(browser,prefs={},width=1024,height=600,old=false){
 const context=await browser.newContext({viewport:{width,height},hasTouch:true}),page=await context.newPage(),errors=[];page.setDefaultTimeout(9000);page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(p=>localStorage.getItem('liquid-touch.preferences.v1') || localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({updateChecks:false,keyboard:false,...p})),prefs);
 await page.goto(origin+(old ? '/old' : '/'));await page.waitForFunction(()=>window.LiquidTouch?.diagnostics().phase==='mounted');return {context,page,errors};
}
async function player(page){await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open' && document.querySelectorAll('#lt-lyrics-lines .lt-lyric-line').length===5);}
async function options(page){await page.locator('[data-action=lyricsMenu]').tap();await page.waitForFunction(()=>document.activeElement.dataset.action==='lyricTiming');}
function pass(name,errors){assert.deepEqual(errors,[]);console.log('PASS '+name);passed++;}
(async()=>{
 const server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(fs.readFileSync(q.url==='/old' ? process.env.LT_OLD_PREVIEW : path.join(base,'LiquidTouch-Preview.html')));});await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox']});
 try{
  {
   const {page,context,errors}=await open(browser);await player(page);
   assert.equal(await page.locator('#lt-lyrics-menu').isVisible(),false);assert.equal(await page.locator('.lt-lyrics-heading button:visible').count(),1);assert.equal(await page.locator('.lt-lyrics-heading').innerText(),'⋯');assert.ok(!(await page.locator('#lt-lyrics-status').textContent()).includes('Tap a line'));
   await options(page);await page.locator('.lt-np-layout').evaluate(n=>n.dispatchEvent(new Event('scroll')));assert.equal(await page.locator('#lt-lyrics-menu').isVisible(),true);await page.keyboard.press('ArrowDown');assert.equal(await page.locator('[data-action=retryLyrics]').evaluate(n=>n===document.activeElement),true);await page.keyboard.press('Home');assert.equal(await page.locator('[data-action=lyricTiming]').evaluate(n=>n===document.activeElement),true);await page.keyboard.press('End');await page.keyboard.press('Escape');assert.equal(await page.locator('#lt-lyrics-menu').isVisible(),false);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);assert.equal(await page.locator('[data-action=lyricsMenu]').evaluate(n=>n===document.activeElement),true);
   await page.keyboard.press('ArrowUp');assert.equal(await page.locator('[data-action=retryLyrics]').evaluate(n=>n===document.activeElement),true);await page.keyboard.press('Escape');
   pass('one visible three-dot button replaces the heading/buttons; first-touch opening, keyboard arrows/Home/End and Escape work without closing the player',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await player(page);await options(page);await page.locator('[data-action=lyricTiming]').tap();assert.equal(await page.locator('#lt-lyrics-menu').isVisible(),false);assert.equal(await page.locator('#lt-lyric-timing').isVisible(),true);
   await page.locator('[data-action=lyricsEarlier]').tap();assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().lyricOffsetMs),250);await page.locator('[data-action=lyricsTimingReset]').tap();assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().lyricOffsetMs),0);
   const count=()=>page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='apiGet' && r[1].includes('color-lyrics')).length),before=await count();await options(page);await page.locator('[data-action=retryLyrics]').tap();await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsState==='ready');assert.equal(await count(),before+1);assert.equal(await page.locator('#lt-lyrics-menu').isVisible(),false);
   await page.locator('#lt-lyrics-lines [data-lyric-index="2"]').tap();assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='seek').at(-1)[1]),25000);
   pass('Timing retains correction/Reset; Reload requests once and dismisses; tapping a synced lyric still seeks with the instruction removed',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await player(page);await options(page);await page.locator('#lt-lyrics-status').tap();assert.equal(await page.locator('#lt-lyrics-menu').isVisible(),false);
   await options(page);await page.locator('#lt-now-playing [data-action=next]').tap();assert.equal(await page.locator('#lt-lyrics-menu').isVisible(),false);await page.waitForTimeout(180);await options(page);await page.locator('[data-action=toggleLyrics]').tap();assert.equal(await page.locator('#lt-lyrics-menu').isVisible(),false);await page.locator('[data-action=toggleLyrics]').tap();await options(page);await page.locator('[data-action=closePlayer]').tap();await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);await player(page);assert.equal(await page.locator('#lt-lyrics-menu').isVisible(),false);
   pass('outside taps, track changes, lyric-off and player close clear the menu; reopening retains no invisible menu layer',errors);await context.close();
  }
  for(const [width,height,scale] of [[1920,1080,100],[1024,600,130],[480,800,200]]){
   const {page,context,errors}=await open(browser,{textScale:scale,playerTextScale:scale,lyricsOpacity:65},width,height);await player(page);await options(page);
   const menu=await page.locator('#lt-lyrics-menu').boundingBox();assert.ok(menu.x>=0 && menu.x+menu.width<=width && menu.y>=0 && menu.y+menu.height<=height);
   for(const b of await page.locator('#lt-lyrics-menu button').all()){const r=await b.boundingBox();assert.ok(r.height>=44 && r.width>=44);}
   assert.equal(await page.locator('#lt-lyrics-menu').evaluate(n=>getComputedStyle(n).getPropertyValue('--lt-surface-opacity').trim()),'0.65');
   if(width===1024)await page.screenshot({path:path.resolve(base,'../qa/v192-lyrics-options.png')});
   pass(`menu stays in bounds with touch targets and the lyric opacity override at ${width}×${height}, ${scale}% text`,errors);await context.close();
  }
  {
   for(const address of ['', '   ', 'https://custom.example.test/latest.json']){
    const {page,context,errors}=await open(browser,{updateFeed:address,homeClock:true,clockFormat:'12'});const prefs=await page.evaluate(()=>LiquidTouch.diagnostics().preferences);assert.equal(prefs.updateFeed,address.trim() || feed);assert.equal(prefs.updateChecks,false);assert.equal(prefs.homeClock,true);assert.equal(prefs.clockFormat,'12');assert.deepEqual(errors,[]);await context.close();
   }
   pass('empty feeds adopt the official address; custom feeds, disabled checks and clock preferences remain intact',[]);
  }
  if(process.env.LT_OLD_PREVIEW){
   const {page,context,errors}=await open(browser,{updateFeed:'https://custom.example.test/latest.json',homeClock:true,clockFormat:'12',playerLyricsScale:145},1024,600,true);assert.equal(await page.evaluate(()=>LiquidTouch.version),'1.9.1');await page.waitForFunction(()=>localStorage.getItem('liquid-touch.seen-release')==='1.9.1');await page.locator('#lt-shell [data-action=settings]').tap();await page.locator('#lt-update-file').setInputFiles(path.join(base,'LiquidTouch-Update-v1.9.2.json'));await page.waitForFunction(()=>document.querySelector('#lt-release').open);await page.locator('[data-action=confirmUpdate]').tap();await page.waitForFunction(()=>LiquidTouch?.version==='1.9.2' && LiquidTouch.diagnostics().phase==='mounted');await page.waitForFunction(()=>document.querySelector('#lt-release').open);assert.equal(await page.locator('#lt-release-title').textContent(),'What’s new');await page.locator('#lt-release footer [data-action=closeRelease]').tap();assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),false);await player(page);await options(page);await page.keyboard.press('Escape');await page.reload();await page.waitForFunction(()=>LiquidTouch?.version==='1.9.2' && LiquidTouch.diagnostics().phase==='mounted');const prefs=await page.evaluate(()=>LiquidTouch.diagnostics().preferences);assert.equal(prefs.updateFeed,'https://custom.example.test/latest.json');assert.equal(prefs.updateChecks,false);assert.equal(prefs.playerLyricsScale,145);assert.equal(prefs.clockFormat,'12');assert.equal(prefs.homeClock,true);assert.equal(await page.locator('#lt-shell').count(),1);assert.equal(await page.evaluate(()=>__ltMock.listenerCount()),3);
   pass('the published 1.9.1 loader imports 1.9.2, shows notes, uses the menu, and persists preferences with one runtime after restart',errors);await context.close();
  }
  console.log(passed+' release 1.9.2 suites passed with simulated Spotify services.');
 }finally{await browser.close();server.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
