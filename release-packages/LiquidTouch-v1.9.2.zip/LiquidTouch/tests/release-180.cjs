/* Owned detail pages under failed native routing; player accessibility controls. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
let origin,passed=0;
async function open(browser,prefs={},width=1024,height=600){
 const context=await browser.newContext({viewport:{width,height},hasTouch:true,reducedMotion:'reduce'}),page=await context.newPage(),errors=[];page.setDefaultTimeout(8000);page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(p=>localStorage.getItem('liquid-touch.preferences.v1') || localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,textScale:130,uiScale:120,...p})),prefs);
 await page.goto(origin);await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted' && document.querySelector('#lt-browse .lt-card'));return {page,context,errors};
}
function pass(name,errors){assert.deepEqual(errors,[]);passed++;console.log('PASS '+name);}
async function range(page,key,value){await page.locator('#lt-'+key).evaluate((n,v)=>{n.value=String(v);n.dispatchEvent(new Event('input',{bubbles:true}));},value);}
async function own(page,uri){const card=page.locator('#lt-browse [data-lt-card="'+uri+'"]');await card.tap();await card.tap();await page.waitForSelector('.lt-detail-track');}
async function settings(page){await page.locator('#lt-now-playing [data-action=playerSettings]').tap();}
async function closeSettings(page){await page.locator('#lt-settings [data-action=closeSettings]').tap();}
async function main(){
 const html=fs.readFileSync(path.resolve(__dirname,'../LiquidTouch-Preview.html')),server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(html);});await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox']});
 try{
  for(const [type,tab,id] of [['playlist','home',0],['album','home',1],['artist','library',4]]){
   const {page,context,errors}=await open(browser);if(tab==='library')await page.locator('.lt-nav [data-action=library]').tap();
   await page.evaluate(()=>{Spicetify.Platform.History.push=()=>{throw new Error('Native router is broken');};document.querySelector('.Root').style.display='none';});
   const uri=`spotify:${type}:demo-${id}`,card=page.locator('#lt-browse [data-lt-card="'+uri+'"]');await card.tap();const count=await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length);await card.tap();await page.waitForSelector('.lt-detail-track');
   assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'detail');assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().route),`/${type}/demo-${id}`);assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length),count);
   const row=page.locator('.lt-detail-track').nth(1),title=await row.locator('strong').textContent();await row.tap();assert.equal(await page.locator('#lt-mini-title').textContent(),title);
   if(type!=='artist')assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').at(-1)[2].uri),uri);
   if(type==='artist')assert.ok(await page.locator('.lt-detail-songs + .lt-card-section .lt-card').count());
   await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),tab);
   pass('double-tapped '+type+' opens real songs with a broken router and hidden native root, plays the chosen row once and returns through Back',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.locator('.lt-nav [data-action=search]').tap();await page.locator('#lt-search-input').fill('Blue');await page.locator('#lt-search-input').press('Enter');await page.waitForSelector('[data-lt-card="spotify:track:demo-1"]');
   await page.evaluate(()=>Spicetify.Platform.History.push=()=>{throw Error('Broken detail router');});await own(page,'spotify:track:demo-1');assert.equal(await page.locator('.lt-detail-copy h1').textContent(),'Blue Hour');await page.locator('.lt-detail-track').tap();assert.equal(await page.locator('#lt-mini-title').textContent(),'Blue Hour');
   await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'results');assert.equal(await page.locator('#lt-search-input').inputValue(),'Blue');
   pass('a searched song opens an owned song page and Back restores the retained query/results even when native detail routing fails',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.evaluate(()=>{Spicetify.GraphQL={};delete Spicetify.Platform.PlaylistAPI;});
   await own(page,'spotify:album:demo-1');assert.equal(await page.locator('.lt-detail-track').count(),6);assert.ok(await page.evaluate(()=>__ltMock.log.some(r=>r[0]==='apiGet' && r[1].endsWith('/albums/demo-1'))));
   await page.locator('.lt-nav [data-action=library]').tap();await own(page,'spotify:artist:demo-4');assert.equal(await page.locator('.lt-detail-track').count(),6);assert.ok(await page.locator('.lt-card-section .lt-card').count());
   await page.locator('.lt-nav [data-action=home]').tap();await own(page,'spotify:playlist:demo-0');assert.equal(await page.locator('.lt-detail-track').count(),6);
   pass('album, artist and playlist contents fall back to authenticated catalog responses when installed client APIs are absent',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{Spicetify.Platform.PlaylistAPI.getContents=async(uri,{offset,limit})=>({items:Array.from({length:Math.min(limit,105-offset)},(_,i)=>({track:{uri:'spotify:track:demo'+((offset+i)%6),name:'Fictional song '+(offset+i),artists:[{name:'Pagination Artist'}],duration_ms:120000}})),totalLength:105});});
   await own(page,'spotify:playlist:demo-0');assert.equal(await page.locator('.lt-detail-track').count(),50);await page.locator('[data-detail-action=more]').tap();await page.waitForFunction(()=>document.querySelectorAll('.lt-detail-track').length===100);await page.locator('[data-detail-action=more]').tap();await page.waitForFunction(()=>document.querySelectorAll('.lt-detail-track').length===105);assert.equal(await page.locator('[data-detail-action=more]').count(),0);assert.equal(await page.locator('.lt-detail-track strong').last().textContent(),'Fictional song 104');
   pass('playlist paging advances through 50/100/105 items, preserving repeated recordings and ending at the declared total',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{window.failDetailMore=true;Spicetify.Platform.PlaylistAPI.getContents=async(uri,{offset})=>{if(offset && failDetailMore)throw Error('Next page unavailable');return {items:Array.from({length:Math.min(50,60-offset)},(_,i)=>({track:{uri:'spotify:track:demo'+((offset+i)%6),name:'Paged song '+(offset+i)}})),totalCount:60};};const get=Spicetify.CosmosAsync.get;Spicetify.CosmosAsync.get=async url=>{if(url.includes('/playlists/') && url.includes('/tracks'))throw Error('No catalog fallback');return get(url);};});
   await own(page,'spotify:playlist:demo-0');await page.locator('[data-detail-action=more]').tap();await page.waitForFunction(()=>document.querySelector('.lt-detail-status').textContent.includes('could not'));assert.equal(await page.locator('.lt-detail-track').count(),50);
   await page.evaluate(()=>window.failDetailMore=false);await page.locator('[data-detail-action=more]').tap();await page.waitForFunction(()=>document.querySelectorAll('.lt-detail-track').length===60);assert.equal(await page.locator('.lt-detail-track strong').last().textContent(),'Paged song 59');
   pass('a failed next page retains loaded songs and retries the same offset without dropping or duplicating rows',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.evaluate(()=>{Spicetify.GraphQL.Request=async()=>({data:{unexpectedShape:{}}});Spicetify.Platform.PlaylistAPI.getContents=async()=>({unknown:true});});
   await own(page,'spotify:album:demo-1');assert.equal(await page.locator('.lt-detail-track').count(),6);await page.locator('.lt-nav [data-action=home]').tap();await own(page,'spotify:playlist:demo-0');assert.equal(await page.locator('.lt-detail-track').count(),6);
   pass('changed or malformed client response shapes fall through to a recognized catalog page instead of producing an empty screen',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.locator('[data-action=likedSongs]').tap();await page.waitForSelector('.lt-detail-track');assert.equal(await page.locator('.lt-detail-copy h1').textContent(),'Liked Songs');assert.equal(await page.locator('.lt-detail-track').count(),6);await page.locator('.lt-detail-track').nth(1).tap();assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').at(-1)[2].uri),'spotify:collection:tracks');
   pass('Liked Songs opens its owned collection and selected tracks retain collection playback context',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{window.restoreDetailAPI=Spicetify.GraphQL;Spicetify.GraphQL={};window.oldCosmos=Spicetify.CosmosAsync.get;Spicetify.CosmosAsync.get=async url=>{if(url.includes('/albums/'))throw Error('Catalog unavailable');return oldCosmos(url);};});
   await page.locator('[data-open-uri="spotify:album:demo-1"]').tap();await page.waitForFunction(()=>document.querySelector('.lt-detail-status')?.textContent.includes('could not'));assert.equal(await page.locator('.lt-detail-copy h1').textContent(),'Blue Hour');assert.equal(await page.locator('[data-detail-action=play]').isVisible(),true);assert.equal(await page.locator('#lt-browse').getAttribute('aria-busy'),'false');
   await page.evaluate(()=>{Spicetify.GraphQL=restoreDetailAPI;Spicetify.CosmosAsync.get=oldCosmos;});await page.locator('[data-detail-action=retry]').tap();await page.waitForSelector('.lt-detail-track');assert.equal(await page.locator('.lt-detail-track').count(),6);
   await page.locator('[data-detail-action=desktop]').tap();assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().enabled),false);assert.equal(await page.evaluate(()=>Spicetify.Platform.History.location.pathname),'/album/demo-1');
   pass('unavailable content leaves a readable hero, play/retry controls and an explicit desktop exit; retry restores actual songs',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.evaluate(()=>{const request=Spicetify.GraphQL.Request;Spicetify.GraphQL.Request=(definition,args)=>args.uri==='spotify:album:demo-1' ? new Promise(resolve=>window.finishOldDetail=()=>request(definition,args).then(resolve)) : request(definition,args);});
   await page.locator('[data-open-uri="spotify:album:demo-1"]').tap();await page.waitForFunction(()=>Boolean(window.finishOldDetail));await page.locator('.lt-nav [data-action=home]').tap();await page.locator('[data-open-uri="spotify:album:demo-3"]').tap();await page.waitForSelector('.lt-detail-track');await page.evaluate(()=>finishOldDetail());await page.waitForTimeout(100);assert.equal(await page.locator('.lt-detail-copy h1').textContent(),'Soft Signal');
   await page.evaluate(()=>Spicetify.Platform.History.push('/queue'));assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().route),'/album/demo-3');
   pass('late item data and background host-route completions cannot replace the currently owned detail page',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await own(page,'spotify:album:demo-1');await page.locator('.lt-detail-track').last().scrollIntoViewIfNeeded();const scroll=await page.locator('#lt-browse').evaluate(n=>n.scrollTop);const calls=await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='detailQuery').length);
   await page.locator('#lt-mini-open').tap();await page.locator('#lt-now-playing [data-action=closePlayer]').tap();assert.equal(await page.locator('#lt-browse').evaluate(n=>n.scrollTop),scroll);
   await page.locator('.lt-nav [data-action=home]').tap();await own(page,'spotify:album:demo-1');assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='detailQuery').length),calls);
   await page.locator('[data-detail-action=refresh]').tap();await page.waitForFunction(()=>document.querySelector('#lt-browse').getAttribute('aria-busy')==='false');assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='detailQuery').length),calls+1);
   pass('returning from the player preserves detail scroll and revisiting an item reuses its cached contents',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{cardTapDelay:700});await page.locator('[data-lt-card="spotify:playlist:demo-0"]').tap();await page.locator('.lt-nav [data-action=library]').tap();await page.locator('[data-lt-card="spotify:playlist:demo-0"]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'library');
   await page.waitForTimeout(550);await page.locator('[data-lt-card="spotify:playlist:demo-0"]').tap();await page.waitForSelector('.lt-detail-track');
   pass('the two-tap window is forgiving, but taps on matching cards in different tabs cannot combine into a double tap',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{artworkSize:60});const navSize=await page.locator('.lt-nav button').first().evaluate(n=>getComputedStyle(n).fontSize);await page.locator('#lt-mini-open').tap();
   const before=await page.evaluate(()=>({title:parseFloat(getComputedStyle(document.querySelector('#lt-np-title')).fontSize),button:document.querySelector('.lt-play-large').getBoundingClientRect().height,art:document.querySelector('#lt-art').getBoundingClientRect().width}));
   await settings(page);await range(page,'playerTextScale',175);await range(page,'playerControlScale',150);await closeSettings(page);
   const after=await page.evaluate(()=>({title:parseFloat(getComputedStyle(document.querySelector('#lt-np-title')).fontSize),button:document.querySelector('.lt-play-large').getBoundingClientRect().height,art:document.querySelector('#lt-art').getBoundingClientRect().width}));assert.ok(Math.abs(after.title/before.title-1.75)<.01);assert.ok(Math.abs(after.button/before.button-1.5)<.01);assert.ok(Math.abs(after.art-before.art)<1);assert.equal(await page.locator('.lt-nav button').first().evaluate(n=>getComputedStyle(n).fontSize),navSize);
   await page.reload();await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().preferences.playerTextScale),175);assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().preferences.playerControlScale),150);
   pass('Now Playing text and controls scale independently, leave artwork/navigation unchanged and persist across reloads',errors);await context.close();
  }
  for(const [width,height] of [[800,480],[480,800]]){
   const {page,context,errors}=await open(browser,{textScale:200,uiScale:140,playerTextScale:200,playerControlScale:180,artworkSize:180},width,height);await page.locator('#lt-mini-open').tap();
   assert.equal(await page.locator('#lt-np-header .lt-context').textContent(),'');assert.equal(await page.locator('#lt-np-header [data-action=closePlayer]').isVisible(),true);
   const result=await page.locator('#lt-now-playing').evaluate(root=>[root,root.querySelector('.lt-np-record'),root.querySelector('#lt-lyrics-lines')].map(n=>({bar:getComputedStyle(n).scrollbarWidth,display:getComputedStyle(n,'::-webkit-scrollbar').display,overflow:getComputedStyle(n).overflowY})));assert.ok(result.every(n=>n.bar==='none' && n.display==='none'));
   const play=page.locator('#lt-now-playing .lt-play-large');await play.scrollIntoViewIfNeeded();const rect=await play.boundingBox();assert.ok(rect.width>=44 && rect.height>=44 && rect.x>=0 && rect.x+rect.width<=width+1);await play.tap();assert.equal(await page.evaluate(()=>Spicetify.Player.isPlaying()),false);
   pass('maximum player text/controls keep reachable 44 px playback targets and hide every scrollbar without removing scrolling at '+width+'×'+height,errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{artworkSize:60});await page.locator('#lt-mini-open').tap();await page.waitForSelector('.lt-lyric-line');const old=await page.locator('.lt-lyric-line').first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize));await settings(page);await range(page,'playerLyricsScale',150);await closeSettings(page);assert.ok(Math.abs((await page.locator('.lt-lyric-line').first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize)))/old-1.5)<.01);
   await page.locator('[data-lyric-index="2"]').tap();assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='seek').at(-1)[1]),25000);assert.equal(await page.locator('#lt-lyrics-lines').evaluate(n=>getComputedStyle(n).scrollbarWidth),'none');
   pass('the independent lyrics text setting enlarges lyrics while hidden-scrollbar seeking retains exact timestamps',errors);await context.close();
  }
  console.log(passed+' release 1.8 suites passed using simulated Spotify services.');
 }finally{await browser.close();await new Promise(r=>server.close(r));}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
