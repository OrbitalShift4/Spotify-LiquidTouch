const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
let url,passed=0;
async function open(browser,width=1024,height=600,extra={}){
 const context=await browser.newContext({viewport:{width,height},hasTouch:true,reducedMotion:'reduce'});const page=await context.newPage();page.setDefaultTimeout(7000);const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(p=>localStorage.getItem('liquid-touch.preferences.v1') || localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,textScale:130,uiScale:120,...p})),extra);
 await page.goto(url);await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted' && document.querySelector('#lt-browse .lt-card'));
 return {page,context,errors};
}
function pass(label,errors){assert.deepEqual(errors,[]);passed++;console.log('PASS '+label);}
async function main(){
 const html=fs.readFileSync(path.resolve(__dirname,'../LiquidTouch-Preview.html'));const server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(html);});await new Promise(r=>server.listen(0,'127.0.0.1',r));url='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox']});
 try{
  {
   const {page,context,errors}=await open(browser);
   await page.locator('#lt-browse [data-open-uri="spotify:album:demo-1"]').tap();
   assert.equal(await page.locator('.Root__top-container').evaluate(n=>getComputedStyle(n).display),'block');
   await page.waitForSelector('.lt-detail-track');assert.equal(await page.locator('.lt-detail-track').first().isVisible(),true);
   const old=await page.addStyleTag({content:'body.lt-active .Root__top-container{display:none!important;visibility:hidden!important}'});
   assert.equal(await page.locator('.lt-detail-track').first().isVisible(),true);
   await old.evaluate(n=>n.remove());assert.equal(await page.locator('.lt-detail-track').first().isVisible(),true);
   await page.locator('.lt-nav [data-action=search]').tap();await page.locator('#lt-search-input').fill('Blue');await page.locator('#lt-search-input').press('Enter');
   assert.equal(await page.evaluate(()=>Spicetify.Platform.History.location.pathname),'/search/Blue');await page.waitForFunction(()=>document.querySelector('#lt-browse [data-lt-card]'));assert.equal(await page.locator('#lt-browse [data-lt-card="spotify:track:demo-1"]').first().isVisible(),true);
   pass('owned album content stays visible even with the native parent hidden, and submitted search stays visible',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.locator('.lt-nav [data-action=library]').tap();const artist=page.locator('#lt-browse [data-lt-card="spotify:artist:demo-4"]');await artist.tap();await page.waitForFunction(()=>!LiquidTouch.diagnostics().cardTapPending);
   assert.equal(await page.locator('#lt-mini-title').textContent(),'Night Drive');assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');await artist.tap();await artist.tap();
   assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().route),'/artist/demo-4');await page.waitForSelector('.lt-detail-track');assert.equal(await page.locator('.lt-detail-track').first().isVisible(),true);
   pass('artist cards play on one touch and open a visible page on two touches',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.locator('.lt-nav [data-action=search]').tap();await page.evaluate(()=>__ltMock.setSearchDelay(500));await page.locator('#lt-search-input').fill('Blue');
   assert.equal(await page.locator('#lt-search-preview').getAttribute('aria-busy'),'true');
   await page.waitForFunction(()=>document.querySelector('#lt-search-preview [data-lt-card]'));
   const calls=await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='apiGet' && r[1].includes('/v1/search?')).length);
   await page.locator('#lt-search-input').fill('Blue');await page.waitForTimeout(220);
   assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='apiGet' && r[1].includes('/v1/search?')).length),calls);
   await page.locator('#lt-search-preview [data-lt-card="spotify:track:demo-1"]').tap();
   await page.locator('#lt-search-input').press('Enter');await page.locator('.lt-nav [data-action=search]').tap();
   assert.equal(await page.locator('#lt-browse [data-lt-card="spotify:track:demo-1"]').count(),1,await page.evaluate(()=>JSON.stringify({stored:localStorage.getItem('liquid-touch.search-items.v1:demo'),plays:__ltMock.log.filter(r=>r[0]==='playUri'),page:document.body.dataset.ltPage,kind:document.body.dataset.ltCustomPage,cards:[...document.querySelectorAll('#lt-browse [data-lt-card]')].map(n=>n.dataset.ltCard)})));
   assert.equal(await page.locator('#lt-browse [data-search-query]').count(),0);
   pass('live search shows loading and result cards, caches repeat queries, and recent searches contain items rather than text chips',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.locator('#lt-shell .lt-header [data-action=settings]').tap();await page.locator('#lt-welcome').fill('Welcome aboard, Saif.');await page.locator('#lt-welcomeSubtitle').fill('My music, my orbit.');await page.locator('#lt-settings [data-action=closeSettings]').tap();
   assert.equal(await page.locator('.lt-home-hero h1').textContent(),'Welcome aboard, Saif.');await page.reload();await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');
   assert.equal(await page.locator('.lt-home-hero p').textContent(),'My music, my orbit.');
   pass('custom welcome heading and subtitle update immediately and persist across reloads',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   const nav=page.locator('.lt-nav [data-action=library]');
   await nav.dispatchEvent('pointerdown',{pointerType:'touch',isPrimary:true,pointerId:71,clientX:100,clientY:100,button:0});
   await nav.dispatchEvent('pointermove',{pointerType:'touch',isPrimary:true,pointerId:71,clientX:118,clientY:103});
   await nav.dispatchEvent('pointerup',{pointerType:'touch',isPrimary:true,pointerId:71,clientX:118,clientY:103});
   assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');
   await page.locator('.lt-nav [data-action=home]').tap();const card=page.locator('#lt-browse [data-lt-card="spotify:album:demo-1"]');const pressed=await card.elementHandle();
   await card.dispatchEvent('pointerdown',{pointerType:'touch',isPrimary:true,pointerId:72,clientX:300,clientY:300,button:0});
   await page.evaluate(()=>{const a=document.createElement('a');a.href='/album/new-record';a.textContent='New result';const img=document.createElement('img');img.src=LT_DEMO_COVERS[0];a.append(img);document.querySelector('#fixture-content').append(a);});
   await page.waitForTimeout(400);assert.equal(await pressed.evaluate(n=>n.isConnected),true);
   await card.dispatchEvent('pointerup',{pointerType:'touch',isPrimary:true,pointerId:72,clientX:301,clientY:301});await page.waitForFunction(()=>!LiquidTouch.diagnostics().cardTapPending);assert.equal(await page.locator('#lt-mini-title').textContent(),'Blue Hour');
   pass('small finger drift still activates navigation and background catalog changes preserve the pressed card',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.locator('.lt-nav [data-action=library]').tap();await page.locator('#lt-browse').evaluate(n=>n.scrollTop=350);
   await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>document.querySelector('#lt-now-playing').open);assert.equal(await page.evaluate(()=>Boolean(document.fullscreenElement)),false);
   const geometry=await page.locator('#lt-now-playing').evaluate(n=>{const r=n.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height,backdrop:getComputedStyle(n).backdropFilter};});assert.equal(geometry.x,0);assert.equal(geometry.y,0);assert.equal(geometry.w,1024);assert.equal(geometry.h,600);assert.equal(geometry.backdrop,'none');
   assert.equal(await page.locator('#lt-player-background').getAttribute('src'),await page.locator('#lt-art').getAttribute('src'));
   await page.locator('#lt-np-header').dispatchEvent('pointerdown',{pointerType:'touch',isPrimary:true,pointerId:1,clientX:500,clientY:20});await page.locator('#lt-np-header').dispatchEvent('pointerup',{pointerType:'touch',isPrimary:true,pointerId:1,clientX:500,clientY:130});
   await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open && !document.fullscreenElement);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');
   await page.locator('#lt-heading').dispatchEvent('pointerdown',{pointerType:'touch',isPrimary:true,pointerId:2,clientX:500,clientY:20});await page.locator('#lt-heading').dispatchEvent('pointerup',{pointerType:'touch',isPrimary:true,pointerId:2,clientX:500,clientY:120});
   assert.equal(await page.locator('#lt-quick-search').isVisible(),true);await page.locator('#lt-quick-input').fill('Astra');await page.waitForFunction(()=>document.querySelector('#lt-search-preview [data-lt-card]'));
   pass('player fills the display with its own artwork; swipe-down returns to the prior tab, and top-center pull opens working quick search',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.locator('.lt-nav [data-action=search]').tap();await page.locator('.lt-nav [data-action=library]').tap();await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'search');
   await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'home');
   await page.locator('#lt-browse [data-open-uri="spotify:album:demo-1"]').tap();await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'home');
   pass('Back restores the previous local tab and previous native detail route without skipping Library',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>document.querySelectorAll('.lt-lyric-line').length===5);
   assert.equal(await page.locator('#lt-lyrics-panel').isVisible(),true);assert.equal(await page.locator('#lt-art').isVisible(),true);
   const line=page.locator('[data-lyric-index="2"]');await line.tap();assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='seek').at(-1)[1]),25000);
   await page.waitForFunction(()=>document.querySelector('[data-lyric-index="2"]').getAttribute('aria-current')==='true');
   assert.equal(await page.locator('#lt-lyrics-panel').isVisible(),true);
   pass('Spotify timed lyrics show an active line and tapping it seeks to the exact millisecond timestamp',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,1024,600,{lyricsFallback:false});
   await page.evaluate(()=>{const get=Spicetify.CosmosAsync.get;Spicetify.CosmosAsync.get=async url=>url.includes('color-lyrics') ? {lyrics:{syncType:'UNSYNCED',lines:[{words:'An original unsynced demo line'}]}} : get(url);});
   await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>document.querySelectorAll('.lt-lyric-line').length===1);assert.equal(await page.locator('.lt-lyric-line').isDisabled(),true);
   pass('unsynced lyric lines are readable and cannot seek to invented timestamps',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{__ltMock.libraryItems[0].images=[];});await page.locator('.lt-nav [data-action=library]').tap();await page.locator('#lt-browse [data-action=refreshLibrary]').tap();
   await page.waitForFunction(()=>document.querySelector('#lt-browse .lt-card[data-uri="spotify:playlist:demo-0"] img'));
   assert.ok(await page.locator('#lt-browse .lt-card[data-uri="spotify:playlist:demo-0"] img').getAttribute('src'));
   assert.equal(await page.locator('.Root__globalNav').isVisible(),false);assert.equal(await page.locator('.Titlebar').isVisible(),false);
   assert.equal(await page.locator('#lt-shell').evaluate(n=>getComputedStyle(n,'::before').backgroundColor),'rgba(0, 0, 0, 0)');
   pass('missing visible playlist artwork is hydrated, stock chrome stays hidden, and the header has no separate opaque color plate',errors);await context.close();
  }

  {
   const {page,context,errors}=await open(browser);
   await page.locator('.lt-nav [data-action=search]').tap();
   await page.evaluate(()=>__ltMock.setSearchDelay(500));await page.locator('#lt-search-input').fill('Blue');await page.waitForTimeout(190);
   await page.evaluate(()=>__ltMock.setSearchDelay(0));await page.locator('#lt-search-input').fill('Astra');
   await page.waitForFunction(()=>document.querySelector('#lt-search-preview [data-lt-card="spotify:artist:demo-2"]'));
   await page.waitForTimeout(550);
   assert.equal(await page.locator('#lt-search-preview [data-lt-card="spotify:track:demo-1"]').count(),0);
   pass('slower obsolete search responses cannot replace a newer live query',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{const push=Spicetify.Platform.History.push.bind(Spicetify.Platform.History);Spicetify.Platform.History.push=path=>{push(path);if(path==='/queue')setTimeout(()=>push('/queue/canonical'),40);};});
   await page.locator('#lt-mini-open').tap();await page.locator('#lt-now-playing [data-action=queue]').tap();await page.waitForFunction(()=>Spicetify.Platform.History.location.pathname==='/queue/canonical');
   await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'home');
   pass('automatic Spotify route redirects do not create a phantom extra Back step',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.emulateMedia({reducedMotion:'no-preference'});await page.locator('#lt-mini-open').tap();
   assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().playerPhase),'opening');
   await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);
   await page.emulateMedia({reducedMotion:'reduce'});await page.locator('#lt-mini-open').tap();
   assert.equal(await page.locator('#lt-now-playing .lt-np-layout').evaluate(n=>n.getAnimations().length),0);
   await page.evaluate(()=>LiquidTouch.destroy());assert.equal(await page.evaluate(()=>Boolean(document.fullscreenElement)),false);
   pass('player transitions animate when enabled and honor the operating system reduced-motion preference',errors);await context.close();
  }
  console.log(passed+' release suites passed using simulated Spotify services.');
 }finally{await browser.close();await new Promise(r=>server.close(r));}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
