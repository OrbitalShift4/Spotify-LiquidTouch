const {revealSetting}=require('./settings-navigation.cjs');
/* 1.5: trusted interactive gestures, safe motion and recording-specific lyric correction. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
let origin,passed=0;
async function open(browser,opts={}){
 const context=await browser.newContext({viewport:{width:1024,height:600},hasTouch:true,reducedMotion:opts.reduce ? 'reduce' : 'no-preference'}),page=await context.newPage(),errors=[];
 page.setDefaultTimeout(6000);page.on('pageerror',error=>errors.push(error.message));
 await page.addInitScript(()=>{if(!localStorage.getItem('liquid-touch.preferences.v1'))localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,playerFullscreen:false}));});
 await page.goto(origin);await page.waitForFunction(()=>window.LiquidTouch?.diagnostics().phase==='mounted');return {page,context,errors};
}
function pass(name,errors){assert.deepEqual(errors,[]);console.log('PASS '+name);passed++;}
async function touch(page,x,y){
 const session=await page.context().newCDPSession(page);let last={x,y};
 await session.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y,id:1}]});
 return {async move(x,y){const before=last;for(let i=1;i<=4;i++)await session.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:before.x+(x-before.x)*i/4,y:before.y+(y-before.y)*i/4,id:1}]});last={x,y};await page.waitForTimeout(32);},async end(){await session.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await session.detach();},async cancel(){await session.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});await session.detach();}};
}
async function player(page){await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open' && document.querySelectorAll('#lt-lyrics-lines .lt-lyric-line').length===5);}
async function timing(page){await page.locator('[data-action=lyricsMenu]').tap();await page.locator('#lt-now-playing [data-action=lyricTiming]').tap();}
async function active(page){return page.locator('#lt-lyrics-lines [aria-current=true]').getAttribute('data-lyric-index');}
async function animations(page,selector){return page.locator(selector).evaluate(n=>n.getAnimations().length);}
async function main(){
 const server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(fs.readFileSync(path.resolve(__dirname,'../LiquidTouch-Preview.html')));});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin='http://127.0.0.1:'+server.address().port;
 let browser;
 try{
  browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox']});
  {
   const {page,context,errors}=await open(browser);await page.waitForTimeout(180);
   let drag=await touch(page,620,250);await drag.move(575,251);
   assert.notEqual(await page.locator('#lt-browse').evaluate(n=>n.style.transform),'');assert.equal(await page.locator('#lt-gesture-cue').count(),0);
   await drag.end();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'home');await page.waitForTimeout(180);assert.equal(await page.locator('#lt-browse').evaluate(n=>n.style.transform),'');
   drag=await touch(page,620,250);await drag.move(470,253);assert.equal(await page.locator('#lt-gesture-cue').count(),0);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'home');await drag.end();
   assert.equal(await page.locator('body').getAttribute('data-lt-page'),'search');assert.ok(await animations(page,'#lt-browse')>0);
   pass('page drag follows the finger, springs back below threshold, and commits only on release beyond it',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   const drag=await touch(page,620,250);await drag.move(470,250);assert.equal(await page.locator('#lt-gesture-cue').count(),0);
   await drag.move(610,250);assert.equal(await page.locator('#lt-gesture-cue').count(),0);await drag.end();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'home');
   const cancelled=await touch(page,620,250);await cancelled.move(550,250);await cancelled.cancel();await page.waitForTimeout(180);assert.equal(await page.locator('#lt-gesture-cue').count(),0);assert.equal(await page.locator('#lt-browse').evaluate(n=>n.style.transform),'');
   pass('reversing an armed swipe or cancelling a pointer clears progress without navigation or stale transforms',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.locator('.lt-nav [data-action=library]').tap();await player(page);await page.waitForTimeout(180);
   let drag=await touch(page,240,150);await drag.move(242,197);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);assert.notEqual(await page.locator('.lt-np-layout').evaluate(n=>n.style.transform),'');assert.equal(await page.locator('#lt-now-playing').evaluate(n=>getComputedStyle(n).transform),'none');await drag.end();
   await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);
   drag=await touch(page,240,150);await drag.move(244,270);await drag.end();await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),false);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');
   await player(page);await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await player(page);assert.equal(await page.locator('#lt-now-playing').isVisible(),true);
   pass('player dismissal is interactive while its root stays opaque/stationary; short drags cancel and rapid reopening remains safe',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await player(page);await page.waitForTimeout(180);await page.evaluate(()=>{if(Spicetify.Player.isPlaying())Spicetify.Player.togglePlay();});
   const before=await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='next').length);const drag=await touch(page,245,180);await drag.move(140,180);
   assert.equal(await page.locator('#lt-np-title').textContent(),'Afterhours');assert.notEqual(await page.locator('#lt-art').evaluate(n=>n.style.transform),'');await drag.end();assert.equal(await page.locator('#lt-np-title').textContent(),'Blue Hour');
   assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='next').length),before+1);await page.waitForTimeout(180);assert.equal(await page.locator('#lt-art').evaluate(n=>n.style.transform),'');
   pass('artwork skip preview waits for release and sends exactly one track action, then animates the new artwork',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.waitForTimeout(180);
   const drag=await touch(page,700,105);await drag.move(706,155);assert.equal(await page.locator('#lt-quick-search').isVisible(),false);assert.notEqual(await page.locator('.lt-header').evaluate(n=>n.style.transform),'');await drag.move(706,210);await drag.end();assert.equal(await page.locator('#lt-quick-search').isVisible(),true);
   await page.locator('#lt-quick-search [data-action=closeQuickSearch]').tap();await player(page);await page.locator('#lt-now-playing [data-action=playerSettings]').tap();await page.waitForTimeout(170);
   const box=await page.locator('#lt-settings .lt-sheet-header').boundingBox(),sheet=await touch(page,box.x+150,box.y+25);await sheet.move(box.x+150,box.y+135);assert.notEqual(await page.locator('#lt-settings .lt-settings-content').evaluate(n=>n.style.transform),'');await sheet.end();await page.waitForFunction(()=>!document.querySelector('#lt-settings').open);assert.equal(await page.locator('#lt-settings').evaluate(n=>n.open),false);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);
   pass('quick-search pulls and nested settings dismissal have threshold-based interactive movement',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.waitForTimeout(170);await page.locator('.lt-nav [data-action=library]').tap();assert.ok(await animations(page,'#lt-browse')>0);
   await page.locator('#lt-browse [data-open-uri="spotify:artist:demo-4"]').tap();assert.ok(await animations(page,'#lt-browse')>0);
   await page.locator('#lt-shell [data-action=goBack]').tap();assert.ok(await animations(page,'#lt-browse')>0);
   await page.locator('#lt-shell .lt-header [data-action=settings]').tap();await revealSetting(page,'playHistory');await page.locator('#lt-settings [data-action=playHistory]').tap();assert.ok(await animations(page,'#lt-history-list')>0);
   await page.locator('#lt-history [data-action=closeHistory]').tap();assert.ok(await animations(page,'#lt-browse')>0);
   pass('tab taps, owned detail opening, Back and history opening/closing all animate content without moving modal roots',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await player(page);await page.waitForTimeout(180);
   await page.locator('#lt-now-playing [data-action=toggleLyrics]').tap();assert.equal(await page.locator('#lt-lyrics-panel').isVisible(),false);assert.equal(await page.locator('.lt-lyrics-exit-ghost').count(),1);assert.equal(await page.locator('.lt-lyrics-exit-ghost [id]').count(),0);assert.equal(await page.locator('.lt-lyrics-exit-ghost').evaluate(n=>n.inert),true);
   assert.ok(await animations(page,'.lt-art-frame')>0);await page.locator('#lt-now-playing [data-action=toggleLyrics]').tap();assert.equal(await page.locator('#lt-lyrics-panel').isVisible(),true);assert.ok(await animations(page,'#lt-lyrics-panel')>0);
   for(let i=0;i<4;i++)await page.locator('#lt-now-playing [data-action=toggleLyrics]').tap();await page.waitForTimeout(220);
   assert.equal(await page.locator('.lt-lyrics-exit-ghost').count(),0);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>getComputedStyle(n).opacity),'1');
   const ids=await page.evaluate(()=>[...document.querySelectorAll('[id]')].map(n=>n.id));assert.equal(ids.length,new Set(ids).size);
   pass('lyrics on/off animates art/control reflow and an inert, ID-free exiting lyric pane; rapid toggles clean up safely',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await player(page);await page.evaluate(()=>{if(Spicetify.Player.isPlaying())Spicetify.Player.togglePlay();__ltMock.setPosition(24750);});await page.waitForTimeout(120);assert.equal(await active(page),'1');await timing(page);
   await page.locator('[data-action=lyricsEarlier]').tap();assert.equal(await page.locator('#lt-timing-value').textContent(),'0.25 s earlier');assert.equal(await active(page),'2');
   await page.locator('[data-action=lyricsMenu]').tap();await page.locator('[data-action=lyricTiming]').tap();await page.locator('#lt-lyrics-lines [data-lyric-index="2"]').tap();assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='seek').at(-1)[1]),24750);
   await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await page.reload();await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');await player(page);await timing(page);assert.equal(await page.locator('#lt-timing-value').textContent(),'0.25 s earlier');
   await page.evaluate(()=>__ltMock.choose(1));await page.waitForFunction(()=>document.querySelector('#lt-timing-value').textContent==='Original timing');await page.evaluate(()=>__ltMock.choose(0));await page.waitForFunction(()=>document.querySelector('#lt-timing-value').textContent==='0.25 s earlier');
   pass('250 ms earlier timing advances the exact lyric boundary, corrects tap-to-seek, persists, and stays separate for other recordings',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await player(page);await page.evaluate(()=>{if(Spicetify.Player.isPlaying())Spicetify.Player.togglePlay();__ltMock.setPosition(5000);});await timing(page);
   const seeks=await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='seek').length);await page.locator('[data-action=lyricsMatchLine]').tap();await page.locator('#lt-lyrics-lines [data-lyric-index="1"]').tap();assert.equal(await page.locator('#lt-timing-value').textContent(),'5.00 s earlier');assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='seek').length),seeks);assert.equal(await active(page),'1');
   await timing(page);await page.locator('[data-action=lyricsTimingReset]').tap();assert.equal(await page.locator('#lt-timing-value').textContent(),'Original timing');
   await page.locator('[data-action=lyricsMatchLine]').tap();await page.locator('#lt-lyrics-lines [data-lyric-index="4"]').tap();assert.equal(await page.locator('#lt-timing-value').textContent(),'15.00 s earlier');assert.ok((await page.locator('#lt-toast').textContent()).includes('15 seconds'));
   pass('Match a line calibrates by ear without seeking, Reset restores source timing, and corrections remain bounded',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await player(page);await timing(page);await page.locator('[data-action=lyricsEarlier]').tap();
   await page.route('https://lrclib.net/api/get?*',route=>route.fulfill({contentType:'application/json',body:JSON.stringify({duration:238,syncedLyrics:'[00:01.00]An original backup line\n[00:05.00]Another backup line'})}));
   await page.evaluate(()=>{window.savedLyricGet=Spicetify.CosmosAsync.get;Spicetify.CosmosAsync.get=async url=>{if(url.includes('color-lyrics'))throw new Error('Unavailable');return savedLyricGet(url);};});
   await page.locator('[data-action=lyricsMenu]').tap();await page.locator('#lt-now-playing [data-action=retryLyrics]').tap();await page.waitForFunction(()=>document.querySelector('#lt-lyrics-status').textContent==='LRCLIB' && document.querySelectorAll('#lt-lyrics-lines .lt-lyric-line').length===2);
   assert.equal(await page.locator('#lt-timing-value').textContent(),'Original timing');await page.locator('[data-action=lyricsLater]').tap();assert.equal(await page.locator('#lt-timing-value').textContent(),'0.25 s later');
   await page.evaluate(()=>Spicetify.CosmosAsync.get=window.savedLyricGet);await page.locator('[data-action=lyricsMenu]').tap();await page.locator('#lt-now-playing [data-action=retryLyrics]').tap();await page.waitForFunction(()=>document.querySelectorAll('#lt-lyrics-lines .lt-lyric-line').length===5);assert.equal(await page.locator('#lt-timing-value').textContent(),'0.25 s earlier');
   pass('timing corrections for Spotify and LRCLIB stay independent for the same recording',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await player(page);await page.evaluate(()=>{if(Spicetify.Player.isPlaying())Spicetify.Player.togglePlay();__ltMock.setPosition(9999);});await page.waitForFunction(()=>document.querySelector('#lt-lyrics-lines [data-lyric-index="0"]').getAttribute('aria-current')==='true');
   await page.evaluate(()=>__ltMock.setPosition(10000));await page.waitForFunction(()=>document.querySelector('#lt-lyrics-lines [data-lyric-index="1"]').getAttribute('aria-current')==='true');
   await page.evaluate(()=>__ltMock.setPosition(2000));await page.waitForFunction(()=>document.querySelector('#lt-lyrics-lines [data-lyric-index="0"]').getAttribute('aria-current')==='true');
   await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(30);assert.equal(await animations(page,'.lt-np-layout'),0);assert.equal(await animations(page,'#lt-lyrics-panel'),0);await page.locator('#lt-now-playing [data-action=toggleLyrics]').tap();assert.equal(await page.locator('.lt-lyrics-exit-ghost').count(),0);
   pass('lyric boundaries follow pause/seek immediately and reduced motion cancels active transitions and lyric ghosts',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);const drag=await touch(page,620,250);await drag.move(550,250);await page.evaluate(()=>LiquidTouch.destroy());await drag.cancel();await page.waitForTimeout(200);
   assert.equal(await page.locator('#lt-gesture-cue').count(),0);assert.equal(await page.locator('[style*="translate3d"]').count(),0);assert.equal(await page.locator('.lt-lyrics-exit-ghost').count(),0);
   await page.reload();await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');assert.equal(await page.locator('#lt-shell').count(),1);
   pass('teardown during a drag removes cues, inline transforms, animations and snapshots; reload mounts a single clean instance',errors);await context.close();
  }
  console.log(passed+' release 1.5 suites passed. Spotify data and Windows IPC remain simulated.');
 }finally{await browser?.close();await new Promise(resolve=>server.close(resolve));}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
