LiquidTouch 1.9.2 — 1 November 2026

LYRICS OPTIONS
Open the three-dot menu at the top right of the lyrics panel to choose Timing… or Reload lyrics. Timing retains Earlier, Later, Reset, and Match a line. The menu supports touch, keyboard navigation, Escape and outside-tap dismissal.

CLEANER LYRIC VIEW
Removed the Live Lyrics heading and the tap-to-seek instruction. Tapping a synced lyric still seeks to that line. Loading, source and availability status remain visible.

UPDATE FEED
New installations and empty feed settings use the official repository update feed. Existing custom addresses and disabled update checks are preserved.
