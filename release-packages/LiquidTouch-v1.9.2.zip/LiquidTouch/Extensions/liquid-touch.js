// Stable LiquidTouch runtime loader. Generated releases embed their fallback below.
(() => {
  'use strict';
  const BUNDLED={"schema":1,"app":"LiquidTouch","minimumLoader":"1.9.0","version":"1.9.2","summary":["Lyrics timing and reload actions now share a compact three-dot menu.","Removed the Live Lyrics heading and tap-to-seek hint; lyric seeking remains available.","Official update-feed address is prefilled; custom addresses remain saved."],"notes":"LiquidTouch 1.9.2 — 1 November 2026\n\nLYRICS OPTIONS\nOpen the three-dot menu at the top right of the lyrics panel to choose Timing… or Reload lyrics. Timing retains Earlier, Later, Reset, and Match a line. The menu supports touch, keyboard navigation, Escape and outside-tap dismissal.\n\nCLEANER LYRIC VIEW\nRemoved the Live Lyrics heading and the tap-to-seek instruction. Tapping a synced lyric still seeks to that line. Loading, source and availability status remain visible.\n\nUPDATE FEED\nNew installations and empty feed settings use the official repository update feed. Existing custom addresses and disabled update checks are preserved.\n","javascript":"","css":"/* LiquidTouch 1.9.0 — original CSS. No remote fonts or scripts. */\n:root {\n  --lt-bg: #0c101c;\n  --lt-ink: #f6f8fc;\n  --lt-muted: #d0d9e7;\n  --lt-accent: #b4eedc;\n  --lt-accent-ink: #0b2822;\n  --lt-glass: rgba(28, 39, 58, .76);\n  --lt-border: rgba(228, 242, 255, .19);\n  --lt-shadow: 0 12px 38px #03071355, inset 0 1px 0 #ffffff1f;\n  --lt-touch: 48px;\n  --lt-row: 64px;\n  --lt-header: 64px;\n  --lt-mini: 72px;\n  --lt-nav: 64px;\n  --lt-footer: calc(var(--lt-mini) + var(--lt-nav) + 28px + env(safe-area-inset-bottom, 0px));\n  --lt-keyboard-height: 260px;\n  --lt-art-color: #354464;\n  --lt-art-rgb: 53, 68, 100;\n  --lt-glass-rgb: 25, 34, 49;\n  --lt-glass-opacity: .35;\n  --lt-text-scale: 1.2;\n  --lt-ui-scale: 1;\n  --lt-keyboard-scale: 1.45;\n  --lt-artwork-scale: 1.35;\n  --lt-chrome-height: 0px;\n}\n\n/* Theme alone is deliberately usable; desktop chrome is hidden ONLY when\n   the extension has mounted and found Spotify's main view. */\nbody {\n  background: var(--spice-main, var(--lt-bg));\n}\n.Root__main-view, .Root__nav-bar {\n  border-radius: 20px;\n}\n\nbody.lt-active {\n  --background-base: var(--lt-bg);\n  --background-highlight: #222c3e;\n  --background-elevated-base: #202b40;\n  --text-base: var(--lt-ink);\n  --text-subdued: var(--lt-muted);\n  min-width: 0 !important;\n  overflow: hidden;\n  color: var(--lt-ink);\n  background: var(--lt-bg);\n  font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif;\n  -webkit-tap-highlight-color: transparent;\n}\nbody[data-lt-size=\"large\"] {\n  --lt-touch: 56px;\n  --lt-row: 72px;\n  --lt-header: 72px;\n  --lt-mini: 80px;\n  --lt-nav: 72px;\n}\nbody[data-lt-palette=\"ocean\"] {\n  --lt-bg: #091520;\n  --lt-accent: #a8dfff;\n  --lt-accent-ink: #102536;\n  --lt-glass: rgba(22, 47, 65, .82);\n}\nbody[data-lt-palette=\"graphite\"] {\n  --lt-bg: #101114;\n  --lt-accent: #e4e7ef;\n  --lt-accent-ink: #1a1e25;\n  --lt-glass: rgba(39, 42, 49, .86);\n}\n\n/* Native Spotify browsing area. Nodes stay in Spotify's React tree. */\nbody.lt-active .Root {\n  position: fixed !important;\n  inset: 0 !important;\n  display: block !important;\n  width: 100% !important;\n  height: 100% !important;\n  min-width: 0 !important;\n  min-height: 0 !important;\n  overflow: hidden;\n  isolation: isolate;\n  background: radial-gradient(ellipse at 10% -15%, rgba(var(--lt-art-rgb), .24), transparent 65%),\n    radial-gradient(ellipse at 95% 90%, rgba(var(--lt-art-rgb), .13), transparent 65%), var(--lt-bg) !important;\n}\nbody.lt-active :is(.Root__globalNav, .Root__top-bar, .Root__right-sidebar,\n  .Root__now-playing-bar, .main-topBar-container, .main-buddyFeed-buddyFeedRoot,\n  .main-resizeBar-resizeBar, .main-yourLibraryX-resizeBar) {\n  display: none !important;\n}\nbody.lt-active :is(.Root__main-view, [data-lt-native=\"main\"]) {\n  position: fixed !important;\n  inset: calc(var(--lt-chrome-height) + var(--lt-header) + 6px) 12px var(--lt-footer-measured, calc(var(--lt-footer) + 4px)) !important;\n  display: flex !important;\n  flex-direction: column;\n  width: auto !important;\n  height: auto !important;\n  min-width: 0 !important;\n  min-height: 0 !important;\n  max-width: none !important;\n  margin: 0 !important;\n  border: 1px solid #ffffff09;\n  border-radius: 24px;\n  background: #ffffff03 !important;\n  overflow: hidden;\n  z-index: 1;\n}\nbody.lt-active :is(.main-view-container, .main-view-container__scroll-node,\n  .main-view-container__scroll-node-child) {\n  width: 100% !important;\n  min-width: 0 !important;\n  min-height: 0 !important;\n}\nbody.lt-active :is(.main-view-container, .main-view-container__scroll-node) {\n  height: 100% !important;\n}\nbody.lt-active .main-view-container__scroll-node {\n  overflow-y: auto !important;\n  overscroll-behavior: contain;\n  touch-action: pan-y;\n  -webkit-overflow-scrolling: touch;\n}\nbody.lt-active .Root__nav-bar { display: none !important; }\nbody.lt-active[data-lt-page=\"library\"] :is(.Root__main-view, [data-lt-native=\"main\"]) {\n  visibility: hidden;\n  pointer-events: none;\n}\nbody.lt-active[data-lt-page=\"library\"] [data-lt-native=\"library\"] {\n  display: flex !important;\n  flex-direction: column;\n  position: fixed !important;\n  inset: calc(var(--lt-chrome-height) + var(--lt-header) + 6px) 12px var(--lt-footer-measured, calc(var(--lt-footer) + 4px)) !important;\n  width: auto !important;\n  height: auto !important;\n  min-width: 0 !important;\n  max-width: none !important;\n  border-radius: 24px;\n  background: #ffffff04 !important;\n  border: 1px solid #ffffff0c;\n  z-index: 2;\n  overflow: hidden;\n}\nbody.lt-active[data-lt-page=\"library\"] :is(.main-yourLibraryX-libraryContainer,\n  .main-yourLibraryX-libraryRootlist, .main-yourLibraryX-library) {\n  width: 100% !important;\n  min-width: 0 !important;\n  max-width: none !important;\n  flex: 1;\n}\nbody.lt-active[data-lt-page=\"library\"] .main-yourLibraryX-libraryRootlist {\n  overflow-y: auto !important;\n  overscroll-behavior: contain;\n  touch-action: pan-y;\n}\nbody.lt-active[data-lt-page=\"library\"] :is([role=\"row\"], .main-yourLibraryX-listItem) {\n  min-height: var(--lt-row);\n}\nbody.lt-active :is(.main-view-container, [data-lt-native=\"library\"]) :is(button, [role=\"button\"]) {\n  min-height: var(--lt-touch);\n  min-width: var(--lt-touch);\n  touch-action: manipulation;\n}\nbody.lt-active :is(.main-view-container, [data-lt-native=\"library\"]) input {\n  min-height: var(--lt-touch);\n  font-size: 16px;\n}\nbody.lt-active .main-trackList-trackListRow {\n  min-height: var(--lt-row) !important;\n  border-radius: 14px;\n  touch-action: pan-y;\n}\nbody.lt-active .main-trackList-trackListRow :is(.main-trackList-rowSectionEnd button,\n  .main-trackList-rowSectionStart button) {\n  opacity: 1 !important;\n  visibility: visible !important;\n}\nbody.lt-active :is(.main-card-PlayButtonContainer, .main-card-playButtonContainer) {\n  opacity: 1 !important;\n  transform: none !important;\n}\nbody.lt-active .main-card-card {\n  border-radius: 20px;\n  background: #ffffff06;\n}\nbody.lt-active :is(.main-cardImage-image, .main-cardImage-imageWrapper) {\n  border-radius: 16px;\n}\nbody.lt-active .main-view-container main { min-width: 0 !important; }\nbody.lt-active .main-view-container :is(h1, h2) { letter-spacing: -.035em; }\nbody.lt-active ::-webkit-scrollbar { width: 7px; height: 7px; }\nbody.lt-active ::-webkit-scrollbar-thumb { background: #b5c8dd40; border-radius: 20px; }\nbody.lt-active[data-lt-keyboard=\"true\"] :is([data-lt-native=\"main\"], [data-lt-native=\"library\"]) {\n  bottom: calc(var(--lt-keyboard-height) + 6px) !important;\n}\n\n/* All extension selectors are namespaced. */\n#lt-shell, .lt-dialog, #lt-rescue, #lt-toast {\n  box-sizing: border-box;\n  color: var(--lt-ink);\n  font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif;\n  font-size: 16px;\n  line-height: 1.35;\n  -webkit-app-region: no-drag;\n}\n:is(#lt-shell, .lt-dialog, #lt-rescue, #lt-toast) *,\n:is(#lt-shell, .lt-dialog) *::before,\n:is(#lt-shell, .lt-dialog) *::after { box-sizing: border-box; }\n:is(#lt-shell, .lt-dialog) [hidden], #lt-rescue[hidden], #lt-toast[hidden] { display: none !important; }\n#lt-shell { position: fixed; inset: 0; pointer-events: none; z-index: 120; }\nbody:not(.lt-active) #lt-shell { display: none; }\n:where(#lt-shell, .lt-dialog) button, #lt-rescue {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  flex-shrink: 0;\n  min-width: var(--lt-touch);\n  min-height: var(--lt-touch);\n  margin: 0;\n  padding: 10px;\n  border: 0;\n  border-radius: 50%;\n  background: transparent;\n  color: inherit;\n  font: inherit;\n  text-decoration: none;\n  cursor: pointer;\n  user-select: none;\n  touch-action: manipulation;\n  -webkit-tap-highlight-color: transparent;\n  transition: background .16s, transform .16s, opacity .16s;\n}\n:where(#lt-shell, .lt-dialog) button:active { transform: scale(.94); background: #ffffff18; }\n:where(#lt-shell, .lt-dialog) button:disabled { opacity: .35; cursor: default; }\n:is(#lt-shell, .lt-dialog) :is(button, input, select):focus-visible,\n#lt-rescue:focus-visible {\n  outline: 3px solid var(--lt-accent);\n  outline-offset: 3px;\n}\n:where(#lt-shell, .lt-dialog) svg, #lt-rescue svg {\n  display: block;\n  width: 24px;\n  height: 24px;\n  flex-shrink: 0;\n  pointer-events: none;\n}\n.lt-glass {\n  background: linear-gradient(125deg, #ffffff12, #ffffff02 45%, #ffffff08), rgba(var(--lt-glass-rgb), var(--lt-glass-opacity));\n  border: 1px solid #e5f3ff45;\n  box-shadow: 0 8px 28px #03071333, inset 0 1px 0 #ffffff42, inset 0 -1px 0 #ffffff09;\n  backdrop-filter: blur(14px) saturate(175%);\n  -webkit-backdrop-filter: blur(14px) saturate(175%);\n}\n.lt-header {\n  position: absolute;\n  inset: calc(var(--lt-chrome-height) + 6px) 12px auto;\n  height: calc(var(--lt-header) - 6px);\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  pointer-events: auto;\n}\n.lt-header > button { background: #ffffff08 !important; }\n.lt-heading {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  flex: 1;\n  min-width: 0;\n}\n.lt-heading-mark {\n  width: 34px;\n  height: 34px;\n  display: grid;\n  place-items: center;\n  border-radius: 50%;\n  color: var(--lt-accent);\n  background: linear-gradient(135deg, #c9fff51e, #c1a8ff15);\n  border: 1px solid #d3fff32e;\n}\n.lt-heading-text { font-size: 20px; font-weight: 650; letter-spacing: -.045em; }\n.lt-search-form {\n  display: flex;\n  flex: 1;\n  min-width: 0;\n  align-items: center;\n  padding-left: 16px;\n  border-radius: 30px;\n}\n.lt-search-form input {\n  display: block;\n  flex: 1;\n  min-width: 0;\n  width: 100%;\n  height: var(--lt-touch);\n  padding: 0 4px;\n  border: 0;\n  border-radius: 0;\n  background: transparent;\n  color: var(--lt-ink);\n  font: inherit;\n  font-size: 16px;\n}\n.lt-search-form input::placeholder { color: var(--lt-muted); }\n.lt-footer {\n  position: absolute;\n  left: 12px;\n  right: 12px;\n  bottom: calc(10px + env(safe-area-inset-bottom, 0px));\n  display: grid;\n  gap: 8px;\n  pointer-events: auto;\n}\nbody[data-lt-keyboard=\"true\"] .lt-footer { visibility: hidden; }\n.lt-mini {\n  height: var(--lt-mini);\n  position: relative;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  padding: 4px 8px;\n  border-radius: 22px;\n  overflow: hidden;\n}\n#lt-mini-open {\n  display: flex;\n  flex: 1;\n  min-width: 0;\n  height: 100%;\n  gap: 12px;\n  justify-content: flex-start;\n  padding: 4px;\n  border-radius: 16px;\n  text-align: left;\n  touch-action: pan-y;\n}\n.lt-cover-small {\n  display: block;\n  width: 48px;\n  height: 48px;\n  flex-shrink: 0;\n  border-radius: 12px;\n  object-fit: cover;\n  background: linear-gradient(145deg, #4b617c, #1b2446);\n}\n.lt-track-text { display: block; min-width: 0; }\n.lt-track-title, .lt-track-artist {\n  display: block;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.lt-track-title { font-size: 16px; font-weight: 650; }\n.lt-track-artist { color: var(--lt-muted); font-size: 13px; margin-top: 2px; }\n.lt-mini button[data-action=\"togglePlay\"] { background: #ffffff12 !important; }\n.lt-mini-progress { position: absolute; bottom: 0; left: 0; width: 100%; height: 2px; background: #ffffff0a; }\n.lt-mini-progress span { display: block; height: 100%; width: 0; background: var(--lt-accent); }\n.lt-nav {\n  height: var(--lt-nav);\n  display: grid;\n  grid-template-columns: repeat(3, minmax(0, 1fr));\n  align-items: center;\n  gap: 4px;\n  padding: 4px;\n  border-radius: 999px;\n}\n.lt-nav button {\n  height: 100%;\n  min-height: var(--lt-touch);\n  flex-direction: column;\n  gap: 2px;\n  padding: 4px 8px;\n  border-radius: 999px !important;\n  color: var(--lt-muted) !important;\n  font-size: 11px !important;\n  font-weight: 600 !important;\n}\n.lt-nav button[aria-current=\"page\"] {\n  color: var(--lt-ink) !important;\n  background: linear-gradient(125deg, #ffffff1f, #ffffff0b) !important;\n  box-shadow: inset 0 1px 0 #ffffff29, 0 3px 12px #02091633;\n}\n.lt-nav button[aria-current=\"page\"] svg { color: var(--lt-accent); }\n\n/* Expanded player is a real modal: native content becomes inert while open. */\n.lt-dialog {\n  padding: 0;\n  border: 1px solid var(--lt-border);\n  border-radius: 28px;\n  background: #151d2e;\n  max-width: calc(100vw - 24px);\n  max-height: calc(100dvh - 24px);\n  color-scheme: dark;\n  box-shadow: 0 32px 100px #0009;\n  overflow: auto;\n  overscroll-behavior: contain;\n}\n.lt-dialog::backdrop { background: #030711b8; backdrop-filter: blur(12px); }\n.lt-dialog button[aria-pressed=\"true\"] { color: var(--lt-accent); background: #ffffff0b; }\n#lt-now-playing {\n  inset: 0;\n  margin: 0;\n  width: 100vw;\n  height: 100dvh;\n  max-width: 100vw;\n  max-height: 100dvh;\n  border: 0;\n  border-radius: 0;\n  background: radial-gradient(ellipse at 12% 0%, var(--lt-art-color), transparent 70%),\n    radial-gradient(ellipse at 100% 100%, #36636a55, transparent 65%), var(--lt-bg);\n}\n#lt-now-playing[open] { display: flex; flex-direction: column; }\n.lt-np-header {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  flex: 0 0 calc(var(--lt-touch) + 16px);\n  padding: 8px 20px;\n  touch-action: none;\n}\n.lt-context { flex: 1; min-width: 0; text-align: center; }\n.lt-eyebrow { display: block; font-size: 10px; font-weight: 650; letter-spacing: .19em; color: #e2eaf4bd; }\n.lt-context-title { display: block; font-size: 13px; font-weight: 600; margin-top: 3px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.lt-np-layout {\n  flex: 1;\n  min-height: 0;\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) minmax(0, 1.05fr);\n  align-items: center;\n  gap: clamp(24px, 5vw, 76px);\n  padding: 12px clamp(24px, 6vw, 96px) 28px;\n}\n.lt-art-area { display: flex; align-items: center; justify-content: center; min-width: 0; touch-action: pan-y; }\n.lt-art-frame {\n  width: min(100%, 440px, calc(100dvh - 148px));\n  aspect-ratio: 1;\n  position: relative;\n  border-radius: 26px;\n  box-shadow: 0 24px 58px #0005, 0 0 0 1px #ffffff1c;\n  background: linear-gradient(140deg, #566e87, #242e52);\n  overflow: hidden;\n}\n.lt-art-frame::after {\n  content: \"\";\n  position: absolute;\n  inset: 0;\n  border-radius: inherit;\n  box-shadow: inset 0 1px 0 #ffffff40;\n  pointer-events: none;\n}\n#lt-art { width: 100%; height: 100%; display: block; object-fit: cover; }\n.lt-np-controls { width: 100%; min-width: 0; max-width: 540px; margin: auto; }\n.lt-np-track { display: flex; gap: 12px; align-items: center; margin-bottom: 12px; }\n.lt-np-track > div { flex: 1; min-width: 0; }\n#lt-np-title { margin: 0; font-size: clamp(24px, 3.4vw, 40px); font-weight: 700; line-height: 1.12; letter-spacing: -.045em; overflow-wrap: anywhere; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }\n#lt-np-artist { color: #d5deec; font-size: 16px; margin: 7px 0 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }\n.lt-range {\n  display: block;\n  width: 100%;\n  min-width: 0;\n  min-height: var(--lt-touch);\n  margin: 0;\n  padding: 0;\n  border: 0;\n  background: transparent;\n  color: var(--lt-accent);\n  cursor: pointer;\n  touch-action: none;\n  accent-color: var(--lt-accent);\n  appearance: none;\n  -webkit-appearance: none;\n}\n.lt-range::-webkit-slider-runnable-track {\n  height: 5px;\n  border-radius: 10px;\n  background: linear-gradient(to right, var(--lt-accent) var(--lt-fill, 0%), #ffffff2a var(--lt-fill, 0%));\n}\n.lt-range::-webkit-slider-thumb {\n  appearance: none;\n  -webkit-appearance: none;\n  width: 22px;\n  height: 22px;\n  margin-top: -8.5px;\n  border-radius: 50%;\n  background: #f3fff9;\n  box-shadow: 0 2px 7px #0005;\n}\n.lt-range:disabled { opacity: .35; cursor: default; }\n.lt-timestamps { display: flex; justify-content: space-between; color: #d5deec; font-size: 12px; font-variant-numeric: tabular-nums; margin-top: -7px; }\n.lt-transport { display: flex; align-items: center; justify-content: space-between; gap: 4px; margin: 14px 0 8px; }\n.lt-transport > button { width: var(--lt-touch); height: var(--lt-touch); }\n.lt-transport > button[data-action=\"back\"] svg,\n.lt-transport > button[data-action=\"next\"] svg { width: 30px; height: 30px; }\n.lt-transport > button.lt-play-large {\n  width: 76px;\n  height: 76px;\n  min-height: 76px;\n  min-width: 76px;\n  background: var(--lt-accent) !important;\n  color: var(--lt-accent-ink) !important;\n  box-shadow: 0 6px 24px #0003, inset 0 1px 0 #ffffffaa;\n}\n.lt-play-large svg { width: 30px !important; height: 30px !important; }\n.lt-volume { display: flex; align-items: center; gap: 8px; }\n.lt-volume .lt-range { flex: 1; }\n#lt-volume-text { min-width: 35px; color: #d5deec; font-size: 12px; font-variant-numeric: tabular-nums; text-align: right; }\n.lt-np-bottom { display: flex; justify-content: space-between; gap: 8px; align-items: center; }\n.lt-np-bottom button { border-radius: 18px !important; gap: 8px; padding: 8px 12px !important; color: #d5deec !important; font-size: 13px !important; }\n.lt-np-bottom button svg { width: 20px !important; height: 20px !important; }\n\n/* Settings are intentionally usable without a mouse or keyboard. */\n#lt-settings { width: 580px; }\n.lt-sheet-header { position: sticky; top: 0; display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: #192338f0; z-index: 1; border-bottom: 1px solid #ffffff0d; }\n.lt-sheet-header > div { flex: 1; min-width: 0; }\n.lt-sheet-header h2 { font-size: 22px; letter-spacing: -.045em; font-weight: 650; margin: 0; }\n.lt-sheet-header p { font-size: 12px; color: var(--lt-muted); margin: 3px 0 0; }\n.lt-settings-content { padding: 8px 20px 20px; }\n.lt-setting { display: flex; align-items: center; justify-content: space-between; gap: 16px; min-height: 78px; padding: 12px 0; border-bottom: 1px solid #ffffff0c; }\n.lt-setting label { display: block; font-size: 15px; font-weight: 600; }\n.lt-setting small { display: block; max-width: 320px; color: var(--lt-muted); font-size: 12px; margin-top: 4px; }\n.lt-setting > div { flex: 1; min-width: 0; }\n.lt-setting select { min-height: var(--lt-touch); max-width: 160px; border-radius: 14px; border: 1px solid #ffffff24; color: var(--lt-ink); background: #ffffff0b; font: inherit; font-size: 14px; padding: 8px 12px; }\n.lt-setting select option { background: #1c283c; color: var(--lt-ink); }\n.lt-setting .lt-toggle { border-radius: 999px !important; width: 64px; background: #ffffff12 !important; position: relative; }\n.lt-setting .lt-toggle::before { content: \"\"; display: block; position: absolute; width: 25px; height: 25px; left: 9px; border-radius: 50%; background: #d7e0ed; transition: transform .16s; }\n.lt-setting .lt-toggle[aria-checked=\"true\"] { background: #b4eedc33 !important; }\n.lt-setting .lt-toggle[aria-checked=\"true\"]::before { transform: translateX(21px); background: var(--lt-accent); }\n.lt-settings-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; padding-top: 18px; }\n.lt-settings-actions button { border-radius: 16px !important; background: #ffffff0c !important; padding: 12px !important; gap: 8px; font-size: 14px !important; }\n.lt-note { color: var(--lt-muted); font-size: 12px; line-height: 1.6; margin: 18px 0 0; }\n\n/* Optional local keyboard: no external program is needed to search. */\n.lt-keyboard {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  padding: 6px 12px calc(10px + env(safe-area-inset-bottom, 0px));\n  pointer-events: auto;\n  border-radius: 24px 24px 0 0;\n}\n.lt-kb-toolbar { display: flex; align-items: center; justify-content: space-between; min-height: 44px; font-size: 12px; color: var(--lt-muted); padding-left: 4px; }\n.lt-kb-toolbar button { min-height: 44px !important; min-width: 44px !important; height: 44px; padding: 8px !important; }\n.lt-kb-row { display: flex; align-items: center; justify-content: center; gap: 5px; margin-top: 5px; }\n.lt-kb-row button { flex: 1; min-width: 0 !important; min-height: 44px !important; height: 44px; border-radius: 11px !important; background: #ffffff12 !important; font-size: 17px !important; padding: 5px !important; box-shadow: inset 0 1px 0 #ffffff0b; }\n.lt-kb-row button.lt-kb-wide { flex: 1.7; font-size: 13px !important; }\n.lt-kb-row button.lt-kb-space { flex: 4; font-size: 13px !important; }\n.lt-kb-row button.lt-kb-submit { background: var(--lt-accent) !important; color: var(--lt-accent-ink) !important; }\n.lt-kb-inner { width: 100%; max-width: 1000px; margin: auto; }\n\n#lt-rescue {\n  position: fixed;\n  bottom: 16px;\n  right: 16px;\n  padding: 10px 18px;\n  gap: 8px;\n  border-radius: 999px;\n  background: #24394ff5;\n  border: 1px solid #c8e9ff80;\n  color: #f6f8fc;\n  box-shadow: 0 8px 24px #0006;\n  z-index: 2147483000;\n  font-size: 14px;\n}\n#lt-toast {\n  position: fixed;\n  z-index: 2147483001;\n  bottom: calc(var(--lt-footer) + 18px);\n  left: 50%;\n  transform: translateX(-50%);\n  width: max-content;\n  max-width: calc(100vw - 40px);\n  padding: 12px 18px;\n  border-radius: 18px;\n  background: #e2f8f1;\n  color: #112c29;\n  box-shadow: 0 10px 30px #0005;\n  font-size: 14px;\n  pointer-events: none;\n}\nbody:not(.lt-active) #lt-toast { bottom: 86px; }\n\n/* Graceful fallback for GPUs without blur or small PCs running hot. */\n@supports not ((backdrop-filter: blur(1px)) or (-webkit-backdrop-filter: blur(1px))) {\n  .lt-glass { background: #1b2a40; }\n}\nbody[data-lt-lite=\"true\"] .lt-glass {\n  backdrop-filter: none;\n  -webkit-backdrop-filter: none;\n  background: linear-gradient(135deg, #ffffff0d, #ffffff00), rgba(var(--lt-glass-rgb), var(--lt-glass-opacity));\n}\nbody[data-lt-lite=\"true\"] .lt-dialog::backdrop { backdrop-filter: none; }\nbody[data-lt-motion=\"reduce\"] :is(#lt-shell, .lt-dialog) *,\nbody[data-lt-motion=\"reduce\"] :is(#lt-shell, .lt-dialog) *::before { transition: none !important; animation: none !important; }\n@media (prefers-reduced-motion: reduce) {\n  :is(#lt-shell, .lt-dialog) *, :is(#lt-shell, .lt-dialog) *::before { transition: none !important; animation: none !important; }\n}\n@media (hover: hover) {\n  :is(#lt-shell, .lt-dialog) button:hover { background: #ffffff10; }\n}\n@media (max-width: 900px) {\n  body.lt-active .main-trackList-trackListRow {\n    grid-template-columns: var(--lt-touch) minmax(0, 1fr) minmax(64px, auto) !important;\n    gap: 8px !important;\n  }\n  body.lt-active .main-trackList-trackListRow .main-trackList-rowSectionVariable { display: none !important; }\n  body.lt-active .main-trackList-trackListHeader { display: none !important; }\n  .lt-np-layout { padding: 8px 30px 20px; gap: 28px; }\n  .lt-np-track { margin-bottom: 2px; }\n}\n@media (max-width: 650px) and (min-height: 620px) {\n  .lt-np-layout { display: flex; flex-direction: column; justify-content: center; gap: 24px; padding: 12px 28px 26px; }\n  .lt-art-area { width: 100%; flex-shrink: 0; }\n  .lt-art-frame { width: min(100%, 38dvh, 400px); border-radius: 24px; }\n  .lt-np-controls { flex-shrink: 0; }\n  #lt-np-title { font-size: 30px; }\n  .lt-transport { margin-top: 18px; }\n}\n@media (max-height: 540px) {\n  .lt-np-header { padding: 4px 16px; flex-basis: 56px; }\n  .lt-np-layout { padding: 0 28px 12px; gap: 24px; }\n  .lt-art-frame { width: min(100%, calc(100dvh - 120px), 360px); border-radius: 22px; }\n  #lt-np-title { font-size: 27px; }\n  #lt-np-artist { font-size: 14px; margin-top: 4px; }\n  .lt-transport { margin: 7px 0 3px; }\n  .lt-transport > button.lt-play-large { width: 68px; height: 68px; min-width: 68px; min-height: 68px; }\n  .lt-np-bottom button { font-size: 12px !important; }\n  .lt-np-bottom { gap: 2px; }\n  .lt-np-bottom button { padding: 6px !important; }\n}\n@media (max-width: 520px) {\n  .lt-header { gap: 4px; left: 8px; right: 8px; }\n  .lt-footer { left: 8px; right: 8px; }\n  .lt-mini { gap: 2px; padding-right: 4px; }\n  #lt-mini-open { gap: 9px; }\n  .lt-header .lt-heading-mark { display: none; }\n  .lt-search-form { padding-left: 9px; }\n  .lt-search-form input { font-size: 14px; }\n  .lt-setting { gap: 10px; }\n  .lt-setting select { max-width: 126px; padding: 8px; font-size: 13px; }\n  .lt-keyboard { padding-left: 8px; padding-right: 8px; }\n  .lt-kb-row { gap: 2px; }\n}\n\n/* Readability and native chrome. Geometry is measured after text changes,\n   so larger labels grow the reserved space instead of covering content. */\n.lt-windowbar { display: none; }\nbody.lt-active[data-lt-window=\"custom\"] .lt-windowbar {\n  display: flex;\n  position: absolute;\n  top: 0; left: 12px; right: 12px;\n  height: var(--lt-chrome-height);\n  align-items: center;\n  gap: 12px;\n  pointer-events: auto;\n  z-index: 4;\n}\nbody.lt-active[data-lt-window=\"custom\"] .Titlebar { display: none !important; }\n.lt-window-drag {\n  display: flex; align-items: center; gap: 10px;\n  min-width: 0; flex: 1; height: 100%;\n  color: var(--lt-muted); font-size: calc(12px * var(--lt-text-scale));\n  font-weight: 600; letter-spacing: .015em;\n  user-select: none; -webkit-app-region: drag;\n}\n.lt-window-drag .lt-heading-mark { width: 26px; height: 26px; }\n.lt-window-drag svg { width: 18px !important; height: 18px !important; }\n.lt-caption-buttons {\n  display: flex; align-items: center; flex-shrink: 0; gap: 3px; padding: 3px;\n  border-radius: 999px; -webkit-app-region: no-drag;\n}\n.lt-caption-buttons button {\n  min-width: calc(44px * var(--lt-ui-scale));\n  min-height: calc(44px * var(--lt-ui-scale));\n  width: calc(44px * var(--lt-ui-scale));\n  height: calc(44px * var(--lt-ui-scale));\n  padding: 8px; border-radius: 50%;\n}\n.lt-caption-buttons button svg { width: 19px; height: 19px; }\n.lt-caption-buttons button[data-action=\"windowClose\"] { color: #ffc1c9; }\n.lt-caption-buttons button[data-action=\"windowClose\"]:hover,\n.lt-caption-buttons button[data-action=\"windowClose\"]:active { background: #e9546d32; }\n.lt-heading-text {\n  font-size: calc(22px * var(--lt-text-scale));\n  line-height: 1.2; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;\n}\n.lt-search-form input {\n  font-size: calc(16px * var(--lt-text-scale));\n  height: auto; min-height: var(--lt-touch); border-radius: 18px;\n}\n.lt-mini { height: auto; min-height: var(--lt-mini); padding-top: 6px; padding-bottom: 6px; }\n#lt-mini-open { min-height: calc(var(--lt-mini) - 14px); height: auto; }\n.lt-cover-small { width: var(--lt-touch); height: var(--lt-touch); }\n.lt-track-title {\n  font-size: calc(18px * var(--lt-text-scale)); line-height: 1.25;\n  white-space: normal; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;\n  overflow-wrap: anywhere;\n}\n.lt-track-artist { font-size: calc(14px * var(--lt-text-scale)); line-height: 1.3; }\n.lt-nav { min-height: var(--lt-nav); height: auto; }\n.lt-nav button {\n  font-size: calc(13px * var(--lt-text-scale)) !important;\n  min-height: calc(var(--lt-nav) - 10px); line-height: 1.15;\n}\n.lt-nav button svg { width: calc(24px * var(--lt-ui-scale)); height: calc(24px * var(--lt-ui-scale)); }\n.lt-track-title, .lt-track-artist, .lt-nav button, .lt-heading-text { text-shadow: 0 1px 6px #0006; }\n\n/* Spotify Encore text tokens and known native card/track labels. */\nbody.lt-active .Root {\n  --encore-text-size-smaller-2: calc(12px * var(--lt-text-scale));\n  --encore-text-size-smaller: calc(14px * var(--lt-text-scale));\n  --encore-text-size-base: calc(16px * var(--lt-text-scale));\n  --encore-text-size-larger: calc(22px * var(--lt-text-scale));\n  --encore-text-size-larger-2: calc(30px * var(--lt-text-scale));\n  --background-base: var(--lt-bg);\n  --background-elevated-base: var(--lt-bg);\n  --text-base: #f6f8fc; --text-subdued: #d0d9e7;\n  font-size: calc(16px * var(--lt-text-scale));\n}\nbody.lt-active :is(.main-view-container, [data-lt-native=\"library\"]) {\n  background-color: transparent !important;\n  font-size: calc(16px * var(--lt-text-scale));\n}\nbody.lt-active :is(.main-yourLibraryX-libraryContainer,.main-yourLibraryX-libraryRootlist,.main-view-container__scroll-node) { background-color: transparent !important; }\nbody.lt-active .main-home-homeHeader { background: transparent !important; }\nbody.lt-active :is(.main-view-container,[data-lt-native=\"library\"]) [data-encore-id=\"text\"] {\n  font-size: calc(16px * var(--lt-text-scale)) !important; line-height: 1.35;\n}\nbody.lt-active :is(.main-view-container,[data-lt-native=\"library\"]) :is(h1,h2,h3)[data-encore-id=\"text\"] { font-size: calc(25px * var(--lt-text-scale)) !important; }\nbody.lt-active :is(.main-cardHeader-link,.main-cardHeader-text,.main-trackList-rowTitle,[data-testid=\"context-item-info-title\"],.main-yourLibraryX-listItem strong) {\n  font-size: calc(18px * var(--lt-text-scale)) !important;\n  line-height: 1.3 !important; white-space: normal;\n  overflow-wrap: anywhere;\n}\nbody.lt-active :is(.main-cardHeader-text,.main-cardHeader-link) {\n  min-height: 2.6em; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;\n}\nbody.lt-active :is(.main-cardSubHeader-root,.main-trackList-rowSubTitle) { font-size: calc(14px * var(--lt-text-scale)) !important; line-height: 1.35; }\nbody.lt-active .main-card-card { height: auto; }\nbody.lt-active .main-view-container input,\nbody.lt-active [data-lt-native=\"library\"] input { font-size: calc(16px * var(--lt-text-scale)) !important; min-height: var(--lt-touch); }\n\n#lt-now-playing {\n  background: radial-gradient(ellipse at 0% 0%, rgba(var(--lt-art-rgb),.28), transparent 72%),\n    radial-gradient(ellipse at 100% 100%, rgba(var(--lt-art-rgb),.13), transparent 60%), var(--lt-bg);\n  overflow-y: auto;\n  scroll-padding-top: calc(var(--lt-chrome-height) + var(--lt-header) + 12px);\n  scroll-padding-bottom: 20px;\n}\n.lt-np-header {\n  margin-top: var(--lt-chrome-height);\n  position: sticky; top: var(--lt-chrome-height); z-index: 3;\n  background: var(--lt-bg);\n  min-height: calc(var(--lt-touch) + 16px);\n  flex: 0 0 auto; padding: 8px 16px;\n}\n.lt-eyebrow { font-size: calc(12px * var(--lt-text-scale)); letter-spacing: .13em; }\n.lt-context-title { font-size: calc(15px * var(--lt-text-scale)); line-height: 1.25; }\n.lt-np-layout { min-height: min-content; flex: 1 0 auto; }\n.lt-art-frame { width: min(100%, 440px, calc(100dvh - var(--lt-chrome-height) - 148px)); }\n#lt-np-title { font-size: calc(clamp(25px, 3.4vw, 40px) * var(--lt-text-scale)); line-height: 1.15; }\n#lt-np-artist { font-size: calc(17px * var(--lt-text-scale)); line-height: 1.3; }\n.lt-timestamps { font-size: calc(13px * var(--lt-text-scale)); line-height: 1.3; }\n.lt-transport { gap: 3px; }\n.lt-transport > button.lt-play-large {\n  width: max(68px, calc(70px * var(--lt-ui-scale)));\n  height: max(68px, calc(70px * var(--lt-ui-scale)));\n  min-width: max(68px, calc(70px * var(--lt-ui-scale)));\n  min-height: max(68px, calc(70px * var(--lt-ui-scale)));\n}\n#lt-volume-text { font-size: calc(13px * var(--lt-text-scale)); min-width: 3.5em; }\n.lt-np-bottom button { font-size: calc(14px * var(--lt-text-scale)) !important; }\n.lt-range::-webkit-slider-runnable-track { height: 6px; }\n.lt-range::-webkit-slider-thumb { width: 26px; height: 26px; margin-top: -10px; }\n\n#lt-settings {\n  width: min(680px,calc(100vw - 24px));\n  inset: calc(var(--lt-chrome-height) + 12px) 0 12px;\n  margin: auto;\n  max-height: calc(100dvh - var(--lt-chrome-height) - 24px);\n  background: linear-gradient(145deg,#223047,#172235);\n}\n.lt-sheet-header { padding: 14px 18px; }\n.lt-sheet-header h2 { font-size: calc(23px * var(--lt-text-scale)); }\n.lt-sheet-header p { font-size: calc(13px * var(--lt-text-scale)); }\n.lt-setting { min-height: calc(74px * var(--lt-ui-scale)); }\n.lt-setting label { font-size: calc(17px * var(--lt-text-scale)); line-height: 1.3; }\n.lt-setting small { font-size: calc(13px * var(--lt-text-scale)); line-height: 1.45; max-width: none; }\n.lt-setting select { font-size: calc(15px * var(--lt-text-scale)); min-height: var(--lt-touch); max-width: 48%; }\n.lt-setting-range { display: block; }\n.lt-scale-control { display: flex; width: 100%; align-items: center; gap: 10px; margin-top: 8px; }\n.lt-scale-control input { flex: 1; min-width: 0; width: 0; }\n.lt-scale-control output { min-width: 3.7em; font-size: calc(15px * var(--lt-text-scale)); font-variant-numeric: tabular-nums; text-align: center; }\n.lt-scale-control button { background: #ffffff10; font-size: calc(23px * var(--lt-text-scale)); }\n.lt-settings-actions { grid-template-columns: 1fr; }\n.lt-settings-actions button { font-size: calc(16px * var(--lt-text-scale)) !important; }\n.lt-note { font-size: calc(13px * var(--lt-text-scale)); }\n.lt-kb-toolbar { font-size: calc(13px * var(--lt-text-scale)); }\n.lt-kb-row button { font-size: calc(17px * min(var(--lt-text-scale),1.5)) !important; }\n.lt-kb-row button.lt-kb-wide,.lt-kb-row button.lt-kb-space { font-size: calc(13px * min(var(--lt-text-scale),1.5)) !important; }\n#lt-toast { font-size: calc(15px * var(--lt-text-scale)); bottom: calc(var(--lt-footer-measured, var(--lt-footer)) + 8px); }\n\n@media (max-width: 650px) and (min-height: 620px) {\n  .lt-art-frame { width: min(100%,calc((100dvh - var(--lt-chrome-height)) * .36),400px); }\n  #lt-np-title { font-size: calc(29px * var(--lt-text-scale)); }\n  .lt-np-layout { gap: 18px; padding-top: 8px; padding-bottom: 20px; }\n}\n@media (max-height: 540px) {\n  .lt-np-header { min-height: calc(var(--lt-touch) + 8px); padding-top: 4px; padding-bottom: 4px; }\n  #lt-np-title { font-size: calc(25px * var(--lt-text-scale)); }\n  .lt-np-layout { padding-top: 0; padding-bottom: 12px; }\n  .lt-art-frame { width: min(100%,calc(100dvh - var(--lt-chrome-height) - 130px),350px); }\n}\n@media (max-width: 520px) {\n  .lt-window-drag .lt-heading-mark { display: none; }\n  .lt-heading-text { font-size: calc(20px * var(--lt-text-scale)); }\n  .lt-header .lt-heading-mark { display: none; }\n  .lt-scale-control { gap: 4px; }\n  .lt-np-bottom button { padding-left: 5px !important; padding-right: 5px !important; }\n}\nbody[data-lt-expanded-text=\"true\"] .lt-np-bottom { flex-wrap: wrap; }\nbody[data-lt-expanded-text=\"true\"] .lt-np-track { align-items: flex-start; }\n:where(#lt-shell,.lt-dialog) svg { width: calc(24px * var(--lt-ui-scale)); height: calc(24px * var(--lt-ui-scale)); }\n.lt-caption-buttons button svg { width: calc(19px * var(--lt-ui-scale)); height: calc(19px * var(--lt-ui-scale)); }\n.lt-transport > button[data-action=\"back\"] svg,.lt-transport > button[data-action=\"next\"] svg { width: calc(30px * var(--lt-ui-scale)); height: calc(30px * var(--lt-ui-scale)); }\n.lt-play-large svg { width: calc(30px * var(--lt-ui-scale)) !important; height: calc(30px * var(--lt-ui-scale)) !important; }\n.lt-range::-webkit-slider-runnable-track { height: calc(6px * var(--lt-ui-scale)); }\n.lt-range::-webkit-slider-thumb { width: calc(26px * var(--lt-ui-scale)); height: calc(26px * var(--lt-ui-scale)); margin-top: calc(-10px * var(--lt-ui-scale)); }\nbody[data-lt-motion=\"reduce\"] .Root, body[data-lt-motion=\"reduce\"] #lt-now-playing { transition: none; }\n#lt-now-playing .lt-windowbar, #lt-settings .lt-windowbar { position: fixed; }\nbody.lt-active[data-lt-window=\"custom\"] #lt-settings {\n  inset-block-start: calc(max(var(--lt-chrome-height),calc(48px * var(--lt-ui-scale) + 8px)) + 12px);\n  max-height: calc(100dvh - max(var(--lt-chrome-height),calc(48px * var(--lt-ui-scale) + 8px)) - 24px);\n}\n@media (max-width: 900px) {\n  body[data-lt-roomy=\"true\"] .lt-np-layout { grid-template-columns: minmax(0,1fr); gap: 22px; }\n  body[data-lt-roomy=\"true\"] .lt-art-frame { width: min(100%,42dvh,280px); }\n}\n@media (min-width: 651px) {\n  body.lt-active[data-lt-window=\"custom\"] .lt-windowbar {\n    left: auto; top: 6px; right: 12px; width: var(--lt-caption-width,146px);\n    height: calc(var(--lt-header) - 6px);\n  }\n  body.lt-active[data-lt-window=\"custom\"] .lt-window-drag { display: none; }\n  body.lt-active[data-lt-window=\"custom\"] .lt-header { right: calc(var(--lt-caption-width,146px) + 24px); }\n  body.lt-active[data-lt-window=\"custom\"] .lt-np-header { padding-right: calc(var(--lt-caption-width,146px) + 28px); }\n  body.lt-active .lt-heading { -webkit-app-region: drag; }\n}\n\n/* 1.2: Own scrolling surfaces, continuous artwork light, and clear glass. */\n/* Keep horizontal edge pulls in the app even when they start in a gutter. */\nbody.lt-active { touch-action:pan-y;overscroll-behavior-x:none; }\nbody.lt-active .lt-dialog,body.lt-active .lt-dialog::backdrop { touch-action:pan-y;overscroll-behavior-x:none; }\n:root { --lt-radius: 32px; --lt-card-columns: 4; }\nbody.lt-active { --spice-main: var(--lt-bg); --spice-sidebar: var(--lt-bg); --spice-card: var(--lt-bg); background:var(--lt-bg); }\n.lt-atmosphere { display:none; }\nbody.lt-active .lt-atmosphere {\n  display:block;position:fixed;inset:0;z-index:0;pointer-events:none;overflow:hidden;\n  background:radial-gradient(ellipse at 12% 5%,rgba(var(--lt-art-rgb),.64),transparent 68%),radial-gradient(ellipse at 92% 95%,rgba(var(--lt-art-rgb),.5),transparent 65%),var(--lt-bg);\n}\n.lt-atmosphere img { width:100%;height:100%;object-fit:cover;filter:blur(75px) saturate(1.4);opacity:.22;transform:scale(1.2); }\nbody.lt-active .Root { background:transparent !important;z-index:1;clip-path:inset(calc(var(--lt-chrome-height) + var(--lt-header) + 5px) 0 var(--lt-footer-measured,var(--lt-footer))); }\nbody.lt-active .Root :is(main,.main-home-home,.main-home-content,[data-testid=\"home-page\"],.main-view-container__scroll-node-child,[data-overlayscrollbars-viewport]) { background-color:transparent !important; }\nbody.lt-active :is(.Root__globalNav,.Root__top-bar,.main-topBar-container,.main-topBar-topbar,.main-topBar-background,.main-topBar-overlay,[data-testid=\"top-bar\"]) { visibility:hidden !important;display:none !important; }\nbody.lt-active[data-lt-window=\"custom\"] :is(.Titlebar,.main-topBar-windowControls,[data-testid=\"window-controls\"]) { visibility:hidden !important;display:none !important; }\n#lt-shell { z-index:10000;isolation:isolate; }\n/* Opaque at the very top only: changing native titlebar height can leave a\n   one-pixel app-menu remnant outside the React root. Cover its entire strip. */\n#lt-shell::before { content:\"\";position:absolute;inset:0 0 auto;height:calc(var(--lt-chrome-height) + var(--lt-header) + 6px);z-index:-1;background:linear-gradient(110deg,rgba(var(--lt-art-rgb),.22),transparent 80%),var(--lt-bg);pointer-events:none; }\nbody.lt-active[data-lt-custom-page]:not([data-lt-custom-page=\"\"]) :is([data-lt-native=\"main\"],[data-lt-native=\"library\"]) { visibility:hidden !important;pointer-events:none !important; }\n/* Keep the hidden native library measured so its virtualized items can load. */\nbody.lt-active[data-lt-page=\"library\"] [data-lt-native=\"library\"] { display:flex !important;min-height:0 !important; }\n.lt-browse {\n  position:absolute;inset:calc(var(--lt-chrome-height) + var(--lt-header) + 6px) 12px var(--lt-footer-measured,calc(var(--lt-footer) + 4px));\n  min-height:0;min-width:0;overflow-x:hidden;overflow-y:auto;pointer-events:auto;\n  padding:clamp(16px,2vw,32px);border-radius:var(--lt-radius);touch-action:pan-y;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;\n  scrollbar-gutter:stable;background:linear-gradient(140deg,#ffffff05,#ffffff00),rgba(var(--lt-glass-rgb),.08);\n}\nbody[data-lt-keyboard=\"true\"] .lt-browse { bottom:calc(var(--lt-keyboard-height) + 6px); }\n.lt-home-hero { padding:clamp(8px,2vw,28px) 0 24px; }\n.lt-home-hero h1,.lt-page-heading h1 { font-size:calc(clamp(24px,3.2vw,38px) * var(--lt-text-scale));font-weight:700;line-height:1.12;letter-spacing:-.045em;margin:8px 0 10px; }\n.lt-home-hero p,.lt-page-heading p { margin:0 0 14px;font-size:calc(16px * var(--lt-text-scale));color:var(--lt-muted); }\n.lt-home-hero .lt-eyebrow,.lt-page-heading .lt-eyebrow { color:var(--lt-muted); }\n.lt-quick-actions,.lt-filter-bar { display:flex;flex-wrap:wrap;gap:10px;margin:16px 0; }\n#lt-shell .lt-pill,.lt-dialog .lt-pill { border-radius:var(--lt-radius);min-height:var(--lt-touch);padding:10px 18px;font-size:calc(15px * var(--lt-text-scale));font-weight:600; }\n.lt-pill[aria-pressed=\"true\"] { color:var(--lt-accent) !important;box-shadow:inset 0 0 0 2px #b4eedc80 !important; }\n.lt-section-title { font-size:calc(20px * var(--lt-text-scale));font-weight:650;letter-spacing:-.025em;line-height:1.25;margin:10px 0 18px; }\n.lt-card-section { margin:0 0 30px; }\n.lt-card-grid { display:grid;grid-template-columns:repeat(var(--lt-card-columns),minmax(0,1fr));gap:clamp(12px,1.5vw,26px);align-items:stretch; }\n.lt-card { min-width:0;position:relative;border-radius:var(--lt-radius);overflow:hidden;display:flex;flex-direction:column;padding:8px; }\n#lt-shell .lt-card-face { display:flex;flex:1;flex-direction:column;align-items:stretch;justify-content:flex-start;min-width:0;width:100%;border-radius:max(10px,calc(var(--lt-radius) - 6px));padding:0;text-align:left;touch-action:pan-y; }\n.lt-card-art { position:relative;display:grid;place-items:center;aspect-ratio:1;width:100%;border-radius:max(10px,calc(var(--lt-radius) - 6px));overflow:hidden;background:linear-gradient(140deg,rgba(var(--lt-art-rgb),.42),#ffffff05); }\n.lt-card-art img { width:100%;height:100%;object-fit:cover;display:block; }\n.lt-art-placeholder svg { width:36% !important;height:36% !important;opacity:.8;color:var(--lt-accent); }\n.lt-card-title { display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;font-size:calc(17px * var(--lt-text-scale));font-weight:650;line-height:1.3;min-height:2.6em;margin:12px 8px 4px;overflow-wrap:anywhere; }\n.lt-card-subtitle { display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;color:var(--lt-muted);font-size:calc(13px * var(--lt-text-scale));line-height:1.4;margin:0 8px 6px; }\n#lt-shell .lt-card-open { align-self:flex-end;gap:8px;font-size:calc(13px * var(--lt-text-scale));font-weight:600;color:var(--lt-accent);padding:6px 12px;border-radius:var(--lt-radius);min-height:44px;margin:2px 2px 0; }\n.lt-card-open::after { content:'↗';font-size:1.3em; }\n.lt-library-tools { display:flex;align-items:center;gap:12px;margin:20px 0 10px; }\n.lt-field { display:flex;align-items:center;gap:12px;min-width:0;flex:1;padding:6px 14px;border-radius:var(--lt-radius); }\n.lt-field input { min-width:0;width:100%;height:var(--lt-touch);border:0;border-radius:var(--lt-radius);font:inherit;font-size:calc(16px * var(--lt-text-scale));color:var(--lt-ink);background:transparent;outline-offset:2px; }\n.lt-field input::placeholder { color:var(--lt-muted); }\n.lt-empty { font-size:calc(17px * var(--lt-text-scale));color:var(--lt-muted);max-width:48em;line-height:1.5;padding:20px 0; }\n.lt-glass { background:linear-gradient(128deg,#ffffff15,#ffffff00 38%,#ffffff07),rgba(var(--lt-glass-rgb),var(--lt-glass-opacity));border-color:#e5f3ff55;box-shadow:0 8px 30px #03071324,inset 0 1px 0 #ffffff60,inset 1px 0 0 #ffffff20,inset 0 -1px 0 #ffffff10;backdrop-filter:blur(18px) saturate(180%);-webkit-backdrop-filter:blur(18px) saturate(180%); }\n.lt-mini,.lt-caption-buttons,.lt-search-form { border-radius:var(--lt-radius); }\n#lt-mini-open { border-radius:max(10px,calc(var(--lt-radius) - 8px)); }\n.lt-cover-small,.lt-history-row img { border-radius:max(8px,calc(var(--lt-radius) * .4)); }\n.lt-nav { border-radius:calc(var(--lt-radius) * 1.7); }\n.lt-nav button { font-size:calc(18px * var(--lt-text-scale)) !important;gap:5px;padding:6px 12px;border-radius:calc(var(--lt-radius) * 1.5) !important; }\n.lt-nav button svg { width:calc(28px * var(--lt-ui-scale));height:calc(28px * var(--lt-ui-scale)); }\n@media (hover:hover) and (pointer:fine) { #lt-shell .lt-card-face:hover { background:#ffffff07; } }\n#lt-now-playing { inset:8px;margin:0;width:calc(100vw - 16px);height:calc(100dvh - 16px);max-width:calc(100vw - 16px);max-height:calc(100dvh - 16px);border:1px solid #e5f3ff44;border-radius:var(--lt-radius);background:radial-gradient(ellipse at 5% 10%,rgba(var(--lt-art-rgb),.22),transparent 75%),rgba(var(--lt-glass-rgb),.24);backdrop-filter:blur(22px) saturate(180%);-webkit-backdrop-filter:blur(22px) saturate(180%); }\n#lt-now-playing::backdrop { background:rgba(var(--lt-glass-rgb),.16);backdrop-filter:blur(9px); }\n.lt-np-header { background:linear-gradient(110deg,#ffffff08,#ffffff00),rgba(var(--lt-glass-rgb),.12);border-radius:var(--lt-radius) var(--lt-radius) 0 0;backdrop-filter:blur(18px); }\n.lt-art-frame { border-radius:var(--lt-radius); }\n#lt-settings { border-radius:var(--lt-radius);background:linear-gradient(145deg,#ffffff09,#ffffff00),rgba(var(--lt-glass-rgb),.78);backdrop-filter:blur(24px); }\n.lt-setting select,.lt-kb-row button,.lt-search-form input { border-radius:max(10px,calc(var(--lt-radius) * .6)) !important; }\nbody.lt-active .Root :is(.main-card-card,.main-trackList-trackListRow,.main-cardImage-image,.main-cardImage-imageWrapper,input,[data-testid=\"card-container\"]) { border-radius:max(10px,calc(var(--lt-radius) * .6)) !important; }\n#lt-history { inset:8px;margin:0;width:calc(100vw - 16px);height:calc(100dvh - 16px);max-width:calc(100vw - 16px);max-height:calc(100dvh - 16px);border-radius:var(--lt-radius);background:linear-gradient(140deg,#ffffff08,#ffffff00),rgba(var(--lt-glass-rgb),.76);backdrop-filter:blur(24px); }\n#lt-history[open] { display:flex;flex-direction:column; }\n#lt-history .lt-windowbar { position:fixed; }\n#lt-history .lt-np-header { position:relative;top:0; }\n#lt-history-title { font-size:calc(22px * var(--lt-text-scale));margin:3px 0;letter-spacing:-.03em; }\n.lt-history-tools { padding:16px clamp(16px,4vw,60px); }\n#lt-history-count { font-size:calc(15px * var(--lt-text-scale));margin:12px 0 4px; }\n.lt-history-tools .lt-note { margin:4px 0; }\n.lt-history-list { flex:1;min-height:0;overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;padding:0 clamp(16px,4vw,60px) 24px; }\n.lt-history-day { font-size:calc(17px * var(--lt-text-scale));font-weight:600;margin:20px 0 12px; }\n#lt-history .lt-history-row { display:flex;align-items:center;justify-content:flex-start;width:100%;text-align:left;gap:16px;border-radius:var(--lt-radius);padding:12px;margin:0 0 10px; }\n.lt-history-row img { width:calc(54px * var(--lt-ui-scale));height:calc(54px * var(--lt-ui-scale));object-fit:cover; }\n.lt-history-text { display:flex;flex:1;min-width:0;flex-direction:column;gap:3px; }\n.lt-history-text strong { font-size:calc(17px * var(--lt-text-scale));line-height:1.3;overflow-wrap:anywhere; }\n.lt-history-text span,.lt-history-row time { font-size:calc(14px * var(--lt-text-scale));color:var(--lt-muted); }\n.lt-history-text small { font-size:calc(12px * var(--lt-text-scale));color:var(--lt-muted); }\n.lt-history-row time { font-variant-numeric:tabular-nums;white-space:nowrap; }\n@media(min-width:651px) { body.lt-active[data-lt-window=\"custom\"] #lt-history .lt-np-header { padding-right:calc(var(--lt-caption-width,146px) + 28px); } }\n@media(max-width:650px) { .lt-history-row time { white-space:normal;max-width:5em; }.lt-library-tools{flex-wrap:wrap;}.lt-nav button{font-size:calc(16px * var(--lt-text-scale)) !important;}.lt-history-tools{padding-top:10px;padding-bottom:6px;} }\nbody[data-lt-lite=\"true\"] .lt-glass { backdrop-filter:none;-webkit-backdrop-filter:none;background:rgba(var(--lt-glass-rgb),var(--lt-glass-opacity)); }\nbody[data-lt-lite=\"true\"] :is(#lt-now-playing,#lt-settings,#lt-history,.lt-np-header) { backdrop-filter:none;-webkit-backdrop-filter:none; }\nbody[data-lt-lite=\"true\"] .lt-atmosphere img { display:none; }\n/* The content scrolls beneath the floating glass, with enough trailing space\n   to bring every final card completely above the player and navigation. */\n.lt-browse { bottom:12px;padding-bottom:calc(var(--lt-footer-measured,var(--lt-footer)) + 16px);scroll-padding-bottom:var(--lt-footer-measured,var(--lt-footer));border:0;background:transparent;box-shadow:none;backdrop-filter:none;-webkit-backdrop-filter:none; }\n.lt-home-hero { display:grid;grid-template-columns:minmax(0,1fr) auto;column-gap:24px;padding:8px 0 22px; }\n.lt-home-hero h1 { margin:6px 0;font-size:calc(clamp(24px,3vw,32px) * var(--lt-text-scale)); }\n.lt-home-hero p { margin:4px 0; }\n.lt-home-hero .lt-eyebrow,.lt-home-hero .lt-home-greeting,.lt-home-hero p { grid-column:1; }\n.lt-home-greeting { display:flex;align-items:center;flex-wrap:wrap;gap:clamp(12px,2vw,24px);min-width:0; }\n.lt-home-greeting h1 { min-width:0;overflow-wrap:anywhere; }\n.lt-home-clock { flex:0 0 auto;white-space:nowrap;padding:8px 16px;border-radius:var(--lt-radius);font-size:calc(clamp(22px,2.5vw,30px) * var(--lt-text-scale));font-weight:600;font-variant-numeric:tabular-nums;letter-spacing:-.025em;line-height:1.2; }\n.lt-home-hero .lt-quick-actions { grid-column:2;grid-row:1 / 4;align-self:end;margin:0; }\n@media(max-width:1100px) { .lt-home-hero { display:block; }.lt-home-hero .lt-quick-actions { margin-top:14px; } }\n@media(max-width:650px) and (min-height:620px) { .lt-art-frame { width:min(100%,calc((100dvh - var(--lt-chrome-height) - 16px) * .33),400px); } }\n/* The backdrop already blurs Settings. Filtering the dialog itself would\n   capture its fixed window buttons and move them onto the sheet's Close button. */\n#lt-settings { backdrop-filter:none;-webkit-backdrop-filter:none; }\n#lt-now-playing { background:radial-gradient(ellipse at 5% 10%,rgba(var(--lt-art-rgb),.22),transparent 75%),rgba(var(--lt-glass-rgb),var(--lt-glass-opacity)); }\n#lt-now-playing :is(h1,p,.lt-context,.lt-timestamps,.lt-volume,.lt-np-bottom) { text-shadow:0 1px 8px #0009; }\n/* Keep Library's tools compact so the larger covers still have room for titles. */\n.lt-library-heading h1 { position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap; }\n.lt-library-heading .lt-eyebrow { margin:0; }\n.lt-library-controls { display:grid;grid-template-columns:minmax(0,1fr) auto;gap:16px;align-items:center;margin:14px 0; }\n.lt-library-controls .lt-library-tools { margin:0; }\n.lt-library-controls .lt-filter-bar { margin:0; }\n.lt-library-controls + .lt-note { margin:8px 0; }\n.lt-card[data-uri=\"spotify:collection:tracks\"] .lt-card-art { background:linear-gradient(135deg,#5727e4,#7d82d0 55%,#b1e3d0); }\n.lt-card[data-uri=\"spotify:collection:tracks\"] .lt-card-art svg { color:#fff; }\n@media(max-width:1100px) { .lt-library-controls { grid-template-columns:minmax(0,1fr);gap:12px; } }\n\n/* 1.3: The top container contains native detail/search views. Never hide it. */\nbody.lt-active .Root__top-container { display:block !important;position:absolute !important;inset:0;width:100%;height:100%;min-width:0;min-height:0;visibility:visible !important;background:transparent !important; }\nbody.lt-active[data-lt-custom-page=\"\"] :is(.Root__main-view,[data-lt-native=\"main\"]) { visibility:visible !important;pointer-events:auto !important; }\nbody.lt-active .Root { clip-path:inset(calc(var(--lt-chrome-height) + var(--lt-header) + 5px) 0 var(--lt-footer-measured,var(--lt-footer))); }\nbody.lt-active :is(.main-topBar-topbarContentLeft,.main-topBar-topbarContentRight,#spicetify-show-list,.main-topBar-historyButtons) { display:none !important; }\n#lt-shell::before { background:transparent; }\n#lt-shell::after { content:\"\";position:fixed;top:0;left:0;right:0;height:3px;background:var(--lt-bg);pointer-events:none;z-index:20; }\n.lt-header,.lt-heading { -webkit-app-region:no-drag !important; }\n.lt-header { touch-action:none; }\n.lt-nav { touch-action:none; }\n.lt-card-art { position:relative; }\n.lt-card-art > svg { position:absolute;inset:0;margin:auto;z-index:0; }\n.lt-card-art > img { position:relative;z-index:1; }\n.lt-setting-text { display:block;width:100%;min-height:var(--lt-touch);margin-top:10px;padding:12px 14px;border:1px solid #ffffff40;border-radius:var(--lt-radius);background:#ffffff08;color:inherit;font:inherit;font-size:calc(16px * var(--lt-text-scale)); }\n.lt-quick-search { position:absolute;left:12px;right:12px;top:calc(var(--lt-chrome-height) + var(--lt-header) + 12px);z-index:12;display:flex;align-items:center;gap:12px;padding:8px 14px;border-radius:var(--lt-radius);pointer-events:auto; }\n.lt-quick-search input { flex:1;min-width:0;border:0;min-height:var(--lt-touch);border-radius:var(--lt-radius);color:inherit;background:transparent;font:inherit;font-size:calc(17px * var(--lt-text-scale)); }\n.lt-search-preview { position:absolute;top:calc(var(--lt-chrome-height) + var(--lt-header) + 8px);left:12px;right:12px;z-index:13;padding:14px;border-radius:var(--lt-radius);max-height:calc(100dvh - var(--lt-chrome-height) - var(--lt-header) - 34px);overflow-y:auto;pointer-events:auto;background:linear-gradient(125deg,#ffffff12,#ffffff00),rgba(var(--lt-glass-rgb),.92); }\nbody[data-lt-quick=\"true\"] .lt-search-preview { top:calc(var(--lt-chrome-height) + var(--lt-header) + var(--lt-touch) + 42px);max-height:calc(100dvh - var(--lt-chrome-height) - var(--lt-header) - var(--lt-touch) - 60px); }\nbody[data-lt-keyboard=\"true\"] .lt-search-preview { max-height:calc(100dvh - var(--lt-chrome-height) - var(--lt-header) - var(--lt-keyboard-height) - 12px); }\n.lt-preview-status { margin:0 8px 10px;font-size:calc(14px * var(--lt-text-scale));color:var(--lt-muted); }\n.lt-preview-list { display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px; }\n.lt-preview-list .lt-card { padding:6px; }\n#lt-shell .lt-preview-list .lt-card-face { display:grid;grid-template-columns:var(--lt-touch) minmax(0,1fr);column-gap:12px;align-items:center; }\n.lt-preview-list .lt-card-art { grid-row:1 / 3;width:var(--lt-touch);height:var(--lt-touch);border-radius:max(8px,calc(var(--lt-radius)*.4)); }\n.lt-preview-list .lt-card-title { min-height:0;margin:0;font-size:calc(15px * var(--lt-text-scale)); }\n.lt-preview-list .lt-card-subtitle { margin:0;font-size:calc(12px * var(--lt-text-scale)); }\n#lt-shell .lt-preview-list .lt-card-open { display:none; }\n.lt-search-preview > .lt-pill { margin-top:10px; }\n@media(max-width:700px){.lt-preview-list{grid-template-columns:minmax(0,1fr);}}\n/* The expanded player owns an opaque artwork canvas. No previous tab bleeds in. */\n#lt-now-playing { inset:0;margin:0;width:100vw;height:100dvh;max-width:100vw;max-height:100dvh;border:0;border-radius:0;background:var(--lt-bg);backdrop-filter:none;-webkit-backdrop-filter:none;isolation:isolate; }\n#lt-now-playing::backdrop { background:var(--lt-bg);backdrop-filter:none; }\n.lt-player-wallpaper { position:fixed;inset:0;z-index:-1;overflow:hidden;pointer-events:none;background:radial-gradient(ellipse at 10% 5%,rgba(var(--lt-art-rgb),.65),transparent 80%),var(--lt-bg); }\n.lt-player-wallpaper img { width:100%;height:100%;object-fit:cover;filter:blur(45px) saturate(1.15);transform:scale(1.16);opacity:.64; }\n.lt-player-wallpaper::after { content:\"\";position:absolute;inset:0;background:linear-gradient(120deg,#070a1280,#070a12b0); }\n.lt-np-header { background:transparent;border-radius:0;backdrop-filter:none;-webkit-backdrop-filter:none; }\n#lt-now-playing::after { content:\"\";position:fixed;inset:0 0 auto;height:3px;background:var(--lt-bg);z-index:8;pointer-events:none; }\n.lt-lyrics-panel { width:100%;max-height:calc(100dvh - var(--lt-chrome-height) - var(--lt-header) - 32px);min-height:180px;overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;border-radius:var(--lt-radius);padding:18px;scroll-behavior:smooth; }\n#lt-lyrics-status { color:var(--lt-muted);font-size:calc(12px * var(--lt-text-scale));line-height:1.4;margin:0 0 20px; }\n#lt-now-playing .lt-lyric-line { display:block;width:100%;min-height:var(--lt-touch);border-radius:calc(var(--lt-radius)*.5);padding:12px 8px;text-align:left;font-size:calc(23px * var(--lt-text-scale));line-height:1.35;font-weight:650;color:#ffffff80;transition:color .22s,background .22s; }\n#lt-now-playing .lt-lyric-line.lt-lyric-active { color:#fff;background:#ffffff12;text-shadow:0 1px 8px #0008; }\n#lt-now-playing .lt-lyric-line:disabled { opacity:.8; }\n.lt-np-bottom { flex-wrap:wrap; }\n@media(prefers-reduced-motion:reduce){.lt-lyrics-panel{scroll-behavior:auto;}.lt-lyric-line{transition:none !important;}}\nbody[data-lt-motion=\"reduce\"] .lt-lyric-line { transition:none !important; }\nbody[data-lt-lite=\"true\"] .lt-player-wallpaper img { opacity:.18;filter:none; }\n/* Covers occupy most of each card; keep its glass cheaper than the floating bars. */\n.lt-card { backdrop-filter:blur(10px) saturate(160%);-webkit-backdrop-filter:blur(10px) saturate(160%); }\nbody[data-lt-lite=\"true\"] .lt-card { backdrop-filter:none;-webkit-backdrop-filter:none; }\nbody[data-lt-keyboard=\"true\"][data-lt-quick=\"true\"] .lt-search-preview { max-height:max(0px,calc(100dvh - var(--lt-chrome-height) - var(--lt-header) - var(--lt-touch) - var(--lt-keyboard-height) - 46px)); }\n.lt-search-preview[aria-busy=\"true\"] .lt-preview-status::before { content:\"\";display:inline-block;width:14px;height:14px;margin-right:10px;border:2px solid #ffffff35;border-top-color:var(--lt-accent);border-radius:50%;vertical-align:-1px;animation:lt-search-spin .8s linear infinite; }\n@keyframes lt-search-spin { to { transform:rotate(360deg); } }\nbody[data-lt-motion=\"reduce\"] .lt-preview-status::before { animation:none !important; }\n@media(prefers-reduced-motion:reduce){.lt-preview-status::before{animation:none !important;}}\n\n/* 1.4: stable modal surface, compact record deck and simultaneous live lyrics. */\n#lt-now-playing[open] {\n  display:flex !important;position:fixed !important;visibility:visible !important;\n  opacity:1 !important;transform:none !important;animation:none !important;\n  content-visibility:visible;z-index:2147482000;overflow:hidden;\n}\n#lt-now-playing .lt-np-layout {\n  display:grid;grid-template-columns:minmax(0,.95fr) minmax(0,1.15fr);\n  flex:1 1 0;min-height:0;align-items:stretch;gap:clamp(16px,3vw,42px);\n  padding:8px clamp(16px,4vw,64px) 16px;\n}\n.lt-np-record {\n  display:flex;flex-direction:column;align-items:center;justify-content:safe center;\n  gap:10px;min-width:0;min-height:0;overflow-y:auto;overscroll-behavior:contain;\n  scrollbar-width:thin;touch-action:pan-y;padding:2px 6px 10px;\n}\n#lt-now-playing .lt-art-area { flex:0 0 auto;width:100%;touch-action:pan-y; }\n#lt-now-playing .lt-art-frame {\n  width:min(100%,300px,max(110px,calc((100dvh - var(--lt-chrome-height) - var(--lt-header) - 90px) * .43)));\n  flex:none;border-radius:var(--lt-radius);\n}\n#lt-now-playing .lt-np-controls { flex:0 0 auto;max-width:460px;margin:0 auto; }\n#lt-now-playing .lt-np-track { margin-bottom:0;gap:6px;align-items:center; }\n#lt-now-playing #lt-np-title { font-size:calc(20px * var(--lt-text-scale));line-height:1.2;-webkit-line-clamp:2; }\n#lt-now-playing #lt-np-artist { font-size:calc(14px * var(--lt-text-scale));margin-top:4px; }\n#lt-now-playing .lt-np-track > button { min-width:44px;min-height:44px;width:44px;height:44px; }\n#lt-now-playing .lt-range { min-height:44px; }\n#lt-now-playing .lt-timestamps { font-size:calc(11px * var(--lt-text-scale));margin-top:-7px; }\n#lt-now-playing .lt-transport { margin:4px 0 2px;gap:2px; }\n#lt-now-playing .lt-transport > button { min-width:44px;min-height:44px;width:calc(44px * var(--lt-ui-scale));height:calc(44px * var(--lt-ui-scale)); }\n#lt-now-playing .lt-transport > button.lt-play-large {\n  min-width:52px;min-height:52px;width:calc(52px * var(--lt-ui-scale));height:calc(52px * var(--lt-ui-scale));\n}\n#lt-now-playing .lt-volume { gap:4px; }\n#lt-now-playing .lt-volume > button { min-width:44px;min-height:44px; }\n#lt-now-playing .lt-np-bottom { gap:2px;flex-wrap:nowrap; }\n#lt-now-playing .lt-np-bottom button { min-width:44px;min-height:44px;padding:4px 6px !important;gap:4px;font-size:calc(12px * var(--lt-text-scale)) !important; }\n#lt-now-playing .lt-lyrics-panel {\n  align-self:stretch;height:auto !important;max-height:none;min-height:0;\n  margin:0;padding:20px clamp(16px,2vw,32px) 36px;scroll-behavior:auto;\n  background:linear-gradient(145deg,#ffffff0d,#ffffff02),rgba(var(--lt-glass-rgb),.2);\n  backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);\n}\n.lt-lyrics-heading { display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px; }\n#lt-now-playing .lt-lyrics-heading button { min-height:44px;padding:6px 12px;border-radius:calc(var(--lt-radius)*.6);font-size:calc(12px * var(--lt-text-scale));background:#ffffff0b; }\n#lt-now-playing .lt-lyric-line { font-size:calc(clamp(21px,2.3vw,30px) * var(--lt-text-scale));line-height:1.4;color:#ffffffaa;transition:color .1s,background .1s; }\n#lt-now-playing .lt-lyric-active { color:#fff; }\n#lt-now-playing[data-lyrics=\"false\"] .lt-np-layout { grid-template-columns:minmax(0,1fr); }\n#lt-now-playing[data-lyrics=\"false\"] .lt-np-record { display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.1fr);gap:clamp(18px,4vw,60px);align-items:center; }\n#lt-now-playing[data-lyrics=\"false\"] .lt-art-frame { width:min(100%,440px,calc(100dvh - var(--lt-header) - var(--lt-chrome-height) - 50px)); }\nbody.lt-active[data-lt-window=\"custom\"] .lt-windowbar { display:flex !important;visibility:visible !important;opacity:1 !important; }\n#lt-now-playing .lt-windowbar { z-index:12; }\n#lt-now-playing .lt-np-header { touch-action:none;flex-shrink:0; }\nbody.lt-active :is(.lt-browse,[data-lt-native=\"main\"],.lt-card-face,.lt-card-open) { touch-action:pan-y; }\n.lt-card { backdrop-filter:none;-webkit-backdrop-filter:none;contain:layout style; }\n.lt-card-art img { content-visibility:auto; }\n.lt-atmosphere img { filter:blur(30px) saturate(1.15); }\n.lt-player-wallpaper img { filter:blur(28px) saturate(1.1);transform:scale(1.1); }\n:where(#lt-shell,.lt-dialog) button { transition:background-color .08s,color .08s; }\n@media(max-height:620px) and (min-width:701px) {\n  #lt-now-playing .lt-art-frame { width:min(100%,max(105px,calc(100dvh - var(--lt-header) - var(--lt-chrome-height) - 330px)),215px); }\n  #lt-now-playing .lt-np-record { gap:6px;padding-bottom:4px; }\n  #lt-now-playing .lt-np-layout { padding-top:0;padding-bottom:8px; }\n}\n@media(max-width:700px) {\n  #lt-now-playing[open] { overflow-y:auto; }\n  #lt-now-playing .lt-np-layout { grid-template-columns:minmax(0,1fr);flex:1 0 auto;gap:16px;min-height:min-content; }\n  #lt-now-playing .lt-np-record { overflow:visible; }\n  #lt-now-playing .lt-art-frame { width:min(100%,230px,29dvh); }\n  #lt-now-playing .lt-lyrics-panel { min-height:300px;height:52dvh !important; }\n  #lt-now-playing[data-lyrics=\"false\"] .lt-np-record { display:flex; }\n  #lt-now-playing[data-lyrics=\"false\"] .lt-art-frame { width:min(100%,300px,35dvh); }\n  #lt-now-playing .lt-np-bottom { flex-wrap:wrap; }\n}\nbody[data-lt-lite=\"true\"] #lt-now-playing .lt-lyrics-panel { backdrop-filter:none;-webkit-backdrop-filter:none; }\n#lt-now-playing .lt-lyrics-panel { display:flex;flex-direction:column;overflow:hidden; }\n.lt-lyrics-heading,#lt-lyrics-status { flex:0 0 auto; }\n#lt-lyrics-lines { min-height:0;flex:1;overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;scrollbar-width:thin; }\n\n/* 1.5: interactive gestures, safe lyric reflow, and per-recording timing. */\n#lt-now-playing .lt-lyrics-exit-ghost { position:absolute !important;z-index:7;pointer-events:none;overflow:hidden; }\n#lt-now-playing .lt-motion-lyric-lines { min-height:0;flex:1;overflow:hidden; }\n#lt-now-playing .lt-motion-lyric-status { color:var(--lt-muted);font-size:calc(12px * var(--lt-text-scale));line-height:1.4;margin:0 0 20px;flex:none; }\n.lt-lyrics-heading { flex-wrap:wrap; }\n.lt-lyrics-heading > div { display:flex;gap:6px;align-items:center; }\n#lt-now-playing .lt-lyric-timing {\n  flex:0 1 auto;max-height:min(245px,45dvh);overflow-y:auto;overscroll-behavior:contain;\n  touch-action:pan-y;border-radius:calc(var(--lt-radius)*.65);padding:12px;margin:0 0 14px;\n  background:rgba(var(--lt-glass-rgb),.65);backdrop-filter:none;-webkit-backdrop-filter:none;\n}\n#lt-timing-note,#lt-timing-help { margin:0 0 8px;color:var(--lt-muted);font-size:calc(12px * var(--lt-text-scale));line-height:1.4; }\n#lt-timing-help { margin:8px 0 0; }\n#lt-timing-value { display:block;font-size:calc(16px * var(--lt-text-scale));font-weight:650;line-height:1.35;margin-bottom:10px;color:var(--lt-ink); }\n.lt-timing-buttons { display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px; }\n#lt-now-playing .lt-timing-buttons button { min-width:44px;min-height:44px;white-space:normal;border-radius:calc(var(--lt-radius)*.5);padding:8px;background:#ffffff12;font-size:calc(13px * var(--lt-text-scale)); }\n.lt-setting > .lt-pill { border-radius:var(--lt-radius);padding:10px 16px; }\n\n/* 1.6: one tint policy, optional panel overrides, a better balanced lyric deck. */\n.lt-glass { --lt-surface-opacity:var(--lt-glass-opacity); }\n.lt-header,.lt-windowbar .lt-caption-buttons { --lt-surface-opacity:var(--lt-header-opacity,var(--lt-glass-opacity)); }\n.lt-nav { --lt-surface-opacity:var(--lt-nav-opacity,var(--lt-glass-opacity)); }\n.lt-mini { --lt-surface-opacity:var(--lt-mini-opacity,var(--lt-glass-opacity)); }\n#lt-now-playing .lt-np-header,#lt-now-playing .lt-caption-buttons { --lt-surface-opacity:var(--lt-player-header-opacity,var(--lt-glass-opacity)); }\n#lt-now-playing .lt-lyrics-panel { --lt-surface-opacity:var(--lt-lyrics-opacity,var(--lt-glass-opacity)); }\n#lt-settings,#lt-settings .lt-caption-buttons { --lt-surface-opacity:var(--lt-settings-opacity,var(--lt-glass-opacity)); }\n#lt-history,#lt-history .lt-caption-buttons { --lt-surface-opacity:var(--lt-history-opacity,var(--lt-glass-opacity)); }\n:is(#lt-shell,#lt-now-playing,#lt-settings,#lt-history).lt-glass,\n:is(#lt-shell,#lt-now-playing,#lt-settings,#lt-history) .lt-glass {\n  background:linear-gradient(128deg,rgba(255,255,255,calc(var(--lt-surface-opacity) * .12)),transparent 45%,rgba(255,255,255,calc(var(--lt-surface-opacity) * .04))),rgba(var(--lt-glass-rgb),var(--lt-surface-opacity));\n}\n.lt-header { border-radius:var(--lt-radius);padding:0 6px;box-shadow:inset 0 1px 0 #ffffff20; }\n#lt-now-playing .lt-np-header { border:0;border-radius:0;box-shadow:none;min-height:calc(var(--lt-touch) + 12px); }\n:is(#lt-settings,#lt-history) :is(.lt-sheet-header,.lt-np-header) { border:0;border-bottom:1px solid #ffffff18;box-shadow:none; }\nbody.lt-active :is(.Root__main-view,[data-lt-native=\"main\"]) { background:rgba(var(--lt-glass-rgb),var(--lt-glass-opacity)) !important; }\nbody.lt-active .Root { --background-base:rgba(var(--lt-glass-rgb),var(--lt-glass-opacity));--background-elevated-base:rgba(var(--lt-glass-rgb),var(--lt-glass-opacity)); }\n#lt-now-playing .lt-player-wallpaper::after { background:rgba(var(--lt-glass-rgb),var(--lt-glass-opacity)); }\n:is(#lt-settings,#lt-history)::backdrop { background:transparent;backdrop-filter:blur(12px); }\n.lt-dialog button[aria-pressed=\"true\"],.lt-scale-control button,.lt-setting-text,.lt-setting select {\n  background-color:rgba(255,255,255,calc(var(--lt-glass-opacity) * .24));\n}\n.lt-header > button,.lt-mini button[data-action=\"togglePlay\"] { background:rgba(255,255,255,calc(var(--lt-surface-opacity) * .3)) !important; }\n.lt-nav button[aria-current=\"page\"] { background:linear-gradient(125deg,rgba(255,255,255,calc(var(--lt-surface-opacity) * .4)),rgba(255,255,255,calc(var(--lt-surface-opacity) * .15))) !important; }\n#lt-now-playing .lt-lyrics-heading button,#lt-now-playing .lt-timing-buttons button { background:rgba(255,255,255,calc(var(--lt-surface-opacity) * .25)); }\n.lt-opacity-options { margin:16px 0;padding:12px;border:1px solid #ffffff30;border-radius:calc(var(--lt-radius) * .65); }\n.lt-opacity-options summary { min-height:44px;align-content:center;font-size:calc(17px * var(--lt-text-scale));font-weight:600;cursor:pointer;touch-action:manipulation; }\n.lt-opacity-options > .lt-pill { margin:12px 0;padding:10px 16px;border-radius:var(--lt-radius);font-size:calc(14px * var(--lt-text-scale)); }\n.lt-opacity-panel { border-top:1px solid #ffffff25;margin-top:12px;padding-top:12px; }\n.lt-opacity-mode { display:flex;align-items:center;gap:10px;font-size:calc(14px * var(--lt-text-scale)); }\n.lt-opacity-mode > span:first-child { flex:1;font-weight:600; }\n.lt-opacity-panel .lt-setting { border-bottom:0;min-height:0;padding:8px 0; }\n.lt-opacity-panel .lt-setting label { position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%); }\n.lt-opacity-mode .lt-toggle { border-radius:999px !important;width:64px;min-width:64px;background:#ffffff12 !important;position:relative; }\n.lt-opacity-mode .lt-toggle::before { content:\"\";position:absolute;width:25px;height:25px;left:9px;top:50%;margin-top:-12.5px;border-radius:50%;background:#d7e0ed;transition:transform .1s; }\n.lt-opacity-mode .lt-toggle[aria-checked=\"true\"] { background:#b4eedc33 !important; }\n.lt-opacity-mode .lt-toggle[aria-checked=\"true\"]::before { transform:translateX(21px);background:var(--lt-accent); }\n.lt-opacity-options:focus-visible,.lt-opacity-options summary:focus-visible { outline:3px solid var(--lt-accent);outline-offset:3px; }\n#lt-now-playing[data-lyrics=\"true\"] .lt-art-frame {\n  width:min(100%,360px,max(110px,calc((100dvh - var(--lt-chrome-height) - var(--lt-header) - 70px) * .5)));\n}\n#lt-now-playing[data-lyrics=\"true\"] .lt-np-controls { max-width:420px; }\n#lt-now-playing[data-lyrics=\"true\"] #lt-np-title { font-size:calc(18px * var(--lt-text-scale)); }\n#lt-now-playing[data-lyrics=\"true\"] #lt-np-artist { font-size:calc(13px * var(--lt-text-scale)); }\n#lt-now-playing[data-lyrics=\"true\"] .lt-transport > button { width:max(44px,calc(40px * var(--lt-ui-scale)));height:max(44px,calc(40px * var(--lt-ui-scale))); }\n#lt-now-playing[data-lyrics=\"true\"] .lt-transport > button.lt-play-large { min-width:48px;min-height:48px;width:calc(48px * var(--lt-ui-scale));height:calc(48px * var(--lt-ui-scale)); }\n#lt-now-playing[data-lyrics=\"true\"] .lt-transport > button svg { width:calc(26px * var(--lt-ui-scale));height:calc(26px * var(--lt-ui-scale)); }\n#lt-now-playing[data-lyrics=\"true\"] .lt-play-large svg { width:calc(26px * var(--lt-ui-scale)) !important;height:calc(26px * var(--lt-ui-scale)) !important; }\n@media(max-height:620px) and (min-width:701px) {\n  #lt-now-playing[data-lyrics=\"true\"] .lt-art-frame { width:min(100%,max(110px,calc(100dvh - var(--lt-header) - var(--lt-chrome-height) - 285px)),245px); }\n}\n@media(max-width:700px) {\n  #lt-now-playing[data-lyrics=\"true\"] .lt-art-frame { width:min(100%,265px,33dvh); }\n}\nbody[data-lt-motion=\"reduce\"] .lt-opacity-mode .lt-toggle::before { transition:none; }\n@media(prefers-reduced-motion:reduce) { .lt-opacity-mode .lt-toggle::before { transition:none; } }\n\n/* 1.6.1: viewport-only player, visibly larger artwork, taller search keys. */\n#lt-now-playing .lt-art-frame {\n  --lt-record-art-base:min(440px,calc(100dvh - var(--lt-header) - var(--lt-chrome-height) - 50px));\n}\n#lt-now-playing[data-lyrics=\"true\"] .lt-art-frame {\n  --lt-record-art-base:min(360px,max(110px,calc((100dvh - var(--lt-chrome-height) - var(--lt-header) - 70px) * .5)));\n}\n@media(max-height:620px) and (min-width:701px) {\n  #lt-now-playing[data-lyrics=\"true\"] .lt-art-frame {\n    --lt-record-art-base:min(max(110px,calc(100dvh - var(--lt-header) - var(--lt-chrome-height) - 285px)),245px);\n  }\n}\n@media(max-width:700px) {\n  #lt-now-playing[data-lyrics=\"true\"] .lt-art-frame { --lt-record-art-base:min(265px,33dvh); }\n  #lt-now-playing[data-lyrics=\"false\"] .lt-art-frame { --lt-record-art-base:min(300px,35dvh); }\n}\n#lt-now-playing:is([data-lyrics=\"true\"],[data-lyrics=\"false\"]) .lt-art-frame {\n  width:min(100%,calc(var(--lt-record-art-base) * var(--lt-artwork-scale)));\n  min-width:0;flex-shrink:0;\n}\n.lt-keyboard {\n  --lt-key-height:clamp(44px,calc(44px * var(--lt-ui-scale) * var(--lt-keyboard-scale)),max(44px,calc((100dvh - var(--lt-chrome-height) - var(--lt-header) - 84px) / 4)));\n  z-index:14;\n}\n#lt-keyboard .lt-kb-row button {\n  min-height:var(--lt-key-height) !important;height:var(--lt-key-height);\n  font-size:calc(19px * min(var(--lt-text-scale),1.5)) !important;\n}\n#lt-keyboard .lt-kb-row button:is(.lt-kb-wide,.lt-kb-space) { font-size:calc(15px * min(var(--lt-text-scale),1.5)) !important; }\n#lt-search-preview { max-height:var(--lt-preview-room,calc(100dvh - var(--lt-chrome-height) - var(--lt-header) - 34px)); }\n#lt-search-preview[data-no-room=\"true\"] { visibility:hidden;pointer-events:none; }\n\n/* 1.7: one Settings surface, linked navigation, key feedback and queue artwork. */\nbody.lt-active[data-lt-custom-page]:not([data-lt-custom-page=\"\"]) :is(.Root__main-view,[data-lt-native=\"main\"]) { opacity:0 !important;pointer-events:none !important; }\n#lt-settings[open] { display:flex;flex-direction:column;overflow:hidden; }\n#lt-settings .lt-sheet-header { position:relative;top:auto;flex:0 0 auto;background:none !important;backdrop-filter:none;-webkit-backdrop-filter:none;border:0;box-shadow:none; }\n#lt-settings .lt-settings-content { min-height:0;flex:1 1 auto;overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;background:none; }\n#lt-history .lt-np-header { background:none !important;backdrop-filter:none;-webkit-backdrop-filter:none;box-shadow:none; }\n#lt-settings::backdrop,#lt-history::backdrop { backdrop-filter:none;-webkit-backdrop-filter:none;background:transparent; }\n#lt-settings,#lt-history,.lt-nav,.lt-mini {\n  backdrop-filter:blur(calc(18px * var(--lt-surface-opacity))) saturate(160%);\n  -webkit-backdrop-filter:blur(calc(18px * var(--lt-surface-opacity))) saturate(160%);\n  border-color:rgba(229,243,255,calc(var(--lt-surface-opacity) * .45));\n  box-shadow:0 8px 30px rgba(3,7,19,calc(var(--lt-surface-opacity) * .2)),inset 0 1px 0 rgba(255,255,255,calc(var(--lt-surface-opacity) * .4));\n}\n:is(#lt-settings,#lt-history,.lt-nav,.lt-mini):is([data-lt-clear=\"true\"],[data-lt-solid=\"true\"]),\nbody[data-lt-lite=\"true\"] :is(#lt-settings,#lt-history,.lt-nav,.lt-mini) { backdrop-filter:none;-webkit-backdrop-filter:none; }\n#lt-settings,#lt-history { backdrop-filter:none;-webkit-backdrop-filter:none; }\n#lt-settings::before,#lt-history::before { content:\"\";position:absolute;inset:0;z-index:-1;pointer-events:none;border-radius:inherit;backdrop-filter:blur(calc(18px * var(--lt-surface-opacity))) saturate(160%);-webkit-backdrop-filter:blur(calc(18px * var(--lt-surface-opacity))) saturate(160%); }\n:is(#lt-settings,#lt-history):is([data-lt-clear=\"true\"],[data-lt-solid=\"true\"])::before,\nbody[data-lt-lite=\"true\"] :is(#lt-settings,#lt-history)::before { backdrop-filter:none;-webkit-backdrop-filter:none; }\n.lt-nav { position:relative;isolation:isolate; }\n.lt-nav-selection { position:absolute;top:4px;bottom:4px;pointer-events:none;z-index:0;border-radius:calc(var(--lt-radius) * 1.5);background:linear-gradient(125deg,rgba(255,255,255,calc(var(--lt-surface-opacity) * .4)),rgba(255,255,255,calc(var(--lt-surface-opacity) * .15)));box-shadow:inset 0 1px 0 rgba(255,255,255,calc(var(--lt-surface-opacity) * .25)); }\n.lt-nav > button { position:relative;z-index:1; }\n.lt-nav > button { color:color-mix(in srgb,var(--lt-ink) calc(var(--lt-nav-weight,0) * 100%),var(--lt-muted)) !important; }\n.lt-nav > button .lt-icon svg { color:color-mix(in srgb,var(--lt-accent) calc(var(--lt-nav-weight,0) * 100%),var(--lt-muted)); }\n.lt-nav button[aria-current=\"page\"] { background:none !important;box-shadow:none; }\n.lt-mini-art-stage { position:relative;display:block;flex:none;width:var(--lt-touch);height:var(--lt-touch);overflow:hidden;border-radius:max(10px,calc(var(--lt-radius) * .45)); }\n.lt-mini-art-stage .lt-cover-small { width:100%;height:100%;object-fit:cover;border-radius:0; }\n.lt-track-incoming { position:absolute;inset:0;display:block;width:100%;height:100%;object-fit:cover;z-index:1;pointer-events:none;will-change:transform; }\n.lt-track-outgoing { position:absolute;inset:0;display:block;width:100%;height:100%;object-fit:cover;z-index:2;pointer-events:none; }\n#lt-art { position:relative;z-index:0; }\n#lt-now-playing .lt-art-size-button { position:absolute;right:8px;bottom:8px;z-index:3;min-width:44px;min-height:44px;width:44px;height:44px;border-radius:50%;padding:10px;background:rgba(var(--lt-glass-rgb),.8);box-shadow:0 2px 10px #0005; }\n#lt-now-playing .lt-art-size-button svg { width:24px;height:24px; }\n#lt-keyboard .lt-kb-row button.lt-key-held { position:relative;z-index:2;transform:scale(1.08);background:#d8fff0 !important;color:#102d26;box-shadow:0 5px 18px #0005; }\n.lt-key-popup { position:fixed;display:grid;place-items:center;z-index:30;pointer-events:none;border-radius:18px;background:var(--lt-accent);color:var(--lt-accent-ink);border:1px solid #ffffffaa;box-shadow:0 8px 24px #0005;font-size:calc(25px * min(var(--lt-text-scale),1.5));font-weight:650; }\nbody[data-lt-motion=\"reduce\"] #lt-keyboard .lt-key-held { transform:none; }\n@media(prefers-reduced-motion:reduce) { #lt-keyboard .lt-kb-row button.lt-key-held { transform:none; } }\n\n/* 1.7.1: an explicit native detail handoff, matching footer glass, and only\n   genuinely overflowing player regions show a scrollbar. */\nbody.lt-active[data-lt-custom-page=\"\"] :is(.Root,.Root__top-container,.Root__main-view,[data-lt-native=\"main\"],[data-lt-native-layout],[data-lt-native-viewport]) {\n  opacity:1 !important;visibility:visible !important;content-visibility:visible !important;\n}\nbody.lt-active[data-lt-custom-page=\"\"] [data-lt-native-layout] {\n  display:flex !important;flex-direction:column !important;flex:1 1 0 !important;\n  width:100% !important;height:100% !important;min-width:0 !important;min-height:0 !important;max-height:none !important;\n}\nbody.lt-active[data-lt-custom-page=\"\"] [data-lt-native-viewport] {\n  display:block !important;flex:1 1 0 !important;width:100% !important;height:100% !important;\n  min-height:0 !important;max-height:none !important;overflow-y:auto !important;overscroll-behavior:contain;touch-action:pan-y;\n}\n#lt-now-playing .lt-np-record { overflow-x:hidden;scrollbar-gutter:auto; }\n#lt-now-playing,#lt-now-playing * { scrollbar-width:none !important;-ms-overflow-style:none; }\n#lt-now-playing::-webkit-scrollbar,#lt-now-playing *::-webkit-scrollbar,\n#lt-now-playing::-webkit-scrollbar-button,#lt-now-playing *::-webkit-scrollbar-button { display:none !important;width:0 !important;height:0 !important; }\n\n/* 1.8: owned card destinations and separate player accessibility scales. */\n.lt-detail-hero { display:grid;grid-template-columns:minmax(100px,min(28vw,240px)) minmax(0,1fr);gap:clamp(16px,3vw,36px);padding:clamp(16px,2vw,28px);border-radius:var(--lt-radius);margin-bottom:18px; }\n.lt-detail-art { position:relative;display:grid;place-items:center;aspect-ratio:1;overflow:hidden;border-radius:max(12px,calc(var(--lt-radius) - 6px));background:rgba(var(--lt-art-rgb),.35); }\n.lt-detail-art > svg { width:40% !important;height:40% !important;color:var(--lt-accent); }\n.lt-detail-art img { position:absolute;inset:0;width:100%;height:100%;object-fit:cover; }\n.lt-detail-copy { align-self:center;min-width:0; }\n.lt-detail-copy h1 { font-size:calc(clamp(24px,3vw,40px) * var(--lt-text-scale));line-height:1.12;letter-spacing:-.035em;overflow-wrap:anywhere;margin:8px 0 12px; }\n.lt-detail-copy p,.lt-detail-status { color:var(--lt-muted);font-size:calc(15px * var(--lt-text-scale));line-height:1.4; }\n.lt-detail-description { max-height:5.6em;overflow:auto; }\n#lt-shell .lt-detail-play { background:var(--lt-accent);color:var(--lt-accent-ink);min-width:100px; }\n.lt-detail-tracklist { display:grid;gap:8px;margin-bottom:28px; }\n#lt-shell .lt-detail-track { display:flex;align-items:center;justify-content:flex-start;gap:clamp(10px,2vw,20px);padding:12px 16px;border-radius:max(12px,calc(var(--lt-radius)*.65));width:100%;min-width:0;text-align:left;touch-action:pan-y; }\n.lt-detail-number,.lt-detail-duration { color:var(--lt-muted);font-size:calc(13px * var(--lt-text-scale));font-variant-numeric:tabular-nums; }\n.lt-detail-number { min-width:2ch; }\n.lt-detail-track img { flex:none;width:var(--lt-touch);height:var(--lt-touch);border-radius:max(8px,calc(var(--lt-radius)*.35));object-fit:cover; }\n.lt-detail-track-copy { flex:1;min-width:0;display:flex;flex-direction:column;gap:4px; }\n.lt-detail-track-copy strong { font-size:calc(17px * var(--lt-text-scale));line-height:1.3;overflow-wrap:anywhere; }\n.lt-detail-track-copy > span { font-size:calc(13px * var(--lt-text-scale));color:var(--lt-muted);line-height:1.3; }\n#lt-now-playing .lt-np-layout { --lt-text-scale:calc(var(--lt-app-text-scale,1.2) * var(--lt-player-text-scale,1));--lt-ui-scale:calc(var(--lt-app-ui-scale,1) * var(--lt-player-control-scale,1));--lt-touch:max(44px,calc(48px * var(--lt-ui-scale))); }\n#lt-now-playing .lt-np-controls .lt-transport { display:grid;grid-template-columns:repeat(5,minmax(44px,1fr));place-items:center;gap:4px; }\n#lt-now-playing .lt-np-controls .lt-transport > button { min-width:44px;min-height:44px;width:min(100%,max(44px,calc(40px * var(--lt-ui-scale))));height:max(44px,calc(40px * var(--lt-ui-scale))); }\n#lt-now-playing .lt-np-controls .lt-transport > button.lt-play-large { min-width:44px;min-height:48px;width:min(100%,max(48px,calc(48px * var(--lt-ui-scale))));height:max(48px,calc(48px * var(--lt-ui-scale))); }\n#lt-now-playing .lt-np-controls button svg { max-width:100%;max-height:100%; }\n#lt-now-playing .lt-np-track > button,#lt-now-playing .lt-volume > button { min-width:max(44px,calc(36px * var(--lt-ui-scale)));min-height:max(44px,calc(36px * var(--lt-ui-scale)));width:max(44px,calc(36px * var(--lt-ui-scale)));height:max(44px,calc(36px * var(--lt-ui-scale))); }\n#lt-now-playing .lt-np-controls .lt-range { min-height:max(44px,calc(36px * var(--lt-ui-scale))); }\n#lt-now-playing .lt-np-bottom { flex-wrap:wrap; }\n#lt-now-playing .lt-np-bottom button { min-height:max(44px,calc(36px * var(--lt-ui-scale))); }\n@media(max-width:560px) { .lt-detail-hero { grid-template-columns:minmax(0,1fr); }.lt-detail-art { width:min(58vw,210px);justify-self:center; }.lt-detail-number { display:none; } }\n#lt-now-playing .lt-lyrics-panel { --lt-text-scale:calc(var(--lt-app-text-scale,1.2) * var(--lt-player-lyrics-scale,1)); }\n.lt-card-face.lt-card-pending { outline:2px solid var(--lt-accent);outline-offset:-2px; }\n#lt-mini-open { touch-action:none; }\n#lt-now-playing::backdrop { background:transparent; }\n#lt-release { --lt-surface-opacity:var(--lt-settings-opacity,var(--lt-glass-opacity));width:min(680px,calc(100vw - 24px));max-width:calc(100vw - 24px);max-height:calc(100dvh - 100px);margin:84px auto 12px;padding:0;border-radius:var(--lt-radius);backdrop-filter:none;-webkit-backdrop-filter:none;background:rgba(var(--lt-glass-rgb),var(--lt-surface-opacity)); }\n#lt-release[open] { display:flex;flex-direction:column; }\n#lt-release .lt-windowbar { position:fixed;z-index:12; }\n#lt-release .lt-caption-buttons { --lt-surface-opacity:var(--lt-settings-opacity,var(--lt-glass-opacity)); }\n#lt-release::backdrop { background:#0003; }\n#lt-release::before { content:'';position:absolute;inset:0;z-index:-1;pointer-events:none;border-radius:inherit;backdrop-filter:blur(calc(18px * var(--lt-surface-opacity))); }\n#lt-release:is([data-lt-clear=true],[data-lt-solid=true])::before,body[data-lt-lite=true] #lt-release::before { backdrop-filter:none; }\n#lt-release .lt-sheet-header { flex:none;background:none;position:relative;top:auto;border:0; }\n.lt-release-content { padding:0 24px 20px;overflow:auto;min-height:0;font-size:calc(16px * var(--lt-text-scale));line-height:1.5; }\n.lt-release-content ul { margin:0 0 16px;padding-left:1.2em; }.lt-release-content li { margin:0 0 12px; }\n.lt-release-content pre { white-space:pre-wrap;overflow-wrap:anywhere;font:inherit; }\n.lt-release-content a { color:var(--lt-accent);text-decoration:underline;display:inline-flex;min-height:44px;align-items:center; }\n.lt-release-actions { display:flex;justify-content:flex-end;gap:12px;padding:12px 24px 20px;flex:none; }\n#lt-release .lt-pill { min-height:48px;padding:10px 22px;border-radius:var(--lt-radius);background:#ffffff18; }\n#lt-release [data-action=confirmUpdate] { color:var(--lt-accent-ink);background:var(--lt-accent); }\n.lt-updates-settings { padding-top:16px; }.lt-updates-settings h3 { font-size:calc(22px * var(--lt-text-scale)); }.lt-updates-settings .lt-settings-actions { display:flex;flex-wrap:wrap;gap:10px; }\n\n/* 1.9.2: compact, touch-accessible lyric options. */\n.lt-lyrics-tools { position:relative; }\n#lt-now-playing .lt-lyrics-heading { justify-content:flex-end; }\n#lt-now-playing [data-action=\"lyricsMenu\"] { min-width:48px;min-height:48px;font-size:30px;line-height:1; }\n#lt-lyrics-menu {\n  --lt-surface-opacity:var(--lt-lyrics-opacity,var(--lt-glass-opacity));\n  --lt-text-scale:calc(var(--lt-app-text-scale,1.2) * var(--lt-player-lyrics-scale,1));\n  position:fixed;z-index:20;margin:0;min-width:180px;width:max-content;max-width:calc(100vw - 40px);\n  max-height:calc(100dvh - 24px);overflow-y:auto;padding:8px;display:flex;flex-direction:column;gap:4px;\n  border:1px solid #ffffff40;border-radius:calc(var(--lt-radius)*.65);box-shadow:0 10px 28px #0005;\n}\n#lt-lyrics-menu[hidden] { display:none !important; }\n#lt-now-playing #lt-lyrics-menu button {\n  width:100%;min-width:44px;min-height:48px;padding:8px 12px;justify-content:flex-start;text-align:left;white-space:normal;\n  font-size:calc(14px * var(--lt-text-scale));border-radius:calc(var(--lt-radius)*.4);\n  background:rgba(255,255,255,calc(var(--lt-surface-opacity) * .25));\n}\n#lt-now-playing #lt-lyrics-menu button:focus-visible { outline:2px solid var(--lt-accent);outline-offset:-2px; }\n","integrity":"2aa68cd4e9cc76d2c715feddda1cddc0f85150145e3257189f0ecfc509cecf0d"};
  const launchBundled=function(){
// LiquidTouch 1.9.2 — MIT. Application source for the bundled runtime.
// Spotify keeps ownership of browsing, audio, authentication, and DRM.
(() => {
  "use strict";

  const VERSION = "1.9.2";
  const LIVE_REPLACEMENT=Boolean(window.LiquidTouch?.version && window.LiquidTouch.version!==VERSION);
  try { window.LiquidTouch?.destroy?.(); } catch (error) { console.warn("[LiquidTouch] Previous instance cleanup:", error); }
  const STORE = "liquid-touch.preferences.v1";
  const OWN = "#lt-shell, .lt-dialog, #lt-rescue, #lt-toast, #lt-startup-status";
  const CHROME_QUEUE = Symbol.for("LiquidTouch.windowChromeQueue");
  const CHROME_BASE_HEIGHT = Symbol.for("LiquidTouch.nativeChromeHeight");
  function queueChrome(job) {
    const pending = (window[CHROME_QUEUE] || Promise.resolve()).catch(()=>{}).then(job);
    window[CHROME_QUEUE] = pending;
    return pending;
  }
  const DEFAULT_UPDATE_FEED = "https://raw.githubusercontent.com/OrbitalShift4/Spotify-LiquidTouch/main/latest.json";
  const DEFAULTS = Object.freeze({
    enabled: true, palette: "glass", size: "comfort", keyboard: true,
    lite: false, reduceMotion: false, startPlayer: false, updateChecks: true, updateFeed: DEFAULT_UPDATE_FEED, homeClock: false, clockFormat: '24',
    textScale: 120, uiScale: 100, playerTextScale: 100, playerLyricsScale: 100, playerControlScale: 100, cardTapDelay: 400, keyboardHeight: 145, artworkSize: 135, glassOpacity: 35, headerOpacity: null, navOpacity: null, miniOpacity: null, playerHeaderOpacity: null, lyricsOpacity: null, settingsOpacity: null, historyOpacity: null, adaptive: true, windowControls: true, rounding: 32, welcome: "", welcomeSubtitle: "A little closer to the music.", lyrics: true, lyricsFallback: true, lyricsTextFallback: true
  });
  // A null override follows the universal setting, including future changes.
  const OPACITY_PANELS = [
    ['headerOpacity','--lt-header-opacity','Top toolbar'],
    ['navOpacity','--lt-nav-opacity','Floating navigation'],
    ['miniOpacity','--lt-mini-opacity','Mini player'],
    ['playerHeaderOpacity','--lt-player-header-opacity','Now Playing header'],
    ['lyricsOpacity','--lt-lyrics-opacity','Lyrics panel'],
    ['settingsOpacity','--lt-settings-opacity','Entire Settings window'],
    ['historyOpacity','--lt-history-opacity','Entire history window']
  ];
  const paths = {
    home: '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
    search: '<circle cx="10.5" cy="10.5" r="7"/><path d="m16 16 5 5"/>',
    library: '<path d="M4 4v16M9 4v16m5-16 6 16M3 7h7M3 17h7"/>',
    back: '<path d="m14 5-7 7 7 7"/>',
    down: '<path d="m5 9 7 7 7-7"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    play: '<path d="m8 4 12 8-12 8Z" fill="currentColor" stroke="none"/>',
    pause: '<path d="M6 4h4v16H6zm8 0h4v16h-4z" fill="currentColor" stroke="none"/>',
    next: '<path d="m5 5 11 7-11 7Z" fill="currentColor" stroke="none"/><path d="M19 5v14"/>',
    previous: '<path d="m19 5-11 7 11 7Z" fill="currentColor" stroke="none"/><path d="M5 5v14"/>',
    shuffle: '<path d="M3 6h3c4 0 8 12 12 12h3m-4-4 4 4-4 4M3 18h3c1 0 2-1 3-2M15 8c1-1 2-2 3-2h3m-4-4 4 4-4 4"/>',
    repeat: '<path d="m17 2 4 4-4 4M3 11V8a2 2 0 0 1 2-2h16M7 22l-4-4 4-4m14-3v5a2 2 0 0 1-2 2H3"/>',
    repeatOne: '<path d="m17 2 4 4-4 4M3 11V8a2 2 0 0 1 2-2h16M7 22l-4-4 4-4m14-3v5a2 2 0 0 1-2 2H3m8-8 2-1v6"/>',
    plus: '<circle cx="12" cy="12" r="9"/><path d="M8 12h8m-4-4v8"/>',
    saved: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
    speaker: '<path d="M3 9h4l5-4v14l-5-4H3Zm13-1a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>',
    muted: '<path d="M3 9h4l5-4v14l-5-4H3Zm13 0 6 6m0-6-6 6"/>',
    queue: '<path d="M3 5h18M3 11h18M3 17h10m4-2 5 3-5 3Z"/>',
    devices: '<rect x="2" y="3" width="14" height="12" rx="2"/><path d="M9 15v5H5m4 0h4"/><rect x="17" y="10" width="5" height="11" rx="1"/>',
    settings: '<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="3" fill="currentColor"/><circle cx="16" cy="17" r="3" fill="currentColor"/>',
    keyboard: '<rect x="2" y="5" width="20" height="14" rx="3"/><path d="M6 9h.01M10 9h.01M14 9h.01M18 9h.01M6 13h.01M10 13h.01M14 13h.01M18 13h.01M8 16h8"/>',
    enter: '<path d="M20 5v8H4m5-5-5 5 5 5"/>',
    minimize: '<path d="M5 12h14"/>',
    maximize: '<rect x="5" y="5" width="14" height="14" rx="3"/>',
    restore: '<path d="M9 5V3h12v12h-2"/><rect x="3" y="9" width="12" height="12" rx="2"/>',
    desktop: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M12 17v4m-4 0h8"/>',
    history: '<path d="M3 11a9 9 0 1 1 2.6 7M3 4v7h7m2-5v6l4 2"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z" fill="currentColor" stroke="none"/>',
    spark: '<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5Z"/>',
    art: '<rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 5-5 4 4 4-6 5 7"/>'
  };
  function icon(name) {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.spark}</svg>`;
  }
  function button(action, label, glyph, extra = "") {
    // Arguments are compile-time strings. Spotify data is ONLY written with textContent.
    return `<button type="button" data-action="${action}" aria-label="${label}" ${extra}><span class="lt-icon">${icon(glyph)}</span></button>`;
  }
  function loadPreferences() {
    let stored = {};
    try { stored = JSON.parse(localStorage.getItem(STORE) || "{}"); } catch { /* reset invalid local preferences */ }
    const value = { ...DEFAULTS };
    // Legacy playerFullscreen is intentionally ignored: the player fills the
    // app window and never requests or exits display fullscreen.
    for (const key of ["enabled", "keyboard", "lite", "reduceMotion", "startPlayer", "updateChecks", "homeClock", "adaptive", "windowControls", "lyrics", "lyricsFallback", "lyricsTextFallback"]) {
      if (typeof stored?.[key] === "boolean") value[key] = stored[key];
    }
    if (["glass", "ocean", "graphite"].includes(stored?.palette)) value.palette = stored.palette;
    if (["comfort", "large"].includes(stored?.size)) value.size = stored.size;
    if (["12", "24"].includes(stored?.clockFormat)) value.clockFormat = stored.clockFormat;
    for (const [key, lo, hi] of [["textScale",100,200],["uiScale",100,140],["playerTextScale",75,200],["playerLyricsScale",75,200],["playerControlScale",75,180],["cardTapDelay",200,700],["keyboardHeight",100,180],["artworkSize",60,200],["glassOpacity",0,100],["rounding",12,56],...OPACITY_PANELS.map(([key])=>[key,0,100])]) {
      if (typeof stored?.[key] === "number" && Number.isFinite(stored[key])) value[key] = clamp(Math.round(stored[key]), lo, hi);
    }
    if(stored?.playerLyricsScale===undefined)value.playerLyricsScale=value.playerTextScale;
    for(const key of ['settingsOpacity','historyOpacity'])if(stored?.[key]===undefined && typeof stored?.sheetOpacity==='number' && Number.isFinite(stored.sheetOpacity))value[key]=clamp(Math.round(stored.sheetOpacity),0,100);
    for (const key of ["welcome","welcomeSubtitle"]) if(typeof stored?.[key]==="string")value[key]=stored[key].slice(0,160);
    if(typeof stored?.updateFeed==='string' && stored.updateFeed.trim())value.updateFeed=stored.updateFeed.trim().slice(0,2000);
    return value;
  }
  function read(fn, fallback) { try { const v = fn(); return v ?? fallback; } catch { return fallback; } }
  function number(value, fallback = 0) { return Number.isFinite(Number(value)) ? Number(value) : fallback; }
  function clamp(value, lo, hi) { return Math.min(hi, Math.max(lo, value)); }
  function time(ms) { const s = Math.floor(Math.max(0, number(ms)) / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; }
  function imageURL(value) {
    if (typeof value !== "string") return "";
    // Spotify puts animated playing indicators in the same cards as covers.
    // They are state icons, never entity artwork.
    if (/(?:equalis|equaliz|visualis|visualiz|playing[-_]?indicator|audio[-_]?bars|spinner)(?:[^/]*)(?:\.|\/|\?|$)/i.test(value)) return "";
    if (/^spotify:image:[a-zA-Z0-9]+$/.test(value)) return `https://i.scdn.co/image/${value.split(":")[2]}`;
    if(/^spotify:mosaic:(?:[a-f0-9]{40}:?){2,4}$/i.test(value))return "https://mosaic.scdn.co/640/"+value.slice(15).replaceAll(":","");
    // Raster data URLs also allow the offline preview to use original artwork.
    if (/^data:image\/(?:png|jpeg|webp);base64,[a-zA-Z0-9+/=]+$/.test(value)) return value;
    // Do not permit script, file, or SVG data URLs from track metadata.
    if (/^https?:\/\//i.test(value)) return value;
    return "";
  }
  function windowBar() {
    return `<div class="lt-windowbar" aria-label="Window title bar"><div class="lt-window-drag"><span class="lt-heading-mark">${icon("spark")}</span><span>LiquidTouch</span></div><div class="lt-caption-buttons lt-glass">${button("windowMinimize","Minimize Spotify","minimize")}${button("windowMaximize","Maximize or restore Spotify","maximize")}${button("windowClose","Close Spotify window","close")}</div></div>`;
  }
  function trackFromState(state) {
    if (!state || typeof state !== "object") return null;
    const item = state.item || state.track || state.currentTrack || state.current_track;
    if (!item || typeof item !== "object") return null;
    const value = item.data && (item.data.uri || item.data.name || item.data.metadata) ? item.data : item;
    const m = value.metadata || {};
    return value.uri || value.name || m.title ? value : null;
  }
  function colorRGB(value) {
    if (typeof value !== "string") return null;
    const match = value.trim().match(/^#?([\da-f]{6})$/i);
    if (match) return [0,2,4].map(i=>parseInt(match[1].slice(i,i+2),16));
    const rgb = value.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/i);
    return rgb ? rgb.slice(1).map(n=>clamp(Number(n),0,255)) : null;
  }

  const cleanText = (value, length=500) => typeof value === "string" ? value.trim().slice(0,length) : "";
  function uriInfo(raw) {
    if (typeof raw !== "string") return null;
    if (/^https:\/\/open\.spotify\.com\//.test(raw)) { try { raw=new URL(raw).pathname; } catch { return null; } }
    if (raw === "/collection/tracks" || raw === "spotify:collection:tracks" || /^spotify:user:[^:]+:collection$/.test(raw)) return {uri:raw.startsWith("spotify:user:") ? raw : "spotify:collection:tracks",path:"/collection/tracks",type:"collection"};
    const match=raw.match(/^(?:spotify:(album|playlist|artist|track|episode|show):|\/(album|playlist|artist|track|episode|show)\/)([\w-]+)(?:$|[?#/])/);
    if (!match) return null;
    const type=match[1] || match[2], id=match[3];
    return {uri:`spotify:${type}:${id}`,path:`/${type}/${id}`,type};
  }
  function normalizeEntity(input) {
    if (!input || typeof input !== "object") return null;
    const value=input.item?.data || input.item || input.data || input;
    const info=uriInfo(value.uri || value.link || input.uri || "");
    if (!info) return null;
    const artists=Array.isArray(value.artists) ? value.artists : Array.isArray(value.artists?.items) ? value.artists.items : [];
    const images=value.images?.items || value.images?.sources || value.images || value.album?.images || value.image?.sources || value.coverArt?.sources || [];
    const first=Array.isArray(images) ? images[0] : images;
    const rawImage=value.imageUrl || value.image_url || (typeof value.image === "string" ? value.image : value.image?.uri) || (typeof first==='string' ? first : first?.url || first?.uri) || first?.sources?.[0]?.url || value.metadata?.image_xlarge_url || "";
    return {...info,title:cleanText(value.name || value.profile?.name || value.title || value.metadata?.title) || (info.type === "collection" ? "Liked Songs" : "Your music"),
      subtitle:cleanText(value.subtitle || value.owner?.displayName || value.owner?.name || artists.map(a=>typeof a === "string" ? a : a.name || a.profile?.name).filter(Boolean).join(", ")) || ({playlist:"Playlist",album:"Album",artist:"Artist",track:"Song",episode:"Episode",show:"Podcast",collection:"Playlist"}[info.type]),
      image:imageURL(rawImage) || pickArtwork(value), section:cleanText(value.section,100)};
  }
  function node(tag, className, text) {
    const result=document.createElement(tag); result.className=className;
    if (text !== undefined) result.textContent=String(text);
    return result;
  }

  function pickArtwork(value,depth=0){
    if(!value || depth>5)return '';if(typeof value==='string')return imageURL(value);
    if(Array.isArray(value)){for(const item of value){const result=pickArtwork(item,depth+1);if(result)return result;}return '';}
    for(const key of ['url','imageUrl','image_url','uri','images','image','pictures','picture','coverArt','sources','items','album','albumOfTrack','visuals','avatarImage','playlist','data']){const result=pickArtwork(value[key],depth+1);if(result)return result;}return '';
  }
  class LiquidTouchController {
    constructor(S) {
      this.S = S;
      this.accountNamespace=cleanText(S.Platform?.LocalStorageAPI?.namespace,100) || 'device';
      this.player = S.Player;
      this.history = S.Platform.History;
      this.hadSavedPreferences=Boolean(read(()=>localStorage.getItem(STORE),''));
      this.prefs = loadPreferences();
      this.abort = new AbortController();
      this.timers = new Set();
      this.destroyed = false;
      this.enabled = false;
      this.libraryOpen = false;
      this.editing = new Set();
      this.lastURI = null;
      this.lastImage = null;
      this.pendingColor = 0;
      this.keyboardShift = false;
      this.keyboardSymbols = false;
      this.suppressOpenUntil = 0;
      this.focusBeforeModal = new WeakMap();
      this.eventState = null;
      this.platformState = null;
      this.stateSource = "none";
      this.colorCache = new Map();
      this.chromeMode = "native";
      this.chromeBusy = false;
      this.nativeChromeOwned = false;
      this.chromeAttempts = 0;
      this.entities = new Map(); this.homeEntities = new Map(); this.libraryEntities = new Map();
      this.libraryFilter = "all"; this.libraryQuery = ""; this.libraryOffset = 0; this.libraryHasMore = true;
      this.playHistory = this.loadRecords("play-history",10000);
      this.recentSearches = this.loadRecords("search-items",50);
      this.searchQueries = this.loadRecords("search-queries",30);
      this.historyLimit = 100;
      this.routePath=this.history.location?.pathname || '/';this.viewStack=[];
      this.observedHostPath=this.routePath;this.tabViews=new Map();
      this.catalogVersion=0;this.searchCache=new Map();this.artCache=new Map();this.artJobs=[];this.artBusy=0;
      this.searchFlights=new Map();this.searchResultVersion=0;this.searchResults=[];this.searchFilter='all';
      this.lyricsCache=new Map();this.lyricLines=[];this.lyricIndex=-1;this.liveSearchToken=0;this.lyricsToken=0;
      this.motionAnimations=new Map();this.lyricOffsets=this.loadLyricOffsets();
      this.fastPointerClicks=new Map();
      this.browsePages=new Map();this.routeRequests=new Map();this.navigationSerial=0;
      this.detailPages=new Map();

    }
    later(fn, delay) {
      const id = setTimeout(() => { this.timers.delete(id); if (!this.destroyed) fn(); }, delay);
      this.timers.add(id);
      return id;
    }
    listen(node, type, fn, options = {}) {
      node.addEventListener(type, fn, { ...options, signal: this.abort.signal });
    }
    save() {
      try { localStorage.setItem(STORE, JSON.stringify(this.prefs)); }
      catch { this.notify("This session works, but your preferences could not be saved."); }
    }
    mount() {
      this.shell = document.createElement("div");
      this.shell.id = "lt-shell";
      this.shell.innerHTML = `
        ${windowBar()}
        <header class="lt-header lt-glass" aria-label="LiquidTouch toolbar">
          ${button("goBack", "Go back", "back")}
          <div class="lt-heading" id="lt-heading"><span class="lt-heading-mark">${icon("spark")}</span><span class="lt-heading-text" id="lt-page-title">Home</span></div>
          <form class="lt-search-form lt-glass" id="lt-search-form" role="search" hidden>
            <input id="lt-search-input" type="search" aria-label="Search Spotify" placeholder="Artists, songs, podcasts…" autocomplete="off" spellcheck="false" maxlength="300">
            ${button("keyboard", "Show or hide search keyboard", "keyboard", 'aria-expanded="false" aria-controls="lt-keyboard"')}
            <button type="submit" aria-label="Submit search"><span class="lt-icon">${icon("enter")}</span></button>
          </form>
          ${button("settings", "LiquidTouch settings", "settings")}
        </header>
        <main id="lt-browse" class="lt-browse lt-glass" aria-label="Music browser" hidden></main>
        <form id="lt-quick-search" class="lt-quick-search lt-glass" role="search" hidden><span class="lt-icon">${icon("search")}</span><input id="lt-quick-input" type="search" aria-label="Quick search" placeholder="Find a song, artist, or playlist" maxlength="300">${button("closeQuickSearch","Close quick search","close")}</form>
        <section id="lt-search-preview" class="lt-search-preview lt-glass" aria-label="Live search preview" hidden></section>
        <div class="lt-footer">
          <section class="lt-mini lt-glass" aria-label="Now playing mini player">
            <button type="button" id="lt-mini-open" data-action="nowPlaying" aria-label="Open Now Playing">
              <span class="lt-mini-art-stage"><img class="lt-cover-small" id="lt-mini-art" alt="" hidden></span>
              <span class="lt-track-text"><span class="lt-track-title" id="lt-mini-title">Your next good listen</span><span class="lt-track-artist" id="lt-mini-artist">Choose something in Spotify</span></span>
            </button>
            ${button("togglePlay", "Play", "play")}${button("next", "Next track", "next")}
            <div class="lt-mini-progress" aria-hidden="true"><span id="lt-mini-fill"></span></div>
          </section>
          <nav class="lt-nav lt-glass" aria-label="Main navigation">
            <span class="lt-nav-selection" aria-hidden="true"></span>
            <button type="button" data-action="home" aria-label="Home"><span class="lt-icon">${icon("home")}</span><span>Home</span></button>
            <button type="button" data-action="search" aria-label="Search"><span class="lt-icon">${icon("search")}</span><span>Search</span></button>
            <button type="button" data-action="library" aria-label="Your Library"><span class="lt-icon">${icon("library")}</span><span>Your Library</span></button>
          </nav>
        </div>
        <section id="lt-keyboard" class="lt-keyboard lt-glass" aria-label="Search keyboard" hidden>
          <div class="lt-kb-inner"><div class="lt-kb-toolbar"><span>Search keyboard</span>${button("hideKeyboard", "Hide keyboard", "down")}</div><div id="lt-key-rows"></div></div>
        </section>`;
      this.keyPopup=node('output','lt-key-popup');this.keyPopup.hidden=true;this.keyPopup.setAttribute('aria-hidden','true');this.shell.append(this.keyPopup);
      this.nowPlaying = document.createElement("dialog");
      this.nowPlaying.id = "lt-now-playing";
      this.nowPlaying.className = "lt-dialog";
      this.nowPlaying.setAttribute("aria-labelledby", "lt-np-title");
      this.nowPlaying.innerHTML = `
        <div class="lt-player-wallpaper" aria-hidden="true"><img id="lt-player-background" alt=""></div>
        ${windowBar()}
        <header class="lt-np-header lt-glass" id="lt-np-header">
          ${button("closePlayer", "Close Now Playing", "down", "autofocus")}
          <div class="lt-context" aria-hidden="true"></div>
          ${button("playerSettings", "LiquidTouch settings", "settings")}
        </header>
        <div class="lt-np-layout">
          <div class="lt-np-record"><div class="lt-art-area" id="lt-art-swipe"><div class="lt-art-frame"><img id="lt-art" alt="Album artwork" hidden>${button('artworkSettings','Adjust artwork size','art','class="lt-art-size-button" title="Artwork size"')}</div></div>
          <div class="lt-np-controls">
            <div class="lt-np-track"><div><h1 id="lt-np-title">Nothing playing yet</h1><p id="lt-np-artist">Pick a song to get started</p></div>${button("toggleHeart", "Save to your library", "plus", 'aria-pressed="false"')}</div>
            <input class="lt-range" id="lt-seek" type="range" min="0" max="1000" value="0" step="1" aria-label="Playback position" disabled>
            <div class="lt-timestamps"><span id="lt-elapsed">0:00</span><span id="lt-duration">0:00</span></div>
            <div class="lt-transport" aria-label="Playback controls">
              ${button("toggleShuffle", "Turn shuffle on", "shuffle", 'aria-pressed="false"')}
              ${button("back", "Previous track", "previous")}
              ${button("togglePlay", "Play", "play", 'class="lt-play-large"')}
              ${button("next", "Next track", "next")}
              ${button("toggleRepeat", "Repeat off", "repeat", 'aria-pressed="false"')}
            </div>
            <div class="lt-volume">${button("toggleMute", "Mute", "speaker", 'aria-pressed="false"')}<input class="lt-range" id="lt-volume" type="range" min="0" max="100" value="50" step="1" aria-label="Volume"><span id="lt-volume-text" aria-hidden="true">50%</span></div>
            <div class="lt-np-bottom">
              <button type="button" data-action="devices" aria-label="Open Spotify desktop controls for devices"><span class="lt-icon">${icon("devices")}</span><span>Devices</span></button>
              <button type="button" data-action="toggleLyrics" aria-label="Show or hide lyrics"><span class="lt-icon">${icon("queue")}</span><span>Lyrics</span></button><button type="button" data-action="queue" aria-label="Open play queue"><span class="lt-icon">${icon("queue")}</span><span>Queue</span></button>
            </div>
          </div>
          </div>
          <section id="lt-lyrics-panel" class="lt-lyrics-panel lt-glass" aria-label="Live lyrics"><header class="lt-lyrics-heading"><div class="lt-lyrics-tools"><button type="button" data-action="lyricsMenu" aria-label="Lyrics options" aria-haspopup="menu" aria-expanded="false" aria-controls="lt-lyrics-menu"><span aria-hidden="true">⋯</span></button><div id="lt-lyrics-menu" class="lt-glass" role="menu" aria-label="Lyrics options" hidden><button type="button" role="menuitem" data-action="lyricTiming" aria-label="Adjust lyrics timing" aria-expanded="false">Timing…</button><button type="button" role="menuitem" data-action="retryLyrics" aria-label="Retry loading lyrics">Reload lyrics</button></div></div></header><p id="lt-lyrics-status" role="status">Lyrics load when available.</p><section id="lt-lyric-timing" class="lt-lyric-timing lt-glass" aria-label="Lyrics timing for this recording" hidden><p id="lt-timing-note">Saved separately for this recording and lyric source.</p><output id="lt-timing-value" aria-live="polite">Original timing</output><div class="lt-timing-buttons"><button type="button" data-action="lyricsEarlier" aria-label="Show lyrics 0.25 seconds earlier">Earlier</button><button type="button" data-action="lyricsLater" aria-label="Show lyrics 0.25 seconds later">Later</button><button type="button" data-action="lyricsTimingReset">Reset</button><button type="button" data-action="lyricsMatchLine" aria-pressed="false">Match a line</button></div><p id="lt-timing-help">Lyrics late? Tap Earlier. Or choose Match a line, then tap the line you hear.</p></section><div id="lt-lyrics-lines"></div></section>
        </div>`;
      this.settings = document.createElement("dialog");
      this.settings.id = "lt-settings";
      this.settings.className = "lt-dialog lt-glass";
      this.settings.setAttribute("aria-labelledby", "lt-settings-title");
      const toggle = (key, label, help) => `<div class="lt-setting"><div><label id="lt-label-${key}">${label}</label><small>${help}</small></div><button type="button" class="lt-toggle" role="switch" data-pref="${key}" aria-checked="false" aria-labelledby="lt-label-${key}"></button></div>`;
      const scale = (key, label, help, min, max, step) => `<div class="lt-setting lt-setting-range"><div><label for="lt-${key}">${label}</label><small>${help}</small></div><div class="lt-scale-control"><button type="button" data-adjust="${key}" data-delta="-${step}" aria-label="Decrease ${label.toLowerCase()}">−</button><input id="lt-${key}" class="lt-range" type="range" min="${min}" max="${max}" step="${step}" data-pref="${key}" aria-label="${label}"><output id="lt-${key}-value" for="lt-${key}"></output><button type="button" data-adjust="${key}" data-delta="${step}" aria-label="Increase ${label.toLowerCase()}">+</button></div></div>`;
      this.settings.innerHTML = `
        ${windowBar()}
        <header class="lt-sheet-header"><div><h2 id="lt-settings-title">Make it yours.</h2><p>LiquidTouch · ${VERSION}</p></div>${button("closeSettings", "Close settings", "close", "autofocus")}</header>
        <div class="lt-settings-content">
          ${scale("artworkSize","Player artwork size","Shrink or enlarge the cover, with lyrics on or off. Also available from the picture button on the artwork.",60,200,5)}
          ${scale("playerTextScale","Now Playing text size","Scale song details without changing lyrics or other pages.",75,200,5)}
          ${scale("playerLyricsScale","Lyrics text size","Scale lyric lines and their panel text independently of song details.",75,200,5)}
          ${scale("playerControlScale","Now Playing control size","Scale playback buttons, icons and sliders relative to the app interface. Touch targets stay at least 44 px.",75,180,5)}
          ${scale("cardTapDelay","Card tap timing","Single-tap playback waits this long for a second tap. Double taps open without playing.",200,700,25)}
          <div class="lt-setting lt-setting-range"><label for="lt-welcome">Home welcome</label><small>Leave blank for a time-of-day greeting, or use {greeting} in custom text. Good morning/afternoon/evening phrases follow the time of day.</small><input id="lt-welcome" class="lt-setting-text" data-text-pref="welcome" type="text" maxlength="160" placeholder="{greeting}, Saif."></div>
          <div class="lt-setting lt-setting-range"><label for="lt-welcomeSubtitle">Welcome subtitle</label><input id="lt-welcomeSubtitle" class="lt-setting-text" data-text-pref="welcomeSubtitle" type="text" maxlength="160"></div>
          ${toggle("homeClock", "Show Home clock", "Display your device’s local time beside the Home greeting.")}
          <div class="lt-setting"><div><label for="lt-clockFormat">Clock format</label><small>Choose 12-hour time with AM/PM or 24-hour time.</small></div><select id="lt-clockFormat" data-pref="clockFormat"><option value="12">12-hour</option><option value="24">24-hour</option></select></div>
          ${toggle("lyrics", "Live lyrics beside artwork", "Show lyrics beside the artwork and compact controls. Tap a timed line to seek.")}
          ${toggle("lyricsFallback", "Broader lyric lookup", "Try LRCLIB exact lookup and recording-aware search when Spotify has no timed lyrics. No account is sent.")}
          ${toggle("lyricsTextFallback", "Additional text lyrics", "If no lyrics were found, also try lyrics.ovh. Text-only lyrics are readable but cannot seek. Uses track and artist names only.")}
          <div class="lt-setting"><div><label>Current song’s lyric timing</label><small>Correct a recording without changing other songs. Positive adjustment shows lyrics earlier.</small></div><button type="button" class="lt-pill" data-action="openLyricTiming">Adjust</button></div>

          ${scale("textScale","Text size","Larger type across browsing, the player, and menus.",100,200,10)}
          ${scale("uiScale","Interface size","Roomier buttons, spacing, and text fields.",100,140,10)}
          <div class="lt-setting"><div><label for="lt-palette">Glass tint</label><small>A little atmosphere, without losing contrast.</small></div><select id="lt-palette" data-pref="palette"><option value="glass">Aurora</option><option value="ocean">Ocean</option><option value="graphite">Graphite</option></select></div>
          <div class="lt-setting"><div><label for="lt-size">Touch controls</label><small>Comfort: 48 px. Large: 56 px.</small></div><select id="lt-size" data-pref="size"><option value="comfort">Comfort</option><option value="large">Large</option></select></div>
          ${scale("glassOpacity","Universal glass opacity","0% clears the glass tint; 100% makes it solid. Text and artwork keep their full visibility.",0,100,1)}
          <details class="lt-opacity-options"><summary>Panel opacity overrides</summary><p class="lt-note">Every panel follows Universal by default. Enable Custom for a panel to choose its own 0–100% tint.</p>
            <button type="button" class="lt-pill" data-action="resetOpacity">Use universal for all panels</button>
            ${OPACITY_PANELS.map(([key,,label])=>`<section class="lt-opacity-panel"><div class="lt-opacity-mode"><span>${label}</span><span>Custom</span><button type="button" class="lt-toggle" role="switch" data-opacity-override="${key}" aria-checked="false" aria-label="Custom opacity for ${label.toLowerCase()}"></button></div>${scale(key,label+' opacity','Follow universal, or enable Custom above.',0,100,1)}</section>`).join('')}
          </details>
          ${scale("rounding","Corner rounding","Round the cards, fields, menus, and player surfaces.",12,56,2)}
          ${toggle("adaptive", "Artwork atmosphere", "Match backgrounds and glass to the current track’s artwork.")}
          ${toggle("windowControls", "Glass window buttons", "Matching minimize, maximize, and close controls when supported.")}
          ${toggle("keyboard", "Built-in keyboard", "A local English keyboard for search. Turn off to use your system keyboard, including Arabic.")}
          ${scale("keyboardHeight","Keyboard height","Taller keys without widening the keyboard. Height adapts to leave the search field accessible.",100,180,5)}
          ${toggle("lite", "Lighter glass", "Turn off blur for quieter, cooler mini PCs. Your opacity setting still applies.")}
          ${toggle("reduceMotion", "Reduce motion", "Keep the shine. Skip the movement.")}
          ${toggle("startPlayer", "Open in Now Playing", "Start on the expanded player next time Spotify opens.")}
          <section class="lt-updates-settings"><h3>Updates</h3><p class="lt-note">Import one update file here. A trusted hosted release feed also enables Update / Later notifications.</p><label for="lt-update-feed">Release feed URL</label><input id="lt-update-feed" class="lt-setting-text" type="url" maxlength="2000" placeholder="https://your-release-host/latest.json"><p id="lt-update-status" class="lt-note" role="status">No hosted release feed is configured.</p>
          ${toggle("updateChecks","Check for updates","Check the configured feed at launch and about every six hours. Installation always asks first.")}
          <div class="lt-settings-actions"><button type="button" data-action="checkUpdates">Check now</button><button type="button" data-action="importUpdate">Import update file</button><button type="button" data-action="releaseNotes">What’s new</button><button type="button" data-action="restoreRuntime">Restore installed version</button></div><input id="lt-update-file" type="file" accept=".json,.ltupdate" hidden></section>
          <div class="lt-settings-actions"><button type="button" data-action="playHistory"><span class="lt-icon">${icon("history")}</span><span>Listening history</span></button><button type="button" data-action="desktop"><span class="lt-icon">${icon("desktop")}</span><span>Desktop interface</span></button></div>
          <p class="lt-note">Tap a playlist or album card to play; double tap to open it. Swipe artwork to skip, or swipe the player header down to close it. Ctrl + Alt + T switches interfaces. Devices opens Spotify’s desktop controls.</p>
        </div>`;
      this.historyPage=document.createElement("dialog");
      this.historyPage.id="lt-history"; this.historyPage.className="lt-dialog lt-glass";
      this.historyPage.setAttribute("aria-labelledby","lt-history-title");
      this.historyPage.innerHTML=`${windowBar()}<header class="lt-np-header"><div class="lt-context"><span class="lt-eyebrow">YOUR LISTENING JOURNAL</span><h2 id="lt-history-title">Listening history</h2></div>${button("closeHistory","Close listening history","close")}</header><div class="lt-history-tools"><label class="lt-field lt-glass"><span class="lt-icon">${icon("search")}</span><input id="lt-history-search" type="search" placeholder="Search songs, artists, albums, or dates" aria-label="Search listening history" maxlength="300"></label><p id="lt-history-count" role="status"></p><p class="lt-note">Saved on this device from this version onward. Times use your computer’s local time.</p></div><div id="lt-history-list" class="lt-history-list"></div>`;
      this.releaseDialog=document.createElement('dialog');this.releaseDialog.id='lt-release';this.releaseDialog.className='lt-dialog lt-glass';this.releaseDialog.setAttribute('aria-labelledby','lt-release-title');
      this.releaseDialog.innerHTML=`${windowBar()}<header class="lt-sheet-header"><div><h2 id="lt-release-title"></h2><p id="lt-release-subtitle"></p></div>${button('closeRelease','Close update window','close')}</header><div class="lt-release-content"><ul id="lt-release-summary"></ul><pre id="lt-full-release-notes" hidden></pre><p id="lt-release-status" role="status"></p><a href="#lt-full-release-notes" data-action="fullReleaseNotes">Full patch notes</a></div><footer class="lt-release-actions"><button type="button" data-action="confirmUpdate" class="lt-pill">Update</button><button type="button" data-action="closeRelease" class="lt-pill">Later</button></footer>`;
      this.atmosphere=node("div","lt-atmosphere"); this.atmosphere.id="lt-atmosphere";
      this.atmosphere.setAttribute("aria-hidden","true");
      this.ambientArt=node("img",""); this.ambientArt.alt=""; this.ambientArt.hidden=true;
      this.atmosphere.append(this.ambientArt);
      this.rescue = document.createElement("button");
      this.rescue.id = "lt-rescue";
      this.rescue.type = "button";
      this.rescue.setAttribute("aria-label", "Return to LiquidTouch interface");
      this.rescue.innerHTML = `${icon("spark")}<span>Touch UI</span>`;
      this.rescue.hidden = true;
      this.toast = document.createElement("div");
      this.toast.id = "lt-toast";
      this.toast.setAttribute("role", "status");
      this.toast.setAttribute("aria-live", "polite");
      this.toast.hidden = true;
      document.body.append(this.atmosphere, this.shell, this.nowPlaying, this.settings, this.historyPage, this.releaseDialog, this.rescue, this.toast);
      this.$ = id => document.getElementById(id);
      // Keep the popup outside the lyric scroller so it cannot be clipped.
      this.nowPlaying.append(this.$("lt-lyrics-menu"));
      this.searchInput = this.$("lt-search-input");
      this.seek = this.$("lt-seek");
      this.volume = this.$("lt-volume");
      this.browse = this.$("lt-browse");
      this.refreshNative();
      this.applyPreferences();
      this.buildKeyboard();
      this.bind();
      this.enable(this.prefs.enabled, false);
      this.routeChanged();
      this.render();
      void this.syncWindowChrome();
      this.bindReleaseFeatures();
      this.later(()=>void this.loadLibrary(true),120);
      this.later(()=>this.queueReleaseNotes(),1000);this.later(()=>this.maybeCheckUpdates(),1800);
      if (this.prefs.startPlayer && this.enabled) void this.showPlayer();
      this.syncLyricClock();
      this.interval = setInterval(() => {
        if (this.enabled && !document.hidden) {
          if (this.observedHostPath !== this.history.location?.pathname)this.acceptHostRoute(this.history.location?.pathname || '/');
          this.render();
          if(Date.now()-(this.lastGreetingCheck || 0)>30000)this.refreshGreeting();
          if(this.prefs.homeClock)this.refreshHomeClock();
          this.refreshPlatformState();
          if (++this.chromeAttempts % 4 === 0){void this.syncWindowChrome();this.flushReleasePrompt();this.maybeCheckUpdates();}
        }
      }, 500);
      if (this.S.Menu?.Item) {
        // Profile-menu APIs vary independently of playback. This convenience
        // entry must never prevent the entire touch interface from starting.
        try {
          this.menu = new this.S.Menu.Item("LiquidTouch settings", false, () => {
            this.enable(true); this.openDialog(this.settings);
          });
          this.menu.register();
        } catch (error) { console.warn("[LiquidTouch] Optional profile menu unavailable:", error); }
      }
    }
    getRoutePath(){return this.routePath || this.history.location?.pathname || '/';}
    motionAllowed(){return !this.prefs.reduceMotion && !matchMedia('(prefers-reduced-motion: reduce)').matches;}
    stopMotion(){
      this.clearGestureMotion(false);this.clearTrackPeek(false);this.clearKeyFeedback();cancelAnimationFrame(this.lyricScrollFrame);
      this.cancelPlayerPresentation();if(this.nowPlaying?.open){this.setPlayerReveal(1);this.playerPhase='open';}
      for(const animation of this.motionAnimations.values())animation.cancel();this.motionAnimations.clear();this.lyricExitGhost?.remove();this.lyricExitGhost=null;
    }
    playMotion(target,frames,options={}){
      if(!target || !target.isConnected || !this.motionAllowed() || !target.animate)return null;
      this.motionAnimations.get(target)?.cancel();
      const animation=target.animate(frames,{duration:140,easing:'cubic-bezier(.18,.8,.25,1)',fill:'none',...options});
      this.motionAnimations.set(target,animation);
      const clean=()=>{if(this.motionAnimations.get(target)===animation)this.motionAnimations.delete(target);};
      animation.finished.then(clean,clean);return animation;
    }
    animateSurface(element,opening=true){
      // Modal roots and caption controls stay stationary and fully opaque.
      const target=element===this.settings ? element.querySelector('.lt-settings-content') : element===this.nowPlaying ? element.querySelector('.lt-np-layout') : element===this.historyPage ? element.querySelector('.lt-history-list') : element===this.releaseDialog ? element.querySelector('.lt-release-content') : element;
      return this.playMotion(target,opening ? [{opacity:.65,transform:'translateY(9px)'},{opacity:1,transform:'none'}] : [{opacity:1,transform:'none'},{opacity:.65,transform:'translateY(9px)'}],{duration:opening ? 120 : 100});
    }
    cancelPlayerPresentation(){this.playerMotionToken=(this.playerMotionToken || 0)+1;cancelAnimationFrame(this.playerMotionFrame);this.playerMotionFrame=0;}
    setPlayerReveal(value){
      const progress=clamp(value,0,1);this.playerReveal=progress;const offset=(1-progress)*innerHeight;
      this.nowPlaying.style.clipPath=progress>=.9999 ? '' : `inset(${offset}px 0 0 0)`;
      for(const target of [this.nowPlaying.querySelector('.lt-np-layout'),this.$('lt-np-header'),this.nowPlaying.querySelector('.lt-player-wallpaper')]){
        this.motionAnimations.get(target)?.cancel();target.style.transform=progress>=.9999 ? '' : `translate3d(0,${offset}px,0)`;
      }
    }
    animatePlayerReveal(target,duration=300,close=false){
      this.cancelPlayerPresentation();const token=this.playerMotionToken,start=this.playerReveal ?? 1,began=performance.now();this.playerPhase=target ? 'opening' : 'closing';
      const finish=()=>{if(token!==this.playerMotionToken || this.destroyed)return;this.playerMotionFrame=0;this.setPlayerReveal(target);this.playerPhase=target ? 'open' : 'closed';if(close)this.closeDialog(this.nowPlaying);};
      if(!this.motionAllowed() || Math.abs(target-start)<.001){finish();return;}
      const frame=now=>{if(token!==this.playerMotionToken || this.destroyed)return;const t=clamp((now-began)/duration,0,1);this.setPlayerReveal(start+(target-start)*(1-Math.pow(1-t,3)));if(t<1)this.playerMotionFrame=requestAnimationFrame(frame);else finish();};
      this.playerMotionFrame=requestAnimationFrame(frame);
    }
    preparePlayer(start=0){
      if(this.nowPlaying.open)return;
      this.playerReturn=this.snapshotView();this.hideSearchPreview();this.showQuickSearch(false);this.showKeyboard(false);this.setPlayerReveal(start);
      this.openDialog(this.nowPlaying);this.applyLyricsLayout();this.warmAdjacentArtwork();
    }
    requestPlayerClose(){if(!this.nowPlaying.open)return;this.activeGesture=null;this.animatePlayerReveal(0,280,true);}
    cancelPlayerGesture(g,animate=true){
      if(g?.playerPreview){if(animate)this.animatePlayerReveal(0,200,true);else this.closeDialog(this.nowPlaying);}
      else if(g?.player && g.intent?.kind==='playerClose'){if(animate)this.animatePlayerReveal(1,220);else{this.cancelPlayerPresentation();this.setPlayerReveal(1);this.playerPhase='open';}}
    }
    pageSurface(){return this.browse && !this.browse.hidden ? this.browse : this.main;}
    animatePageChange(direction=0,distance,duration=140){
      const target=this.pageSurface();if(!target || this.nowPlaying?.open)return;
      const start=distance ?? (direction ? clamp(innerWidth*.09,32,88) : 9);
      this.playMotion(target,[{opacity:.72,transform:direction ? `translateX(${direction*start}px)` : `translateY(${start}px)`},{opacity:1,transform:'none'}],{duration});
    }
    animateNavigation(previous){
      this.syncNavigation(true);
      const nav=this.shell.querySelector('.lt-nav'),next=nav.querySelector('[aria-current="page"]');if(!next || next===previous)return;
      this.playMotion(next.querySelector('.lt-icon'),[{transform:'translateY(3px) scale(.92)'},{transform:'none'}],{duration:140});
    }
    placeNavigation(index,animate=false,metrics){
      const nav=this.shell.querySelector('.lt-nav'),pill=nav.querySelector('.lt-nav-selection'),buttons=[...nav.querySelectorAll('button')];if(!pill || !buttons.length)return;
      const m=metrics || {left:buttons[0].offsetLeft,width:buttons[0].offsetWidth,step:buttons[1].offsetLeft-buttons[0].offsetLeft};
      const before=pill.style.transform || 'translateX(0px)',after=`translateX(${index*m.step}px)`;
      pill.style.left=m.left+'px';pill.style.width=m.width+'px';pill.style.transform=after;this.navVisualIndex=index;
      buttons.forEach((button,i)=>button.style.setProperty('--lt-nav-weight',String(Math.max(0,1-Math.abs(index-i)))));
      if(animate && before!==after)this.playMotion(pill,[{transform:before},{transform:after}],{duration:120});
    }
    syncNavigation(animate=false,force=false){
      if(!this.shell || !force && this.activeGesture?.intent?.kind==='tab')return;
      this.placeNavigation(Math.max(0,['home','search','library'].indexOf(document.body.dataset.ltPage)),animate);
    }
    adjacentTrack(method){
      const state=this.getPlayerState(),queue=read(()=>this.S.Queue,null),current=queue?.track?.uri || queue?.track?.contextTrack?.uri;
      const valid=queue && (!current || current===this.lastURI),rows=method==='next' ? valid && queue.nextTracks || state?.nextItems || state?.next_tracks || [] : valid && queue.prevTracks || state?.prevItems || state?.prev_tracks || [];
      const raw=method==='next' ? rows[0] : rows.at?.(-1),value=raw?.contextTrack || raw?.track || raw?.item?.data || raw?.item || raw?.data || raw;
      const info=uriInfo(typeof value==='string' ? value : value?.uri);if(!info || !['track','episode'].includes(info.type))return null;
      const image=imageURL(value?.metadata?.image_xlarge_url || value?.metadata?.image_large_url || value?.metadata?.image_url) || pickArtwork(value) || this.artCache.get(info.uri)?.image || '';
      return {...info,image};
    }
    warmAdjacentArtwork(){
      this.warmedArtwork ||= new Set();
      for(const method of ['next','back']){const entry=this.adjacentTrack(method);if(!entry)continue;if(!entry.image){this.queueArtwork(entry.uri);continue;}
        if(!this.warmedArtwork.has(entry.image)){this.warmedArtwork.add(entry.image);if(this.warmedArtwork.size>32)this.warmedArtwork.delete(this.warmedArtwork.values().next().value);const image=new Image();image.src=entry.image;image.decode?.().catch(()=>{});}
      }
    }
    drawTrackPeek(g,intent,dx){
      let peek=this.trackPeek;
      if(peek && (peek.g!==g || peek.method!==intent.method)){this.clearTrackPeek(false);peek=null;}
      if(!peek){
        const entry=this.adjacentTrack(intent.method);if(!entry)return false;
        const main=g.mini ? this.$('lt-mini-art') : this.$('lt-art'),stage=main.parentElement,width=stage.getBoundingClientRect().width;if(!width || main.hidden)return false;
        const incoming=node('img','lt-track-incoming');incoming.alt='';incoming.setAttribute('aria-hidden','true');incoming.dataset.uri=entry.uri;incoming.hidden=!entry.image;
        incoming.onerror=()=>{incoming.hidden=true;};
        if(entry.image)incoming.src=entry.image;else this.queueArtwork(entry.uri);stage.append(incoming);
        peek={g,method:intent.method,uri:entry.uri,main,incoming,width,dx:0};this.trackPeek=peek;
      }
      peek.dx=clamp(dx,-peek.width,peek.width);const offset=peek.method==='next' ? peek.width : -peek.width;
      peek.main.style.transform=`translate3d(${peek.dx}px,0,0)`;peek.main.style.willChange='transform';
      peek.incoming.style.transform=`translate3d(${peek.dx+offset}px,0,0)`;return true;
    }
    clearTrackPeek(animate=false){
      const peek=this.trackPeek || this.trackTransition;if(!peek)return;
      this.trackPeek=null;this.trackTransition=null;peek.cancelled=true;peek.main.style.removeProperty('will-change');peek.main.style.removeProperty('visibility');peek.outgoing?.remove();
      const from=peek.main.style.transform || 'none';peek.main.style.removeProperty('transform');
      if(animate){this.playMotion(peek.main,[{transform:from},{transform:'none'}],{duration:130});const fromIncoming=peek.incoming.style.transform;peek.incoming.style.transform=`translateX(${peek.method==='next' ? peek.width : -peek.width}px)`;const a=this.playMotion(peek.incoming,[{transform:fromIncoming},{transform:peek.incoming.style.transform}],{duration:130});if(a){a.finished.then(()=>peek.incoming.remove(),()=>peek.incoming.remove());return;}}
      this.motionAnimations.get(peek.incoming)?.cancel();peek.incoming.remove();
    }
    commitTrackPeek(peek){
      if(!peek)return;this.trackPeek=null;this.trackTransition=peek;
      const outgoing=peek.main.cloneNode(false);outgoing.removeAttribute('id');outgoing.className='lt-track-outgoing';outgoing.hidden=false;outgoing.style.transform=`translateX(${peek.dx}px)`;peek.main.parentElement.append(outgoing);peek.outgoing=outgoing;peek.main.style.visibility='hidden';
      const exit=`translateX(${peek.method==='next' ? -peek.width : peek.width}px)`;this.playMotion(outgoing,[{transform:outgoing.style.transform},{transform:exit}],{duration:140});outgoing.style.transform=exit;
      const start=peek.incoming.style.transform;peek.incoming.style.transform='translateX(0px)';peek.main.style.removeProperty('transform');peek.main.style.removeProperty('will-change');
      const a=this.playMotion(peek.incoming,[{transform:start},{transform:'translateX(0px)'}],{duration:140});
      const done=()=>{peek.settled=true;if(peek.confirmed && this.trackTransition===peek)this.clearTrackPeek(false);};if(a)a.finished.then(done,done);else done();
      this.later(()=>{if(this.trackTransition===peek)this.clearTrackPeek(true);},1500);
    }
    confirmTrackPeek(uri){
      const peek=this.trackTransition;if(!peek)return;
      if(uri===peek.uri){peek.confirmed=true;if(peek.settled)this.clearTrackPeek(false);}
      else if(uri!==this.lastURI)this.clearTrackPeek(false);
    }
    animateTrackChange(){
      const direction=this.nextTrackMotion || 0;this.nextTrackMotion=0;
      for(const target of [!this.trackTransition && this.$('lt-art-swipe').querySelector('.lt-art-frame'),!this.trackTransition && this.$('lt-mini-art'),this.nowPlaying.querySelector('.lt-np-track'),this.shell.querySelector('.lt-track-text')]){
        if(target && target.getBoundingClientRect().width)this.playMotion(target,[{opacity:.35,transform:`translateX(${direction*18}px) scale(.985)`},{opacity:1,transform:'none'}],{duration:130});
      }
    }
    lyricLayoutRects(){
      const result=new Map();for(const target of [this.$('lt-art-swipe').querySelector('.lt-art-frame'),this.nowPlaying.querySelector('.lt-np-controls')])if(target?.getBoundingClientRect().width)result.set(target,target.getBoundingClientRect());return result;
    }
    makeLyricExitGhost(){
      this.lyricExitGhost?.remove();this.lyricExitGhost=null;
      const panel=this.$('lt-lyrics-panel');if(!this.motionAllowed() || !this.nowPlaying.open || panel.hidden)return;
      const rect=panel.getBoundingClientRect(),base=this.nowPlaying.getBoundingClientRect();
      if(!rect.width || rect.bottom<0 || rect.top>innerHeight)return;
      const ghost=panel.cloneNode(true);ghost.classList.add('lt-lyrics-exit-ghost');ghost.setAttribute('aria-hidden','true');ghost.inert=true;
      const lines=ghost.querySelector('#lt-lyrics-lines');if(lines)lines.classList.add('lt-motion-lyric-lines');
      const status=ghost.querySelector('#lt-lyrics-status');if(status)status.classList.add('lt-motion-lyric-status');
      for(const n of [ghost,...ghost.querySelectorAll('*')]){n.removeAttribute('id');n.removeAttribute('data-action');n.removeAttribute('data-lyric-index');n.removeAttribute('aria-labelledby');}
      ghost.style.cssText=`left:${rect.left-base.left}px;top:${rect.top-base.top+this.nowPlaying.scrollTop}px;width:${rect.width}px;`;
      ghost.style.setProperty('height',rect.height+'px','important');this.nowPlaying.append(ghost);if(lines)lines.scrollTop=this.$('lt-lyrics-lines').scrollTop;
      this.lyricExitGhost=ghost;
      const animation=this.playMotion(ghost,[{opacity:1,transform:'none'},{opacity:0,transform:'translateX(25px) scale(.985)'}],{duration:130});
      const remove=()=>{ghost.remove();if(this.lyricExitGhost===ghost)this.lyricExitGhost=null;};if(animation)animation.finished.then(remove,remove);else remove();
    }
    animateLyricLayout(previous,enabled){
      if(!this.nowPlaying.open || !this.motionAllowed())return;
      for(const [target,old] of previous){
        const rect=target.getBoundingClientRect();if(!rect.width || !old.width)continue;
        const scale=target.classList.contains('lt-art-frame') ? ` scale(${old.width/rect.width},${old.height/rect.height})` : '';
        this.playMotion(target,[{transformOrigin:'0 0',transform:`translate(${old.x-rect.x}px,${old.y-rect.y}px)${scale}`},{transformOrigin:'0 0',transform:'none'}],{duration:160});
      }
      if(enabled)this.playMotion(this.$('lt-lyrics-panel'),[{opacity:0,transform:'translateX(24px)'},{opacity:1,transform:'none'}],{duration:150});
    }
    clearGestureMotion(animate=false,keepNavigation=false,keepTrack=false){
      cancelAnimationFrame(this.gestureFrame);this.gestureFrame=0;
      const targets=this.gestureTargets || [];this.gestureTargets=[];
      for(const target of targets){
        if(!target.isConnected)continue;
        const transform=target.style.transform,opacity=target.style.opacity;target.style.removeProperty('transform');target.style.removeProperty('opacity');target.style.removeProperty('will-change');
        if(animate)this.playMotion(target,[{transform:transform || 'none',opacity:opacity || '1'},{transform:'none',opacity:1}],{duration:150,easing:'cubic-bezier(.2,.9,.3,1.12)'});
      }
      delete document.body.dataset.ltGesture;
      if(!keepTrack)this.clearTrackPeek(animate);
      if(!keepNavigation)this.syncNavigation(animate,true);
    }
    showGestureMotion(g,intent,dx,dy){
      if(!intent)return;
      this.cancelPendingCardTap();
      const amount=intent.axis==='x' ? Math.abs(dx) : Math.abs(dy),progress=clamp(amount/intent.threshold,0,1);
      document.body.dataset.ltGesture=intent.kind;
      if(!this.motionAllowed())return;
      if(intent.kind==='playerOpen' || intent.kind==='playerClose'){
        if(intent.kind==='playerOpen' && !g.playerPreview){g.playerPreview=true;this.preparePlayer(g.openReveal || 0);}
        this.cancelPlayerPresentation();this.playerPhase='dragging';this.setPlayerReveal(intent.kind==='playerOpen' ? (g.openReveal || 0)-dy/innerHeight : (g.startReveal ?? 1)-dy/innerHeight);return;
      }
      cancelAnimationFrame(this.gestureFrame);
      this.gestureFrame=requestAnimationFrame(()=>{
        this.gestureFrame=0;if(this.activeGesture!==g)return;
        if(intent.kind==='tab'){
          const buttons=this.shell.querySelector('.lt-nav').querySelectorAll('button');g.navMetrics ||= {left:buttons[0].offsetLeft,width:buttons[0].offsetWidth,step:buttons[1].offsetLeft-buttons[0].offsetLeft};
          const start=['home','search','library'].indexOf(document.body.dataset.ltPage),end=['home','search','library'].indexOf(intent.tab);this.placeNavigation(start+(end-start)*progress,false,g.navMetrics);
        }
        if(intent.kind==='track' && this.drawTrackPeek(g,intent,dx))return;
        const targets=intent.kind==='playerClose' || intent.kind==='back' && g.player ? [this.nowPlaying.querySelector('.lt-np-layout'),this.$('lt-np-header')] : intent.kind==='track' ? [g.mini ? this.$('lt-mini-open') : this.$('lt-art-swipe').querySelector('.lt-art-frame')] : intent.kind==='sheetClose' || intent.kind==='back' && g.dialog ? [g.dialog.querySelector('.lt-settings-content,.lt-history-list,.lt-release-content')] : [this.pageSurface()];
        if(intent.kind==='quickOpen' || intent.kind==='quickClose')targets.splice(0,targets.length,this.$('lt-quick-search').hidden ? this.shell.querySelector('.lt-header') : this.$('lt-quick-search'));
        const prior=this.gestureTargets || [];for(const old of prior)if(!targets.includes(old)){old.style.removeProperty('transform');old.style.removeProperty('opacity');old.style.removeProperty('will-change');}
        this.gestureTargets=targets.filter(Boolean);
        for(const target of this.gestureTargets){
          this.motionAnimations.get(target)?.cancel();target.style.willChange='transform,opacity';
          const x=intent.axis==='x' ? Math.sign(dx)*Math.min(Math.abs(dx),innerWidth*.56)*(intent.kind==='boundary' ? .2 : 1) : 0,y=intent.axis==='y' ? Math.sign(dy)*Math.min(Math.abs(dy),innerHeight*.58) : 0;
          target.style.transform=`translate3d(${x}px,${y}px,0)`+(intent.kind==='playerClose' ? ` scale(${1-progress*.035})` : '');
          target.style.opacity=String(1-progress*.18);
        }
      });
    }
    gestureIntent(g,dx,dy){
      const horizontal=Math.abs(dx)>10 && Math.abs(dx)>Math.abs(dy)*1.4,vertical=Math.abs(dy)>10 && Math.abs(dy)>Math.abs(dx)*1.35;
      // Edge Back has the same priority as the Back button, including sheets
      // and the player. Swipes elsewhere keep their tab/track behavior.
      if(horizontal && dx>0 && g.edge)return {kind:'back',axis:'x',threshold:80,label:'go back'};
      if(g.dialog && g.sheetPull && vertical && dy>0)return {kind:'sheetClose',axis:'y',threshold:72,label:'close '+(g.dialog===this.settings ? 'Settings' : 'history')};
      if(horizontal && (g.mini || g.player && g.art)){
        const method=dx<0 ? 'next' : 'back';if(this.nowPlaying.querySelector(`[data-action="${method}"]`).disabled)return null;
        return {kind:'track',axis:'x',threshold:g.player ? 40 : 76,label:dx<0 ? 'play next track' : 'play previous track',method};
      }
      if(vertical && dy<0 && g.mini)return {kind:'playerOpen',axis:'y',threshold:72,label:'expand player'};
      if(vertical && dy>0 && g.player && g.playerPull)return {kind:'playerClose',axis:'y',threshold:72,label:'minimize player'};
      if(!g.player && vertical && g.top && !g.dialog){
        if(this.quickOpen && dy<0)return {kind:'quickClose',axis:'y',threshold:64,label:'close quick search'};
        if(dy>0 && (g.toolbar || (this.activeScroll()?.scrollTop || 0)<=1))return {kind:'quickOpen',axis:'y',threshold:64,label:'open quick search'};
      }
      if(horizontal && !g.player && !g.dialog){
        if(dx>0 && !g.nav && (g.edge || document.body.dataset.ltCustomPage===''))return {kind:'back',axis:'x',threshold:80,label:'go back'};
        const tabs=['home','search','library'],index=tabs.indexOf(document.body.dataset.ltPage),next=clamp(index+(dx<0 ? 1 : -1),0,2);
        if(index!==next)return {kind:'tab',axis:'x',threshold:80,label:'open '+['Home','Search','Your Library'][next],tab:tabs[next]};
        return {kind:'boundary',axis:'x',threshold:Infinity,label:['Home','Search','Your Library'][next]};
      }
      return null;
    }
    commitGesture(g,intent,dx){
      const peek=intent.kind==='track' ? this.trackPeek : null;
      this.clearGestureMotion(false,intent.kind==='tab',Boolean(peek));this.gestureConsumedUntil=Date.now()+700;this.suppressOpenUntil=Date.now()+500;this.pointerHeld=false;
      if(intent.kind==='track'){this.commitTrackPeek(peek);this.nextTrackMotion=dx<0 ? 1 : -1;void this.callPlayer(intent.method);}
      else if(intent.kind==='playerOpen'){if(!this.nowPlaying.open)this.preparePlayer(0);this.animatePlayerReveal(1,300);}
      else if(intent.kind==='playerClose')this.requestPlayerClose();
      else if(intent.kind==='sheetClose')this.closeDialog(g.dialog);
      else if(intent.kind==='quickOpen')this.showQuickSearch(true);
      else if(intent.kind==='quickClose')this.showQuickSearch(false);
      else{const previous=this.viewKey(this.snapshotView());this.nextPageMotion={direction:dx<0 ? 1 : -1,distance:48,duration:100};if(intent.kind==='back')this.goBack();else this.switchTab(intent.tab);if(previous===this.viewKey(this.snapshotView()))this.nextPageMotion=null;}
    }
    viewKey(view){return (view.library ? 'library:' : 'page:')+view.path;}
    activeScroll(){return this.browse && !this.browse.hidden ? this.browse : this.main?.querySelector('.main-view-container__scroll-node, [data-overlayscrollbars-viewport]');}
    snapshotView(){return {path:this.getRoutePath(),library:this.libraryOpen,scroll:this.activeScroll()?.scrollTop || 0};}
    rememberView(){const view=this.snapshotView(),last=this.viewStack.at(-1);if(!last || this.viewKey(last)!==this.viewKey(view))this.viewStack.push(view);if(this.viewStack.length>80)this.viewStack.shift();this.tabViews.set(document.body.dataset.ltPage,view);}
    restoreScroll(view){requestAnimationFrame(()=>{if(this.viewKey(this.snapshotView())===this.viewKey(view)){const scroll=this.activeScroll();if(scroll)scroll.scrollTop=view.scroll || 0;}});}
    acceptHostRoute(path){
      if(!path)return;const previousHost=this.observedHostPath;this.observedHostPath=path;
      const request=this.routeRequests.get(path),latest=this.latestRouteRequest;
      // Owned detail pages keep their own route while a previous host request
      // finishes underneath. A deliberate interaction with native Spotify exits.
      if(this.detailOwned && this.enabled && (this.nativeNavAt || 0)<=this.localDetailAt){if(request)request.pending=false;return;}
      if(!this.issuingRoute && request?.pending && latest && request.serial<latest.serial && Date.now()-request.at<5000 && (this.nativeNavAt || 0)<=latest.at){
        // A slow completion from an older tab must not replace the latest tab.
        request.pending=false;
        if(latest.local)return;
        if(this.history.location?.pathname!==latest.path){this.issuingRoute=true;try{this.history.push(latest.path);}finally{this.issuingRoute=false;}}
        return;
      }
      if(this.issuingRoute || path===this.pendingRoute?.path){if(request)request.pending=false;this.pendingRoute=null;return;}
      // An unchanged host route must not erase a local Library view. Pending
      // routing also prevents polling an old host URL from undoing a new page.
      if(path===previousHost)return;
      const automatic=this.pendingRoute && Date.now()-this.pendingRoute.at<5000 || this.lastRequestedAt && Date.now()-this.lastRequestedAt<1500 && (this.nativeNavAt || 0)<=this.lastRequestedAt;
      if(path!==this.getRoutePath() && !automatic)this.rememberView();
      const keepLibrary=this.libraryOpen && automatic;
      this.pendingRoute=null;this.libraryOpen=Boolean(keepLibrary);this.routeChanged(false,path);
    }
    switchTab(tab){
      const current=document.body.dataset.ltPage;
      if(current===tab && (this.libraryOpen || this.getRoutePath()==='/' || this.getRoutePath()==='/search'))return;
      if(tab==='library'){this.showLibrary();return;}
      const previous=this.tabViews.get(tab),path=tab==='home' ? '/' : previous?.path?.startsWith('/search') ? previous.path : '/search';
      this.navigate(path);if(previous?.path===path)this.restoreScroll(previous);
    }
    goBack(){
      if(this.releaseDialog.open){this.closeDialog(this.releaseDialog);return;}
      if(this.settings.open){this.closeDialog(this.settings);return;}
      if(this.historyPage.open){this.closeDialog(this.historyPage);return;}
      if(!this.$('lt-lyrics-menu').hidden){this.showLyricsMenu(false,true);return;}
      if(this.nowPlaying.open || this.playerOpening){this.requestPlayerClose();return;}
      if(this.quickOpen){this.showQuickSearch(false);return;}
      this.hideSearchPreview();const current=this.viewKey(this.snapshotView());let previous;
      do{previous=this.viewStack.pop();}while(previous && this.viewKey(previous)===current);
      if(!previous){if(this.getRoutePath()!=='/')this.navigate('/',false);return;}
      this.nextPageMotion ||= {direction:-1};this.navigate(previous.path,false,previous.library);this.restoreScroll(previous);
    }
    async withTimeout(operation,timeout=3500){
      let timer;try{return await Promise.race([operation,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Spotify request timed out')),timeout);})]);}finally{clearTimeout(timer);}
    }
    async apiGet(url,timeout=3500){
      if(typeof this.S.CosmosAsync?.get!=='function')throw new Error('Spotify service unavailable');
      const result=await this.withTimeout(this.S.CosmosAsync.get(url),timeout);
      if(result?.error || result?.status>=400)throw new Error('Spotify request rejected');return result;
    }
    bindReleaseFeatures(){
      this.bindKeyFeedback();
      this.listen(this.searchInput,'input',()=>this.queueLiveSearch(this.searchInput.value));
      this.listen(this.$('lt-quick-input'),'input',e=>this.queueLiveSearch(e.target.value));
      this.listen(this.$('lt-quick-search'),'submit',e=>{e.preventDefault();this.submitSearch(this.$('lt-quick-input').value);});
      this.listen(this.settings,'input',e=>{
        const key=e.target.dataset.textPref;if(!['welcome','welcomeSubtitle'].includes(key))return;
        this.prefs[key]=cleanText(e.target.value,160);this.save();
        const hero=this.browse.querySelector('.lt-home-hero');
        if(hero){hero.querySelector('h1').textContent=this.welcomeText();hero.querySelector('p').textContent=this.prefs.welcomeSubtitle;}
      });
      this.listen(document,'pointerdown',e=>{this.pointerEpoch=(this.pointerEpoch || 0)+1;this.pointerHeld=true;if(!e.target.closest(OWN))this.nativeNavAt=Date.now();},{capture:true});
      const released=()=>{const epoch=this.pointerEpoch;requestAnimationFrame(()=>{if(epoch!==this.pointerEpoch)return;this.pointerHeld=false;if(this.browseDeferred){this.browseDeferred=false;this.renderBrowse();}});};
      this.listen(window,'pointerup',released,{capture:true});this.listen(window,'pointercancel',released,{capture:true});this.listen(window,'blur',()=>{const epoch=this.pointerEpoch;this.later(()=>{if(epoch===this.pointerEpoch && !document.hasFocus())released();},600);});
      for(const type of ['touchstart'])this.listen(document,type,()=>{this.fastClickBlock=null;if(!this.pointerHeld){this.pointerEpoch=(this.pointerEpoch || 0)+1;this.pointerHeld=true;}},{capture:true,passive:true});
      this.listen(window,'touchend',released,{capture:true,passive:true});this.listen(window,'touchcancel',released,{capture:true,passive:true});
      this.listen(document,'click',e=>{if(!e.target.closest('#lt-search-preview,#lt-search-form,#lt-quick-search'))this.hideSearchPreview();},{capture:true});
      this.bindGestures();
      this.listen(matchMedia('(prefers-reduced-motion: reduce)'),'change',()=>{if(!this.motionAllowed())this.stopMotion();});
      this.listen(document,'visibilitychange',()=>{this.syncLyricClock();if(document.hidden)cancelAnimationFrame(this.lyricScrollFrame);else{this.refreshGreeting();if(this.nowPlaying.open)this.updateLyricPosition();}});
      this.listen(this.$('lt-lyrics-panel'),'wheel',()=>{this.lyricScrollUntil=Date.now()+5000;cancelAnimationFrame(this.lyricScrollFrame);},{passive:true});
      this.listen(this.$('lt-lyrics-panel'),'touchstart',()=>{this.lyricScrollUntil=Date.now()+5000;cancelAnimationFrame(this.lyricScrollFrame);},{passive:true});
      this.imageObserver=window.IntersectionObserver ? new IntersectionObserver(entries=>{for(const item of entries)if(item.isIntersecting){this.imageObserver.unobserve(item.target);this.queueArtwork(item.target.dataset.uri);}},{root:this.browse,rootMargin:'200px'}) : null;
      for(const card of this.browse.querySelectorAll('.lt-card[data-needs-art]'))this.imageObserver?.observe(card);
    }
    bindGestures(){
      this.listen(window,'pointerdown',e=>{
        this.gestureConsumedUntil=0;this.suppressOpenUntil=0;this.clearGestureMotion(false);this.activeGesture=null;
        if(!this.enabled || e.pointerType==='mouse' || e.isPrimary===false || e.target.closest('input,select,textarea,[contenteditable="true"],.lt-caption-buttons,.lt-keyboard,.lt-search-preview'))return;
        const dialog=this.releaseDialog.open ? this.releaseDialog : this.settings.open ? this.settings : this.historyPage.open ? this.historyPage : null;
        const edge=e.clientX<=Math.min(120,Math.max(64,innerWidth*.12)),sheetPull=Boolean(e.target.closest('.lt-sheet-header,.lt-np-header'));
        if(dialog && !sheetPull && !edge)return;
        const header=this.shell.querySelector('.lt-header').getBoundingClientRect();
        const playerTop=Math.min(220,Math.max(140,innerHeight*.25,this.$('lt-np-header').getBoundingClientRect().bottom+64));
        this.activeGesture={x:e.clientX,y:e.clientY,id:e.pointerId,at:Date.now(),player:this.nowPlaying.open && !dialog,dialog,
          startReveal:this.playerReveal ?? 1,openReveal:clamp(1-this.shell.querySelector('.lt-mini').getBoundingClientRect().top/innerHeight,0,1),
          top:e.clientY<=Math.min(280,Math.max(180,innerHeight*.3,header.bottom+96)),
          edge,sheetPull,
          mini:Boolean(e.target.closest('#lt-mini-open')),art:Boolean(e.target.closest('#lt-art-swipe')),
          nav:Boolean(e.target.closest('.lt-nav')),
          toolbar:Boolean(e.target.closest('.lt-header')) || e.clientY<=header.bottom+36,
          playerPull:Boolean(e.target.closest('.lt-np-header,.lt-art-area')) || this.nowPlaying.open && e.clientY<=playerTop,
          slop:e.target.closest('.lt-nav,.lt-header,.lt-np-header,.lt-sheet-header') ? 26 : 14};
      },{capture:true});
      this.listen(window,'pointermove',e=>{
        const g=this.activeGesture;if(!g || e.pointerId!==g.id)return;
        const dx=e.clientX-g.x,dy=e.clientY-g.y;
        if(Math.hypot(dx,dy)<=g.slop){if(g.intent)this.showGestureMotion(g,g.intent,dx,dy);return;}
        const intent=this.gestureIntent(g,dx,dy);
        if(!intent){if(g.intent){this.cancelPlayerGesture(g);g.playerPreview=false;g.intent=null;this.clearGestureMotion(true);}return;}
        g.intent=intent;this.showGestureMotion(g,intent,dx,dy);
        if((intent.axis==='x' || intent.kind==='playerOpen' || intent.kind==='playerClose') && e.cancelable)e.preventDefault();
      },{capture:true,passive:false});
      this.listen(window,'touchmove',e=>{
        const g=this.activeGesture,t=e.touches[0];if(!g || !t || e.touches.length!==1)return;
        const dx=t.clientX-g.x,dy=t.clientY-g.y;
        if((dy< -12 && g.mini || dy>12 && dy>Math.abs(dx)*1.5 && (g.dialog && g.sheetPull || g.player && g.playerPull || !g.player && !g.dialog && g.top && (g.toolbar || (this.activeScroll()?.scrollTop || 0)<=1))) && e.cancelable)e.preventDefault();
      },{capture:true,passive:false});
      this.listen(window,'pointercancel',()=>{const g=this.activeGesture;this.activeGesture=null;this.cancelPlayerGesture(g);this.clearGestureMotion(true);},{capture:true});
      this.listen(window,'blur',()=>{const g=this.activeGesture;this.activeGesture=null;this.cancelPlayerGesture(g,false);this.clearGestureMotion(false);});
      this.listen(window,'pointerup',e=>{
        const g=this.activeGesture;this.activeGesture=null;if(!g || g.id!==e.pointerId){this.clearGestureMotion(false);return;}
        const dx=e.clientX-g.x,dy=e.clientY-g.y,intent=this.gestureIntent(g,dx,dy),amount=intent?.axis==='x' ? Math.abs(dx) : Math.abs(dy);
        if(!intent || amount<=g.slop){this.cancelPlayerGesture(g);this.clearGestureMotion(Boolean(g.intent));return;}
        e.preventDefault();e.stopImmediatePropagation();
        if(amount>=intent.threshold && Date.now()-g.at<2500)this.commitGesture(g,intent,dx);
        else{this.cancelPlayerGesture(g);this.clearGestureMotion(true);this.gestureConsumedUntil=Date.now()+700;this.pointerHeld=false;}
      },{capture:true});
      this.listen(document,'click',e=>{if(e.isTrusted && Date.now()<(this.gestureConsumedUntil || 0)){this.gestureConsumedUntil=0;e.preventDefault();e.stopImmediatePropagation();}},{capture:true});
    }
    welcomeText(){
      const hour=new Date().getHours(),period=hour>=5 && hour<12 ? 'morning' : hour>=12 && hour<18 ? 'afternoon' : 'evening',greeting='Good '+period;
      return this.prefs.welcome ? this.prefs.welcome.replace(/\{greeting\}/gi,greeting).replace(/\{timeOfDay\}/gi,period).replace(/\bGood (?:morning|afternoon|evening)\b/gi,greeting) : greeting+'.';
    }
    refreshGreeting(){this.lastGreetingCheck=Date.now();const heading=this.browse?.querySelector('.lt-home-hero h1');if(heading && heading.textContent!==this.welcomeText())heading.textContent=this.welcomeText();this.refreshHomeClock();}
    refreshHomeClock(){
      const clock=this.browse?.querySelector('#lt-home-clock');if(!clock)return;
      clock.hidden=!this.prefs.homeClock;if(clock.hidden)return;
      const now=new Date(),hour=now.getHours(),minute=String(now.getMinutes()).padStart(2,'0'),local=String(hour).padStart(2,'0')+':'+minute;
      const label=this.prefs.clockFormat==='12' ? ((hour+11)%12+1)+':'+minute+' '+(hour<12 ? 'AM' : 'PM') : local;
      if(clock.textContent!==label){clock.textContent=label;clock.dateTime=local;clock.setAttribute('aria-label','Local time, '+label);}
    }
    showQuickSearch(show){
      const changed=this.quickOpen!==show;
      this.quickOpen=show;this.$('lt-quick-search').hidden=!show;document.body.dataset.ltQuick=String(show);
      if(show){if(changed)this.animateSurface(this.$('lt-quick-search'));this.$('lt-quick-input').focus({preventScroll:true});if(this.prefs.keyboard)this.showKeyboard(true);}else{this.hideSearchPreview();this.showKeyboard(false);this.$('lt-quick-input').blur();if(changed)this.animateSurface(this.shell.querySelector('.lt-header'));}
    }
    hideSearchPreview(){clearTimeout(this.searchDebounce);this.$('lt-search-preview').hidden=true;this.liveSearchToken++;}
    updateSearchPreviewBounds(){
      const panel=this.$('lt-search-preview');if(!panel?.isConnected)return;
      const keyboard=this.$('lt-keyboard'),top=parseFloat(getComputedStyle(panel).top) || 0;
      const bottom=keyboard.hidden ? innerHeight-12 : keyboard.getBoundingClientRect().top-8;
      const room=Math.max(0,Math.floor(bottom-top));
      panel.style.setProperty('--lt-preview-room',room+'px');panel.dataset.noRoom=String(room<64);
    }
    normalizeSearch(result){
      if(result?.errors?.length)throw new Error('Spotify search unavailable');
      const root=result?.data?.searchV2 || result?.data?.search || result?.searchV2 || result?.search || result?.data || result;
      const entries=[],seen=new Set();let recognized=false;
      for(const [type,keys] of [['track',['tracksV2','tracks']],['artist',['artists']],['album',['albumsV2','albums']],['playlist',['playlists']]]){
        for(const key of keys){
          const group=root?.[key];if(!group)continue;recognized=true;
          const rows=Array.isArray(group) ? group : group.items || group.edges || [];
          for(const row of rows){
            const raw=row?.item?.data || row?.item || row?.data || row?.node || row;
            if(!raw)continue;
            const entry=normalizeEntity({...raw,uri:raw.uri || raw.link || (raw.id ? `spotify:${type}:${raw.id}` : ''),name:raw.name || raw.profile?.name,title:raw.title,album:raw.album || raw.albumOfTrack});
            if(entry && !seen.has(entry.uri)){seen.add(entry.uri);entries.push(entry);}
          }
          break;
        }
      }
      if(!recognized)throw new Error('Unknown Spotify search response');
      return entries;
    }
    async searchMusic(query,offset=0){
      const key=query.toLocaleLowerCase()+'|'+offset,cached=this.searchCache.get(key);
      if(cached && Date.now()-cached.at<60000)return cached.entries;
      if(this.searchFlights.has(key))return this.searchFlights.get(key);
      const job=(async()=>{
        const gql=this.S.GraphQL,definition=gql?.Definitions?.searchDesktop || gql?.QueryDefinitions?.searchDesktop;
        let entries,source='web-api';
        if(definition && typeof gql?.Request==='function'){
          try{
            const result=await this.withTimeout(gql.Request(definition,{searchTerm:query,offset,limit:10,numberOfTopResults:5,includeAudiobooks:false,includePreReleases:false}),2300);
            entries=this.normalizeSearch(result);source='spotify-client';
          }catch{ /* Fall through to the supported Web API in older wrappers. */ }
        }
        if(!entries){
          const result=await this.apiGet('https://api.spotify.com/v1/search?'+new URLSearchParams({q:query,type:'track,artist,album,playlist',limit:'10',offset:String(offset)}));
          entries=this.normalizeSearch(result);
        }
        this.searchSource=source;this.searchError='';this.searchCache.set(key,{at:Date.now(),entries});
        if(this.searchCache.size>32)this.searchCache.delete(this.searchCache.keys().next().value);
        return entries;
      })();
      this.searchFlights.set(key,job);
      try{return await job;}finally{this.searchFlights.delete(key);}
    }
    queueLiveSearch(value){
      clearTimeout(this.searchDebounce);const query=cleanText(value,300);const token=++this.liveSearchToken;
      if(!query){this.hideSearchPreview();return;}
      const panel=this.$('lt-search-preview');panel.hidden=false;panel.replaceChildren(node('p','lt-preview-status','Searching…'));panel.setAttribute('aria-busy','true');this.updateSearchPreviewBounds();
      this.searchDebounce=setTimeout(()=>void this.searchPreview(query,token),100);
    }
    async searchPreview(query,token){
      try{
        const entries=await this.searchMusic(query);
        if(this.destroyed || token!==this.liveSearchToken)return;
        if(this.pointerHeld){this.later(()=>void this.searchPreview(query,token),30);return;}
        const panel=this.$('lt-search-preview');panel.replaceChildren();panel.setAttribute('aria-busy','false');
        panel.append(node('p','lt-preview-status',entries.length ? 'Quick results · tap to play, double tap to open' : 'No matches. Try another song or artist.'));
        const list=node('div','lt-preview-list');for(const entry of entries.slice(0,6)){list.append(this.makeCard(entry));if(!entry.image)this.queueArtwork(entry.uri);}panel.append(list);
        const all=node('button','lt-pill','See all results');all.type='button';all.dataset.action='submitLiveSearch';all.dataset.query=query;panel.append(all);
      }catch{
        if(this.destroyed || token!==this.liveSearchToken)return;
        this.searchError='Search could not connect to Spotify.';
        const panel=this.$('lt-search-preview');panel.setAttribute('aria-busy','false');panel.replaceChildren(node('p','lt-preview-status','Search could not connect. Press Enter for retry and desktop search options.'));
      }
    }
    queryFromPath(path=this.getRoutePath()){
      if(!path.startsWith('/search/'))return '';try{return decodeURIComponent(path.slice(8)).trim();}catch{return path.slice(8).trim();}
    }
    async loadSearchResults(query,more=false){
      if(!query)return;
      const token=(this.searchResultsToken || 0)+1;this.searchResultsToken=token;
      this.resultsQuery=query;this.searchResultBusy=true;this.searchError='';
      if(!more){this.searchOffset=0;this.searchResults=[];this.searchFilter='all';}
      this.searchResultVersion++;this.renderBrowse();
      try{
        const entries=await this.searchMusic(query,more ? this.searchOffset+10 : 0);
        if(this.destroyed || token!==this.searchResultsToken || this.queryFromPath()!==query)return;
        if(more)this.searchOffset+=10;
        const all=more ? [...this.searchResults,...entries] : entries;
        this.searchResults=[...new Map(all.map(entry=>[entry.uri,entry])).values()];
        this.searchHasMore=entries.length>0 && ['track','artist','album','playlist'].some(type=>entries.filter(entry=>entry.type===type).length>=10);
      }catch{
        if(token!==this.searchResultsToken || this.destroyed)return;
        this.searchError='Search is unavailable in this Spotify session. Retry, or open Spotify’s desktop search.';
        this.searchHasMore=false;
      }finally{
        if(token===this.searchResultsToken && !this.destroyed){this.searchResultBusy=false;this.searchResultVersion++;this.renderBrowse();}
      }
    }
    queueArtwork(uri){
      const cached=this.artCache.get(uri);if(cached && Date.now()-cached.at<300000){if(cached.image)this.applyEntityArtwork(uri,cached.image);return;}
      if(!uriInfo(uri) || this.artJobs.includes(uri) || this.artInFlight?.has(uri))return;
      this.artJobs.push(uri);this.pumpArtwork();
    }
    pumpArtwork(){
      this.artInFlight ||= new Set();
      while(this.artBusy<3 && this.artJobs.length){const uri=this.artJobs.shift();this.artBusy++;this.artInFlight.add(uri);
        void this.fetchArtwork(uri).then(image=>{this.artCache.set(uri,{image,at:Date.now()});if(image&&!this.destroyed)this.applyEntityArtwork(uri,image);if(this.artCache.size>200)this.artCache.delete(this.artCache.keys().next().value);}).finally(()=>{this.artBusy--;this.artInFlight.delete(uri);if(!this.destroyed)this.pumpArtwork();});
      }
    }
    async fetchArtwork(uri){
      const info=uriInfo(uri);if(!info || info.type==='collection')return '';
      try{
        if(info.type==='playlist' && typeof this.S.Platform?.PlaylistAPI?.getMetadata==='function'){
          const result=await this.S.Platform.PlaylistAPI.getMetadata(uri);const image=pickArtwork(result);if(image)return image;
        }
      }catch{}
      try{const id=info.path.split('/')[2],result=await this.apiGet(`https://api.spotify.com/v1/${info.type}s/${encodeURIComponent(id)}${info.type==='playlist' ? '/images' : ''}`);return pickArtwork(result);}catch{return '';}
    }
    applyEntityArtwork(uri,image){
      for(const peek of [this.trackPeek,this.trackTransition])if(peek?.uri===uri){peek.incoming.src=image;peek.incoming.hidden=false;}
      for(const map of [this.entities,this.homeEntities,this.libraryEntities]){const entry=map.get(uri);if(entry)entry.image=image;}
      for(const root of [this.shell,...[...this.browsePages.values()].map(page=>page.fragment)])for(const card of root.querySelectorAll('.lt-card'))if(card.dataset.uri===uri){const art=card.querySelector('.lt-card-art');let img=art.querySelector('img');if(!img){img=node('img','');img.alt='';img.loading='lazy';img.decoding='async';art.append(img);}img.hidden=false;img.src=image;delete card.dataset.needsArt;}
      for(const row of this.recentSearches)if(row.uri===uri)row.image=image;
      const page=this.detailPages.get(uri);if(page)page.entry.image=image;
      const hero=this.browse.querySelector('.lt-detail-hero');if(hero?.dataset.detailUri===uri){const art=hero.querySelector('.lt-detail-art');let img=art.querySelector('img');if(!img){img=node('img','');img.alt='';art.append(img);}img.src=image;}
    }
    parseLRC(text){
      const lines=[];let offset=0;const offsetMatch=String(text || '').match(/\[offset:([+-]?\d+)\]/i);if(offsetMatch)offset=number(offsetMatch[1]);
      for(const row of String(text || '').split(/\r?\n/)){
        const tags=[...row.matchAll(/\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g)];
        const words=cleanText(row.replace(/\[[^\]]*\]/g,''),1000);if(!words)continue;
        for(const tag of tags)lines.push({text:words,at:Math.max(0,(Number(tag[1])*60+Number(tag[2]))*1000+Number((tag[3] || '').padEnd(3,'0') || 0)+offset)});
      }
      return lines.sort((a,b)=>a.at-b.at);
    }
    lyricTitle(value){
      return String(value || '').replace(/\s*[([](?:feat\.?|ft\.?|featuring|from\b|remaster)[^\])]*[\])]/gi,'').replace(/\s*-\s*(?:\d{4}\s*)?remaster(?:ed)?(?:\s+\d{4})?\s*$/i,'').trim();
    }
    lyricName(value){return String(value || '').normalize('NFKD').replace(/\p{M}/gu,'').toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();}
    lyricVersion(value){return (String(value || '').toLocaleLowerCase().match(/\b(?:live|remix|acoustic|instrumental|karaoke|extended|radio edit)\b/g) || []).sort().join('|');}
    async lyricJSON(url,signal){
      const host=new URL(url).host;this.lyricCooldowns ||= new Map();
      if(signal.aborted || (this.lyricCooldowns.get(host) || 0)>Date.now())throw new Error('Lyric service cooling down');
      if(host==='lrclib.net' && this.lastLRCLIBAt){const remaining=200-(Date.now()-this.lastLRCLIBAt);if(remaining>0)await new Promise(resolve=>setTimeout(resolve,remaining));}
      if(signal.aborted)throw new Error('Lyrics cancelled');
      const abort=new AbortController(),cancel=()=>abort.abort();signal.addEventListener('abort',cancel,{once:true});
      const timer=setTimeout(cancel,host==='lrclib.net' ? 1800 : 2200);
      try{
        if(host==='lrclib.net')this.lastLRCLIBAt=Date.now();
        const response=await fetch(url,{credentials:'omit',referrerPolicy:'no-referrer',signal:abort.signal,headers:host==='lrclib.net' ? {'Lrclib-Client':`LiquidTouch/${VERSION} (Spicetify extension; https://spicetify.app)`} : {}});
        if(response.status===429 || response.status===503){const retry=response.headers.get('Retry-After'),seconds=number(retry,0) || Math.max(0,(Date.parse(retry)-Date.now())/1000) || 60;this.lyricCooldowns.set(host,Date.now()+seconds*1000*(1+Math.random()*.2));}
        if(!response.ok)throw new Error('Lyric service unavailable');return await response.json();
      }finally{clearTimeout(timer);signal.removeEventListener('abort',cancel);}
    }
    backupRecord(result,info,search=false){
      const title=this.lyricName(this.lyricTitle(info.title)),artist=this.lyricName(info.artists?.[0] || info.artist.split(/,\s+|\s+feat\.?\s+/i)[0]);
      if(search){
        const candidateArtist=this.lyricName(result.artistName);
        const raw=value=>String(value || '').normalize('NFKD').replace(/\p{M}/gu,'').toLocaleLowerCase().trim(),lead=raw(info.artists?.[0] || info.artist.split(/,\s+|\s+feat\.?\s+/i)[0]),credit=raw(result.artistName);
        const credited=credit.startsWith(lead) && /^(?:[,&;/]|feat\.?\b|ft\.?\b|with\b|and\b)/i.test(credit.slice(lead.length).trim());
        if(this.lyricName(this.lyricTitle(result.trackName || result.name))!==title || !(candidateArtist===artist || credited) || this.lyricVersion(result.trackName || result.name)!==this.lyricVersion(info.title))return null;
      }
      const expected=info.duration/1000,diff=result.duration && expected ? Math.abs(number(result.duration)-expected) : Infinity;
      if(diff>Math.max(10,expected*.04) && diff!==Infinity)return null;
      const synced=this.parseLRC(String(result.syncedLyrics || '').slice(0,200000)),timed=synced.length>0 && (diff<=2 || !search && diff===Infinity);
      const plain=String(result.plainLyrics || '').slice(0,200000).split(/\r?\n/).map(text=>({text:cleanText(text,1000),at:-1})).filter(line=>line.text);
      const lines=timed ? synced : plain.length ? plain : synced.map(line=>({text:line.text,at:-1}));
      if(!lines.length && !result.instrumental)return null;
      return {lines,timed,provider:'LRCLIB',source:'lrclib',instrumental:Boolean(result.instrumental),rank:(timed ? 100 : 0)+(diff<=2 ? 10-diff : 0)+(this.lyricName(result.albumName)===this.lyricName(info.album) ? 5 : 0)};
    }
    async fetchBackupLyrics(info,signal,allowText=true){
      if(!info?.title || !info?.artist)throw new Error('Track metadata unavailable');
      const query=new URLSearchParams({track_name:info.title,artist_name:info.artist,album_name:info.album || '',duration:String(Math.round(info.duration/1000))});
      let fallback=null;
      try{fallback=this.backupRecord(await this.lyricJSON('https://lrclib.net/api/get?'+query,signal),info);if(fallback?.timed || fallback?.instrumental)return fallback;}catch{}
      const title=this.lyricTitle(info.title),artist=info.artists?.[0] || info.artist.split(/,\s+|\s+feat\.?\s+/i)[0];
      for(const search of [new URLSearchParams({track_name:title,artist_name:artist}),new URLSearchParams({q:title+' '+artist})]){
        if(signal.aborted)throw new Error('Lyrics cancelled');
        try{const rows=await this.lyricJSON('https://lrclib.net/api/search?'+search,signal),matches=(Array.isArray(rows) ? rows : []).map(row=>this.backupRecord(row,info,true)).filter(Boolean).sort((a,b)=>b.rank-a.rank);if(matches[0]?.timed || matches[0]?.instrumental)return matches[0];fallback ||= matches[0];}catch{}
        if(fallback)break;
      }
      if(fallback)return fallback;
      if(allowText && this.prefs.lyricsTextFallback && !signal.aborted){
        const result=await this.lyricJSON(`https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`,signal);
        const lines=String(result.lyrics || '').slice(0,200000).split(/\r?\n/).map(text=>({text:cleanText(text,1000),at:-1})).filter(line=>line.text);
        if(lines.length)return {lines,timed:false,provider:'lyrics.ovh · text only',source:'lyrics-ovh',instrumental:false};
      }
      throw new Error('No matching lyrics');
    }
    async loadLyrics(force=false){
      const uri=this.lastURI;if(!this.prefs.lyrics || !/^spotify:track:[\w-]+$/.test(uri || ''))return;
      if(!force && (this.lyricsLoadedURI===uri || this.lyricsInFlight===uri))return;
      this.lyricsAbort?.abort();const abort=new AbortController();this.lyricsAbort=abort;
      const token=++this.lyricsToken;this.lyricsInFlight=uri;this.lyricState='loading';this.paintLyrics();
      const info={...this.currentTrackMeta};
      try{
        let lyrics=force ? null : this.lyricsCache.get(uri);
        if(!lyrics){
          try{
            const result=await this.apiGet(`https://spclient.wg.spotify.com/color-lyrics/v2/track/${encodeURIComponent(uri.split(':')[2])}?format=json&vocalRemoval=false&market=from_token`,2200);
            const data=result?.lyrics || result,timed=['LINE_SYNCED','SYLLABLE_SYNCED'].includes(data?.syncType);
            const lines=(data?.lines || []).map(line=>({text:cleanText(line.words,1000),at:timed ? number(line.startTimeMs,-1) : -1})).filter(line=>line.text && (!timed || line.at>=0));
            if(lines.length)lyrics={lines:timed ? lines.sort((a,b)=>a.at-b.at) : lines,timed,source:'spotify',provider:cleanText(data.providerDisplayName || data.provider,80) || 'Spotify'};
          }catch{ /* Spotify may not provide lyrics for this recording/session. */ }
          if(token!==this.lyricsToken || this.destroyed || !this.prefs.lyrics)return;
          if((!lyrics || !lyrics.timed) && this.prefs.lyricsFallback){
            this.$('lt-lyrics-status').textContent='Searching more lyric sources…';
            const timer=setTimeout(()=>abort.abort(),7500);
            try{const backup=await this.fetchBackupLyrics(info,abort.signal,!lyrics);if(!lyrics || backup.timed)lyrics=backup;}catch(error){if(!lyrics)throw error;}finally{clearTimeout(timer);}
          }
          if(!lyrics)throw new Error('Lyrics unavailable');
          if(lyrics.lines.length || lyrics.instrumental){this.lyricsCache.set(uri,lyrics);if(this.lyricsCache.size>32)this.lyricsCache.delete(this.lyricsCache.keys().next().value);}
        }
        if(this.destroyed || !this.prefs.lyrics || token!==this.lyricsToken || uri!==this.lastURI)return;
        this.lyricsLoadedURI=uri;this.lyricLines=lyrics.lines;this.lyricTimed=lyrics.timed;this.lyricProvider=lyrics.provider;this.lyricSource=lyrics.source || (lyrics.provider==='LRCLIB' ? 'lrclib' : 'spotify');this.matchLyricLine=false;
        this.lyricInstrumental=lyrics.instrumental;this.lyricState=lyrics.lines.length ? 'ready' : 'empty';this.lyricIndex=-2;
        this.paintLyrics();this.updateLyricPosition();
      }catch{
        if(!this.destroyed && token===this.lyricsToken && uri===this.lastURI){this.lyricsLoadedURI=uri;this.lyricLines=[];this.lyricState='unavailable';this.paintLyrics();}
      }finally{if(token===this.lyricsToken)this.lyricsInFlight=null;}
    }
    loadLyricOffsets(){
      const offsets=new Map();
      try{
        const data=JSON.parse(localStorage.getItem(this.storageKey('lyric-timing')) || '[]');
        if(Array.isArray(data))for(const row of data.slice(-500))if(/^spotify:track:[\w-]+$/.test(row?.uri || '') && ['spotify','lrclib'].includes(row?.source) && Number.isFinite(row.ms))offsets.set(row.uri+'|'+row.source,{...row,ms:clamp(Math.round(row.ms),-15000,15000)});
      }catch{ /* Ignore corrupt timing records without changing other preferences. */ }
      return offsets;
    }
    lyricTimingKey(){return this.lastURI+'|'+(this.lyricSource || 'spotify');}
    lyricOffset(){return this.lyricOffsets.get(this.lyricTimingKey())?.ms || 0;}
    setLyricOffset(ms){
      if(!this.lastURI || !this.lyricTimed || !this.lyricLines.length)return;
      const value=clamp(Math.round(ms),-15000,15000),key=this.lyricTimingKey();
      this.lyricOffsets.delete(key);if(value)this.lyricOffsets.set(key,{uri:this.lastURI,source:this.lyricSource || 'spotify',ms:value,at:Date.now()});
      while(this.lyricOffsets.size>500)this.lyricOffsets.delete(this.lyricOffsets.keys().next().value);
      try{localStorage.setItem(this.storageKey('lyric-timing'),JSON.stringify([...this.lyricOffsets.values()]));}catch{this.notify('Timing works for this session, but could not be saved.');}
      this.matchLyricLine=false;this.lyricIndex=-2;this.lyricScrollUntil=0;this.updateTimingControls();this.updateLyricPosition();
    }
    showLyricsMenu(show, focus=false){
      const menu=this.$?.('lt-lyrics-menu');if(!menu || !show && menu.hidden)return;
      menu.hidden=!show;
      const trigger=this.nowPlaying.querySelector('[data-action="lyricsMenu"]');
      trigger.setAttribute('aria-expanded',String(show));
      if(show)this.positionLyricsMenu();
      if(focus){if(show)requestAnimationFrame(()=>{if(!this.destroyed && !menu.hidden && this.nowPlaying.open)menu.querySelector('button').focus({preventScroll:true});});else trigger.focus({preventScroll:true});}
    }
    positionLyricsMenu(){
      const menu=this.$('lt-lyrics-menu');if(menu.hidden)return;
      const anchor=this.nowPlaying.querySelector('[data-action="lyricsMenu"]').getBoundingClientRect(),rect=menu.getBoundingClientRect();
      if(anchor.bottom<0 || anchor.top>innerHeight){this.showLyricsMenu(false);return;}
      const top=anchor.bottom+8+rect.height<=innerHeight-12 ? anchor.bottom+8 : anchor.top-rect.height-8;
      menu.style.left=Math.max(12,Math.min(anchor.right-rect.width,innerWidth-rect.width-12))+'px';
      menu.style.top=Math.max(12,Math.min(top,innerHeight-rect.height-12))+'px';
    }
    showLyricTiming(show){
      this.showLyricsMenu(false,true);
      this.$('lt-lyric-timing').hidden=!show;this.matchLyricLine=false;
      this.nowPlaying.querySelector('[data-action="lyricTiming"]').setAttribute('aria-expanded',String(show));
      this.updateTimingControls();if(show)this.animateSurface(this.$('lt-lyric-timing'));else this.animateSurface(this.$('lt-lyrics-lines'));
    }
    updateTimingControls(){
      if(!this.$?.('lt-timing-value'))return;
      const offset=this.lyricOffset(),ready=this.prefs.lyrics && this.lyricTimed && this.lyricLines.length>0 && this.lyricState==='ready';
      this.$('lt-timing-value').textContent=offset ? `${(Math.abs(offset)/1000).toFixed(2)} s ${offset>0 ? 'earlier' : 'later'}` : 'Original timing';
      this.$('lt-timing-note').textContent=`${this.lyricProvider ? this.lyricProvider+' · ' : ''}Saved for this recording.`;
      this.$('lt-timing-help').textContent=this.matchLyricLine ? 'Tap the line you hear now. This adjusts timing without moving playback.' : ready ? 'Lyrics late? Tap Earlier. Or choose Match a line, then tap the line you hear.' : 'Timing controls become available with synced lyrics.';
      for(const action of ['lyricsEarlier','lyricsLater','lyricsTimingReset','lyricsMatchLine']){const button=this.nowPlaying.querySelector(`[data-action="${action}"]`);button.disabled=!ready;}
      this.nowPlaying.querySelector('[data-action="lyricsEarlier"]').disabled=!ready || offset>=15000;
      this.nowPlaying.querySelector('[data-action="lyricsLater"]').disabled=!ready || offset<=-15000;
      this.nowPlaying.querySelector('[data-action="lyricsMatchLine"]').setAttribute('aria-pressed',String(Boolean(this.matchLyricLine)));
      if(this.matchLyricLine)this.$('lt-lyrics-status').textContent='Tap the line you hear now to match timing.';
      else if(this.lyricState==='ready')this.$('lt-lyrics-status').textContent=`${this.lyricTimed ? this.lyricProvider || '' : 'Unsynced lyrics · seeking unavailable'+(this.lyricProvider ? ' · '+this.lyricProvider : '')}`;
      for(const b of this.$('lt-lyrics-lines').children){const line=this.lyricLines[Number(b.dataset.lyricIndex)];b.disabled=!this.lyricTimed || !line || line.at<0 || !this.matchLyricLine && this.seek.disabled;if(line)b.setAttribute('aria-label',`${this.matchLyricLine ? 'Match current playback to' : 'Seek to '+time(line.at-offset)+':'} ${line.text}`);}
    }
    paintLyrics(){
      const container=this.$?.('lt-lyrics-lines');if(!container)return;
      cancelAnimationFrame(this.lyricScrollFrame);container.replaceChildren();
      const status=this.lyricState==='loading' ? 'Finding lyrics…' : this.lyricLines.length ? `${this.lyricTimed ? this.lyricProvider || '' : 'Unsynced lyrics · seeking unavailable'+(this.lyricProvider ? ' · '+this.lyricProvider : '')}` : this.lyricInstrumental ? 'Instrumental · no sung lyrics for this recording.' : this.lyricState==='unavailable' ? 'No lyrics found for this recording. Choose Reload lyrics from the options menu, or enable the backup source in Settings.' : 'Lyrics appear here when available.';
      this.$('lt-lyrics-status').textContent=status;
      this.$('lt-lyrics-panel').setAttribute('aria-busy',String(this.lyricState==='loading'));
      this.lyricLines.forEach((line,index)=>{const b=node('button','lt-lyric-line',line.text);b.type='button';b.dataset.lyricIndex=String(index);b.disabled=!this.lyricTimed || line.at<0 || this.seek.disabled;b.setAttribute('aria-label',this.lyricTimed ? `Seek to ${time(line.at-this.lyricOffset())}: ${line.text}` : line.text);container.append(b);});
      this.lyricsSeekDisabled=this.seek.disabled;this.updateTimingControls();
      if(this.nowPlaying.open && this.lyricLines.length)this.animateSurface(container);
    }
    syncLyricClock(){
      const wanted=!this.destroyed && this.nowPlaying?.open && this.prefs.lyrics && !document.hidden;
      if(wanted && !this.lyricsInterval)this.lyricsInterval=setInterval(()=>this.updateLyricPosition(),80);
      else if(!wanted && this.lyricsInterval){clearInterval(this.lyricsInterval);this.lyricsInterval=null;}
    }
    scrollLyricsTo(panel,top){
      cancelAnimationFrame(this.lyricScrollFrame);
      const end=clamp(top,0,Math.max(0,panel.scrollHeight-panel.clientHeight)),start=panel.scrollTop;
      if(!this.motionAllowed() || Math.abs(end-start)<2){panel.scrollTop=end;return;}
      const began=performance.now();
      const tick=now=>{
        if(this.destroyed || !this.nowPlaying.open || !this.prefs.lyrics || Date.now()<(this.lyricScrollUntil || 0))return;
        const t=clamp((now-began)/120,0,1);panel.scrollTop=start+(end-start)*(1-Math.pow(1-t,3));
        if(t<1)this.lyricScrollFrame=requestAnimationFrame(tick);else this.lyricScrollFrame=0;
      };
      this.lyricScrollFrame=requestAnimationFrame(tick);
    }
    updateLyricPosition(){
      if(!this.prefs.lyrics || !this.lyricTimed || !this.lyricLines.length)return;
      const progress=number(read(()=>this.player.getProgress(),0))+this.lyricOffset();let lo=0,hi=this.lyricLines.length;
      while(lo<hi){const mid=(lo+hi)>>1;if(this.lyricLines[mid].at<=progress)lo=mid+1;else hi=mid;}
      const index=lo-1;if(index===this.lyricIndex)return;this.lyricIndex=index;
      const children=this.$('lt-lyrics-lines').children;
      for(let i=0;i<children.length;i++){children[i].classList.toggle('lt-lyric-active',i===index);if(i===index)children[i].setAttribute('aria-current','true');else children[i].removeAttribute('aria-current');}
      const panel=this.$('lt-lyrics-lines'),active=children[index];
      if(active)this.playMotion(active,[{opacity:.7,transform:'translateY(3px)'},{opacity:1,transform:'none'}],{duration:100});
      if(this.prefs.lyrics && active && Date.now()>(this.lyricScrollUntil || 0)){
        const top=active.getBoundingClientRect().top-panel.getBoundingClientRect().top+panel.scrollTop-panel.clientHeight*.4;
        this.scrollLyricsTo(panel,top);
      }
    }
    applyLyricsLayout(){
      if(!this.nowPlaying)return;
      const enabled=this.prefs.lyrics,changed=this.lastLyricsLayout!==undefined && this.lastLyricsLayout!==enabled;
      const previous=changed ? this.lyricLayoutRects() : new Map();
      if(changed && !enabled)this.makeLyricExitGhost();
      else if(enabled){this.lyricExitGhost?.remove();this.lyricExitGhost=null;}
      this.nowPlaying.dataset.lyrics=String(enabled);this.$('lt-lyrics-panel').hidden=!enabled;this.lastLyricsLayout=enabled;
      const b=this.nowPlaying.querySelector('[data-action="toggleLyrics"]');b?.setAttribute('aria-pressed',String(enabled));
      if(!enabled){this.showLyricsMenu(false);this.lyricsToken++;this.lyricsAbort?.abort();this.lyricsInFlight=null;cancelAnimationFrame(this.lyricScrollFrame);}
      else if(this.nowPlaying.open)void this.loadLyrics();
      if(changed)this.animateLyricLayout(previous,enabled);
      this.updateTimingControls();this.syncLyricClock();
    }
    toggleLyrics(){
      this.prefs.lyrics=!this.prefs.lyrics;this.save();this.applyPreferences();
    }

    storageKey(name) {
      return `liquid-touch.${name}.v1:${this.accountNamespace}`;
    }
    loadRecords(name, limit) {
      try {
        const parsed=JSON.parse(localStorage.getItem(this.storageKey(name)) || '[]');
        if(!Array.isArray(parsed))return [];
        return parsed.slice(0,limit).filter(row=>row && typeof row==='object').map(row=>{
          if(name==='search-queries')return {query:cleanText(row.query,300),at:number(row.at)};
          const entity=normalizeEntity({...row,name:row.title});
          return entity ? {...entity,artist:cleanText(row.artist),album:cleanText(row.album),at:number(row.at)} : null;
        }).filter(row=>row && (name!=='search-queries' || row.query));
      } catch { return []; }
    }
    persistRecords(name, records) {
      const serializable=()=>records.map(row=>({...row,image:row.image?.length<2048 ? row.image : ''}));
      try { localStorage.setItem(this.storageKey(name),JSON.stringify(serializable())); }
      catch {
        if(name==='play-history' && records.length>500){records.splice(Math.max(500,Math.floor(records.length*.75)));try{localStorage.setItem(this.storageKey(name),JSON.stringify(serializable()));return;}catch{}}
        if(!this.storageWarning){this.storageWarning=true;this.notify('Local storage is full or unavailable. New history stays in this session.');}
      }
    }
    collectNativeEntities(root) {
      const found=new Map(); if(!root)return found;
      const selectors='a[href], [data-uri], [data-context-uri], [id^="listrow-title-spotify:"]';
      for(const element of root.querySelectorAll(selectors)){
        const raw=element.dataset.uri || element.dataset.contextUri || element.getAttribute('href') || element.id.replace(/^listrow-title-/,'');
        const info=uriInfo(raw);if(!info)continue;
        let card=element.closest('.main-card-card, [data-testid="card"], [data-testid="card-container"], [data-testid="grid-card"], [data-testid="shortcut"], [data-encore-id="card"], .main-yourLibraryX-listItem, [role="row"], [role="treeitem"], li');
        if(!card){
          let parent=element;
          for(let i=0;i<5 && parent && parent!==root;i++,parent=parent.parentElement){
            const count=parent.querySelectorAll('img').length;
            if(count===1){card=parent;break;}
          }
        }
        if(!card)continue;
        const titleNode=card.querySelector('[data-testid="entityTitle"], [id^="listrow-title-"], .main-cardHeader-text, .main-cardHeader-link, h3, h2, strong');
        const title=cleanText(titleNode?.textContent || element.getAttribute('aria-label') || element.textContent,300).replace(/^Play\s+/i,'');
        if(!title || title.length>250)continue;
        const images=[...card.querySelectorAll('img')].filter(image=>!image.closest('[data-testid*="equaliz"], [data-testid*="equalis"], [class*="equaliz"], [class*="equalis"], [data-testid="playing-indicator"], [aria-label="Playing"]'));
        const image=images.find(image=>image.matches('.main-cardImage-image, [data-testid="card-image"], [data-testid="cover-art-image"]') && imageURL(image.currentSrc || image.getAttribute('src'))) || images.find(image=>imageURL(image.currentSrc || image.getAttribute('src')));
        const subtitle=cleanText(card.querySelector('.main-cardSubHeader-root, [data-testid="entitySubtitle"], [class*="subtitle"]')?.textContent,300);
        const section=cleanText(card.closest('section, [data-testid="component-shelf"]')?.querySelector('h2,h3')?.textContent,100);
        const entity=normalizeEntity({...info,name:title,subtitle,imageUrl:image?.currentSrc || image?.getAttribute('src'),section});
        if(entity){
          // A lazy image or playing state must not erase an already known cover.
          entity.image ||= this.homeEntities.get(entity.uri)?.image || this.libraryEntities.get(entity.uri)?.image || this.entities.get(entity.uri)?.image || this.artCache.get(entity.uri)?.image || '';
          found.set(entity.uri,entity);
        }
      }
      return found;
    }
    captureNativeCatalog() {
      let changed=false;
      const merge=(source,target)=>{for(const [uri,entry] of source){
        const old=target.get(uri);
        if(old && target===this.libraryEntities && ['platform','rootlist'].includes(this.librarySource)){
          if(!old.image && entry.image){target.set(uri,{...old,image:entry.image});changed=true;}
          continue;
        }
        entry.image ||= old?.image || '';
        if(!old || old.title!==entry.title || old.image!==entry.image || old.section!==entry.section){target.set(uri,entry);changed=true;}
        this.entities.set(uri,target.get(uri));
      }};
      if((this.history.location?.pathname || '/')==='/')merge(this.collectNativeEntities(this.main),this.homeEntities);
      if(/^\/search\/?$/.test(this.history.location?.pathname || '')){
        for(const section of this.main?.querySelectorAll('section, [data-testid="recent-searches"]') || []){
          if(section.dataset.testid==='recent-searches' || /recent.*search|search.*recent/i.test(section.querySelector('h2,h3')?.textContent || '')){
            for(const entry of this.collectNativeEntities(section).values()){
              if(!this.recentSearches.some(row=>row.uri===entry.uri)){this.recentSearches.push({...entry,at:Date.now()});changed=true;}
            }
          }
        }
        if(this.recentSearches.length>50)this.recentSearches.length=50;
        if(changed)this.persistRecords('search-items',this.recentSearches);
      }
      merge(this.collectNativeEntities(this.library),this.libraryEntities);
      if(changed){this.catalogVersion++;if(this.browse)this.renderBrowse();}
    }
    async readLibraryPage(api) {
      const rows=result=>result?.items || result?.data?.items || result?.rows;
      if(!this.libraryLanes){
        try {
          const result=await api.getContents({filters:[],offset:this.libraryOffset,limit:100,flattenTree:true});
          const items=rows(result);
          if(!Array.isArray(items))throw new Error('Unknown library shape');
          if(items.length || this.libraryOffset>0)return result;
        }catch{ /* Older clients require explicit playlist/album/artist lanes. */ }
        this.libraryLanes=['2','0','1'].map(filter=>({filter,offset:0,more:true}));
      }
      const lanes=this.libraryLanes.filter(lane=>lane.more);
      const results=await Promise.allSettled(lanes.map(async lane=>({lane,result:await api.getContents({filters:[lane.filter],offset:lane.offset,limit:100,flattenTree:true})})));
      const items=[];let valid=0;
      results.forEach((response,i)=>{
        const lane=lanes[i];
        if(response.status!=='fulfilled'){lane.more=false;return;}
        const page=rows(response.value.result);if(!Array.isArray(page)){lane.more=false;return;}
        valid++;items.push(...page);lane.offset+=page.length;
        const total=response.value.result.totalLength ?? response.value.result.totalCount;
        lane.more=page.length>0 && (typeof total==='number' ? lane.offset<total : page.length>=100);
      });
      if(!valid && lanes.length)throw new Error('Library lanes unavailable');
      return {items,hasMore:this.libraryLanes.some(lane=>lane.more)};
    }
    async loadLibrary(reset=false) {
      if(this.libraryBusy || this.destroyed)return;
      if(!reset && !this.libraryHasMore)return;
      this.libraryBusy=true;
      if(reset){this.libraryOffset=0;this.libraryLanes=null;this.libraryHasMore=true;this.libraryEntities.clear();}
      const add=items=>{
        let added=0;
        for(const raw of items){
          const entry=normalizeEntity(raw);
          if(entry){if(!this.libraryEntities.has(entry.uri))added++;this.libraryEntities.set(entry.uri,entry);this.entities.set(entry.uri,entry);}
          if(Array.isArray(raw?.items))added+=add(raw.items);
          if(Array.isArray(raw?.children))added+=add(raw.children);
        }
        return added;
      };
      try {
        const api=this.S.Platform?.LibraryAPI;
        if(typeof api?.getContents==='function'){
          const result=await this.readLibraryPage(api);
          if(this.destroyed)return;
          const items=result?.items || result?.data?.items || result?.rows;
          if(!Array.isArray(items))throw new Error('Unrecognized library response');
          const added=add(items);this.libraryOffset+=items.length;
          const total=result.totalLength ?? result.totalCount ?? result.total;
          this.libraryHasMore=result.hasMore ?? (items.length>0 && (typeof total==='number' ? this.libraryOffset<total : items.length>=100));
          if(this.libraryOffset>items.length && !added)this.libraryHasMore=false;
          this.librarySource='platform';
        }else throw new Error('Library API unavailable');
      } catch {
        try {
          const root=this.S.Platform?.RootlistAPI;
          if(typeof root?.getContents!=='function')throw new Error('Rootlist unavailable');
          const result=await root.getContents();if(this.destroyed)return;
          const items=result?.items || result?.rows || result?.contents?.items;
          if(!Array.isArray(items))throw new Error('Unrecognized rootlist');
          add(items);this.librarySource='rootlist';
        } catch { this.librarySource='native'; }
        this.libraryHasMore=false;
      } finally {
        this.libraryBusy=false;
        if(!this.destroyed){this.catalogVersion++;this.captureNativeCatalog();this.renderBrowse();}
      }
    }
    detailInfo(path=this.getRoutePath()){const info=uriInfo(path);return info && path.startsWith('/') && info.path===path ? info : null;}
    detailState(info){
      let page=this.detailPages.get(info.uri);
      if(!page){
        const entry=this.entities.get(info.uri) || this.homeEntities.get(info.uri) || this.libraryEntities.get(info.uri) || normalizeEntity({uri:info.uri,name:info.type==='collection' ? 'Liked Songs' : 'Your music'});
        page={entry:{...entry},tracks:[],releases:[],loading:true,version:0,loadedAt:0,nextOffset:0,hasMore:false,error:''};this.detailPages.set(info.uri,page);
        while(this.detailPages.size>12){const key=this.detailPages.keys().next().value;if(key===info.uri)break;this.detailPages.delete(key);}
        void Promise.resolve().then(()=>this.loadDetail(page));
      }
      return page;
    }
    detailRows(group){return Array.isArray(group) ? group : Array.isArray(group?.items) ? group.items : Array.isArray(group?.edges) ? group.edges : null;}
    detailItem(row){
      let value=row;
      for(let i=0;i<5 && value && typeof value==='object';i++){
        const next=value.item?.data || value.item || value.track?.data || value.track || value.episode?.data || value.episode || value.node || value.data;
        if(!next || next===value)break;value=next;
      }
      return value;
    }
    parseDetail(result,entry,offset=0){
      const data=result?.data || result;
      const names={playlist:['playlistV2','playlist'],album:['albumUnion','album'],artist:['artistUnion','artist'],track:['trackUnion','track'],episode:['episodeUnion','episode'],show:['podcastUnion','podcast','show'],collection:['me']};
      const root=(names[entry.type] || []).map(key=>data?.[key]).find(Boolean) || data;
      if(!root || typeof root!=='object' || Array.isArray(root))throw new Error('Unknown detail response');
      const group=entry.type==='artist' ? root.discography?.topTracks || root.topTracks || root.topTracksV2 || root.tracks : entry.type==='album' ? root.tracksV2 || root.tracks : entry.type==='show' ? root.episodesV2 || root.episodes : entry.type==='track' || entry.type==='episode' ? [root] : root.contents || root.content || root.tracks || root;
      const rows=this.detailRows(group);if(!rows)throw new Error('Detail items unavailable');
      const meta=normalizeEntity({...root,uri:entry.uri,name:root.name || root.profile?.name || root.metadata?.name || entry.title});
      if(meta){meta.image=pickArtwork(root.images || root.coverArt || root.visuals || root.image || root.metadata?.image_xlarge_url || root.metadata?.image_url) || entry.image;meta.subtitle=meta.subtitle==='Playlist' || meta.subtitle==='Album' || meta.subtitle==='Artist' ? entry.subtitle : meta.subtitle;}
      const tracks=[];
      rows.forEach((row,index)=>{const raw=this.detailItem(row),track=normalizeEntity(raw);if(track && ['track','episode'].includes(track.type))tracks.push({...track,duration:number(raw?.duration?.totalMilliseconds || raw?.duration?.milliseconds || raw?.duration_ms || raw?.duration || raw?.metadata?.duration),unavailable:raw?.is_playable===false || raw?.isPlayable===false || raw?.playability?.playable===false,sourceIndex:offset+index});});
      const releases=[],seen=new Set();
      const visit=(value,depth=0)=>{if(!value || depth>5)return;if(Array.isArray(value)){for(const row of value)visit(row,depth+1);return;}const entity=normalizeEntity(this.detailItem(value));if(entity?.type==='album' && !seen.has(entity.uri)){seen.add(entity.uri);releases.push(entity);return;}for(const key of ['items','releases','albums','singles','data','item'])visit(value[key],depth+1);};
      if(entry.type==='artist')for(const key of ['albums','singles','all','popularReleases','latest'])visit(root.discography?.[key] || root[key]);
      const total=number(group?.totalCount ?? group?.totalLength ?? group?.total ?? root.totalLength,NaN),nextOffset=offset+rows.length;
      const hasMore=!['artist','track','episode'].includes(entry.type) && rows.length>0 && (Number.isFinite(total) ? nextOffset<total : typeof group?.next==='string' || rows.length>=50);
      return {meta,tracks,releases,total,nextOffset,hasMore,description:cleanText(root.description,1000).replace(/<[^>]*>/g,' ')};
    }
    async detailQuery(name,entry,offset){
      const gql=this.S.GraphQL,definition=gql?.Definitions?.[name] || gql?.QueryDefinitions?.[name];if(!definition || typeof gql.Request!=='function')throw new Error('Client query unavailable');
      return this.withTimeout(gql.Request(definition,{uri:entry.uri,locale:this.S.Platform?.Session?.locale || 'en',offset,limit:50,includePrerelease:true,includePreReleases:true},{persistCache:true}),2300);
    }
    async fetchDetail(entry,offset=0){
      const type=entry.type,id=encodeURIComponent(entry.path.split('/')[2] || ''),query=new URLSearchParams({limit:'50',offset:String(offset)}),platform=this.S.Platform;
      if(type==='playlist' && typeof platform?.PlaylistAPI?.getContents==='function'){
        try{
          const result=await this.withTimeout(platform.PlaylistAPI.getContents(entry.uri,{offset,limit:50}),2300),page=this.parseDetail(result,entry,offset);
          if(!offset && typeof platform.PlaylistAPI.getMetadata==='function'){
            void this.withTimeout(platform.PlaylistAPI.getMetadata(entry.uri),1800).then(meta=>this.updateDetailMetadata(entry.uri,meta)).catch(()=>{});
          }
          return page;
        }catch{ /* Try the installed query or authenticated catalog next. */ }
      }
      if(type==='collection' && typeof platform?.LibraryAPI?.getTracks==='function')try{return this.parseDetail(await this.withTimeout(platform.LibraryAPI.getTracks({offset,limit:50}),2300),entry,offset);}catch{}
      const definition={playlist:'FetchPlaylistContents',album:'getAlbum',artist:'queryArtistOverview',track:'getTrack',episode:'getEpisode',show:'queryPodcastEpisodes'}[type];
      if(definition)try{return this.parseDetail(await this.detailQuery(definition,entry,offset),entry,offset);}catch{}
      if(type==='album' && typeof platform?.LibraryAPI?.getAlbum==='function')try{return this.parseDetail(await this.withTimeout(platform.LibraryAPI.getAlbum(entry.uri,{offset,limit:50}),1800),entry,offset);}catch{}
      const get=path=>this.apiGet('https://api.spotify.com/v1/'+path,2600);
      if(type==='artist'){
        const results=await Promise.allSettled([get(`artists/${id}`),get(`artists/${id}/top-tracks`),get(`artists/${id}/albums?limit=50`)]);
        const value=index=>results[index].status==='fulfilled' ? results[index].value : null;
        const meta=value(0),top=value(1),albums=value(2);if(!Array.isArray(top?.tracks) && !Array.isArray(albums?.items))throw new Error('Artist items unavailable');
        return this.parseDetail({...meta,uri:entry.uri,name:meta?.name || entry.title,topTracks:{items:top?.tracks || []},albums:{items:albums?.items || []}},entry,0);
      }
      if(type==='playlist'){
        const result=await get(`playlists/${id}/tracks?${query}`),page=this.parseDetail(result,entry,offset);
        if(!offset)void get(`playlists/${id}`).then(meta=>this.updateDetailMetadata(entry.uri,meta)).catch(()=>{});
        return page;
      }
      if(type==='collection')return this.parseDetail(await get('me/tracks?'+query),entry,offset);
      if(type==='album' || type==='show'){
        if(!offset)return this.parseDetail(await get(`${type}s/${id}`),entry,offset);
        const group=await get(`${type}s/${id}/${type==='album' ? 'tracks' : 'episodes'}?${query}`);
        return this.parseDetail({[type==='album' ? 'tracks' : 'episodes']:group},entry,offset);
      }
      if(type==='track' || type==='episode')return this.parseDetail(await get(`${type}s/${id}`),entry,0);
      throw new Error('Unsupported detail type');
    }
    updateDetailMetadata(uri,raw){
      const page=this.detailPages.get(uri);if(!page || this.destroyed)return;
      const meta=normalizeEntity({...raw,uri,name:raw?.name || raw?.metadata?.name || page.entry.title});if(!meta)return;
      page.entry={...page.entry,...meta,image:meta.image || page.entry.image};page.description=cleanText(raw?.description,1000).replace(/<[^>]*>/g,' ');page.metaVersion=(page.metaVersion || 0)+1;page.version++;
      if(meta.image)this.applyEntityArtwork(uri,meta.image);
      if(this.detailInfo()?.uri===uri && !this.libraryOpen)this.renderBrowse();
    }
    async loadDetail(page,more=false){
      const uri=page.entry.uri;if(page.fetching || this.destroyed)return;
      page.fetching=true;page.loading=true;page.error='';page.version++;
      if(this.detailInfo()?.uri===uri && !this.libraryOpen)this.renderBrowse();
      const offset=more ? page.nextOffset : 0,metaVersion=page.metaVersion || 0;
      try{
        const result=await this.fetchDetail(page.entry,offset);if(this.destroyed || this.detailPages.get(uri)!==page)return;
        if(result.meta && (page.metaVersion || 0)===metaVersion)page.entry={...page.entry,...result.meta,image:result.meta.image || page.entry.image};
        page.tracks=more ? [...page.tracks,...result.tracks] : result.tracks;page.releases=result.releases.length ? result.releases : page.releases;
        Object.assign(page,{hasMore:result.hasMore,nextOffset:result.nextOffset,total:result.total,description:result.description || page.description,loadedAt:Date.now()});
      }catch{
        if(this.destroyed || this.detailPages.get(uri)!==page)return;
        page.retryMore=more;page.error=more ? 'More songs could not be loaded. Your loaded songs are still available.' : 'Songs could not be loaded in this Spotify session. Try again, or open this item in the desktop interface.';
      }finally{
        page.loading=false;page.fetching=false;page.version++;
        if(!this.destroyed && this.detailInfo()?.uri===uri && !this.libraryOpen)this.renderBrowse();
      }
    }
    renderDetail(page){
      const entry=page.entry,hero=node('section','lt-detail-hero lt-glass');hero.dataset.detailUri=entry.uri;
      const art=node('div','lt-detail-art lt-art-placeholder');art.innerHTML=icon(entry.type==='collection' ? 'heart' : entry.type==='artist' ? 'spark' : 'play');
      if(entry.image){const image=node('img','');image.src=entry.image;image.alt='';image.decoding='async';art.append(image);}
      else if(entry.type!=='collection')this.queueArtwork(entry.uri);
      const text=node('div','lt-detail-copy');text.append(node('span','lt-eyebrow',{playlist:'PLAYLIST',album:'ALBUM',artist:'ARTIST',track:'SONG',episode:'EPISODE',show:'PODCAST',collection:'YOUR FAVORITES'}[entry.type]),node('h1','',entry.title),node('p','',entry.subtitle));
      if(page.description)text.append(node('p','lt-detail-description',page.description));
      const actions=node('div','lt-quick-actions'),play=node('button','lt-pill lt-detail-play','Play');play.type='button';play.dataset.detailAction='play';play.setAttribute('aria-label',`Play ${entry.title}`);actions.append(play);
      const desktop=node('button','lt-pill','Open in Spotify');desktop.type='button';desktop.dataset.detailAction='desktop';actions.append(desktop);text.append(actions);hero.append(art,text);this.browse.append(hero);
      const refresh=node('button','lt-pill','Refresh');refresh.type='button';refresh.dataset.detailAction='refresh';refresh.disabled=page.loading;actions.append(refresh);
      const status=node('p','lt-detail-status',page.loading ? page.tracks.length ? 'Loading more songs…' : 'Loading songs…' : page.error || `${page.tracks.length} ${page.tracks.length===1 ? 'song' : 'songs'}${page.hasMore ? ' loaded' : ''}`);status.setAttribute('role','status');this.browse.append(status);this.browse.setAttribute('aria-busy',String(page.loading));
      if(page.tracks.length){
        const section=node('section','lt-detail-songs');section.append(node('h2','lt-section-title',entry.type==='artist' ? 'Popular songs' : entry.type==='show' ? 'Episodes' : 'Songs'));const list=node('div','lt-detail-tracklist');
        page.tracks.forEach((track,index)=>{
          const row=node('button','lt-detail-track lt-glass');row.type='button';row.dataset.detailTrack=String(index);row.disabled=track.unavailable;row.setAttribute('aria-label',`${track.unavailable ? 'Unavailable' : 'Play'} ${track.title}, ${track.subtitle}`);
          const number=node('span','lt-detail-number',String(index+1));row.append(number);
          if(track.image){const image=node('img','');image.src=track.image;image.alt='';image.loading='lazy';image.decoding='async';row.append(image);}
          const copy=node('span','lt-detail-track-copy');copy.append(node('strong','',track.title),node('span','',track.subtitle));row.append(copy,node('span','lt-detail-duration',track.duration ? time(track.duration) : ''));list.append(row);
        });section.append(list);this.browse.append(section);
      }else if(!page.loading && !page.error)this.browse.append(node('p','lt-empty','No playable songs are available in this item.'));
      if(page.releases.length)this.appendGrid(this.browse,'Releases',page.releases);
      if(page.error){const retry=node('button','lt-pill lt-glass','Try again');retry.type='button';retry.dataset.detailAction=page.retryMore ? 'more' : 'retry';this.browse.append(retry);}
      else if(page.hasMore){const more=node('button','lt-pill lt-glass',page.loading ? 'Loading…' : 'Load more songs');more.type='button';more.disabled=page.loading;more.dataset.detailAction='more';this.browse.append(more);}
    }
    makeCard(entry) {
      this.entities.set(entry.uri,entry);
      const article=node('article','lt-card lt-glass');article.dataset.uri=entry.uri;
      const face=node('button','lt-card-face');face.type='button';face.dataset.ltCard=entry.uri;
      face.setAttribute('aria-label',`${entry.title}. ${entry.type==='album' || entry.type==='playlist' || entry.type==='collection' ? 'Tap to play, double tap to open' : entry.type==='artist' || entry.type==='show' ? 'Open' : 'Play'}`);
      const art=node('span','lt-card-art');
      art.classList.add('lt-art-placeholder');art.innerHTML=icon(entry.type==='collection' ? 'heart' : entry.type==='artist' ? 'spark' : 'play');
      if(entry.image){const img=node('img','');img.src=entry.image;img.alt='';img.loading='lazy';img.decoding='async';img.onerror=()=>{img.hidden=true;this.queueArtwork(entry.uri);};art.append(img);}
      else if(entry.type!=='collection'){article.dataset.needsArt='true';this.imageObserver?.observe(article);}
      const title=node('strong','lt-card-title',entry.title);const typeLabel={track:'Song',artist:'Artist',album:'Album',playlist:'Playlist',collection:'Playlist',episode:'Episode',show:'Podcast'}[entry.type] || '';const subtitle=node('span','lt-card-subtitle',entry.subtitle===typeLabel ? typeLabel : `${typeLabel} · ${entry.subtitle}`);
      face.append(art,title,subtitle);
      const open=node('button','lt-card-open','Open');open.type='button';open.dataset.openUri=entry.uri;open.setAttribute('aria-label',`Open ${entry.title}`);
      article.append(face,open);return article;
    }
    appendGrid(parent, title, entries) {
      if(!entries.length)return;
      const section=node('section','lt-card-section');section.append(node('h2','lt-section-title',title));
      const grid=node('div','lt-card-grid');for(const entry of entries)grid.append(this.makeCard(entry));
      section.append(grid);parent.append(section);
    }
    renderBrowse() {
      if(!this.browse || this.destroyed)return;
      const path=this.getRoutePath();
      const detail=!this.libraryOpen && this.detailInfo(path),page=detail ? this.detailState(detail) : null;
      const kind=this.libraryOpen ? 'library' : path==='/' ? 'home' : /^\/search\/?$/.test(path) ? 'search' : path.startsWith('/search/') ? 'results' : detail ? 'detail' : '';
      document.body.dataset.ltCustomPage=kind;
      this.browse.hidden=!kind;
      if(!kind)return;
      if(this.pointerHeld){this.browseDeferred=true;return;}
      const signature=(kind==='detail' ? [kind,path,page.version] : kind==='home' ? [kind,this.catalogVersion,this.welcomeText(),this.prefs.welcomeSubtitle] : kind==='library' ? [kind,this.catalogVersion,this.libraryQuery,this.libraryFilter,this.libraryBusy,this.libraryHasMore] : kind==='results' ? [kind,path,this.searchResultVersion,this.searchFilter] : [kind,this.catalogVersion]).join('|');
      if(signature===this.browseSignature && kind===this.browseKind){this.refreshGreeting();return;}
      const active=document.activeElement;
      const focusId=this.browse.contains(active) ? active.id : '';
      const selection=focusId && active.selectionStart;
      const previousKind=this.browseKind,previousScroll=this.browse.scrollTop,detailChanged=kind==='detail' && this.browseDetailPath!==path;
      if(previousKind && previousKind!==kind){
        this.imageObserver?.disconnect();const fragment=document.createDocumentFragment();fragment.append(...this.browse.childNodes);
        this.browsePages.set(previousKind,{signature:this.browseSignature,fragment,scroll:previousScroll});
      }
      const cached=this.browsePages.get(kind),scroll=detailChanged ? 0 : kind===previousKind ? previousScroll : cached?.scroll || 0;this.browseDetailPath=kind==='detail' ? path : null;
      this.browseSignature=signature;this.browsePages.delete(kind);
      if(kind!==previousKind && cached?.signature===signature){
        this.browseKind=kind;this.browse.replaceChildren(cached.fragment);this.browse.scrollTop=scroll;this.browseReuseCount=(this.browseReuseCount || 0)+1;
        if(!['results','detail'].includes(kind))this.browse.removeAttribute('aria-busy');
        for(const card of this.browse.querySelectorAll('.lt-card[data-needs-art]'))this.imageObserver?.observe(card);
        this.refreshGreeting();return;
      }
      this.browseBuildCount=(this.browseBuildCount || 0)+1;
      this.browseKind=kind;this.browse.replaceChildren();
      if(kind==='detail')this.renderDetail(page);
      else if(kind==='home'){
        const hero=node('section','lt-home-hero');
        const greeting=node('div','lt-home-greeting'),clock=node('time','lt-home-clock lt-glass');clock.id='lt-home-clock';clock.hidden=!this.prefs.homeClock;
        greeting.append(node('h1','',this.welcomeText()),clock);
        hero.append(node('span','lt-eyebrow','YOUR SPACE, YOUR SOUND'),greeting,node('p','',this.prefs.welcomeSubtitle));
        const actions=node('div','lt-quick-actions');
        for(const [label,action] of [['Liked Songs','likedSongs'],['Listening history','playHistory']]){const b=node('button','lt-pill lt-glass',label);b.type='button';b.dataset.action=action;actions.append(b);}
        hero.append(actions);this.browse.append(hero);this.refreshHomeClock();
        const groups=new Map();
        for(const entry of this.homeEntities.values()){
          const section=entry.section || 'Jump back in';if(!groups.has(section))groups.set(section,[]);groups.get(section).push(entry);
        }
        for(const [title,entries] of groups)this.appendGrid(this.browse,title,entries);
        if(!groups.size)this.appendGrid(this.browse,'From your library',[...this.libraryEntities.values()].slice(0,12));
        if(!groups.size && !this.libraryEntities.size)this.browse.append(node('p','lt-empty','Spotify is loading your music. Your recommendations will appear here.'));
        const more=node('button','lt-pill lt-glass','More from Spotify');more.type='button';more.dataset.action='moreHome';this.browse.append(more);
      }else if(kind==='library'){
        const heading=node('div','lt-page-heading');heading.append(node('span','lt-eyebrow','A COLLECTION THAT SOUNDS LIKE YOU'),node('h1','','Your Library'));
        const tools=node('div','lt-library-tools');
        const field=node('label','lt-field lt-glass');field.innerHTML=icon('search');
        const input=node('input','');input.type='search';input.id='lt-library-search';input.placeholder='Search your library';input.setAttribute('aria-label','Search your library');input.value=this.libraryQuery;field.append(input);
        const refresh=node('button','lt-pill lt-glass','Refresh');refresh.type='button';refresh.dataset.action='refreshLibrary';
        tools.append(field,refresh);
        const filters=node('div','lt-filter-bar');
        for(const [type,label] of [['all','All'],['playlist','Playlists'],['album','Albums'],['artist','Artists']]){
          const b=node('button','lt-pill lt-glass',label);b.type='button';b.dataset.libraryFilter=type;b.setAttribute('aria-pressed',String(this.libraryFilter===type));filters.append(b);
        }
        heading.classList.add('lt-library-heading');
        const controls=node('div','lt-library-controls');controls.append(tools,filters);
        this.browse.append(heading,controls,node('p','lt-note','Tap to play. Double tap to explore.'));
        const liked=normalizeEntity({uri:'spotify:collection:tracks',name:'Liked Songs',subtitle:'Your favorites, together'});
        const all=[liked,...this.libraryEntities.values()].filter((item,i,rows)=>rows.findIndex(r=>r.uri===item.uri)===i);
        const visible=all.filter(entry=>(this.libraryFilter==='all' || entry.type===this.libraryFilter || this.libraryFilter==='playlist' && entry.type==='collection') && `${entry.title} ${entry.subtitle}`.toLocaleLowerCase().includes(this.libraryQuery.toLocaleLowerCase()));
        this.appendGrid(this.browse,`${visible.length} ${visible.length===1 ? 'item' : 'items'}${this.libraryHasMore ? ' · more available' : ''}`,visible);
        if(!visible.length)this.browse.append(node('p','lt-empty','No matches in the loaded library. Try another name.'));
        if(this.libraryHasMore){const more=node('button','lt-pill lt-glass',this.libraryBusy ? 'Loading…' : 'Load more');more.type='button';more.dataset.action='moreLibrary';more.disabled=this.libraryBusy;this.browse.append(more);}
        if(this.librarySource==='native')this.browse.append(node('p','lt-note','Showing items available from Spotify’s sidebar. Refresh after the library finishes loading; Desktop interface keeps access to its full library.'));
      }else if(kind==='results'){
        const query=this.queryFromPath(),heading=node('div','lt-page-heading');
        heading.append(node('span','lt-eyebrow','FIND YOUR NEXT FAVORITE'),node('h1','',`Results for “${query}”`));
        const status=node('p','lt-result-status',this.searchResultBusy ? 'Searching Spotify…' : this.searchError || `${this.searchResults.length} results loaded`);status.setAttribute('role','status');heading.append(status);this.browse.append(heading);
        this.browse.setAttribute('aria-busy',String(this.searchResultBusy));
        const filters=node('div','lt-filter-bar');
        for(const [type,label] of [['all','All'],['track','Songs'],['artist','Artists'],['album','Albums'],['playlist','Playlists']]){const b=node('button','lt-pill lt-glass',label);b.type='button';b.dataset.searchFilter=type;b.setAttribute('aria-pressed',String(this.searchFilter===type));filters.append(b);}this.browse.append(filters);
        if(this.searchFilter==='all')this.appendGrid(this.browse,'Top matches',this.searchResults);
        else for(const [type,label] of [['track','Songs'],['artist','Artists'],['album','Albums'],['playlist','Playlists']])if(this.searchFilter===type)this.appendGrid(this.browse,label,this.searchResults.filter(entry=>entry.type===type));
        if(!this.searchResultBusy && !this.searchError && !this.searchResults.length)this.browse.append(node('p','lt-empty','No matches. Try a different song, artist, or spelling.'));
        if(this.searchError){const row=node('div','lt-quick-actions');for(const [label,action] of [['Retry search','retrySearch'],['Open desktop search','nativeSearch']]){const b=node('button','lt-pill lt-glass',label);b.type='button';b.dataset.action=action;row.append(b);}this.browse.append(row);}
        if(this.searchHasMore){const more=node('button','lt-pill lt-glass',this.searchResultBusy ? 'Loading…' : 'Load more results');more.type='button';more.dataset.action='moreSearch';more.disabled=this.searchResultBusy;this.browse.append(more);}
      }else{
        const heading=node('div','lt-page-heading');heading.append(node('span','lt-eyebrow','PICK UP A THREAD'),node('h1','','Recent searches'),node('p','','Songs, albums, playlists, and artists you found here.'));this.browse.append(heading);
        this.appendGrid(this.browse,'Recently found',this.recentSearches);
        if(!this.recentSearches.length)this.browse.append(node('p','lt-empty','Your next discovery starts above. Items you play or open from search will appear here.'));
      }
      this.browse.scrollTop=scroll;
      if(!['results','detail'].includes(kind))this.browse.removeAttribute('aria-busy');
      for(const card of this.browse.querySelectorAll('.lt-card[data-needs-art]'))this.imageObserver?.observe(card);
      if(focusId){const input=this.$(focusId);if(input){input.focus({preventScroll:true});if(typeof selection==='number')try{input.setSelectionRange(selection,selection);}catch{}}}
    }
    handleBrowseClick(event) {
      const detailControl=event.target.closest('[data-detail-action],[data-detail-track]');
      if(detailControl){
        event.preventDefault();const page=this.detailPages.get(this.detailInfo()?.uri);if(!page)return true;
        if(detailControl.dataset.detailTrack!==undefined){const track=page.tracks[Number(detailControl.dataset.detailTrack)];if(track && !track.unavailable)void this.callPlayer('playUri',track.uri,['album','playlist','collection'].includes(page.entry.type) ? {uri:page.entry.uri} : undefined);}
        else if(detailControl.dataset.detailAction==='play')void this.playEntity(page.entry);
        else if(detailControl.dataset.detailAction==='desktop'){this.detailOwned=false;this.enable(false,false);this.history.push(page.entry.path);}
        else void this.loadDetail(page,detailControl.dataset.detailAction==='more');return true;
      }
      const lyric=event.target.closest('[data-lyric-index]');
      if(lyric){const line=this.lyricLines[Number(lyric.dataset.lyricIndex)];if(line && line.at>=0){if(this.matchLyricLine){const offset=line.at-number(read(()=>this.player.getProgress(),0));this.setLyricOffset(offset);if(Math.abs(offset)>15000)this.notify('Timing correction is limited to 15 seconds. Check the recording or lyric source.');else this.notify('Lyrics matched. Open Timing to adjust or reset.');}else if(!this.seek.disabled){this.lastUserSeek=Date.now();this.lyricScrollUntil=0;void this.callPlayer('seek',Math.round(clamp(line.at-this.lyricOffset(),0,this.duration)));this.lyricIndex=-2;this.updateLyricPosition();}}return true;}
      const live=event.target.closest('[data-action="submitLiveSearch"]');if(live){this.submitSearch(live.dataset.query);return true;}
      const face=event.target.closest('[data-lt-card]');
      if(face){
        event.preventDefault();const entry=this.entities.get(face.dataset.ltCard);if(!entry)return true;
        if(event.detail===0 && this.fastTapButton!==face){this.openEntity(entry);return true;}
        this.rememberSearch(entry);
        if(entry.type==='show')this.openEntity(entry);
        else this.queueCardTap(entry,face,()=>void this.playEntity(entry),()=>this.openEntity(entry));
        return true;
      }
      const open=event.target.closest('[data-open-uri]');if(open){this.openEntity(this.entities.get(open.dataset.openUri));return true;}
      const filter=event.target.closest('[data-library-filter]');if(filter){this.libraryFilter=filter.dataset.libraryFilter;this.renderBrowse();this.animateSurface(this.browse.querySelector('.lt-card-section'));return true;}
      const searchFilter=event.target.closest('[data-search-filter]');if(searchFilter){this.searchFilter=searchFilter.dataset.searchFilter;this.renderBrowse();this.animateSurface(this.browse.querySelector('.lt-card-section'));return true;}
      const query=event.target.closest('[data-search-query]');if(query){this.searchInput.value=query.dataset.searchQuery;this.submitSearch();return true;}
      const history=event.target.closest('[data-history-uri]');if(history){void this.callPlayer('playUri',history.dataset.historyUri);return true;}
      return false;
    }
    cancelPendingCardTap(){const pending=this.pendingCardTap;if(!pending)return;clearTimeout(pending.timer);this.timers.delete(pending.timer);pending.face?.classList.remove('lt-card-pending');this.pendingCardTap=null;}
    reservePendingCardTap(target){
      const pending=this.pendingCardTap;if(!pending)return;
      const face=target.closest?.('[data-lt-card]'),info=face ? {uri:face.dataset.ltCard} : this.cardContext(target);
      if(info?.uri===pending.uri && pending.view===this.viewKey(this.snapshotView()) && Date.now()-pending.at<=this.prefs.cardTapDelay){clearTimeout(pending.timer);this.timers.delete(pending.timer);pending.reserved=true;}
      else if(info)this.cancelPendingCardTap();
    }
    queueCardTap(entry,face,play,open){
      const pending=this.pendingCardTap,view=this.viewKey(this.snapshotView());
      if(pending?.uri===entry.uri && pending.view===view && (pending.reserved || Date.now()-pending.at<=this.prefs.cardTapDelay)){this.cancelPendingCardTap();open();return;}
      this.cancelPendingCardTap();const next={uri:entry.uri,view,face,at:Date.now(),reserved:false};this.pendingCardTap=next;face?.classList.add('lt-card-pending');
      next.timer=this.later(()=>{if(this.pendingCardTap!==next)return;this.pendingCardTap=null;face?.classList.remove('lt-card-pending');if(this.enabled && view===this.viewKey(this.snapshotView()))play();},this.prefs.cardTapDelay);
    }
    openEntity(entry) { if(entry){this.cancelPendingCardTap();this.rememberSearch(entry);this.navigate(entry.path);} }
    async playEntity(entry) {
      const state=this.getPlayerState();
      if((state?.context?.uri || state?.context_uri)===entry.uri){if(!read(()=>this.player.isPlaying(),false))await this.callPlayer('play');return;}
      await this.callPlayer('playUri',entry.uri);
    }
    rememberSearch(entry) {
      if(!(this.getRoutePath().startsWith('/search') || this.quickOpen) || !entry)return;
      this.recentSearches=[{...entry,at:Date.now()},...this.recentSearches.filter(row=>row.uri!==entry.uri)].slice(0,50);
      this.persistRecords('search-items',this.recentSearches);this.catalogVersion++;
    }
    captureSearchSelection(target) {
      if(!this.history.location?.pathname?.startsWith('/search/') || target.closest(OWN))return;
      const link=target.closest('a[href], [data-uri]') || target.closest('.main-trackList-trackListRow')?.querySelector('a[href^="/track/"]');if(!link)return;
      const root=link.closest('.main-trackList-trackListRow, [data-testid="card-container"], [data-testid="card"], article') || link.parentElement;
      const info=uriInfo(link.dataset.uri || link.getAttribute('href'));if(!info)return;
      const entity=normalizeEntity({...info,name:cleanText(link.textContent || root?.querySelector('h3,strong')?.textContent),imageUrl:root?.querySelector('img')?.src});
      this.rememberSearch(entity);
    }
    bindFastTap(root) {
      let tap=null;
      const begin=(target,x,y,id)=>{
        const button=target.closest?.('button');if(!button || button.disabled)return null;
        const toolbar=button.closest('.lt-nav,.lt-header,.lt-np-header,.lt-sheet-header,.lt-caption-buttons');
        return {button,id,x,y,moved:false,tolerance:toolbar ? 26 : 14};
      };
      const finish=(event,x,y,id)=>{
        const current=tap;tap=null;if(!current || current.id!==id || current.moved || !current.button.isConnected || Math.hypot(x-current.x,y-current.y)>current.tolerance)return;
        const r=current.button.getBoundingClientRect();
        if(!current.button.contains(event.target) && !(x>=r.left-6 && x<=r.right+6 && y>=r.top-6 && y<=r.bottom+6))return;
        if(root===this.shell && current.button.id==='lt-mini-open' && Date.now()<this.suppressOpenUntil)return;
        event.preventDefault();event.stopPropagation();this.fastClickBlock={button:current.button,x,y,until:Date.now()+450};
        // A layout-changing action can move the click target before the OS
        // compatibility click arrives. Match its pointer ID, not just pixels.
        if(typeof current.id==='number'){this.fastPointerClicks.set(current.id,Date.now()+1500);while(this.fastPointerClicks.size>16)this.fastPointerClicks.delete(this.fastPointerClicks.keys().next().value);}
        this.pointerHeld=false;this.fastTapButton=current.button;current.button.click();this.fastTapButton=null;
      };
      this.listen(root,'pointerdown',e=>{if(e.button>0 || e.isPrimary===false){tap=null;return;}tap=begin(e.target,e.clientX,e.clientY,e.pointerId);},{capture:true});
      this.listen(root,'pointermove',e=>{if(tap && Math.hypot(e.clientX-tap.x,e.clientY-tap.y)>tap.tolerance)tap.moved=true;},{capture:true,passive:true});
      this.listen(root,'pointercancel',()=>{tap=null;},{capture:true});
      this.listen(root,'pointerup',e=>finish(e,e.clientX,e.clientY,e.pointerId),{capture:true});
      this.listen(root,'touchstart',e=>{if(!tap && e.touches.length===1){const t=e.touches[0];tap=begin(e.target,t.clientX,t.clientY,'touch:'+t.identifier);}},{capture:true,passive:true});
      this.listen(root,'touchmove',e=>{const t=e.touches[0];if(tap && t && Math.hypot(t.clientX-tap.x,t.clientY-tap.y)>tap.tolerance)tap.moved=true;},{capture:true,passive:true});
      this.listen(root,'touchcancel',()=>{tap=null;},{capture:true});
      this.listen(root,'touchend',e=>{const t=e.changedTouches[0];if(t && typeof tap?.id==='string')finish(e,t.clientX,t.clientY,'touch:'+t.identifier);},{capture:true});
    }
    recordPlay(entry, playing, progress) {
      if(!uriInfo(entry.uri) || !['track','episode'].includes(uriInfo(entry.uri).type)){this.observedPlayback=null;return;}
      const previous=this.observedPlayback;
      const same=previous?.uri===entry.uri;
      const repeated=same && previous.progress>=this.duration-5000 && progress<5000 && Date.now()-(this.lastUserSeek || 0)>2500;
      const start=playing && (!same || !previous.recorded || repeated);
      this.observedPlayback={uri:entry.uri,progress,recorded:same && previous.recorded || playing};
      if(!start){
        const latest=this.playHistory[0];
        if(same && latest?.uri===entry.uri && (latest.title!==entry.title || latest.artist!==entry.artist || latest.album!==entry.album)){
          Object.assign(latest,entry);this.persistRecords('play-history',this.playHistory);if(this.historyPage.open)this.renderHistory();
        }
        return;
      }
      const row={...entry,at:Date.now()};this.playHistory.unshift(row);this.playHistory.length=Math.min(this.playHistory.length,10000);
      this.lastRecordedURI=entry.uri;this.persistRecords('play-history',this.playHistory);
      if(this.historyPage.open)this.renderHistory();
    }
    renderHistory() {
      if(!this.historyPage)return;
      const query=this.$('lt-history-search').value.trim().toLocaleLowerCase();
      const rows=this.playHistory.filter(row=>`${row.title} ${row.artist} ${row.album} ${new Date(row.at).toLocaleString()} ${new Date(row.at).toLocaleDateString('sv-SE')}`.toLocaleLowerCase().includes(query));
      this.$('lt-history-count').textContent=`${rows.length.toLocaleString()} ${rows.length===1 ? 'play' : 'plays'}${query ? ' found' : ' saved locally'}`;
      const list=this.$('lt-history-list');const scroll=list.scrollTop;list.replaceChildren();let previousDay='';
      for(const row of rows.slice(0,this.historyLimit)){
        const date=new Date(row.at);const day=date.toLocaleDateString(undefined,{weekday:'long',year:'numeric',month:'long',day:'numeric'});
        if(day!==previousDay){list.append(node('h3','lt-history-day',day));previousDay=day;}
        const b=node('button','lt-history-row lt-glass');b.type='button';b.dataset.historyUri=row.uri;b.setAttribute('aria-label',`Play ${row.title}, ${row.artist}, played ${date.toLocaleString()}`);
        if(row.image){const img=node('img','');img.src=row.image;img.alt='';img.loading='lazy';b.append(img);}
        const text=node('span','lt-history-text');text.append(node('strong','',row.title),node('span','',row.artist || row.subtitle),node('small','',row.album || ''));
        const stamp=node('time','',date.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit',second:'2-digit'}));stamp.dateTime=date.toISOString();b.append(text,stamp);list.append(b);
      }
      if(!rows.length)list.append(node('p','lt-empty',query ? 'No matching plays.' : 'Your listening journal starts with the next track you play.'));
      if(rows.length>this.historyLimit){const more=node('button','lt-pill lt-glass','Show more plays');more.type='button';more.dataset.action='moreHistory';list.append(more);}
      list.scrollTop=scroll;
    }

    queueCatalogRefresh(){
      if(this.catalogRefreshTimer || this.destroyed)return;
      this.catalogRefreshTimer=this.later(()=>{this.catalogRefreshTimer=null;if(!this.enabled || this.nowPlaying.open)return;if(this.pointerHeld){this.queueCatalogRefresh();return;}this.refreshNative();},90);
    }
    refreshNative(scan=true) {
      const main = document.querySelector(".Root__main-view") || document.querySelector('[data-testid="main-view"]') || document.querySelector(".main-view-container");
      const library = document.querySelector(".Root__nav-bar") || document.querySelector(".main-yourLibraryX-libraryContainer");
      if (this.main !== main) {
        if (this.main) delete this.main.dataset.ltNative;
        this.main = main;
        if (main) main.dataset.ltNative = "main";
      }
      if (this.library !== library) {
        if (this.library) delete this.library.dataset.ltNative;
        this.library = library;
        if (library) library.dataset.ltNative = "library";
      }
      this.measureNativeLayout();
      if (!main && this.enabled && !this.detailOwned) {
        if(Date.now()-(this.lastRequestedAt || 0)<1200){
          // History can unmount the old main before the new page is mounted.
          if(!this.nativeRetryTimer)this.nativeRetryTimer=this.later(()=>{this.nativeRetryTimer=null;this.refreshNative(false);},80);
        }else{
          this.enable(false, false);
          this.notify("Spotify’s layout changed. Desktop controls are available; tap Touch UI to retry.");
        }
      }
      if(scan && !this.nowPlaying.open)this.captureNativeCatalog();
      this.updateLayoutMetrics();
    }
    measureNativeLayout(){
      // Modern Spotify inserts additional scroll wrappers. Keep the measured
      // path, rather than relying on the legacy scroll-node being a direct child.
      const viewport=this.main?.querySelector('.main-view-container__scroll-node') || this.main?.querySelector('[data-overlayscrollbars-viewport], [data-testid="scroll-node"]');
      const path=[];
      for(let current=viewport?.parentElement;current && current!==this.main;current=current.parentElement)path.push(current);
      for(const previous of this.nativeLayoutPath || [])if(!path.includes(previous))delete previous.dataset.ltNativeLayout;
      if(this.nativeViewport && this.nativeViewport!==viewport)delete this.nativeViewport.dataset.ltNativeViewport;
      for(const current of path)current.dataset.ltNativeLayout='true';
      if(viewport)viewport.dataset.ltNativeViewport='true';
      this.nativeLayoutPath=path;this.nativeViewport=viewport;
    }
    bind() {
      // The old Update button can produce a compatibility click after its UI
      // has been replaced. A fresh pointer/key event always re-enables input.
      this.runtimeSwapUntil=LIVE_REPLACEMENT ? Date.now()+600 : 0;
      for(const type of ['pointerdown','keydown'])this.listen(window,type,()=>{this.runtimeSwapUntil=0;},{capture:true});
      this.listen(window,'click',e=>{if(e.isTrusted && Date.now()<this.runtimeSwapUntil){this.runtimeSwapUntil=0;e.preventDefault();e.stopImmediatePropagation();}},{capture:true});
      for (const root of [this.shell, this.nowPlaying, this.settings, this.historyPage, this.releaseDialog]) {
        this.bindFastTap(root);
        this.listen(root, "click", e => {
          if(this.handleBrowseClick(e))return;
          const target = e.target.closest("button[data-action]");
          if (target && !target.disabled) void this.action(target.dataset.action);
          const preference = e.target.closest('button[data-pref][role="switch"]');
          if (preference) {
            const key = preference.dataset.pref;
            this.prefs[key] = !this.prefs[key];
            if(['lyricsFallback','lyricsTextFallback'].includes(key)){this.lyricsCache.clear();this.lyricsLoadedURI=null;this.lyricsAbort?.abort();this.lyricsInFlight=null;this.lyricsToken++;}
            this.save(); this.applyPreferences();
          }
          const adjust = e.target.closest("button[data-adjust]");
          if (adjust) this.changeScale(adjust.dataset.adjust, this.prefs[adjust.dataset.adjust] + Number(adjust.dataset.delta));
          const opacity=e.target.closest('button[data-opacity-override]');
          if(opacity && OPACITY_PANELS.some(([key])=>key===opacity.dataset.opacityOverride)){
            const key=opacity.dataset.opacityOverride;this.prefs[key]=this.prefs[key]===null ? this.prefs.glassOpacity : null;
            this.save();this.applyGlassPreferences();
          }
        });
      }
      this.listen(this.settings, "change", e => {
        if(e.target.id==='lt-update-feed'){try{this.saveUpdateFeed(e.target.value);}catch(error){this.setUpdateStatus(error.message);}return;}
        const key = e.target.dataset.pref;
        if ((key === "palette" && ["glass", "ocean", "graphite"].includes(e.target.value)) ||
            (key === "clockFormat" && ["12", "24"].includes(e.target.value)) ||
            (key === "size" && ["comfort", "large"].includes(e.target.value))) {
          this.prefs[key] = e.target.value; this.save(); this.applyPreferences();
        }
      });
      this.listen(this.$('lt-update-file'),'change',async e=>{const file=e.target.files?.[0];e.target.value='';if(!file)return;try{const bundle=await window.LiquidTouchUpdater.importFile(file);if(this.destroyed)return;if(bundle.version===VERSION){this.setUpdateStatus('This file is the version already running.');return;}this.showUpdatePrompt({bundle,version:bundle.version,summary:bundle.summary,source:file.name});}catch(error){this.setUpdateStatus(error.message);}});
      this.listen(this.releaseDialog,'click',e=>{if(e.target.closest('a[data-action="fullReleaseNotes"]')){e.preventDefault();void this.action('fullReleaseNotes');}});
      this.listen(this.settings, "input", e => {
        if (["textScale", "uiScale", "playerTextScale", "playerLyricsScale", "playerControlScale", "cardTapDelay", "keyboardHeight", "artworkSize", "glassOpacity", "rounding",...OPACITY_PANELS.map(([key])=>key)].includes(e.target.dataset.pref)) this.changeScale(e.target.dataset.pref, Number(e.target.value));
      });
      this.listen(document,'click',event=>{
        const handledUntil=this.fastPointerClicks.get(event.pointerId);
        if(event.isTrusted && handledUntil && Date.now()<handledUntil){this.fastPointerClicks.delete(event.pointerId);this.fastClickBlock=null;event.preventDefault();event.stopImmediatePropagation();return;}
        const block=this.fastClickBlock;
        if(event.isTrusted && block && Date.now()<block.until && (block.button.contains(event.target) || event.detail>0 && Math.hypot(event.clientX-block.x,event.clientY-block.y)<4)){
          this.fastClickBlock=null;event.preventDefault();event.stopImmediatePropagation();return;
        }
        this.captureSearchSelection(event.target);
      },{capture:true});
      this.listen(document,'pointerdown',event=>{this.fastClickBlock=null;this.fastPointerClicks.delete(event.pointerId);this.reservePendingCardTap(event.target);},{capture:true});
      this.listen(document,'pointercancel',()=>{if(this.pendingCardTap?.reserved)this.cancelPendingCardTap();},{capture:true});
      this.listen(this.browse,'input',event=>{if(event.target.id==='lt-library-search'){this.libraryQuery=event.target.value;this.renderBrowse();}});
      this.listen(this.browse,'scroll',()=>{
        if(this.libraryOpen && this.libraryHasMore && this.browse.scrollTop+this.browse.clientHeight>this.browse.scrollHeight-180)void this.loadLibrary();
      },{passive:true});
      this.listen(this.$('lt-history-search'),'input',()=>{this.historyLimit=100;this.renderHistory();this.$('lt-history-list').scrollTop=0;});
      this.listen(this.rescue, "click", () => this.enable(true));
      this.listen(this.$("lt-search-form"), "submit", e => { e.preventDefault(); this.submitSearch(); });
      this.listen(this.searchInput, "focus", () => { if (this.prefs.keyboard) this.showKeyboard(true); });
      this.listen(this.$("lt-key-rows"), "click", e => {
        const key = e.target.closest("button[data-key]");
        if (key) this.typeKey(key.dataset.key);
      });
      for (const dialog of [this.nowPlaying, this.settings, this.historyPage, this.releaseDialog]) {
        this.listen(dialog, "cancel", e => { e.preventDefault(); if(dialog===this.nowPlaying && !this.$("lt-lyrics-menu").hidden){this.showLyricsMenu(false,true);return;}this.closeDialog(dialog); });
        this.listen(dialog, "click", e => {
          // Clicking a dialog's backdrop reports the dialog as the target.
          if (dialog === this.settings && e.target === dialog) {
            const r = dialog.getBoundingClientRect();
            if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) this.closeDialog(dialog);
          }
        });
      }
      this.listen(document,'pointerdown',e=>{if(!e.target.closest?.('.lt-lyrics-tools,#lt-lyrics-menu'))this.showLyricsMenu(false);},{capture:true});
      this.listen(window,'resize',()=>this.showLyricsMenu(false));
      this.listen(document,'scroll',e=>{if(!this.$('lt-lyrics-menu').hidden && e.target.contains?.(this.nowPlaying.querySelector('[data-action="lyricsMenu"]')))this.positionLyricsMenu();},{capture:true,passive:true});
      this.listen(this.nowPlaying.querySelector('[data-action="lyricsMenu"]'),'pointerdown',e=>e.preventDefault());
      this.listen(this.nowPlaying.querySelector('[data-action="lyricsMenu"]'),'keydown',e=>{
        if(e.key==='ArrowDown' || e.key==='ArrowUp'){e.preventDefault();this.showLyricsMenu(true);const buttons=this.$('lt-lyrics-menu').querySelectorAll('button');buttons[e.key==='ArrowUp' ? buttons.length-1 : 0].focus({preventScroll:true});}
      });
      this.listen(this.$('lt-lyrics-menu'),'keydown',e=>{
        const buttons=[...e.currentTarget.querySelectorAll('button')],index=buttons.indexOf(document.activeElement);
        if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();buttons[e.key==='Home' ? 0 : e.key==='End' ? buttons.length-1 : (index+(e.key==='ArrowDown' ? 1 : -1)+buttons.length)%buttons.length].focus();}
        if(e.key==='Tab')this.showLyricsMenu(false,true);
      });
      this.listen(document, "keydown", e => {
        if(e.key==='Escape' && !this.$('lt-lyrics-menu').hidden){e.preventDefault();e.stopPropagation();this.showLyricsMenu(false,true);return;}

        if (e.ctrlKey && e.altKey && e.code === "KeyT") {
          e.preventDefault(); this.enable(!this.enabled); return;
        }
        if (e.key === "Escape" && !this.nowPlaying.open && !this.settings.open) {
          if (!this.$("lt-keyboard").hidden) { this.showKeyboard(false); this.searchInput.blur(); }
          else if (this.libraryOpen) { this.libraryOpen = false; this.routeChanged(false); }
        }
      });
      this.listen(this.seek, "input", () => {
        this.editing.add("seek");
        this.paintRange(this.seek);
        const ms = number(this.seek.value) / 1000 * this.duration;
        this.$("lt-elapsed").textContent = time(ms);
        this.seek.setAttribute("aria-valuetext", `${time(ms)} of ${time(this.duration)}`);
      });
      this.listen(this.seek, "change", () => {
        this.lastUserSeek=Date.now();
        const ratio = number(this.seek.value) / 1000;
        this.editing.delete("seek");
        // Milliseconds avoid the wrapper treating the integer ratio 1 as 1 ms.
        void this.callPlayer("seek", Math.round(ratio * this.duration));
      });
      this.listen(this.volume, "input", () => {
        this.editing.add("volume");
        this.paintRange(this.volume);
        this.$("lt-volume-text").textContent = `${this.volume.value}%`;
      });
      this.listen(this.volume, "change", () => {
        this.editing.delete("volume");
        void this.callPlayer("setVolume", number(this.volume.value) / 100);
      });
      for (const input of [this.seek, this.volume]) {
        this.listen(input, "pointercancel", () => { this.editing.clear(); this.render(); });
        this.listen(input, "blur", () => { this.editing.delete(input === this.seek ? "seek" : "volume"); });
      }
      this.bindNativeTrackTaps();
      this.bindNativeCardTaps();
      this.onPlayerEvent = event => {
        const state = event?.data || event?.detail?.data || event?.detail;
        if (state && typeof state === "object") this.eventState = state;
        else if(event && (event.type === "songchange" || event.data === null))this.eventState=null;
        this.render();
      };
      for (const event of ["songchange", "onplaypause"]) this.player.addEventListener(event, this.onPlayerEvent);
      if (typeof this.history.listen === "function") this.unlisten = this.history.listen(event => {
        const path=event?.location?.pathname || event?.pathname || this.history.location?.pathname || '/';
        this.acceptHostRoute(path);
      });
      this.observer = new MutationObserver(records => {
        if (this.refreshPending || !records.some(record => {
          const node = record.target.nodeType === 1 ? record.target : record.target.parentElement;
          return !node?.closest(OWN);
        })) return;
        this.refreshPending = true;
        this.later(() => { this.refreshPending = false; this.refreshNative(); }, 350);
      });
      this.observer.observe(document.querySelector(".Root") || document.body, { childList: true, subtree: true });
      if (window.ResizeObserver) {
        this.resizeObserver = new ResizeObserver(() => {
          if (this.destroyed) return;
          if (!this.$("lt-keyboard").hidden) document.body.style.setProperty("--lt-keyboard-height", `${this.$("lt-keyboard").offsetHeight}px`);
          this.updateLayoutMetrics();
        });
        this.resizeObserver.observe(this.$("lt-keyboard"));
        this.resizeObserver.observe(this.shell.querySelector(".lt-footer"));
        this.resizeObserver.observe(this.shell.querySelector(".lt-header"));
      }
      this.listen(window, "resize", () => { this.updateLayoutMetrics(); void this.syncWindowChrome();clearTimeout(this.windowMotionTimer);if(!this.nowPlaying.open)this.windowMotionTimer=this.later(()=>this.animatePageChange(0),80); });
      this.listen(document, "fullscreenchange", () => { void this.syncWindowChrome(); this.updateLayoutMetrics(); });
      this.listen(window, "beforeunload", () => { void this.restoreNativeChrome(true); });
    }
    bindNativeTrackTaps() {
      // A short, stationary finger tap activates Spotify's own row play button,
      // preserving playlist context. Scrolling, mouse input, artist links, and
      // existing buttons retain their native behavior.
      let candidate = null;
      const start = e => {
        candidate = null;
        if (!this.enabled || e.pointerType !== "touch" || e.target.closest(OWN)) return;
        const row = e.target.closest(".main-trackList-trackListRow");
        if (!row || e.target.closest('button, input, select, [role="button"]')) return;
        const anchor = e.target.closest("a");
        if (anchor && !/^\/track\//.test(anchor.getAttribute("href") || "")) return;
        const play = row.querySelector('.main-trackList-rowSectionStart button, [data-testid="play-button"]');
        if (!play || play.disabled) return;
        candidate = { row, play, id: e.pointerId, x: e.clientX, y: e.clientY, at: Date.now() };
      };
      this.listen(document, "pointerdown", start, { capture: true });
      this.listen(document, "pointercancel", () => { candidate = null; }, { capture: true });
      this.listen(document, "pointerup", e => {
        const tap = candidate; candidate = null;
        if (!tap || tap.id !== e.pointerId || !tap.row.isConnected || !tap.row.contains(e.target)) return;
        if (Date.now() - tap.at > 600 || Math.hypot(e.clientX - tap.x, e.clientY - tap.y) > 12) return;
        this.nativeTouchBlock = { row: tap.row, until: Date.now() + 500 };
        e.preventDefault(); tap.play.click();
      }, { capture: true });
      this.listen(document, "click", e => {
        if (e.isTrusted && this.nativeTouchBlock && Date.now() < this.nativeTouchBlock.until && this.nativeTouchBlock.row.contains(e.target)) {
          e.preventDefault(); e.stopPropagation(); this.nativeTouchBlock = null;
        }
      }, { capture: true });
    }
    cardContext(target) {
      if (!target?.closest || target.closest(OWN) || target.closest('.main-trackList-trackListRow, input, select, textarea, [role="menu"], [role="dialog"]')) return null;
      let card=target.closest('.main-card-card, [data-testid="card"], [data-testid="grid-card"], [data-testid="card-container"], [data-encore-id="card"], .main-yourLibraryX-listItem, [data-testid="shortcut"]');
      let link=target.closest('a[href]');
      if (!card && link) {
        let parent=link;
        for(let i=0;i<5 && parent;i++,parent=parent.parentElement){
          const rect=parent.getBoundingClientRect();
          if(parent.querySelector('img') && rect.width>=100 && rect.width<=650 && rect.height>=44 && rect.height<=550){card=parent;break;}
        }
      }
      if (!card) return null;
      const control=target.closest('button, [role="button"]');
      if(control && !control.querySelector('img') && !control.matches('[data-lt-card-open]'))return null;
      link=link || card.querySelector('a[href^="/playlist/"],a[href^="/album/"],a[href^="spotify:playlist:"],a[href^="spotify:album:"],a[href^="/artist/"],a[href^="spotify:artist:"]');
      let raw=card.dataset.uri || card.dataset.contextUri || link?.getAttribute('href') || '';
      if(/^https:\/\/open\.spotify\.com\//.test(raw)){try{raw=new URL(raw).pathname;}catch{return null;}}
      const match=raw.match(/^(?:spotify:(album|playlist|artist):|\/(album|playlist|artist)\/)([\w-]+)/);
      if(!match)return null;
      const type=match[1] || match[2], id=match[3];
      return {card,uri:`spotify:${type}:${id}`,path:`/${type}/${id}`};
    }
    bindNativeCardTaps() {
      let candidate=null;
      this.listen(document,'pointerdown',event=>{
        candidate=null;
        if(!this.enabled || event.button>0 || event.isPrimary===false)return;
        const info=this.cardContext(event.target);
        if(info){candidate={...info,id:event.pointerId,x:event.clientX,y:event.clientY,at:Date.now()};event.stopPropagation();}
      },{capture:true});
      this.listen(document,'pointercancel',()=>{candidate=null;},{capture:true});
      this.listen(document,'pointerup',event=>{
        const tap=candidate;candidate=null;
        if(!tap || tap.id!==event.pointerId || !tap.card.isConnected || !tap.card.contains(event.target))return;
        if(Date.now()-tap.at>650 || Math.hypot(event.clientX-tap.x,event.clientY-tap.y)>12)return;
        event.preventDefault();event.stopPropagation();
        this.cardClickBlock={card:tap.card,until:Date.now()+700};
        this.queueCardTap(tap,tap.card,()=>void this.playCard(tap),()=>this.navigate(tap.path));
      },{capture:true});
      this.listen(document,'click',event=>{
        if(event.isTrusted && event.detail>0 && this.cardClickBlock && Date.now()<this.cardClickBlock.until && this.cardClickBlock.card.contains(event.target)){
          event.preventDefault();event.stopImmediatePropagation();
        }
      },{capture:true});
      this.listen(document,'dblclick',event=>{
        if(this.enabled && this.cardContext(event.target)){event.preventDefault();event.stopImmediatePropagation();}
      },{capture:true});
    }
    async playCard(info) {
      const state=this.getPlayerState();
      const context=state?.context?.uri || state?.context_uri;
      if(context===info.uri){
        if(!read(()=>this.player.isPlaying(),false))await this.callPlayer('play');
        return;
      }
      this.rememberSearch(this.entities.get(info.uri) || normalizeEntity({uri:info.uri,name:info.card.querySelector('a,h3,strong')?.textContent,imageUrl:info.card.querySelector('img')?.src}));
      await this.callPlayer('playUri',info.uri);
    }
    applyPreferences() {
      const d = document.body.dataset;
      d.ltPalette = this.prefs.palette;
      d.ltSize = this.prefs.size;
      d.ltLite = String(this.prefs.lite);
      d.ltMotion = this.prefs.reduceMotion ? "reduce" : "auto";
      if (this.lastWindowPreference !== this.prefs.windowControls) {
        this.chromeFailed = false; this.lastWindowPreference = this.prefs.windowControls;
      }
      if(!this.motionAllowed())this.stopMotion();
      const style = document.body.style;
      const text = this.prefs.textScale / 100, scale = this.prefs.uiScale / 100;
      style.setProperty("--lt-text-scale", String(text));
      style.setProperty("--lt-ui-scale", String(scale));
      style.setProperty("--lt-app-text-scale",String(text));style.setProperty("--lt-app-ui-scale",String(scale));
      style.setProperty("--lt-player-lyrics-scale",String(this.prefs.playerLyricsScale/100));style.setProperty("--lt-player-text-scale",String(this.prefs.playerTextScale/100));style.setProperty("--lt-player-control-scale",String(this.prefs.playerControlScale/100));
      style.setProperty("--lt-keyboard-scale", String(this.prefs.keyboardHeight/100));
      style.setProperty("--lt-artwork-scale", String(this.prefs.artworkSize/100));
      this.applyGlassPreferences();
      style.setProperty("--lt-touch", `${(this.prefs.size === "large" ? 56 : 48) * scale}px`);
      style.setProperty("--lt-row", `${Math.max((this.prefs.size === "large" ? 72 : 64) * scale, 44 * text + 20)}px`);
      style.setProperty("--lt-header", `${Math.max((this.prefs.size === "large" ? 72 : 64) * scale, 32 * text + 24)}px`);
      style.setProperty("--lt-mini", `${Math.max((this.prefs.size === "large" ? 80 : 72) * scale, 44 * text + 24)}px`);
      style.setProperty("--lt-nav", `${Math.max((this.prefs.size === "large" ? 80 : 72) * scale, 26 * scale + 19 * text + 20)}px`);
      style.setProperty("--lt-radius", `${this.prefs.rounding}px`);
      d.ltExpandedText = String(text >= 1.6);
      d.ltRoomy = String(text >= 1.6 || scale >= 1.3);
      this.searchInput.setAttribute("inputmode", this.prefs.keyboard ? "none" : "search");
      for(const key of ["welcome","welcomeSubtitle"])this.$(`lt-${key}`).value=this.prefs[key];
      this.$('lt-update-feed').value=this.prefs.updateFeed;
      for (const key of ["palette", "size"]) this.$(`lt-${key}`).value = this.prefs[key];
      this.$('lt-clockFormat').value=this.prefs.clockFormat;this.$('lt-clockFormat').disabled=!this.prefs.homeClock;this.refreshHomeClock();
      for (const key of ["textScale", "uiScale", "playerTextScale", "playerLyricsScale", "playerControlScale", "cardTapDelay", "keyboardHeight", "artworkSize", "rounding"]) {
        this.$(`lt-${key}`).value = String(this.prefs[key]);
        this.$(`lt-${key}-value`).textContent = `${this.prefs[key]}${key==='rounding' ? 'px' : key==='cardTapDelay' ? 'ms' : '%'}`;
        this.$(`lt-${key}`).setAttribute("aria-valuetext", `${this.prefs[key]} ${key==='rounding' ? 'pixels' : key==='cardTapDelay' ? 'milliseconds' : 'percent'}`);
        this.paintRange(this.$(`lt-${key}`));
      }
      for (const node of this.settings.querySelectorAll('[role="switch"][data-pref]')) node.setAttribute("aria-checked", String(this.prefs[node.dataset.pref]));
      if (!this.prefs.keyboard) this.showKeyboard(false);
      this.applyLyricsLayout();
      this.applyArtworkColor(this.currentColor || [62,82,108]);
      this.updateLayoutMetrics();
      if (this.enabled) void this.syncWindowChrome();
    }
    changeScale(key, value) {
      const input = this.$(`lt-${key}`);
      if (!input) return;
      this.prefs[key] = clamp(value, Number(input.min), Number(input.max));
      this.save();
      if(key==='glassOpacity' || OPACITY_PANELS.some(([name])=>name===key)){this.applyGlassPreferences();return;}
      this.applyPreferences();
      if (this.nativeResizeTimer) { clearTimeout(this.nativeResizeTimer); this.timers.delete(this.nativeResizeTimer); }
      this.nativeResizeTimer = this.later(() => window.dispatchEvent(new Event("resize")), 100);
    }
    applyGlassPreferences(){
      const style=document.body.style;style.setProperty('--lt-glass-opacity',String(this.prefs.glassOpacity/100));
      for(const [key,property] of OPACITY_PANELS){
        if(this.prefs[key]===null)style.removeProperty(property);else style.setProperty(property,String(this.prefs[key]/100));
      }
      for(const [key,target] of [['navOpacity',this.shell.querySelector('.lt-nav')],['miniOpacity',this.shell.querySelector('.lt-mini')],['settingsOpacity',this.settings],['settingsOpacity',this.releaseDialog],['historyOpacity',this.historyPage]]){
        const opacity=(this.prefs[key] ?? this.prefs.glassOpacity)/100;
        target.style.setProperty('--lt-surface-opacity',String(opacity));target.dataset.ltClear=String(opacity===0);target.dataset.ltSolid=String(opacity===1);
      }
      for(const key of ['glassOpacity',...OPACITY_PANELS.map(([name])=>name)]){
        const inherited=this.prefs[key]===null,value=inherited ? this.prefs.glassOpacity : this.prefs[key],input=this.$('lt-'+key);
        input.value=String(value);input.disabled=inherited;input.setAttribute('aria-valuetext',`${value} percent${inherited ? ', follows universal' : ''}`);this.paintRange(input);
        this.$('lt-'+key+'-value').textContent=value+'%';
        const panel=input.closest('.lt-opacity-panel');
        if(panel){
          panel.querySelector('[data-opacity-override]').setAttribute('aria-checked',String(!inherited));
          panel.querySelector('small').textContent=inherited ? `Following universal: ${value}%.` : 'Custom tint. Turn off Custom to follow Universal again.';
          for(const button of panel.querySelectorAll('[data-adjust]'))button.disabled=inherited;
        }
      }
    }
    updateLayoutMetrics() {
      if (!this.shell || this.destroyed) return;
      this.updateSearchPreviewBounds();
      this.syncNavigation();
      document.body.style.setProperty("--lt-card-columns",String(Math.min(4,Math.max(1,Math.floor((innerWidth-64)/Math.max(180*this.prefs.uiScale/100,145*this.prefs.textScale/100))))));
      const footer = this.shell.querySelector(".lt-footer");
      if (footer && footer.getBoundingClientRect().height) {
        const size = Math.ceil(footer.getBoundingClientRect().height + Math.max(10, innerHeight - footer.getBoundingClientRect().bottom) + 8);
        const value = `${size}px`;
        if (document.body.style.getPropertyValue("--lt-footer-measured") !== value) document.body.style.setProperty("--lt-footer-measured", value);
      }
    }
    windowCapabilities() {
      const platform = this.S.Platform;
      const client = platform?.FocusMainWindowAPI?._windowStateClient;
      const control = [platform?.ControlMessageAPI?._updateUiClient, platform?.UpdateAPI?._updateUiClient].find(value =>
        typeof value?.updateTitlebarHeight === "function" && typeof value?.setButtonsVisibility === "function");
      return client && control && ["setWindowState", "getWindowState", "closeWindow"].every(key => typeof client[key] === "function") ? {client,control} : null;
    }
    nativeTitlebarHeight() {
      const os = String(this.S.Platform?.operatingSystem || this.S.Platform?.PlatformData?.os_name || navigator.platform || "").toLowerCase();
      if (this.originalNativeChromeHeight !== undefined) return this.originalNativeChromeHeight;
      if (!/win|mac|osx/.test(os)) return 0;
      const known = document.querySelector('.Titlebar, [data-testid="window-controls"], .main-topBar-windowControls');
      const height = known?.getBoundingClientRect().bottom;
      return height && height > 1 && height < 130 ? Math.ceil(height) : /mac|osx/.test(os) ? 40 : 64;
    }
    customChromeGeometry() {
      const scale=this.prefs.uiScale/100;
      document.body.style.setProperty("--lt-chrome-height", `${innerWidth<=650 ? Math.max(52,48*scale+8) : 0}px`);
      document.body.style.setProperty("--lt-caption-width", `${132*scale+14}px`);
    }
    async syncWindowChrome() {
      if (this.destroyed || this.chromeBusy) return;
      const capability = this.windowCapabilities();
      const wanted = this.enabled && this.prefs.windowControls && Boolean(capability) && !this.chromeFailed;
      if (!wanted) {
        if (this.nativeChromeOwned) await this.restoreNativeChrome();
        this.chromeMode = "native";
        document.body.dataset.ltWindow = "native";
        document.body.style.setProperty("--lt-chrome-height", `${this.enabled && !document.fullscreenElement ? this.nativeTitlebarHeight() : 0}px`);
        return;
      }
      if(this.originalNativeChromeHeight===undefined){
        this.originalNativeChromeHeight=window[CHROME_BASE_HEIGHT] ?? this.nativeTitlebarHeight();
        window[CHROME_BASE_HEIGHT]=this.originalNativeChromeHeight;
      }
      this.customChromeGeometry();
      if (this.chromeMode === "custom" && this.nativeChromeOwned) {
        if(Date.now()-(this.chromeRefreshed || 0)>6000){this.chromeRefreshed=Date.now();void queueChrome(async()=>{if(!this.enabled || this.destroyed)return;await capability.control.updateTitlebarHeight({height:1});await capability.control.setButtonsVisibility({showButtons:false});}).catch(()=>{});}
        return;
      }
      this.chromeBusy = true;
      try {
        this.windowClient = capability.client;
        this.windowControlClient = capability.control;
        // Custom controls already exist before the native strip is collapsed.
        document.body.dataset.ltWindow = "custom";
        this.customChromeGeometry();
        this.nativeChromeOwned = true;
        await queueChrome(async()=>{
          await capability.control.updateTitlebarHeight({height:1});
          await capability.control.setButtonsVisibility({showButtons:false});
        });
        if (this.destroyed || !this.enabled || !this.prefs.windowControls) { await this.restoreNativeChrome(); return; }
        this.chromeMode = "custom";
      } catch (error) {
        this.chromeFailed = true;
        console.warn("[LiquidTouch] Window controls:", error);
        await this.restoreNativeChrome();
      } finally { this.chromeBusy = false; this.updateLayoutMetrics(); }
    }
    async restoreNativeChrome(immediate=false) {
      if (!this.nativeChromeOwned) return;
      this.nativeChromeOwned = false; this.chromeMode = "native";
      document.body.dataset.ltWindow = "native";
      document.body.style.setProperty("--lt-chrome-height", `${this.enabled && !document.fullscreenElement ? this.nativeTitlebarHeight() : 0}px`);
      const control = this.windowControlClient;
      if (!control) return;
      // Restore on desktop mode, teardown, unloading, or any bridge failure.
      const calls = [() => control.updateTitlebarHeight({height:Math.max(1,this.originalNativeChromeHeight ?? 64)}), () => control.setButtonsVisibility({showButtons:true})];
      if(immediate){
        // Both IPC requests must be sent before an unloading renderer disappears.
        for(const call of calls){try{Promise.resolve(call()).catch(()=>{});}catch{}}
        return;
      }
      await queueChrome(async()=>{
        for (const call of calls) { try { await call(); } catch (error) { console.warn("[LiquidTouch] Restoring native controls:", error); } }
      });
    }
    async windowAction(action) {
      const current=this.settings.open ? this.settings : this.historyPage.open ? this.historyPage : this.nowPlaying.open ? this.nowPlaying : this.shell;
      this.playMotion(current.querySelector('.lt-caption-buttons'),[{transform:'scale(.96)'},{transform:'none'}],{duration:100});
      const api = this.windowCapabilities()?.client;
      if (!api) { await this.restoreNativeChrome(); this.notify("Spotify’s system window controls are available."); return; }
      try {
        if (action === "windowMinimize") await api.setWindowState({state:3});
        else if (action === "windowClose") await api.closeWindow({});
        else {
          const result = await api.getWindowState({});
          await api.setWindowState({state:result.state === 2 ? 1 : 2});
        }
      } catch (error) {
        this.chromeFailed = true;
        console.warn("[LiquidTouch] Native window action:", error);
        await this.restoreNativeChrome();
        this.notify("Spotify’s system window controls have been restored.");
      }
    }
    enable(enabled, persist = true) {
      if(!enabled)this.cancelPendingCardTap();
      if (enabled) {
        this.refreshNative();
        const themed = getComputedStyle(document.documentElement).getPropertyValue("--lt-header").trim();
        if ((!this.main && !this.detailInfo()) || !themed) {
          this.enabled = false;
          document.body.classList.remove("lt-active");
          this.rescue.hidden = false;
          this.notify(themed ? "Spotify’s main view is not ready. Try Touch UI again in a moment." : "Select the LiquidTouch theme and run spicetify apply first.");
          return;
        }
      }
      this.enabled = enabled;
      if (persist) { this.prefs.enabled = enabled; this.save(); }
      if (!enabled) {
        this.closeDialog(this.releaseDialog);this.closeDialog(this.settings); this.closeDialog(this.nowPlaying); this.closeDialog(this.historyPage);
        this.showKeyboard(false); this.libraryOpen = false;
      }
      document.body.classList.toggle("lt-active", enabled);
      this.rescue.hidden = enabled;
      if (enabled) { this.routeChanged(false); this.render(); }
      void this.syncWindowChrome();
    }
    routeChanged(clearLibrary = true, requestedPath) {
      const previousNav=this.shell.querySelector('.lt-nav [aria-current="page"]'),oldTab=previousNav?.dataset.action;
      if (clearLibrary) this.libraryOpen = false;
      const path = requestedPath || this.getRoutePath();
      this.routePath=path;this.lastRoutePath = this.history.location?.pathname;
      this.detailOwned=!this.libraryOpen && Boolean(this.detailInfo(path));if(this.detailOwned)this.localDetailAt=Date.now();
      const tab = this.libraryOpen ? "library" : path.startsWith("/search") ? "search" : "home";
      document.body.dataset.ltPage = tab;
      this.$("lt-page-title").textContent = this.libraryOpen ? "Your Library" : path === "/" ? "Home" : path.startsWith("/queue") ? "Queue" : path.startsWith("/search") ? "Search" : "Your music";
      this.$("lt-heading").hidden = tab === "search";
      this.$("lt-search-form").hidden = tab !== "search";
      for (const node of this.shell.querySelectorAll(".lt-nav button")) {
        if (node.dataset.action === tab) node.setAttribute("aria-current", "page");
        else node.removeAttribute("aria-current");
      }
      if (tab !== "search") this.showKeyboard(false);
      if (tab === "search") {
        const segment = path.slice("/search/".length);
        if (path.startsWith("/search/") && document.activeElement !== this.searchInput) {
          try { this.searchInput.value = decodeURIComponent(segment); } catch { /* malformed route */ }
        }
        if(/^\/search\/?$/.test(path))this.searchInput.value='';
      }
      this.queueCatalogRefresh();
      this.renderBrowse();
      if(this.browse.hidden){
        this.refreshNative(false);
        // React can replace the main view in the frame after History.push.
        const route=path;requestAnimationFrame(()=>{if(!this.destroyed && this.getRoutePath()===route && this.browse.hidden)this.refreshNative(false);});
      }
      const view=this.libraryOpen ? 'library' : this.viewKey(this.snapshotView());
      if(this.lastMotionView && view!==this.lastMotionView){
        const tabs=['home','search','library'],motion=this.nextPageMotion || {direction:oldTab===tab ? 0 : Math.sign(tabs.indexOf(tab)-tabs.indexOf(oldTab))};this.nextPageMotion=null;
        this.animatePageChange(motion.direction,motion.distance,motion.duration);this.animateNavigation(previousNav);
      }
      this.lastMotionView=view;
      if(!this.navVisualIndex || oldTab===tab)this.syncNavigation();
      const query=this.queryFromPath(path);if(!this.libraryOpen && query && query!==this.resultsQuery)void this.loadSearchResults(query);
    }
    navigate(path, remember=true,library=false) {
      this.cancelPendingCardTap();
      if(!this.nextPageMotion && path!==this.getRoutePath() && path!=='/' && path!=='/search' && !library)this.nextPageMotion={direction:1};
      if(remember && (path!==this.getRoutePath() || this.libraryOpen))this.rememberView();
      this.lastRequestedAt=Date.now();this.routePath=path;this.pendingRoute={path,at:Date.now()};this.hideSearchPreview();this.showQuickSearch(false);
      const local=Boolean(this.detailInfo(path));this.detailOwned=local && !library;this.localDetailAt=this.lastRequestedAt;
      const request={path,local,at:this.lastRequestedAt,serial:++this.navigationSerial,pending:!local && this.history.location?.pathname!==path};this.latestRouteRequest=request;this.routeRequests.set(path,request);
      while(this.routeRequests.size>40)this.routeRequests.delete(this.routeRequests.keys().next().value);
      this.closeDialog(this.settings); this.closeDialog(this.nowPlaying); this.closeDialog(this.historyPage);
      this.closeDialog(this.releaseDialog);
      this.showKeyboard(false); this.libraryOpen = library;
      if(!local && this.history.location?.pathname!==path){this.issuingRoute=true;try{this.history.push(path);}finally{this.issuingRoute=false;}}
      this.routeChanged(false,path);
      if(local)this.pendingRoute=null;
      if(this.pendingRoute && this.history.location?.pathname===path){request.pending=false;this.observedHostPath=path;this.pendingRoute=null;}
      this.queueCatalogRefresh();
    }
    showLibrary() {
      this.cancelPendingCardTap();
      if(!this.libraryOpen)this.rememberView();
      if(!this.main?.isConnected || !this.library?.isConnected)this.refreshNative(false);
      if (!this.library && !this.libraryEntities.size && !this.S.Platform?.LibraryAPI) {
        this.enable(false, false);
        this.notify("This Spotify layout needs its desktop library. Tap Touch UI to return.");
        return;
      }
      this.closeDialog(this.settings); this.closeDialog(this.nowPlaying);
      this.libraryOpen = true;this.detailOwned=false;
      this.routeChanged(false,this.getRoutePath());
      if(!this.libraryOffset)void this.loadLibrary(true);
      // Expand Spotify's own library if it is in icon-only mode. Stable test
      // identifiers first; the English accessible-name fallback is optional.
      const expand = this.library?.querySelector('[data-testid="your-library-expand"], .main-yourLibraryX-collapseButton[aria-expanded="false"], button[aria-label="Expand Your Library"], button[aria-label="Expand your library"]');
      if (expand) expand.click();
    }
    showKeyboard(show) {
      if (show && !this.prefs.keyboard) return;
      const changed=this.$('lt-keyboard').hidden===show;
      this.$("lt-keyboard").hidden = !show;
      if(!show)this.clearKeyFeedback();
      document.body.dataset.ltKeyboard = String(show);
      this.shell.querySelector('[data-action="keyboard"]').setAttribute("aria-expanded", String(show));
      if (show) document.body.style.setProperty("--lt-keyboard-height", `${this.$("lt-keyboard").offsetHeight}px`);
      this.updateSearchPreviewBounds();
      if(changed){if(show)this.animateSurface(this.$('lt-keyboard'));else this.animateSurface(this.shell.querySelector('.lt-header'));}
    }
    buildKeyboard() {
      const rows = this.keyboardSymbols ? [Array.from("1234567890"), Array.from("@#$&-+()/"), Array.from(".,?!':;%")] : [Array.from("qwertyuiop"), Array.from("asdfghjkl"), Array.from("zxcvbnm")];
      const container = this.$("lt-key-rows");
      container.replaceChildren();
      const makeKey = (key, text, className = "", label = text) => {
        const b = document.createElement("button");
        b.type = "button"; b.dataset.key = key; b.textContent = text;
        b.className = className; b.setAttribute("aria-label", label);
        return b;
      };
      for (let i = 0; i < rows.length; i++) {
        const row = document.createElement("div"); row.className = "lt-kb-row";
        if (i === 2 && !this.keyboardSymbols) row.append(makeKey("Shift", "⇧", "lt-kb-wide", "Shift"));
        for (const value of rows[i]) row.append(makeKey(value, this.keyboardShift && !this.keyboardSymbols ? value.toUpperCase() : value));
        if (i === 2) row.append(makeKey("Backspace", "⌫", "lt-kb-wide", "Backspace"));
        container.append(row);
      }
      const bottom = document.createElement("div"); bottom.className = "lt-kb-row";
      bottom.append(makeKey("Symbols", this.keyboardSymbols ? "ABC" : "123", "lt-kb-wide", this.keyboardSymbols ? "Letters" : "Numbers and symbols"),
        makeKey("Clear", "Clear", "lt-kb-wide", "Clear search"), makeKey(" ", "space", "lt-kb-space", "Space"),
        makeKey("Submit", "Search", "lt-kb-wide lt-kb-submit", "Search now"));
      container.append(bottom);
    }
    clearKeyFeedback(){
      this.keyFeedbackToken=(this.keyFeedbackToken || 0)+1;this.keyFeedbackButton?.classList.remove('lt-key-held');this.keyFeedbackButton=null;if(this.keyPopup)this.keyPopup.hidden=true;
    }
    pressKeyFeedback(button){
      this.clearKeyFeedback();this.keyFeedbackButton=button;button.classList.add('lt-key-held');
      const r=button.getBoundingClientRect(),label=button.dataset.key===' ' ? 'space' : button.textContent;
      const width=clamp(Math.max(r.width*1.12,label.length>2 ? 100 : 56),56,160),height=Math.max(60,Math.min(86,r.height));
      this.keyPopup.textContent=label;this.keyPopup.style.cssText=`width:${width}px;height:${height}px;left:${clamp(r.x+r.width/2-width/2,6,innerWidth-width-6)}px;top:${Math.max(4,r.y-height-6)}px;`;
      this.keyPopup.hidden=false;this.playMotion(this.keyPopup,[{transform:'translateY(4px) scale(.9)'},{transform:'none'}],{duration:70});
    }
    releaseKeyFeedback(){const token=this.keyFeedbackToken;this.later(()=>{if(token===this.keyFeedbackToken)this.clearKeyFeedback();},110);}
    bindKeyFeedback(){
      this.listen(window,'pointerdown',e=>{const b=e.target.closest?.('#lt-keyboard button[data-key]');if(b && !b.disabled && e.isPrimary!==false)this.pressKeyFeedback(b);},{capture:true});
      this.listen(window,'pointerup',()=>{if(this.keyFeedbackButton)this.releaseKeyFeedback();},{capture:true});
      this.listen(window,'pointercancel',()=>this.clearKeyFeedback(),{capture:true});this.listen(window,'blur',()=>this.clearKeyFeedback());
      this.listen(this.$('lt-key-rows'),'click',e=>{const b=e.target.closest('button[data-key]');if(b && this.keyFeedbackButton!==b){this.pressKeyFeedback(b);this.releaseKeyFeedback();}},{capture:true});
    }
    typeKey(key) {
      const input = this.quickOpen ? this.$('lt-quick-input') : this.searchInput;
      if (key === "Submit") { this.submitSearch(input.value); return; }
      if (key === "Shift") { this.keyboardShift = !this.keyboardShift; this.buildKeyboard(); return; }
      if (key === "Symbols") { this.keyboardSymbols = !this.keyboardSymbols; this.buildKeyboard(); return; }
      input.focus({ preventScroll: true });
      let start = input.selectionStart ?? input.value.length;
      let end = input.selectionEnd ?? start;
      if (key === "Clear") input.value = "";
      else if (key === "Backspace") {
        if (start === end && start > 0) start = Array.from(input.value.slice(0, start)).slice(0, -1).join("").length;
        input.setRangeText("", start, end, "end");
      } else if (input.value.length < 300) {
        input.setRangeText(this.keyboardShift && !this.keyboardSymbols ? key.toUpperCase() : key, start, end, "end");
        if (this.keyboardShift) { this.keyboardShift = false; this.buildKeyboard(); }
      }
      input.dispatchEvent(new Event("input", { bubbles: true }));
    }
    submitSearch(value) {
      const query = cleanText(value ?? this.searchInput.value,300);
      this.hideSearchPreview();this.showQuickSearch(false);
      if(query){this.searchQueries=[{query,at:Date.now()},...this.searchQueries.filter(row=>row.query.toLocaleLowerCase()!==query.toLocaleLowerCase())].slice(0,30);this.persistRecords('search-queries',this.searchQueries);}
      this.searchInput.blur();
      this.navigate(query ? `/search/${encodeURIComponent(query)}` : "/search");
    }
    setUpdateStatus(message){this.$('lt-update-status').textContent=message;}
    saveUpdateFeed(value){
      const address=value.trim() ? window.LiquidTouchUpdater.normalizeFeed(value.trim()) : '';
      if(address===this.prefs.updateFeed)return;
      this.prefs.updateFeed=address;this.save();this.updateCheckToken=(this.updateCheckToken || 0)+1;this.updateCheckBusy=false;this.updateCheckManual=false;this.pendingUpdatePrompt=null;
      this.setUpdateStatus(address ? 'Feed saved. Use Check now to check it.' : 'No hosted release feed is configured.');
    }
    queueReleaseNotes(){
      const seen=read(()=>localStorage.getItem('liquid-touch.seen-release'),'');
      if(seen===VERSION)return;
      if(!seen && (window.LT_DEMO_COVERS || !this.hadSavedPreferences)){try{localStorage.setItem('liquid-touch.seen-release',VERSION);}catch{}return;}
      this.pendingFirstRelease=true;this.flushReleasePrompt();
    }
    flushReleasePrompt(){
      if(!this.enabled || this.destroyed || this.pointerHeld || this.pendingCardTap || this.releaseDialog.open || this.settings.open || this.historyPage.open || this.nowPlaying.open)return;
      if(this.pendingFirstRelease){this.pendingFirstRelease=false;this.showReleaseNotes();return;}
      if(this.pendingUpdatePrompt){const item=this.pendingUpdatePrompt;this.pendingUpdatePrompt=null;this.showUpdatePrompt(item);}
    }
    paintRelease(summary,full=false){
      const list=this.$('lt-release-summary');list.replaceChildren();for(const line of summary || [])list.append(node('li','',line));list.hidden=full;
      this.$('lt-full-release-notes').hidden=!full;this.releaseDialog.querySelector('a[data-action=fullReleaseNotes]').hidden=full;
      this.$('lt-release-status').textContent='';
    }
    showReleaseNotes(){
      this.updateCandidate=null;const release=window.LiquidTouchUpdater?.release?.() || window.LiquidTouchRelease || {version:VERSION,summary:['LiquidTouch '+VERSION],notes:''};
      this.$('lt-release-title').textContent='What’s new';this.$('lt-release-subtitle').textContent='LiquidTouch '+release.version;this.paintRelease(release.summary);
      this.releaseDialog.querySelector('[data-action=confirmUpdate]').hidden=true;this.releaseDialog.querySelector('footer [data-action=closeRelease]').textContent='Done';
      this.openDialog(this.releaseDialog);try{localStorage.setItem('liquid-touch.seen-release',VERSION);}catch{}
    }
    showUpdatePrompt(item){
      this.updateCandidate=item;this.$('lt-release-title').textContent=item.restore ? 'Restore installed version?' : 'Update available';
      this.$('lt-release-subtitle').textContent=`LiquidTouch ${VERSION} → ${item.version} · ${item.source}`;this.paintRelease(item.summary);
      const button=this.releaseDialog.querySelector('[data-action=confirmUpdate]');button.hidden=false;button.disabled=false;button.textContent=item.restore ? 'Restore' : 'Update';
      this.releaseDialog.querySelector('footer [data-action=closeRelease]').textContent='Later';this.openDialog(this.releaseDialog);
    }
    async preparedUpdate(){
      const candidate=this.updateCandidate;if(!candidate || candidate.restore)return null;if(candidate.bundle)return candidate.bundle;
      candidate.download ||= window.LiquidTouchUpdater.download(candidate).then(bundle=>{candidate.bundle=bundle;return bundle;}).catch(error=>{candidate.download=null;throw error;});return candidate.download;
    }
    async showFullReleaseNotes(){
      try{
        const candidate=this.updateCandidate;this.$('lt-release-status').textContent='Loading patch notes…';const bundle=candidate && !candidate.restore ? await this.preparedUpdate() : window.LiquidTouchUpdater?.release?.();
        if(this.destroyed || candidate!==this.updateCandidate)return;this.paintRelease([],true);this.$('lt-full-release-notes').textContent=bundle?.notes || 'Full notes are not available for this version.';
      }catch(error){if(!this.destroyed)this.$('lt-release-status').textContent=error.message;}
    }
    async confirmUpdate(){
      const candidate=this.updateCandidate;if(!candidate)return;const button=this.releaseDialog.querySelector('[data-action=confirmUpdate]');button.disabled=true;
      try{this.$('lt-release-status').textContent=candidate.restore ? 'Restoring installed version…' : 'Verifying and installing…';if(candidate.restore)window.LiquidTouchUpdater.restore();else await window.LiquidTouchUpdater.apply(await this.preparedUpdate());}
      catch(error){if(!this.destroyed){this.$('lt-release-status').textContent=error.message;button.disabled=false;}}
    }
    maybeCheckUpdates(){
      if(!this.enabled || !this.prefs.updateChecks || !this.prefs.updateFeed || this.updateCheckBusy)return;
      if(this.lastUpdateFeed!==this.prefs.updateFeed){this.lastUpdateFeed=this.prefs.updateFeed;const saved=read(()=>JSON.parse(localStorage.getItem('liquid-touch.update-check') || '{}'),{});this.nextUpdateCheck=saved.url===this.prefs.updateFeed ? number(saved.at)+21600000 : 0;}
      if(Date.now()>=this.nextUpdateCheck)void this.checkForUpdates(false);
    }
    async checkForUpdates(manual=false){
      if(manual){try{this.saveUpdateFeed(this.$('lt-update-feed').value);}catch(error){this.setUpdateStatus(error.message);return;}}
      if(this.updateCheckBusy){if(manual)this.updateCheckManual=true;return;}if(!this.prefs.updateFeed){if(manual)this.setUpdateStatus('No release feed is configured. Import an update file, or add a trusted HTTPS release-feed URL.');return;}
      const address=this.prefs.updateFeed,token=this.updateCheckToken=(this.updateCheckToken || 0)+1;this.updateCheckBusy=true;this.nextUpdateCheck=Date.now()+21600000;
      try{localStorage.setItem('liquid-touch.update-check',JSON.stringify({url:address,at:Date.now()}));}catch{}
      this.setUpdateStatus('Checking for updates…');
      try{
        const release=await window.LiquidTouchUpdater.check(address);if(this.destroyed || token!==this.updateCheckToken || address!==this.prefs.updateFeed)return;
        this.setUpdateStatus(release.newer ? `LiquidTouch ${release.version} is available.` : 'You are up to date.');
        if(release.newer){if(manual || this.updateCheckManual){this.pendingUpdatePrompt=null;this.showUpdatePrompt(release);}else{this.pendingUpdatePrompt=release;this.flushReleasePrompt();}}
      }catch(error){if(!this.destroyed && token===this.updateCheckToken)this.setUpdateStatus(error.message);}
      finally{if(token===this.updateCheckToken){this.updateCheckBusy=false;this.updateCheckManual=false;}}
    }
    openDialog(dialog) {
      if(dialog!==this.nowPlaying)this.showLyricsMenu(false);
      this.showKeyboard(false);
      if (dialog.open) return;
      this.focusBeforeModal.set(dialog, document.activeElement);
      if(dialog!==this.nowPlaying && this.nowPlaying.open){this.cancelPlayerPresentation();this.setPlayerReveal(1);this.playerPhase='open';}
      dialog.showModal();if(dialog!==this.nowPlaying)this.animateSurface(dialog);
      this.render();
    }
    closeDialog(dialog, immediate=false) {
      this.showLyricsMenu(false);
      if(dialog===this.nowPlaying){this.cancelPlayerPresentation();this.setPlayerReveal(1);this.playerPhase='closed';this.playerOpening=false;this.activeGesture=null;this.clearGestureMotion(false);}
      if (!dialog.open) return;
      // Closing is synchronous. A queued fade completion must never close a
      // newly reopened player or restore a page after the next navigation.
      delete dialog.dataset.closing;dialog.getAnimations().forEach(animation=>animation.cancel());
      dialog.close();
      if(dialog===this.nowPlaying){
        this.syncLyricClock();cancelAnimationFrame(this.lyricScrollFrame);
        const previous=this.playerReturn;if(previous && this.viewKey(this.snapshotView())===this.viewKey(previous))this.restoreScroll(previous);
        this.playerReturn=null;
      }
      if (this.toast && dialog.contains(this.toast)) (this.historyPage.open ? this.historyPage : this.settings.open ? this.settings : this.nowPlaying.open ? this.nowPlaying : document.body).append(this.toast);
      const before = this.focusBeforeModal.get(dialog);
      if (before?.isConnected && this.enabled) before.focus({ preventScroll: true });
      if(this.enabled && !this.destroyed){if(this.nowPlaying.open)this.animateSurface(this.nowPlaying);else this.animatePageChange(0);if(dialog===this.nowPlaying)this.playMotion(this.shell.querySelector('.lt-mini'),[{transform:'scale(.975)',opacity:.65},{transform:'none',opacity:1}],{duration:130});}
    }
    showPlayer() {
      if(this.nowPlaying.open){if(this.playerPhase==='closing')this.animatePlayerReveal(1,240);return;}
      this.preparePlayer(0);this.animatePlayerReveal(1,340);
    }
    async action(action) {
      try {
        switch (action) {
          case "home": case "library": this.switchTab(action);break;
          case "search": this.switchTab('search');if(this.getRoutePath()==='/search')this.searchInput.focus({preventScroll:true});break;
          case "likedSongs": this.navigate('/collection/tracks'); break;
          case "retrySearch": void this.loadSearchResults(this.queryFromPath());break;
          case "moreSearch": void this.loadSearchResults(this.queryFromPath(),true);break;
          case "nativeSearch": {const path=this.getRoutePath();this.enable(false,false);this.history.push(path);break;}
          case "lyricsMenu": this.showLyricsMenu(this.$("lt-lyrics-menu").hidden,true);break;
          case "retryLyrics": this.showLyricsMenu(false,true);void this.loadLyrics(true);break;
          case "lyricTiming": this.showLyricTiming(this.$('lt-lyric-timing').hidden);break;
          case "lyricsEarlier": this.setLyricOffset(this.lyricOffset()+250);break;
          case "lyricsLater": this.setLyricOffset(this.lyricOffset()-250);break;
          case "lyricsTimingReset": this.setLyricOffset(0);break;
          case "lyricsMatchLine": this.matchLyricLine=!this.matchLyricLine;if(this.matchLyricLine){this.$('lt-lyric-timing').hidden=true;this.nowPlaying.querySelector('[data-action="lyricTiming"]').setAttribute('aria-expanded','false');this.animateSurface(this.$('lt-lyrics-lines'));}this.updateTimingControls();break;
          case "openLyricTiming": this.closeDialog(this.settings);if(!this.prefs.lyrics){this.prefs.lyrics=true;this.save();this.applyPreferences();}await this.showPlayer();this.showLyricTiming(true);break;
          case "refreshLibrary": void this.loadLibrary(true); break;
          case "moreLibrary": void this.loadLibrary(); break;
          case "moreHome": {
            const scroll=this.main?.querySelector('.main-view-container__scroll-node, [data-overlayscrollbars-viewport]');
            if(scroll){scroll.scrollTop+=Math.max(scroll.clientHeight*.85,400);scroll.dispatchEvent(new Event('scroll',{bubbles:true}));}
            this.captureNativeCatalog();break;
          }
          case "playHistory": this.historyLimit=100;this.closeDialog(this.settings);this.renderHistory();this.openDialog(this.historyPage);break;
          case "closeHistory": this.closeDialog(this.historyPage);break;
          case "moreHistory": this.historyLimit+=100;this.renderHistory();break;
          case "goBack": this.goBack();break;
          case "releaseNotes": this.showReleaseNotes();break;
          case "closeRelease": this.closeDialog(this.releaseDialog);break;
          case "fullReleaseNotes": await this.showFullReleaseNotes();break;
          case "checkUpdates": await this.checkForUpdates(true);break;
          case "importUpdate": this.$('lt-update-file').click();break;
          case "confirmUpdate": await this.confirmUpdate();break;
          case "restoreRuntime": this.showUpdatePrompt({restore:true,version:window.LiquidTouchUpdater.installedVersion,summary:['Restore the version bundled with your last normal installation. Preferences and listening history remain saved.'],source:'Installed package'});break;
          case "closeQuickSearch": this.showQuickSearch(false);break;
          case "resetOpacity": for(const [key] of OPACITY_PANELS)this.prefs[key]=null;this.save();this.applyGlassPreferences();break;
          case "toggleLyrics": this.toggleLyrics();break;
          case "nowPlaying": if (Date.now() > this.suppressOpenUntil) this.showPlayer(); break;
          case "closePlayer": this.requestPlayerClose(); break;
          case "settings": case "playerSettings": if(this.playerOpening)this.closeDialog(this.nowPlaying);this.openDialog(this.settings); break;
          case "closeSettings": this.closeDialog(this.settings); break;
          case "artworkSettings": this.openDialog(this.settings);requestAnimationFrame(()=>this.$('lt-artworkSize').closest('.lt-setting').scrollIntoView({block:'start'}));break;
          case "keyboard":
            if (!this.prefs.keyboard) { this.notify("Built-in keyboard is off. Use the system touch keyboard, or enable it in settings."); break; }
            this.showKeyboard(this.$("lt-keyboard").hidden);
            break;
          case "hideKeyboard": this.showKeyboard(false); this.searchInput.blur(); break;
          case "queue": this.navigate("/queue"); break;
          case "windowMinimize": case "windowMaximize": case "windowClose": await this.windowAction(action); break;
          case "devices":
            this.enable(false, false);
            this.notify("Choose Spotify’s device icon in the desktop player. Tap Touch UI to return.");
            break;
          case "desktop": this.enable(false); break;
          default: await this.callPlayer(action);
        }
      } catch (error) {
        console.warn("[LiquidTouch]", action, error);
        this.notify("Spotify could not complete that action. Try again in its desktop interface.");
      }
    }
    async callPlayer(method, value, context) {
      try {
        if(method==='next' || method==='back')this.nextTrackMotion=method==='next' ? 1 : -1;
        if (typeof this.player[method] !== "function") throw new Error(`Player.${method} is unavailable`);
        await this.player[method](...(value === undefined ? [] : context===undefined ? [value] : [value,context]));
        if (!this.destroyed) { this.render(); this.later(() => this.render(), 250); }
      } catch (error) {
        console.warn("[LiquidTouch] player action:", method, error);
        this.notify("Spotify could not complete that playback action. Check the current device and your account’s playback controls.");
      }
    }
    paintRange(input) {
      const fill = clamp(number(input.value) / number(input.max, 100) * 100, 0, 100);
      input.style.setProperty("--lt-fill", `${fill}%`);
    }
    paintButtons(action, { glyph, label, pressed, disabled } = {}) {
      for (const root of [this.shell, this.nowPlaying]) for (const b of root.querySelectorAll(`button[data-action="${action}"]`)) {
        if (glyph && b.dataset.icon !== glyph) { b.querySelector(".lt-icon").innerHTML = icon(glyph); b.dataset.icon = glyph; }
        if (label && b.getAttribute("aria-label") !== label) b.setAttribute("aria-label", label);
        if (pressed !== undefined) b.setAttribute("aria-pressed", String(pressed));
        if (disabled !== undefined) b.disabled = disabled;
      }
    }
    getPlayerState() {
      const origin = read(() => this.player.origin?._state, null);
      const wrapper = read(() => this.player.data, null);
      const platform = read(() => this.S.Platform?.PlayerAPI?._state, null);
      const sources = [["origin", origin], ["platform", platform], ["event", this.eventState], ["wrapper", wrapper], ["platform-getState", this.platformState]];
      for (const [name, state] of sources) if (trackFromState(state)) { this.stateSource = name; return state; }
      this.stateSource = "none";
      return origin || wrapper || platform || this.platformState || null;
    }
    refreshPlatformState() {
      if (this.destroyed || this.platformReadBusy || trackFromState(read(() => this.player.origin?._state, null)) || trackFromState(read(() => this.player.data, null))) return;
      const api = this.S.Platform?.PlayerAPI;
      if (typeof api?.getState !== "function") return;
      this.platformReadBusy = true;
      Promise.resolve().then(() => api.getState()).then(result => {
        if (!this.destroyed && result && typeof result === "object") { this.platformState = result; this.render(); }
      }).catch(() => {}).finally(() => { this.platformReadBusy = false; });
    }
    nativeTrackDetails() {
      const region = document.querySelector('.Root__now-playing-bar, [data-testid="now-playing-bar"]');
      if (!region) return {};
      const title = region.querySelector('[data-testid="context-item-info-title"], .main-nowPlayingWidget-nowPlaying .main-trackInfo-name a, .main-trackInfo-name a, a[href^="/track/"]');
      const artist = region.querySelector('[data-testid="context-item-info-subtitles"], .main-trackInfo-artists, .main-trackInfo-artists a');
      const image = region.querySelector('[data-testid="cover-art-image"], .main-nowPlayingWidget-coverArt img, img');
      const href = title?.getAttribute("href") || title?.querySelector('a[href]')?.getAttribute('href') || "";
      const match = href.match(/^\/(track|episode)\/([\w-]+)/);
      return { title: title?.textContent?.trim() || "", artist: artist?.textContent?.trim() || "", image: imageURL(image?.getAttribute("src") || ""), uri: match ? `spotify:${match[1]}:${match[2]}` : "" };
    }
    render() {
      if (this.destroyed) return;
      const data = this.getPlayerState();
      const item = trackFromState(data);
      const m = item?.metadata || {};
      const native = item?.name && (item?.album?.images?.length || m.image_xlarge_url || m.image_url) ? {} : this.nativeTrackDetails();
      const uri = item?.uri || native.uri || "";
      const title = item?.name || m.title || native.title || (uri ? "Untitled" : "Your next good listen");
      const hasItem = Boolean(item || native.uri || native.title);
      const artistItems=Array.isArray(item?.artists) ? item.artists : item?.artists?.items;
      const artists=Array.isArray(artistItems) ? artistItems : [];
      const artist = artists.map(a => typeof a === "string" ? a : a.name || a.profile?.name).filter(Boolean).join(", ") || m.artist_name || m.album_artist_name || native.artist || (hasItem ? "Spotify" : "Choose something in Spotify");
      const duration = number(read(() => this.player.getDuration(), item?.duration?.milliseconds || data?.duration || m.duration || 0));
      this.duration = Math.max(0, duration);
      const progress = clamp(number(read(() => this.player.getProgress(), 0)), 0, this.duration);
      const playing = Boolean(read(() => this.player.isPlaying(), data ? !(data.isPaused ?? data.is_paused ?? true) : false));
      const r = data?.restrictions || {};
      const denied = (capability, legacy) => r[capability] === false || (Array.isArray(r[legacy]) && r[legacy].length > 0);
      const repeat = clamp(number(read(() => this.player.getRepeat(), data?.repeat || 0)), 0, 2);
      const shuffled = Boolean(read(() => this.player.getShuffle(), data?.shuffle || false));
      const saved = Boolean(read(() => this.player.getHeart(), m["collection.in_collection"] === "true"));
      const volume = read(() => this.player.getVolume(), null);
      const muted = Boolean(read(() => this.player.getMute(), false));
      this.setText("lt-mini-title", title);
      this.setText("lt-mini-artist", artist);
      this.setText("lt-np-title", hasItem ? title : "Nothing playing yet");
      this.setText("lt-np-artist", hasItem ? artist : "Pick a song to get started");
      this.$("lt-mini-open").setAttribute("aria-label", hasItem ? `Open Now Playing: ${title}, ${artist}` : "Open Now Playing");
      this.paintButtons("togglePlay", { glyph: playing ? "pause" : "play", label: playing ? "Pause" : "Play", disabled: !hasItem || denied(playing ? "canPause" : "canResume", playing ? "disallow_pausing_reasons" : "disallow_resuming_reasons") });
      this.paintButtons("next", { disabled: !hasItem || denied("canSkipNext", "disallow_skipping_next_reasons") });
      this.paintButtons("back", { disabled: !hasItem || denied("canSkipPrevious", "disallow_skipping_prev_reasons") });
      this.paintButtons("toggleHeart", { glyph: saved ? "saved" : "plus", label: saved ? "Remove from your library" : "Save to your library", pressed: saved, disabled: !uri || m["collection.can_add"] === "false" && !saved });
      this.paintButtons("toggleShuffle", { label: shuffled ? "Turn shuffle off" : "Turn shuffle on", pressed: shuffled, disabled: !hasItem || denied("canToggleShuffle", "disallow_toggling_shuffle_reasons") });
      this.paintButtons("toggleRepeat", { glyph: repeat === 2 ? "repeatOne" : "repeat", label: `Repeat ${["off", "all", "one"][repeat]}`, pressed: repeat > 0, disabled: !hasItem || (r.canToggleRepeatContext === false && r.canToggleRepeatTrack === false) });
      this.paintButtons("toggleMute", { glyph: muted ? "muted" : "speaker", label: muted ? "Unmute" : "Mute", pressed: muted, disabled: typeof volume !== "number" || !Number.isFinite(volume) });
      this.seek.disabled = !hasItem || !this.duration || denied("canSeek", "disallow_seeking_reasons");
      if(this.lyricsSeekDisabled!==this.seek.disabled){this.lyricsSeekDisabled=this.seek.disabled;this.updateTimingControls();}
      if (!this.editing.has("seek")) {
        this.seek.value = String(this.duration ? progress / this.duration * 1000 : 0);
        this.paintRange(this.seek);
        this.setText("lt-elapsed", time(progress));
        this.seek.setAttribute("aria-valuetext", `${time(progress)} of ${time(this.duration)}`);
      }
      this.setText("lt-duration", time(this.duration));
      this.$("lt-mini-fill").style.width = `${this.duration ? progress / this.duration * 100 : 0}%`;
      this.volume.disabled = typeof volume !== "number" || !Number.isFinite(volume);
      if (!this.editing.has("volume")) {
        this.volume.value = String(Math.round(clamp(number(volume, .5), 0, 1) * 100));
        this.paintRange(this.volume);
        this.setText("lt-volume-text", `${this.volume.value}%`);
        this.volume.setAttribute("aria-valuetext", `${this.volume.value} percent`);
      }
      const image = imageURL(m.image_xlarge_url || m.image_large_url || m.image_url || item?.album?.images?.[0]?.url || item?.images?.[0]?.url || native.image || "");
      this.confirmTrackPeek(uri);
      if (image !== this.lastImage) {
        this.lastImage = image;
        for (const id of ["lt-art", "lt-mini-art", "lt-player-background"]) {
          const img = this.$(id);
          img.hidden = !image;
          img.onerror = () => { img.hidden = true; };
          if (image) img.src = image; else img.removeAttribute("src");
        }
        this.$('lt-mini-art').parentElement.hidden=!image;
        this.ambientArt.hidden=!image || !this.prefs.adaptive;
        if(image)this.ambientArt.src=image;else this.ambientArt.removeAttribute('src');
      }
      this.currentTrackMeta={uri,title,artist,artists:artists.map(a=>typeof a==='string' ? a : a.name || a.profile?.name).filter(Boolean),album:cleanText(item?.album?.name || m.album_title),duration:this.duration};
      if (uri !== this.lastURI) {
        const changed=Boolean(this.lastURI);if(changed)this.animateTrackChange();
        this.showLyricsMenu(false);
        this.lastURI = uri;
        this.warmAdjacentArtwork();
        this.lyricLines=[];this.lyricIndex=-2;this.lyricsLoadedURI=null;this.lyricInstrumental=false;this.lyricState='idle';this.matchLyricLine=false;this.lyricSource='spotify';this.lyricProvider='';this.paintLyrics();
        if(this.nowPlaying.open)void this.loadLyrics();
        this.editing.delete("seek");
      }
      if (`${uri}|${image}` !== this.lastColorKey) { this.lastColorKey = `${uri}|${image}`; void this.updateArtworkColor(uri, image); }
      this.recordPlay({uri,title,artist,album:cleanText(item?.album?.name || m.album_title),subtitle:artist,image},playing,progress);
    }
    setText(id, value) { const node = this.$(id); if (node.textContent !== value) node.textContent = value; }
    applyArtworkColor(rgb) {
      this.currentColor = rgb;
      const base = this.prefs.palette === "ocean" ? [9,21,32] : this.prefs.palette === "graphite" ? [16,17,20] : [12,16,28];
      const selected = this.prefs.adaptive ? rgb : [53,68,100];
      const factor = Math.min(1, 210/Math.max(1,...selected));
      const color = selected.map(value=>Math.round(value*factor));
      const blend = color.map((n,i)=>Math.round(n*.28 + base[i]*.72));
      const glass = color.map((n,i)=>Math.round(n*.45 + base[i]*.55));
      const style = document.body.style;
      style.setProperty("--lt-art-rgb", color.join(", "));
      style.setProperty("--lt-art-color", `rgb(${color.join(", ")})`);
      style.setProperty("--lt-bg", `rgb(${blend.join(", ")})`);
      style.setProperty("--lt-glass-rgb", glass.join(", "));
      if(this.ambientArt)this.ambientArt.hidden=!this.lastImage || !this.prefs.adaptive;
    }
    sampleArtwork(image) {
      return new Promise(resolve => {
        if (!image) { resolve(null); return; }
        const img = new Image(); img.crossOrigin = "anonymous";
        img.onload = () => {
          try {
            const canvas = document.createElement("canvas"); canvas.width = canvas.height = 24;
            const ctx = canvas.getContext("2d", {willReadFrequently:true}); ctx.drawImage(img,0,0,24,24);
            const pixels = ctx.getImageData(0,0,24,24).data;
            const sum = [0,0,0]; let weights = 0;
            for (let i=0;i<pixels.length;i+=4) {
              const r=pixels[i],g=pixels[i+1],b=pixels[i+2];
              const light=(r+g+b)/765;
              if (pixels[i+3]<128 || light<.06 || light>.94) continue;
              const weight=1+(Math.max(r,g,b)-Math.min(r,g,b))/128;
              sum[0]+=r*weight;sum[1]+=g*weight;sum[2]+=b*weight;weights+=weight;
            }
            resolve(weights ? sum.map(n=>Math.round(n/weights)) : [100,110,125]);
          } catch { resolve(null); }
        };
        img.onerror=()=>resolve(null); img.src=image;
      });
    }
    async updateArtworkColor(uri, image) {
      const request = ++this.pendingColor;
      const key=`${uri}|${image}`;
      if (this.colorCache.has(key)) { this.applyArtworkColor(this.colorCache.get(key)); return; }
      if (!uri && !image) { this.applyArtworkColor([53,68,100]); return; }
      let apiColor = false;
      const apply = rgb => {
        if (!rgb || this.destroyed || request!==this.pendingColor) return;
        this.colorCache.set(key,rgb);
        if(this.colorCache.size>48)this.colorCache.delete(this.colorCache.keys().next().value);
        this.applyArtworkColor(rgb);
      };
      void this.sampleArtwork(image).then(rgb=>{if(!apiColor)apply(rgb);});
      if (!uri || !this.S.colorExtractor) return;
      try {
        const colors = await this.S.colorExtractor(uri);
        const rgb = colorRGB(colors.VIBRANT_NON_ALARMING || colors.VIBRANT || colors.PROMINENT || colors.DARK_VIBRANT);
        if (rgb) { apiColor=true;apply(rgb); }
      } catch { /* Artwork colors are decorative; never block playback. */ }
    }
    notify(message) {
      if (!this.toast || this.destroyed) return;
      this.toast.textContent = message; this.toast.hidden = false;
      if (this.toastTimer) { clearTimeout(this.toastTimer); this.timers.delete(this.toastTimer); }
      this.toastTimer = this.later(() => { this.toast.hidden = true; }, 6500);
      if (this.nowPlaying.open || this.settings.open || this.historyPage.open) {
        // Notifications in Spotify's own toast layer can otherwise sit below a
        // native <dialog>. Keep the same status node inside the topmost modal.
        (this.historyPage.open ? this.historyPage : this.settings.open ? this.settings : this.nowPlaying).append(this.toast);
      } else document.body.append(this.toast);
    }
    diagnostics() {
      return { version: VERSION, phase: "mounted", enabled: this.enabled, nativeMainFound: Boolean(this.main), nativeLibraryFound: Boolean(this.library), librarySource:this.librarySource || 'loading', libraryItems:this.libraryEntities.size, libraryHasMore:this.libraryHasMore, playerAvailable: Boolean(this.player), playerDataReady: Boolean(trackFromState(this.getPlayerState())), stateSource:this.stateSource, playerOpen:this.nowPlaying.open, playerOpening:Boolean(this.playerOpening), playerPhase:this.playerPhase || 'closed', playerReveal:this.playerReveal ?? 1, cardTapPending:Boolean(this.pendingCardTap), fullscreen:Boolean(document.fullscreenElement), route:this.getRoutePath(), backSteps:this.viewStack.length, searchSource:this.searchSource || 'not requested', searchError:this.searchError || '', lyricsState:this.lyricState || 'idle', lyricsProvider:this.lyricProvider || '', lyricSource:this.lyricSource || '', lyricOffsetMs:this.lyricOffset(), gestureActive:Boolean(this.activeGesture), animatingSurfaces:this.motionAnimations.size, browseBuilds:this.browseBuildCount || 0, browseReuses:this.browseReuseCount || 0, windowControls:this.chromeMode, windowBridgeAvailable:Boolean(this.windowCapabilities()), spicetifyVersion: this.S.Config?.version || "unknown", viewport: `${innerWidth}×${innerHeight}`, preferences: { ...this.prefs } };
    }
    destroy() {
      this.cancelPendingCardTap();this.cancelPlayerPresentation?.();
      this.destroyed = true;
      this.enabled = false;
      this.activeGesture=null;this.stopMotion();clearTimeout(this.windowMotionTimer);
      this.fastPointerClicks.clear();
      this.warmedArtwork?.clear();
      void this.restoreNativeChrome();
      clearTimeout(this.searchDebounce);this.liveSearchToken++;this.lyricsToken++;this.lyricsAbort?.abort();
      this.abort.abort();
      this.observer?.disconnect(); this.resizeObserver?.disconnect();
      clearInterval(this.interval);clearInterval(this.lyricsInterval);this.imageObserver?.disconnect();
      for (const timer of this.timers) clearTimeout(timer);
      this.timers.clear();
      for (const event of ["songchange", "onplaypause"]) this.player.removeEventListener?.(event, this.onPlayerEvent);
      if (typeof this.unlisten === "function") this.unlisten();
      try { this.menu?.deregister(); } catch { /* Optional profile-menu cleanup. */ }
      this.browsePages.clear();this.routeRequests.clear();this.detailPages.clear();
      for (const node of [this.shell, this.nowPlaying, this.settings, this.historyPage, this.releaseDialog, this.atmosphere, this.rescue, this.toast]) node?.remove();
      if (this.main) delete this.main.dataset.ltNative;
      if (this.library) delete this.library.dataset.ltNative;
      for(const current of this.nativeLayoutPath || [])delete current.dataset.ltNativeLayout;
      if(this.nativeViewport)delete this.nativeViewport.dataset.ltNativeViewport;
      document.body.classList.remove("lt-active");
      for (const key of Object.keys(document.body.dataset)) if (key.startsWith("lt")) delete document.body.dataset[key];
      for (const property of [...document.body.style]) if(property.startsWith("--lt-"))document.body.style.removeProperty(property);
    }
  }

  let cancelled = false, startupTimer, statusNode, controller;
  let deadline = Date.now() + 60000;
  let phase = "waiting", lastError = "";
  const startedAt = Date.now();
  function startupDiagnostics() {
    const S = window.Spicetify;
    return { version: VERSION, phase, lastError, spicetifyVersion: S?.Config?.version || "unknown",
      theme: S?.Config?.current_theme || "unknown", extensionConfigured: S?.Config?.extensions?.includes("liquid-touch.js") ?? "unknown",
      themeCSS: Boolean(document.documentElement && getComputedStyle(document.documentElement).getPropertyValue("--lt-header").trim()),
      wrapperFound: Boolean(S), playerEvents: typeof S?.Player?.addEventListener === "function",
      navigation: typeof S?.Platform?.History?.push === "function",
      nativeMain: Boolean(document.querySelector(".Root__main-view, .main-view-container, [data-testid='main-view']")) };
  }
  function destroyStartup() {
    cancelled = true; clearTimeout(startupTimer); statusNode?.remove();
    controller?.destroy();
  }
  function retry() {
    if (cancelled) return;
    controller?.destroy(); controller = null;
    phase = "waiting"; lastError = ""; deadline = Date.now() + 60000;
    clearTimeout(startupTimer); boot();
  }
  function exposeStartup() {
    window.LiquidTouch = Object.freeze({ version: VERSION, diagnostics: startupDiagnostics, retry, enable: retry, destroy: destroyStartup });
  }
  function showStartupStatus(message) {
    if (!document.body || cancelled) return;
    if (!statusNode) {
      // Inline styles make the diagnostic visible even if inject_css is off.
      // Build this small panel without innerHTML so it also survives HTML-sink
      // restrictions and can report failures from the main markup injection.
      statusNode = document.createElement("section"); statusNode.id = "lt-startup-status";
      statusNode.style.cssText = "position:fixed;right:16px;bottom:100px;z-index:2147483000;max-width:calc(100vw - 32px);width:390px;padding:18px;border:1px solid #b4eedc80;border-radius:18px;background:#152438;color:#f6f8fc;font:14px/1.5 Segoe UI,sans-serif;box-shadow:0 12px 40px #0008;";
      const title = document.createElement("strong"); title.textContent = "LiquidTouch startup";
      const text = document.createElement("p"); text.id = "lt-startup-message";
      text.setAttribute("role", "status"); text.style.cssText = "margin:8px 0 12px;white-space:normal";
      const row = document.createElement("div"); row.style.cssText = "display:flex;gap:8px";
      for (const [label, handler] of [["Retry", retry], ["Copy details", async () => {
        const details = JSON.stringify(startupDiagnostics(), null, 2);
        try {
          if (window.Spicetify?.Platform?.ClipboardAPI?.copy) await window.Spicetify.Platform.ClipboardAPI.copy(details);
          else if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(details);
          else throw new Error("Clipboard unavailable");
          text.textContent = "Details copied. Paste them into this chat.";
        } catch { text.textContent = "Clipboard unavailable. Open DevTools and run LiquidTouch.diagnostics()."; }
      }]]) {
        const b = document.createElement("button"); b.type = "button"; b.textContent = label;
        b.style.cssText = "min-height:44px;padding:8px 16px;border:1px solid #b4eedc60;border-radius:12px;color:#f6f8fc;background:#2b4057;font:inherit;cursor:pointer";
        b.addEventListener("click", handler); row.append(b);
      }
      statusNode.append(title, text, row); document.body.append(statusNode);
    }
    const text = statusNode.querySelector("#lt-startup-message");
    if (text.textContent !== message) text.textContent = message;
    if (!statusNode.isConnected) document.body.append(statusNode);
  }
  exposeStartup();
  function boot() {
    if (cancelled) return;
    const S = window.Spicetify;
    const main = document.querySelector(".Root__main-view, .main-view-container, [data-testid='main-view']");
    if (!document.body || !main || !S?.Player?.addEventListener || !S?.Platform?.History?.push) {
      const missing = [];
      if (!S) missing.push("Spicetify wrapper");
      if (!S?.Player?.addEventListener) missing.push("player API");
      if (!S?.Platform?.History?.push) missing.push("navigation API");
      if (!main) missing.push("Spotify main view");
      if (Date.now() - startedAt > 3000) showStartupStatus(`Waiting for ${missing.join(", ")}. If this persists, enable expose_apis and update Spicetify, then restore / backup / apply.`);
      if (Date.now() < deadline) startupTimer = setTimeout(boot, 500);
      else {
        phase = "timed-out"; lastError = `Missing: ${missing.join(", ")}`;
        showStartupStatus(`${lastError}. Copy details so the startup failure can be diagnosed.`);
        console.warn("[LiquidTouch] Startup timed out; Spotify's desktop interface was left available.");
      }
      return;
    }
    try {
      controller = new LiquidTouchController(S);
      controller.mount();
      phase = "mounted";
      if (controller.enabled) statusNode?.remove();
      else if (!startupDiagnostics().themeCSS) showStartupStatus("LiquidTouch JavaScript loaded, but its CSS is missing. Enable inject_css, select LiquidTouch, and apply.");
      else statusNode?.remove();
      window.LiquidTouch = Object.freeze({
        version: VERSION,
        enable: () => controller.enable(true), disable: () => controller.enable(false),
        destroy: destroyStartup, retry, diagnostics: () => ({ ...startupDiagnostics(), ...controller.diagnostics() })
      });
    } catch (error) {
      try { controller?.destroy(); } catch { /* Preserve the original startup error. */ }
      controller = null; phase = "failed"; lastError = `${error.name}: ${error.message}`;
      exposeStartup();
      showStartupStatus(`The touch interface could not start. ${lastError}. Use Copy details to report this.`);
      console.error("[LiquidTouch] Startup failed; native Spotify restored:", error);
    }
  }
  boot();
})();

};
  const CACHE='liquid-touch.runtime.v1',MAX=1200000;
  window.LiquidTouchUpdater?.dispose?.();
  let active=BUNDLED,disposed=false,requestAbort=null,applying=false;
  const version=value=>typeof value==='string' && /^\d+\.\d+\.\d+$/.test(value);
  const compare=(a,b)=>{const x=a.split('.').map(Number),y=b.split('.').map(Number);for(let i=0;i<3;i++)if(x[i]!==y[i])return Math.sign(x[i]-y[i]);return 0;};
  const digest=async text=>{
    if(!crypto?.subtle)throw new Error('This Spotify build does not expose update verification. Use the normal installer.');
    return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text))),n=>n.toString(16).padStart(2,'0')).join('');
  };
  const validURL=value=>{const url=new URL(value);if(url.protocol!=='https:' || url.username || url.password)throw new Error('Use a trusted HTTPS update address.');return url;};
  async function verify(raw){
    if(!raw || raw.schema!==1 || raw.app!=='LiquidTouch' || !version(raw.version) || typeof raw.javascript!=='string' || typeof raw.css!=='string' || raw.javascript.length>800000 || raw.css.length>250000 || typeof raw.integrity!=='string' || !/^[a-f0-9]{64}$/.test(raw.integrity))throw new Error('Not a supported LiquidTouch update file.');
    if(await digest(raw.javascript+'\0'+raw.css)!==raw.integrity)throw new Error('Update verification failed. The current installation was kept.');
    if(raw.minimumLoader && (!version(raw.minimumLoader) || compare(raw.minimumLoader,BUNDLED.version)>0))throw new Error('This release needs a normal package installation first.');
    try{new Function(raw.javascript);}catch(error){throw new Error(error.name==='EvalError' ? 'This Spotify build blocks in-app code updates. Use the normal installer.' : 'The update contains invalid JavaScript. The current installation was kept.');}
    const summary=Array.isArray(raw.summary) ? raw.summary.filter(v=>typeof v==='string').slice(0,8).map(v=>v.slice(0,400)) : [];
    return Object.freeze({schema:1,app:'LiquidTouch',version:raw.version,minimumLoader:raw.minimumLoader || '1.9.0',javascript:raw.javascript,css:raw.css,integrity:raw.integrity,summary,notes:typeof raw.notes==='string' ? raw.notes.slice(0,60000) : ''});
  }
  function run(bundle){
    const ready=getComputedStyle(document.documentElement).getPropertyValue('--lt-theme-installed').trim()==='1';
    let style=document.getElementById('lt-runtime-theme');
    if(ready){if(!style){style=document.createElement('style');style.id='lt-runtime-theme';document.head.append(style);}style.textContent=bundle.css;}else style?.remove();
    active=bundle;window.LiquidTouchRelease={version:bundle.version,summary:bundle.summary,notes:bundle.notes};
    if(bundle===BUNDLED)launchBundled();else new Function(bundle.javascript)();
  }
  async function fetchText(url,limit,signal){
    const response=await fetch(url,{credentials:'omit',referrerPolicy:'no-referrer',cache:'no-store',signal});
    if(!response.ok)throw new Error('The update source could not be reached.');
    if(new URL(response.url || url).origin!==new URL(url).origin)throw new Error('The update source redirected to another host.');
    if(Number(response.headers.get('Content-Length'))>limit)throw new Error('The update response is too large.');
    if(!response.body?.getReader){const text=await response.text();if(new TextEncoder().encode(text).length>limit)throw new Error('The update response is too large.');return text;}
    const reader=response.body.getReader(),decoder=new TextDecoder('utf-8',{fatal:true});let size=0,text='';
    for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>limit){await reader.cancel();throw new Error('The update response is too large.');}text+=decoder.decode(value,{stream:true});}return text+decoder.decode();
  }
  async function request(job){
    requestAbort?.abort();const abort=new AbortController();requestAbort=abort;const timer=setTimeout(()=>abort.abort(),8000);
    try{const value=await job(abort.signal);if(disposed)throw new Error('Update session ended.');return value;}finally{clearTimeout(timer);if(requestAbort===abort)requestAbort=null;}
  }
  async function check(address){
    const url=validURL(address);
    return request(async signal=>{
      const raw=JSON.parse(await fetchText(url.href,64000,signal));
      if(raw.schema!==1 || raw.app!=='LiquidTouch' || !version(raw.version) || typeof raw.bundleURL!=='string' || !/^[a-f0-9]{64}$/.test(raw.sha256 || ''))throw new Error('Invalid LiquidTouch release feed.');
      const bundleURL=validURL(new URL(raw.bundleURL,url).href);if(bundleURL.origin!==url.origin)throw new Error('The update file must use the same host as the release feed.');
      return {version:raw.version,newer:compare(raw.version,active.version)>0,bundleURL:bundleURL.href,sha256:raw.sha256,source:url.hostname,summary:Array.isArray(raw.summary) ? raw.summary.filter(v=>typeof v==='string').slice(0,8).map(v=>v.slice(0,400)) : []};
    });
  }
  async function download(manifest){
    if(!manifest?.newer || !version(manifest.version))throw new Error('There is no newer release to install.');
    return request(async signal=>{const text=await fetchText(validURL(manifest.bundleURL).href,MAX,signal);if(await digest(text)!==manifest.sha256)throw new Error('Downloaded update checksum did not match the release feed.');const bundle=await verify(JSON.parse(text));if(bundle.version!==manifest.version)throw new Error('The update version did not match the release feed.');return bundle;});
  }
  async function mounted(expected){
    const began=Date.now();
    while(!disposed && Date.now()-began<4000){const state=window.LiquidTouch?.diagnostics?.();if(state?.phase==='failed' || state?.phase==='timed-out')return false;if(state?.phase==='mounted' && window.LiquidTouch.version===expected)return true;await new Promise(resolve=>setTimeout(resolve,40));}return false;
  }
  async function apply(bundle){
    if(applying || disposed)throw new Error('An update is already running.');
    const verified=await verify(bundle);if(compare(verified.version,active.version)<=0)throw new Error('This update is not newer than the running version.');
    const old=active,previous=localStorage.getItem(CACHE);applying=true;let started=false;
    try{
      localStorage.setItem(CACHE,JSON.stringify(verified)); // One atomic record; quota failures leave the running UI intact.
      started=true;
      run(verified);if(!await mounted(verified.version))throw new Error('The new interface could not start.');
    }catch(error){
      if(started){if(previous===null)localStorage.removeItem(CACHE);else localStorage.setItem(CACHE,previous);run(old);window.Spicetify?.showNotification?.('Update could not start. The previous LiquidTouch interface was restored.');}throw error;
    }finally{applying=false;}
  }
  async function importFile(file){if(!file || file.size>MAX)throw new Error('Choose a LiquidTouch update JSON file smaller than 1.2 MB.');const bundle=await verify(JSON.parse(await file.text()));if(compare(bundle.version,active.version)<=0)throw new Error('This file is not newer than the running version.');return bundle;}
  function restore(){if(applying)throw new Error('Wait for the current update.');localStorage.removeItem(CACHE);run(BUNDLED);}
  window.LiquidTouchUpdater=Object.freeze({installedVersion:BUNDLED.version,currentVersion:()=>active.version,release:()=>({version:active.version,summary:active.summary,notes:active.notes}),check,download,apply,importFile,restore,normalizeFeed:value=>validURL(value).href,dispose:()=>{disposed=true;requestAbort?.abort();}});
  const clearCache=()=>{try{localStorage.removeItem(CACHE);}catch{}};
  let cached;try{cached=JSON.parse(localStorage.getItem(CACHE) || 'null');}catch{clearCache();}
  if(cached && version(cached.version) && compare(cached.version,BUNDLED.version)>0){
    void verify(cached).then(bundle=>{if(!disposed)run(bundle);}).catch(()=>{if(!disposed){clearCache();run(BUNDLED);}});
  }else{if(cached)clearCache();run(BUNDLED);}
})();
