const {revealSetting}=require('./settings-navigation.cjs');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
const base=path.resolve(__dirname,'..'),cache='liquid-touch.runtime.v1';let origin,passed=0;
const bundled=JSON.parse(fs.readFileSync(path.join(base,'LiquidTouch-Update-v1.9.3.json'),'utf8'));
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
function future(extra={}){const b={...bundled,version:'1.9.4',summary:['A fictional update for validation.'],notes:'Full fictional update notes.',javascript:bundled.javascript.replace('const VERSION = "1.9.3"','const VERSION = "1.9.4"'),...extra};b.integrity=hash(b.javascript+'\0'+b.css);return b;}
async function open(browser,prefs={},init=null,motion=true){
 const context=await browser.newContext({viewport:{width:1024,height:600},hasTouch:true,reducedMotion:motion ? 'no-preference' : 'reduce'}),page=await context.newPage(),errors=[];page.setDefaultTimeout(9000);page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(p=>localStorage.getItem('liquid-touch.preferences.v1') || localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,textScale:130,uiScale:120,...p})),prefs);if(init)await page.addInitScript(init);
 await page.goto(origin);await page.waitForFunction(()=>window.LiquidTouch?.diagnostics().phase==='mounted');return {context,page,errors};
}
function pass(name,errors){assert.deepEqual(errors,[]);passed++;console.log('PASS '+name);}
async function player(page){await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');}
async function range(page,key,value){await revealSetting(page,key);await page.locator('#lt-'+key).evaluate((n,v)=>{n.value=String(v);n.dispatchEvent(new Event('input',{bubbles:true}));},value);}
async function settings(page){await page.locator('#lt-shell .lt-header [data-action=settings]').tap();}
async function closeSettings(page){await page.locator('#lt-settings [data-action=closeSettings]').tap();}
async function touch(page,x,y){const session=await page.context().newCDPSession(page);await session.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y,id:1}]});return {async move(x,y){await session.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x,y,id:1}]});await page.waitForTimeout(30);},async end(){await session.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await session.detach();},async cancel(){await session.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});await session.detach();}};}
async function importUpdate(page,bundle){await settings(page);await revealSetting(page,'update-file');await page.locator('#lt-update-file').setInputFiles({name:'LiquidTouch-Update.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(bundle))});}
async function feedRoutes(page,bundle){const text=JSON.stringify(bundle),manifest={schema:1,app:'LiquidTouch',version:bundle.version,bundleURL:'./bundle.json',sha256:hash(text),summary:bundle.summary};await page.route('https://updates.example.test/**',r=>r.fulfill({contentType:'application/json',headers:{'Access-Control-Allow-Origin':'*'},body:r.request().url().endsWith('bundle.json') ? text : JSON.stringify(manifest)}));return manifest;}
async function main(){
 const server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(fs.readFileSync(path.join(base,'LiquidTouch-Preview.html')));});await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;const browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox']});
 try{
  {
   const {page,context,errors}=await open(browser,{playerTextScale:150,artworkSize:60});await player(page);
   assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().preferences.playerLyricsScale),150);
   const size=()=>page.evaluate(()=>({normal:parseFloat(getComputedStyle(document.querySelector('#lt-np-title')).fontSize),lyric:parseFloat(getComputedStyle(document.querySelector('.lt-lyric-line')).fontSize)}));await page.waitForSelector('.lt-lyric-line');const before=await size();
   await page.locator('#lt-now-playing [data-action=playerSettings]').tap();await range(page,'playerTextScale',200);await closeSettings(page);const normal=await size();assert.equal(normal.lyric,before.lyric);assert.ok(normal.normal>before.normal);
   await page.locator('#lt-now-playing [data-action=playerSettings]').tap();await range(page,'playerLyricsScale',90);await closeSettings(page);const lyrics=await size();assert.equal(lyrics.normal,normal.normal);assert.ok(lyrics.lyric<normal.lyric);
   await page.reload();await page.waitForFunction(()=>LiquidTouch?.diagnostics().phase==='mounted');assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().preferences.playerLyricsScale),90);
   pass('legacy lyric size migrates, ordinary text and lyric scales change independently, and the values persist',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);const card=page.locator('[data-lt-card="spotify:album:demo-1"]');await card.tap();assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length),0);await page.waitForTimeout(120);assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length),0);await page.waitForFunction(()=>__ltMock.log.filter(r=>r[0]==='playUri').length===1);assert.equal(await page.locator('#lt-mini-title').textContent(),'Blue Hour');
   await card.tap();await card.tap();await page.waitForSelector('.lt-detail-track');await page.waitForTimeout(500);assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length),1);
   pass('a single tap commits once after its delay; a later double tap opens with no extra playback',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.locator('.lt-nav [data-action=library]').tap();const artist=page.locator('[data-lt-card="spotify:artist:demo-4"]');await artist.tap();await artist.tap();await page.waitForSelector('.lt-detail-track');await page.waitForTimeout(500);assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length),0);assert.equal(await page.locator('#lt-mini-title').textContent(),'Afterhours');
   pass('a fresh artist double tap opens its songs/releases without changing the playing track',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);const card=page.locator('[data-lt-card="spotify:album:demo-1"]');await card.tap();await page.waitForTimeout(220);const r=await card.boundingBox(),t=await touch(page,r.x+r.width/2,r.y+50);await page.waitForTimeout(300);assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length),0);await t.end();await page.waitForSelector('.lt-detail-track');assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length),0);
   pass('the second touch reserves the tap before the timer expires, including a held second touch',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.locator('[data-lt-card="spotify:album:demo-1"]').tap();await page.locator('.lt-nav [data-action=library]').tap();await page.waitForTimeout(500);assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length),0);await settings(page);await range(page,'cardTapDelay',650);assert.equal(await page.locator('#lt-cardTapDelay-value').textContent(),'650ms');await closeSettings(page);
   pass('navigation cancels pending card playback and tap timing is an accessible adjustable millisecond control',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.locator('#lt-mini-open').tap();await page.waitForTimeout(70);const progress=await page.evaluate(()=>LiquidTouch.diagnostics().playerReveal);assert.ok(progress>0 && progress<.98);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>getComputedStyle(n).transform),'none');assert.equal(await page.locator('#lt-now-playing').evaluate(n=>getComputedStyle(n).opacity),'1');await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');
   await page.locator('#lt-now-playing [data-action=closePlayer]').tap();assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);
   pass('tap expansion lasts beyond the old 120 ms, dismissal settles, and the modal root stays opaque and untransformed',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.locator('.lt-nav [data-action=library]').tap();await page.locator('#lt-browse').evaluate(n=>n.scrollTop=180);let r=await page.locator('#lt-mini-open').boundingBox(),t=await touch(page,r.x+150,r.y+r.height/2);await t.move(r.x+150,r.y+r.height/2-38);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);const short=await page.evaluate(()=>LiquidTouch.diagnostics().playerReveal);assert.ok(short>0 && short<1);await t.end();await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);
   r=await page.locator('#lt-mini-open').boundingBox();t=await touch(page,r.x+150,r.y+r.height/2);await t.move(r.x+150,r.y+r.height/2-130);const held=await page.evaluate(()=>LiquidTouch.diagnostics().playerReveal);assert.ok(held>short && held<1);assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().playerPhase),'dragging');await t.end();await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');
   t=await touch(page,500,32);await t.move(500,72);assert.ok((await page.evaluate(()=>LiquidTouch.diagnostics().playerReveal))<1);await t.end();await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');
   t=await touch(page,500,32);await t.move(500,160);await t.end();await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');assert.equal(await page.locator('#lt-browse').evaluate(n=>n.scrollTop),180);
   pass('player opening/closing follows the finger, short swipes return, threshold releases commit, and Library/scroll return intact',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);const r=await page.locator('#lt-mini-open').boundingBox();let t=await touch(page,r.x+120,r.y+30);await t.move(r.x+120,r.y-90);await t.cancel();await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);await player(page);t=await touch(page,500,30);await t.move(500,150);await t.cancel();await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await page.evaluate(()=>document.querySelector('#lt-mini-open').click());await page.waitForTimeout(500);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);
   pass('pointer cancellation and reopening during dismissal cannot leave an invisible modal or dismiss the reopened player',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{},null,false);await player(page);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.style.clipPath),'');await page.locator('#lt-now-playing [data-action=closePlayer]').tap();assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),false);
   pass('Reduce Motion commits without reveal animation while retaining the same player state',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{updateChecks:false});let calls=0;await page.route('https://updates.example.test/**',r=>{calls++;r.abort();});await page.waitForTimeout(2200);assert.equal(calls,0);await settings(page);await revealSetting(page,'update-feed');await page.locator('#lt-update-feed').fill('');await page.locator('#lt-update-feed').dispatchEvent('change');await revealSetting(page,'checkUpdates');await page.locator('[data-action=checkUpdates]').tap();assert.ok((await page.locator('#lt-update-status').textContent()).includes('No release feed'));assert.equal(await page.evaluate(key=>localStorage.getItem(key),cache),null);
   pass('disabled automatic checks make no update requests, and a manually emptied field clearly offers local import',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.waitForFunction(()=>localStorage.getItem('liquid-touch.seen-release')==='1.9.3');const bundle=future();await importUpdate(page,bundle);await page.waitForFunction(()=>document.querySelector('#lt-release').open);assert.equal(await page.evaluate(()=>LiquidTouch.version),'1.9.3');assert.equal(await page.evaluate(key=>localStorage.getItem(key),cache),null);
   const caption=await page.locator('#lt-release .lt-caption-buttons').boundingBox(),close=await page.locator('#lt-release header [data-action=closeRelease]').boundingBox();assert.ok(caption.y+caption.height<=close.y || caption.x>=close.x+close.width);await page.locator('#lt-release a[data-action=fullReleaseNotes]').tap();assert.equal(await page.locator('#lt-full-release-notes').textContent(),bundle.notes);assert.equal(await page.evaluate(()=>LiquidTouch.version),'1.9.3');await page.locator('#lt-release [data-action=confirmUpdate]').tap();await page.waitForFunction(()=>LiquidTouch?.version==='1.9.4' && LiquidTouch.diagnostics().phase==='mounted');assert.equal(await page.locator('#lt-shell').count(),1);assert.equal(await page.locator('#lt-runtime-theme').count(),1);assert.equal(await page.evaluate(()=>__ltMock.listenerCount()),3);
   await page.waitForFunction(()=>document.querySelector('#lt-release').open);assert.equal(await page.locator('#lt-release-title').textContent(),'What’s new');await page.locator('#lt-release a').tap();assert.equal(await page.locator('#lt-full-release-notes').textContent(),bundle.notes);await page.locator('#lt-release footer [data-action=closeRelease]').tap();await page.reload();await page.waitForFunction(()=>LiquidTouch?.version==='1.9.4');await page.waitForTimeout(1200);assert.equal(await page.locator('#lt-release').evaluate(n=>n.open),false);
   await settings(page);await revealSetting(page,'restoreRuntime');await page.locator('[data-action=restoreRuntime]').tap();await page.locator('#lt-release [data-action=confirmUpdate]').tap();await page.waitForFunction(()=>LiquidTouch?.version==='1.9.3' && LiquidTouch.diagnostics().phase==='mounted');assert.equal(await page.evaluate(key=>localStorage.getItem(key),cache),null);assert.equal(await page.locator('#lt-shell').count(),1);assert.equal(await page.locator('#lt-runtime-theme').count(),1);assert.equal(await page.evaluate(()=>__ltMock.listenerCount()),3);
   pass('local updates require approval, persist, show notes once, and can restore the installed version without duplicate UI/listeners',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await feedRoutes(page,future());await settings(page);await revealSetting(page,'update-feed');await page.locator('#lt-update-feed').fill('https://updates.example.test/latest.json');await page.locator('#lt-update-feed').dispatchEvent('change');await revealSetting(page,'checkUpdates');await page.locator('[data-action=checkUpdates]').tap();await page.waitForFunction(()=>document.querySelector('#lt-release').open);assert.equal(await page.evaluate(()=>LiquidTouch.version),'1.9.3');await page.locator('#lt-release footer [data-action=closeRelease]').tap();assert.equal(await page.evaluate(key=>localStorage.getItem(key),cache),null);
   await revealSetting(page,'checkUpdates');await page.locator('[data-action=checkUpdates]').tap();await page.waitForFunction(()=>document.querySelector('#lt-release').open);await page.locator('#lt-release [data-action=confirmUpdate]').tap();await page.waitForFunction(()=>LiquidTouch?.version==='1.9.4');
   pass('a hosted feed checks versions and offers Update/Later; downloading and installing require the Update action',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{updateFeed:'https://updates.example.test/latest.json'});let downloads=0;await feedRoutes(page,future());page.on('request',r=>{if(r.url().endsWith('/bundle.json'))downloads++;});await settings(page);await page.waitForFunction(()=>document.querySelector('#lt-update-status').textContent.includes('is available'));assert.equal(await page.locator('#lt-release').evaluate(n=>n.open),false);await closeSettings(page);await page.waitForFunction(()=>document.querySelector('#lt-release').open);assert.equal(downloads,0);assert.equal(await page.evaluate(key=>localStorage.getItem(key),cache),null);await page.locator('#lt-release footer [data-action=closeRelease]').tap();
   pass('automatic checks defer their popup until Settings closes and do not download code before approval or a notes request',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.route('https://updates.example.test/**',r=>r.fulfill({contentType:'application/json',headers:{'Access-Control-Allow-Origin':'*'},body:JSON.stringify({schema:1,app:'LiquidTouch',version:'1.9.4',bundleURL:r.request().url().includes('foreign') ? 'https://other.example.test/code.json' : './bundle.json',sha256:'0'.repeat(64)})}));
   const result=await page.evaluate(async()=>{const messages=[];for(const address of ['http://updates.example.test/latest.json','https://user:pass@updates.example.test/latest.json','https://updates.example.test/foreign.json'])try{await LiquidTouchUpdater.check(address);messages.push('accepted');}catch(e){messages.push(e.message);}try{await LiquidTouchUpdater.download(await LiquidTouchUpdater.check('https://updates.example.test/latest.json'));messages.push('accepted');}catch(e){messages.push(e.message);}return messages;});
   assert.ok(result[0].includes('HTTPS'));assert.ok(result[1].includes('HTTPS'));assert.ok(result[2].includes('same host'));assert.ok(result[3].includes('checksum'));assert.equal(await page.evaluate(key=>localStorage.getItem(key),cache),null);
   pass('feeds require credential-free HTTPS, same-host bundles, and a matching downloaded checksum before execution',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await importUpdate(page,future({minimumLoader:'2.0.0'}));await page.waitForFunction(()=>document.querySelector('#lt-update-status').textContent.includes('normal package'));assert.equal(await page.evaluate(()=>LiquidTouch.version),'1.9.3');assert.equal(await page.evaluate(key=>localStorage.getItem(key),cache),null);
   pass('updates needing a newer loader request a package installation and keep the current interface intact',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{},()=>{window.Function=function(){throw new EvalError('Code generation blocked');};});await importUpdate(page,future());await page.waitForFunction(()=>document.querySelector('#lt-update-status').textContent.includes('blocks in-app'));assert.equal(await page.evaluate(()=>LiquidTouch.version),'1.9.3');assert.equal(await page.evaluate(key=>localStorage.getItem(key),cache),null);
   pass('the installed fallback runs without dynamic compilation and explains when the host blocks runtime update code',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);const bad=future();bad.integrity='0'.repeat(64);await importUpdate(page,bad);await page.waitForFunction(()=>document.querySelector('#lt-update-status').textContent.includes('verification failed'));assert.equal(await page.evaluate(()=>LiquidTouch.version),'1.9.3');assert.equal(await page.evaluate(key=>localStorage.getItem(key),cache),null);
   pass('corrupt update bytes are rejected before confirmation, storage or execution',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.evaluate(()=>{const set=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key==='liquid-touch.runtime.v1')throw new DOMException('Update cache is full','QuotaExceededError');return set.call(this,key,value);};});const old=await page.locator('#lt-shell').elementHandle();await importUpdate(page,future());await page.waitForFunction(()=>document.querySelector('#lt-release').open);await page.locator('#lt-release [data-action=confirmUpdate]').tap();await page.waitForFunction(()=>document.querySelector('#lt-release-status').textContent.includes('cache is full'));assert.equal(await old.evaluate(n=>n.isConnected),true);assert.equal(await page.evaluate(()=>LiquidTouch.version),'1.9.3');
   pass('a cache quota failure leaves the running interface and its state untouched',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await importUpdate(page,future({javascript:'throw new Error("Fictional startup failure");'}));await page.waitForFunction(()=>document.querySelector('#lt-release').open);await page.locator('#lt-release [data-action=confirmUpdate]').tap();await page.waitForFunction(()=>LiquidTouch?.version==='1.9.3' && !document.querySelector('#lt-release').open);assert.equal(await page.evaluate(key=>localStorage.getItem(key),cache),null);assert.equal(await page.locator('#lt-shell').count(),1);
   pass('a failed new runtime restores the prior UI and cache instead of leaving a broken startup',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);const bad=future({javascript:'window.shouldNotRun=true;'});bad.integrity='0'.repeat(64);await page.evaluate(({key,bundle})=>localStorage.setItem(key,JSON.stringify(bundle)),{key:cache,bundle:bad});await page.reload();await page.waitForFunction(()=>LiquidTouch?.diagnostics().phase==='mounted');assert.equal(await page.evaluate(()=>window.shouldNotRun),undefined);assert.equal(await page.evaluate(()=>LiquidTouch.version),'1.9.3');assert.equal(await page.evaluate(key=>localStorage.getItem(key),cache),null);
   pass('a corrupt saved runtime is verified before execution and falls back to the installed package',errors);await context.close();
  }
  console.log(passed+' release 1.9 suites passed using simulated Spotify/update services.');
 }finally{await browser.close();await new Promise(r=>server.close(r));}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
