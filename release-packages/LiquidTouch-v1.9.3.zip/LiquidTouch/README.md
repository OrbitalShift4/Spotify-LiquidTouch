# LiquidTouch

Current source release: **1.9.3** (cleaner lyrics, individual animation speeds,
and adjustable swipe confirmation distances).

A Spicetify theme and companion extension for a dedicated Spotify touchscreen.
Made for a 7-inch mini-PC display, with a mobile-style layout and a dark,
Liquid Glass inspired finish: translucent surfaces, soft highlights, rounded
controls, and artwork-colored atmosphere.

**Start here:** open **LiquidTouch-Preview.html** in a desktop browser. It is a
self-contained, offline interactive demo using the **same CSS and extension**
as the installed version. Its fictional tracks simulate controls; it plays no
audio and never connects to your Spotify account.
Its window buttons simulate desktop commands without closing or minimizing
your browser. Now Playing fills the preview viewport without changing display mode.

## Settings categories

Settings opens to **Text & accessibility**, **Appearance & glass**, **Now Playing**,
**Lyrics**, **Home & clock**, **Touch & keyboard**, **Animation speeds**, **Swipe thresholds**, **Updates**,
and **History & help**.
Only the selected group is shown, and preferences keep their existing storage keys.
Swipe left to right to go Back (80 px by default). Pull the header down, or pull
content down when already scrolled to the top, to close the whole menu (72 px by default).
Customize these and the other gesture confirmation distances in **Swipe thresholds**.
Both gestures follow the finger, settle on release and cancel below threshold.
Sliders, text fields and normal vertical scrolling retain their native behavior.
The Back button/Escape return to categories first; Close always dismisses Settings.

**Animation speeds** has an overall multiplier and 22 individual controls, grouped
under navigation/menus, player/artwork, lyrics/layout and visual feedback. 100%
is the original speed, 200% is twice as fast, and 50% is half speed. Overall and
individual values multiply. These affect movement only; playback, lyric timestamps,
card double-tap timing and network timeouts keep their own behavior. Reduce Motion
overrides animations.

**Swipe thresholds** has 11 independent confirmation distances. They change how
far to drag before release commits a gesture. Animation remains tied to the finger;
short, reversed or cancelled gestures return without committing. Sliders, text fields
and native vertical scrolling keep their behavior. Both new pages include independent
restore-default buttons and retain their values across restarts.

The lyric provider/status row is hidden when synced lyrics are ready, so the lyric
area uses its space. Loading, failure, instrumental and text-only status remain
visible when relevant. Tapping a synced line still seeks using its timing correction.

## What you get

- Floating **Home / Search / Your Library** navigation.
- Swipe right from the leftmost 64–120 px to go Back. It closes the current
  sheet/player first, then restores page history, including Library scroll.
  Horizontal touches remain in the app when they start in gutters/backdrops.
- Optional **Home clock** beside the greeting: Settings → Home & clock → Show Home clock,
  then Clock format → 12-hour or 24-hour. It uses the device local time, starts
  off, saves its settings and wraps on smaller displays. Minute updates reuse
  the existing UI timer without rebuilding cards or adding network requests.
- A touch-sized mini player with artwork, pause/play, next, and progress.
- An expanded Now Playing screen, with separate landscape and portrait layouts.
- Previous/next, shuffle, three repeat modes, save/remove, seek, mute, and volume.
- Live player-state and metadata fallbacks when the cached `Player.data` object
  is missing or late; expanded Now Playing shares these data sources.
- Swipe artwork left/right to skip; swipe the expanded player's header down to close.
- A taller local search keyboard, or your system keyboard for other languages.
  **Keyboard height 100–180%** starts at 145%; width stays unchanged. Height
  adapts to the viewport so the search field remains accessible.
- Pressed keyboard keys enlarge and show a readable character popup. Cancelled
  touches do not type; Reduce Motion retains feedback without animated movement.
- Redesigned Home and Library with large glass cards, a maximum of four columns,
  and a dedicated touch scroller. Higher text/interface sizes reduce columns.
- Home adapts Spotify’s rendered recommendations; Library reads the client’s
  collection API in pages, with explicit filter, rootlist, and sidebar fallbacks.
- LiquidTouch search results with song/artist/album/playlist filters and paging;
  Card destinations use LiquidTouch detail pages; Spotify retains its play queue.
- Single-tap track playback when Spotify exposes a row play button; scroll
  gestures and artist links keep their original behavior.
- Playlist, album, artist, and song cards play on a single tap and open on a double tap.
  Playback waits 400 ms by default so a second tap can cancel it entirely.
  Settings → **Card tap timing** adjusts this wait from 200–700 ms.
  Native play/pause buttons retain their own behavior, and keyboard activation opens.
- Double-tap opens an owned detail page with a cover, songs, artist releases and
  paging. It does not send a native detail-route request. Client collection and
  installed GraphQL APIs are preferred, with an authenticated catalog fallback.
  A readable loading/error state, Retry, Play and Open in Spotify stay available.
  The desktop button retains access to Spotify's full management tools.
- Playing equalizer/visualizer images are excluded from artwork capture. Known
  covers are retained when a card temporarily loses its cover, and unknown covers
  use the existing metadata lookup.
- Aurora, Ocean, and Graphite glass tints; 48 px or 56 px primary controls.
- Adjustable **100–200% text** (starts at 120%) and **100–140% interface size**.
  Text fields and player areas grow, and enlarged player layouts can scroll.
- Universal glass tint with adjustable **0–100% opacity**, in 1% steps (starts at
  35%). Text and artwork remain fully visible. Optional independent overrides
  cover the toolbar, navigation, mini player, player header, lyrics, the entire
  Settings window, and the entire history window. A single reset restores
  universal inheritance. Settings has one continuous glass fill and a fixed
  transparent header above its scrolling content; its old header override is retired.
- Artwork-derived color across browsing, the player, and glass surfaces. Pixel
  sampling provides a fallback if the color-extractor API is unavailable.
- Matching glass minimize, maximize/restore, and close buttons on supported
  desktop builds. Unsupported or rejected window hooks restore system controls.
- Larger floating-navigation labels and immediate pointer-release activation.
- Continuous artwork light behind all pages and the floating glass surfaces.
- Adjustable **12–56 px corner rounding**, saved with your preferences.
- Recent search item cards below Search; query-text chips are removed.
- Debounced live search with loading feedback, six quick item cards, cached
  responses, and stale-response protection. Enter opens LiquidTouch’s full results.
- Custom Home welcome and subtitle in Settings. The default and saved Good
  morning/afternoon/evening phrases follow the local clock. Use `{greeting}` or
  `{timeOfDay}` inside custom text; unrelated custom welcomes stay as written.
- A stable edge-to-edge player with its own current-artwork canvas. It fills
  the Spotify window without requesting or exiting display fullscreen.
  Custom window controls remain visible; old automatic-fullscreen settings are ignored.
- Larger artwork and more compact playback controls on the left, with live lyrics
  on the right in landscape. Settings can hide lyrics or disable the optional
  public backup sources. Timed lines seek on tap; untimed text cannot seek.
- **Player artwork size 60–200%**, starting at 135% of the previous cover size.
  It works with lyrics on or off. Small displays can scroll the record column
  to reach controls below a larger cover. This is first in Settings, and the
  picture button on the cover opens it directly.
- Artwork drags reveal the actual next/previous queued cover before release,
  in both the player and mini player. Reverse or cancel to return; playback changes
  only on release past the threshold. Missing artwork is hydrated when possible.
  If the client does not expose its queue, playback swipes still work without
  inventing a preview. Adjacent images are decoded ahead of the gesture.
- The floating navigation marker and icon colors follow the page's swipe
  progress. Taps and swipes use the same tab state and retained search view.
- Navigation opacity controls its tint, blur, border and highlights together;
  0% clears its glass effects and 100% gives it a solid reading surface.
- Mini player and navigation share the same tint, blur, border and shadow rules.
  Equal opacity values select the same glass material; underlying artwork or text
  can still vary by position. Independent section overrides remain available.
- Every scrollbar in Now Playing is hidden, including lyrics and timing.
  Finger, mouse-wheel and focus scrolling still reach larger layouts.
- Independent **Now Playing text size 75–200%**, **Lyrics text size 75–200%**,
  and **Now Playing control size 75–180%** settings multiply your app sizes.
  Normal text changes leave lyrics alone; controls include buttons, icons and sliders. Artwork, browsing, menus
  and window captions keep their own sizes. Touch targets stay at least 44 px.
- Wider player/header pull-down areas, content and navigation-bar tab swipes,
  and a wider left-edge Back gesture; sliders and lyric scrolling stay native.
- Navigation Back preserves local tabs and scroll positions, including Library.
- Finger-following swipe motion with release thresholds and spring-back on cancel.
  Tabs, detail pages, Back, sheets, quick search, keyboard and track changes
  have short 100–160 ms transitions. Player tap expansion takes 340 ms and
  dismissal takes 280 ms. Swipes follow the finger and settle on release;
  modal roots and window captions stay stable.
- Animated lyrics on/off with moving artwork/controls and a fading lyric pane.
- Per-recording, per-source lyric timing: Earlier/Later in 0.25-second steps,
  Reset, and Match a line by ear; corrected lyric taps seek to the adjusted time.
- Both the setting and operating-system Reduce Motion are respected.
- Searchable local listening history with dates, timestamps, and replay.
- Reduced motion and a lower-blur mode for modest mini PCs.
- Persistent preferences, an optional Now Playing startup view, and a desktop
  escape hatch.

This is an original interface over the Spotify desktop client. Spotify still
handles audio, account access, playlists, downloads, advertisements, and account
restrictions. Home, Library, Search and card detail pages use LiquidTouch’s own
layouts; their music comes from Spotify. Artist pages show popular songs and
loaded releases. Open in Spotify provides the client's full detail/management UI.
Search results use the installed client query when available, with a Web API fallback.

**Devices:** the Devices button switches to Spotify's desktop interface, where
you can use its real Spotify Connect picker. Tap the floating **Touch UI** button
to return. The device picker itself has not been rebuilt.

## Requirements

1. Spotify desktop and a working Spicetify installation compatible with it.
   Follow the [official setup guide](https://spicetify.app/docs/getting-started)
   if needed. Open Spotify and sign in before applying customizations.
2. Both the **LiquidTouch theme and liquid-touch.js extension** from this package.
3. A usable screen area of at least **480 × 400 CSS pixels**. Recommended:
   **1024 × 600** landscape. The layouts were checked at 800 × 480, 1024 × 600,
   1280 × 720, 480 × 800, and 600 × 1024 in Chromium with a simulated Spotify host.

Spotify's own native window minimum size can limit portrait use on some systems.
The responsive layout cannot change the operating system's window constraints.

## Updating after 1.9.0

Install this package once using the usual Windows installer below. This adds the
stable loader and small theme bootstrap; 1.8 and earlier cannot import runtime
updates. Preserve the entire extracted folder for this installation.

After that, **Settings → Updates → Import update file** accepts one newer
`LiquidTouch-Update-vX.Y.Z.json`. A popup shows the version and brief notes;
**Update** verifies and applies JS/CSS together. **Later** leaves the running
version untouched. The first launch after updating shows brief notes and a
**Full patch notes** link inside the app. Preferences and listening history stay.
**Restore installed version** returns to the last normally installed package.

Optional automatic checks need a trusted **HTTPS release feed URL** in Settings.
The official repository feed is prefilled. Existing custom feed URLs are preserved;
checks occur at launch and about every six hours while Spotify is running.
They offer Update / Later and never install automatically. Turn off Check for
updates to stop automatic checks; manual checks/import remain available.

Runtime updates persist locally across Spotify restarts. Clearing Spotify's
browser data removes them. Installer/bootstrap changes still need a normal
installation. If the host blocks runtime code compilation, use the installer;
the installed bundled app itself does not rely on dynamic compilation.
See **UPDATES.md** for the optional feed format and publishing steps.

## Windows — install

Extract the entire ZIP first. Open PowerShell in the extracted **LiquidTouch**
folder and run, as your normal Windows user:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-Windows.ps1
```

The installer finds the actual config location with `spicetify -c`, backs up
your previous configuration and any existing LiquidTouch files, copies the
theme and extension, and explicitly enables `expose_apis` for the player and
navigation controls. If a native Spotify backup exists, it runs
`spicetify restore backup apply`; otherwise it runs `spicetify backup apply`.
This rebuilds preprocessing with the required APIs enabled. Your existing
extension list is preserved, and the original API-exposure setting is recorded
for removal later.

To also create a Windows login startup shortcut:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-Windows.ps1 -AutoStart
```

The shortcut runs `spicetify auto`. It does not change Windows login, touch
drivers, display orientation, or kiosk settings. Maximize Spotify with its window
button when you want the app to occupy the display; expanding the player does
not change the operating system's window or fullscreen mode.

To copy/configure files without immediately patching or restarting Spotify:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-Windows.ps1 -NoApply
```

Then run `spicetify restore backup apply` if a backup already exists, or
`spicetify backup apply` on a fresh Spicetify installation.

## Linux / macOS — install

The helper installer needs Python 3 and a working `spicetify` command. It has no
third-party Python dependencies and downloads nothing.

```bash
bash install.sh
```

Use `bash install.sh --no-apply` to install files without patching Spotify yet.
Autostart on Linux/macOS is left to your desktop environment.

## Manual installation — all platforms

Run `spicetify -c` to find your configuration file, then open its parent folder.

1. Copy `Themes/LiquidTouch` into that folder's `Themes` directory.
2. Copy `Extensions/liquid-touch.js` into its `Extensions` directory.
3. Run:

```text
spicetify config current_theme LiquidTouch color_scheme Glass inject_css 1 replace_colors 1 expose_apis 1
spicetify config extensions liquid-touch.js
spicetify backup apply
```

For an already modified Spotify installation, use `spicetify restore backup apply`
for the last step. API-exposure changes require preprocessing to be rebuilt.

Spicetify appends extension names rather than replacing your entire list.
For a clean first check, avoid enabling another extension that also replaces
the player, changes sidebar positioning, or forces a fullscreen view.

## Set up the 7-inch display

- Start in **landscape** and maximize Spotify on the touchscreen.
- Adjust **that display's** OS scaling until the effective app area is near
  1024 × 600. A high-resolution 7-inch panel at 100% scaling makes everything
  physically tiny; CSS pixel size is not a promise of fingertip size.
- In LiquidTouch settings, try **Comfort** first, then **Large** if needed.
- For easier reading, start with **Text size 150%** and **Interface size 110%**.
  These are independent of your operating system's display scaling. Increase
  either as needed; higher settings show less content at once.
- Turn **Universal glass opacity** down for a clearer look, or up for a more solid
  reading surface. Open **Panel opacity overrides** and enable **Custom** on any
  panel that needs a different tint. **Use universal for all panels** resets those
  overrides. Artwork atmosphere can be switched off without changing font size.
- If the mini PC stutters or runs hot, switch on **Lighter glass**.
- If you want Arabic or another keyboard layout, turn **Built-in keyboard** off
  and enable your operating system's touch keyboard. The built-in layout is
  English letters, numbers, and common search symbols.
- Use **Keyboard height** for taller keys and **Player artwork size** for a
  larger cover. Both are saved independently of text/interface scale.
- Enable **Open in Now Playing** for a player-first startup view.

## Controls

| Action | How |
| --- | --- |
| Expand player | Tap the mini player, or swipe it upward at least 72 px and release |
| Close player | Tap its down arrow, pull its header/artwork down, or press Escape |
| Next / previous | Use the buttons, or swipe artwork left / right |
| Search | Tap Search, type with either keyboard, then submit |
| Open library | Tap Your Library; double tap a playlist/album card to open it |
| Play an album or playlist card | Tap once |
| Open a card without playing | Double tap within your Card tap timing setting (400 ms default) |
| Open queue | Tap Queue in expanded Now Playing |
| Change output device | Tap Devices, use Spotify's native device control, then Touch UI |
| Adjust volume / position | Drag a slider; the change commits when released |
| Desktop interface | Settings → Desktop interface |
| Return to touch | Floating Touch UI button |
| Emergency switch | Ctrl + Alt + T |
| Settings | Sliders icon at the top right |
| Readability | Settings → Text size / Interface size |
| Player readability | Settings → Now Playing text size / Lyrics text size / Now Playing control size |
| Tap timing | Settings → Card tap timing (200–700 ms) |
| Future runtime updates | Settings → Updates → Import update file, or configure a trusted feed |
| Taller keyboard keys | Settings → Keyboard height |
| Larger player artwork | Picture button on artwork, or first slider in Settings |
| Glass clarity | Settings → Universal glass opacity |
| Separate panel clarity | Settings → Panel opacity overrides → Custom |
| Home greeting | Settings → Home welcome / Welcome subtitle |
| Live lyrics | Settings → Live lyrics beside artwork; tap a timed line to seek |
| Correct lyric delay | Now Playing → ⋯ → Timing → Earlier / Later, or Match a line |
| Quick search | Pull down across the upper area outside Now Playing |
| Previous view | Top-left Back, or swipe right from the left edge and release past 80 px; works on sheets/player too |
| Home clock | Settings → Home & clock → Show Home clock / Clock format (12-hour or 24-hour) |
| Switch tabs | Swipe horizontally across the page or floating navigation |
| Round corners | Settings → Corner rounding |
| Listening history | Settings → Listening history; search by song, artist, album, or local date |
| Recent searches | Search tab, beneath the search field |
| Window controls | Glass capsule at the top right, where the desktop bridge is supported |

Playback controls respect restrictions reported by Spotify. Features requiring
a particular account tier or device are not unlocked by this package.

## Player, lyrics, and live search

Now Playing fills the app viewport with the current artwork behind it. It opens
the modal once without requesting display fullscreen or closing/reopening it to
repair a layer. The old Display fullscreen preference and automatic fullscreen
handoff are retired, including previously saved enabled values. Opening, closing,
or destroying the player does not enter or exit a host-owned fullscreen session.
Minimize, maximize/restore, and close remain visible on supported desktop builds.
Pull down over the header or artwork to return to the prior tab and scroll
position. Swipe opening/closing follows your finger, commits when released
past 72 px, and returns if you reverse or release early. Tap expansion takes
340 ms; closing takes 280 ms. Reopening cancels an old dismissal safely.
The modal root remains fully opaque and untransformed. Use the window maximize
button if Spotify itself is not filling your display.

The top-center player header has no text. Title and artist appear below the art.
Three separate Now Playing size sliders are directly below Player artwork size
in Settings: normal text, lyrics, and controls. They start at 100% of your app
sizes; artwork has its own slider. On upgrade, lyrics inherit the old player
text setting once, preserving their previous size. Later changes are independent.
Player scrollbars stay hidden even when content needs scrolling.
In landscape, larger artwork and smaller controls share the left column; live
lyrics occupy the right column. Portrait stacks them, with normal scrolling.
Artwork starts at 135% of the previous layout's base size: up to 486 CSS pixels
with lyrics enabled on a roomy display, bounded by the column width. Settings →
**Player artwork size** adjusts it from 60–200%, with lyrics on or off. The record
column scrolls when a larger cover plus controls cannot fit vertically. Controls
retain their 420-pixel maximum in lyric mode and at least 44-pixel touch targets.
Settings → **Live lyrics beside artwork** hides/shows the lyric column. The
player’s Lyrics button controls the same saved preference. Timed lines seek to
their real millisecond timestamps and respect playback restrictions. Untimed
lyrics remain readable without inventing timing, and unavailable lyrics show a
message and a Reload lyrics action in the ⋯ menu.

Spotify is the first lyric source. **Broader lyric lookup** adds LRCLIB exact
lookup, then structured and keyword searches. Search removes release/guest-credit
clutter, uses the lead artist, and compares recording title, artist, version and
duration. Search results need a duration within two seconds for timed seeking;
nearby matches can supply text without claiming synchronization. Incompatible
live/remix versions, unrelated artists and very different durations are rejected.

If these lookups have no text, **Additional text lyrics** tries lyrics.ovh. Its
results are labelled text-only and cannot seek. This fallback requires Broader
lyric lookup to be enabled. Turn Broader lyric lookup off to use Spotify alone.
LRCLIB receives title, artist, album and duration; lyrics.ovh receives cleaned
title and lead artist. No Spotify credentials or cookies are sent. LRCLIB also
receives a public client identification header. Requests are bounded/cancellable,
LRCLIB requests are spaced, and Retry-After is honored. Results stay in memory
for up to 32 tracks. Coverage and live provider availability are not guaranteed.

Live search starts after a 100 ms pause. The installed client’s search query is
preferred when exposed, with the Spotify Web API as fallback. Preview and full
results share in-flight requests and a 32-page, 60-second cache. Enter renders
LiquidTouch results with filters and paging. If both service routes fail, the
page offers Retry and Open desktop search instead of an empty surface. Stale
responses cannot replace a newer query. Search results still require a working
Spotify session; the extension does not bypass catalog authorization.

Keyboard keys start about 45% taller at Interface 100%, with larger labels and
the same horizontal layout. **Keyboard height** adjusts 100–180%; the final height
is capped to keep the search field visible. Live previews use only the space
above the keyboard and yield when that space is too small; Enter still opens
full results. The preview cannot cover the keyboard or its Hide button.
Pressed keys grow in place and show a readable popup. Input still occurs once
on release; cancelled touches do not type. The popup ignores pointer input and
cleans up after release, cancellation, keyboard dismissal or focus loss.

Horizontal swipes now work across page content as well as the bottom navigation.
A rightward swipe starting in the left 64–120 px goes Back; native detail pages
also accept a rightward Back swipe from their content. Quick-search pulls can
start across the full width of the upper region, at least 180 pixels deep and
up to 280 pixels depending on display/toolbar size, when the page is at its top.
The toolbar and a 36-pixel band below it also work on scrolled pages. Native
caption buttons, fields and sliders are excluded. Artwork/mini-player horizontal swipes still skip tracks. Ordinary
vertical lists, lyric scrolling, sliders, and text fields retain their native
interaction.

Normal browsing avoids replacing unchanged grids or cards under a finger.
Loaded Home, Library, search landing and the last results view reuse detached
page content when their data is unchanged. This preserves card nodes and scroll
positions. Catalog rescans are deferred until after the tab switch; swipe settling
lasts 100 ms. Superseded in-flight Spotify routes cannot undo the latest tab,
while genuine redirects and Back remain supported. This removes extension work
from the switch; Spotify’s own cold-start/network time is not guaranteed.
Card surfaces keep their translucent highlights without a separate live blur
per card. Wallpaper blur is reduced, duplicate gesture handlers are removed,
and startup library loading is deferred until the touch shell is interactive.
Page/content transitions last 100–160 ms. The slower player reveal runs only
while opening, closing or dragging; it has no ongoing idle animation.
Reduce Motion skips the settle animations. Navigation and teardown still close
modals synchronously to prevent stale callbacks changing a later page.
Swipe content follows the finger without a progress indicator or release label.
Release past the threshold to commit, or reverse/release early to spring back.
Tab/Back thresholds are 80 px, expanded-player artwork skips 40 px (mini-player
skips remain 76 px), player/sheet dismissal 72 px, and quick search 64 px.
No short-flick velocity shortcut is used. Slower deliberate swipes have up to
2.5 seconds to finish. Expanded-player dismissal can start across the full width
of its generous upper area, including space below the toolbar. Native caption
buttons and sliders keep their own interaction. Window maximize/restore keeps the native OS behavior,
with matching caption feedback; the player follows the resized layout without
replaying its opening animation. These
changes use transforms/opacity; Spotify’s network/startup time remains outside
the extension’s control.

### Correcting a song’s lyric timing

Open **⋯ → Timing…** in the lyric panel, or Settings → Lyrics → **Current song’s lyric timing**.
If lyrics arrive late, tap **Earlier**. Each tap advances the displayed lyrics by
0.25 seconds; **Later** does the opposite. **Reset** returns to the source’s
original timestamps. Corrections are bounded to 15 seconds either way.

For a larger mismatch, choose **Match a line**, then tap the line currently being
sung. Timing controls collapse to give the lyrics room while matching. That calibrates the timestamp without seeking or pausing the song. Normal
lyric taps use the corrected media time afterward. The adjustment is saved on
this device for the exact Spotify recording URI and source (Spotify or LRCLIB),
so fixing one version of “Billie Jean” does not shift “Nothing Can Change This
Love” or a different recording. Only URI/source/offset/time records are stored;
lyrics themselves remain in the in-memory cache.

Highlight timing reads the player’s current clock every 80 ms while the player
and lyrics are visible. The clock stops when the view is closed, lyrics are off,
or the document is hidden. Highlighting changes at the timestamp; auto-scrolling
settles in 120 ms and yields to user scrolling. Duration checks reject backup
records differing by more than two seconds. These changes reduce UI lag but do
not infer a universal correction from a song title: timestamp/source or recording
mismatches still need an offset or the matching recording.

See **PATCHNOTES.txt** for the numbered list corresponding to the reported issues.

## Listening history and recent searches

Settings → **Listening history** opens a full page with song/artist/album/date
search, day groups, local timestamps, and tap-to-replay rows. It records observed
track starts while the extension runs. Pause/resume does not duplicate a play;
looping the same song is recorded again when its end-to-start transition is
observed. A track already playing at startup is timestamped when first observed.
Earlier Spotify plays are not backfilled.

Up to **10,000 recent plays**, **50 search items**, and **30 search terms** are kept
in Spotify’s local browser storage. History uses the account namespace when
available. Under storage pressure the oldest history can be trimmed; a notice
appears if a save fails. Clearing Spotify’s app/browser data removes this record.
The package does not upload it or read authentication tokens. Reinstalling just
the theme/extension keeps these local keys. Searching results and opening/playing
an item adds it to Recent searches. Artist, song, album, and playlist
cards play on one tap and open on two; their explicit **Open** button and keyboard
activation also open the detail page.

## Uninstall / restore

If you installed with the Windows helper:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Uninstall-Windows.ps1
```

Linux/macOS:

```bash
bash uninstall.sh
```

The helpers restore the theme settings from before the first installation when
LiquidTouch is still selected, remove the added extension entry, restore any
preexisting LiquidTouch files, and retain unrelated settings/extensions added
later. Backups remain in your Spicetify config directory. A startup shortcut is
removed only if this installer created it.

For a **manual install**, remove the extension and select your previous theme:

```text
spicetify config extensions liquid-touch.js-
spicetify config current_theme YOUR_PREVIOUS_THEME
spicetify apply
```

To return Spotify entirely to its vanilla state instead, `spicetify restore`
removes all Spicetify customizations. This affects your other Spicetify changes too.

## Troubleshooting and compatibility

- **Only the colors changed:** the extension is missing, waiting for APIs, or
  failed during startup. With the updated package, run the installer again to
  enable both `liquid-touch.js` and `expose_apis` and rebuild preprocessing.
  Update an older Spicetify first using its own update command/package manager.
- **Startup panel appears:** it identifies missing APIs, missing CSS, or the
  actual exception. Tap **Copy details** and paste the result into this chat.
  After the missing dependency becomes available, tap **Retry**.
- **No startup panel or touch controls at all:** check `spicetify config extensions`
  contains `liquid-touch.js`; confirm the matching file exists in the Extensions
  directory beside the config file reported by `spicetify -c`.
- **Library is incomplete:** tap Refresh in Library. The main collection API is
  paginated; older versions try separate playlist/album/artist filters, then the
  rootlist and visible sidebar. When only sidebar data is available, the page
  says so. Desktop interface keeps access to Spotify’s full library.
- **Progress works but Now Playing has no title/art:** this release reads the
  live player state first, with wrapper, platform, event, and native-widget fallbacks.
- **System window buttons are visible:** the native bridge is unavailable or
  rejected a command. Space is reserved so it cannot cover touch controls. Use
  **Glass window buttons** in settings to select system controls deliberately.
- **Blank native pages in 1.2.0:** update both CSS and the extension together.
  1.2.0 accidentally hid `.Root__top-container`, which also contains native search
  and detail views. 1.3.0 keeps that parent visible and measurable.
- **Large text needs more scrolling:** this is expected. Font size and interface
  size are separate so you can enlarge text without enlarging every control.
- **A Spotify update broke the layout:** update Spicetify for that client and run
  `spicetify restore backup apply` if its existing backup is still present.
  Use Ctrl + Alt + T for desktop access while diagnosing.
- **Player does not cover the monitor:** maximize Spotify first. Now Playing
  covers the full app window without changing display fullscreen.
- **Changes to controls seem ignored:** test without other player/sidebar
  replacement extensions. The installer deliberately preserves them.
- **Need diagnostics:** in Spotify DevTools, run `LiquidTouch.diagnostics()`.
  It reports version, screen area, preferences, and whether native views were
  found. It does not collect account tokens or listening history.

### What has actually been tested

The supplied checks exercise the actual extension in Chromium against the
included offline Spotify host fixture: responsive layouts, minimum touch
targets, player actions, local keyboard, encoded search, navigation, gestures,
restrictions, safe metadata rendering, persistence, teardown, and recovery.
Installer tests use an isolated fake CLI and temporary configs to verify copies,
backups, reinstallation, and restoration.

**A live Spotify client and physical touchscreen were not available here.**
This is an installable release, not a claim of verified compatibility with
every Spotify build. Spotify's internal DOM and APIs can change. In particular,
library API shapes, native search/track hooks, native window controls, and
physical touch behavior need a check on your mini PC. Windows scripts are
also exercised under PowerShell 7 on Linux against the fake CLI. Windows 5.1,
the optional Windows COM startup-shortcut branch, and live Spotify patching
still need a Windows machine. The manual install path is available as well.

## Files and development

```text
Themes/LiquidTouch/color.ini    Three Spicetify color schemes
Themes/LiquidTouch/user.css     Small installed-theme bootstrap
Themes/LiquidTouch/runtime.css  Authoritative responsive theme source
source/liquid-touch-app.js      Authoritative application source
source/runtime-loader.js        Stable updater/installed fallback template
Extensions/liquid-touch.js      Generated loader, fallback app and bundled CSS
LiquidTouch-Update-v1.9.3.json   Single runtime update file for compatible loaders
updates/release.json            Release summary and full in-app patch notes
updates/latest.example.json     Optional hosted-feed publishing template
UPDATES.md                      Upgrade and optional hosting instructions
Install-Windows.ps1            Backed-up Windows installation
Uninstall-Windows.ps1          Restore/remove helper
install.sh / uninstall.sh      Linux/macOS entry points
tools/                         Installer helpers and preview builder
preview/                       Clearly labeled simulated Spotify host
LiquidTouch-Preview.html       Self-contained offline interactive preview
tests/                         Reproducible host-contract and installer checks
```

There is no runtime npm install, required web server, developer account, or Spotify API
key. A hosted update feed is optional; local update import needs no feed. The extension uses the already-running Spicetify wrapper and Spotify's
native playback and optional desktop navigation. Artwork tint uses Spicetify's optional color extractor,
with local pixel sampling as a fallback.

For developers only:

```bash
npm install --no-save playwright sharp
npx playwright install chromium
node tools/build-preview.cjs
node tests/ui.cjs
node tests/features.cjs
node tests/browse-history.cjs
node tests/release-130.cjs
node tests/release-140.cjs
node tests/release-150.cjs
node tests/release-151.cjs
node tests/release-160.cjs
node tests/release-161.cjs
node tests/release-170.cjs
node tests/release-171.cjs
node tests/release-180.cjs
node tests/release-190.cjs
node tests/release-191.cjs
node tests/release-192.cjs
node tests/settings-192.cjs
node tests/release-193.cjs
python3 tests/test_installer.py
```

The preview builder first rebuilds the generated extension/update file from
source, then embeds that production extension unchanged with mock data.
Edit source/liquid-touch-app.js and runtime.css, not the generated extension.
Do not install `preview/fixture.js` into Spotify.

## API references checked 30 October 2026

- [Spicetify themes](https://spicetify.app/docs/development/themes)
- [Extensions and manual installation](https://spicetify.app/docs/customization/extensions)
- [Player API](https://spicetify.app/docs/development/api-wrapper/methods/player)
- [Platform / History API](https://spicetify.app/docs/development/api-wrapper/methods/platform)
- [Artwork color extractor](https://spicetify.app/docs/development/api-wrapper/functions/color-extractor)
- [Spicetify queue](https://spicetify.app/docs/development/api-wrapper/properties/queue)
- [LRCLIB exact and search API](https://lrclib.net/docs.txt)
- [lyrics.ovh API](https://github.com/NTag/lyrics.ovh)
- [Spotify catalog search](https://developer.spotify.com/documentation/web-api/reference/search)
- [Spotify playlist images](https://developer.spotify.com/documentation/web-api/concepts/playlists)
- [Spicetify lyric providers](https://github.com/spicetify/cli/blob/main/CustomApps/lyrics-plus/Providers.js)
- [LRCLIB provider recording lookup](https://github.com/spicetify/cli/blob/main/CustomApps/lyrics-plus/ProviderLRCLIB.js)
- [Spicetify client query wrapper](https://spicetify.app/docs/development/api-wrapper/methods/graphql)
- [Spicetify commands](https://spicetify.app/docs/cli/commands)
- [DesktopWindowState usage in Xumi](https://github.com/TokyoTF/Xumi) — compatibility
  reference for Spotify's internal desktop window client; Xumi is not a dependency.

LiquidTouch is independent of Spotify and Apple. Original source and demo artwork
are provided under the MIT license in LICENSE.
