# LiquidTouch v1.9.6 — Quality of life

3 November 2026 · build `2026-11-03-qol`

## Lyrics follow the current song

- Every song begins with the lyrics panel hidden. With **Automatically show
  found lyrics** enabled, the panel appears only after actual lyrics load for
  the current song. Failed and empty lookups leave the centered player visible.
- The player's **Lyrics** button can still open the panel when no lyrics were
  found, so the status, Reload and source options remain accessible.
- Manual show/hide applies to the current song. The next song starts hidden
  again and checks its own lyrics. A late response from a previous song cannot
  replace the current lyrics or open the panel.
- Automatic lookup can be disabled in Settings without disabling manual lookup.

## Consistent percentage controls

- Every numeric Settings slider and its plus/minus buttons now use percentages
  in **5% increments**, including opacity, text and control sizes, animation
  speeds, keyboard/artwork size, blur, corner rounding, card tap timing and
  gesture distances. Touch control size is adjustable as a percentage too.
- A value of 100% means the standard amount for that control. Blur and opacity
  can reach 0%; shorter timing/distance percentages shorten the relevant wait
  or swipe. Existing values migrate to the nearest supported step.
- Saved song limits remain actual counts, clock formats remain 12/24-hour
  choices, and per-recording lyric timing remains a measured time correction.
  These are not percentage sliders. Playback seek/volume retain their playback
  precision.

## Home stays current

- A **Recently played** shelf follows actual playback contexts, albums and
  artists as their metadata becomes available, including when playback changes
  while another LiquidTouch page or the player is open.
- Entries move to the front, are deduplicated and persist across normal updates
  and restarts. The shelf retains up to 24 entities. Missing context metadata is
  resolved from Spotify when that session permits it; no invented names or
  artwork are inserted.
- Home refreshes without changing the route or scroll position, and defers
  rebuilds while a finger is down. Native Home snapshots replace stale native
  recommendations instead of accumulating their old ordering indefinitely.

## Less work in Low-RAM mode

- Unchanged playback events now update progress without repainting track
  metadata and playback controls. This optimization also benefits normal mode.
- Low-RAM mode reduces background polling and DOM scans, skips animations and
  adjacent-artwork preloading, releases hidden page fragments, removes blurred
  image backgrounds and limits caches and artwork-fetch concurrency.
- It uses smaller player artwork when Spotify supplies an appropriate image,
  avoids a second image decode for color sampling, removes expensive blur and
  shadow effects, and lets offscreen rows/cards skip rendering work.
- The lyric clock runs only for an open player with visible timed lyrics and
  slows down in Low-RAM mode. Hidden windows defer background polling.
- Settings, local history, song limits and timing corrections remain saved.
  The mode changes LiquidTouch's workload; actual total Spotify RAM and frame
  rate depend on the client, library and PC, and have not been measured here.

## Artwork and gestures

- Removed the picture/settings shortcut over the Now Playing artwork. Artwork
  sizing is in **Settings → Now Playing**. Artwork holds still open track options.
- Left-edge swipes go Back throughout browsing, sheets and the player. Horizontal
  browsing swipes change tabs. Horizontal swipes across player art, track
  information, controls and lyrics skip tracks; the left edge retains Back.
- Downward swipes collapse the player or dismiss the top sheet when the
  relevant scroll container is at the top. Scrolled content continues scrolling.
- Default track-swipe distances match between the mini player and expanded
  player. Numeric thresholds are percentages, using the same 5% steps.
- Fields, sliders, the keyboard and caption buttons keep their normal input.
  Small, reversed, cancelled and differently angled gestures do not commit a
  different action. Existing search recovery, held Backspace and artwork drag
  prevention remain included.

## Update and validation

On a compatible v1.9.0+ loader, open **Settings → Updates → Check now** and
choose Update. Both original and revised v1.9.5 installations can update to
v1.9.6 normally. A fresh full installer is also included in the release package.

The complete built extension passed 23 DOM-host regression suites, including a
real v1.9.5 → v1.9.6 runtime update with settings/history preservation. The 12
search/keyboard/hold controller suites and 7 installer tests also passed.
Syntax, update/feed integrity, installer checksum and Git-bundle cloning are
checked as part of packaging. Chromium installation was unavailable; simulated
DOM tests do not verify visual layout, hardware touch behavior or real Spotify
performance. See `VALIDATION.md` for the reproducible commands and limits.
