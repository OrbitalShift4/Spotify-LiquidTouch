# LiquidTouch v1.9.6 — Quality of life

Revised build: `2026-11-03-queue` · 3 November 2026.

## Queue lyrics and track playback

- Lyrics stay one song ahead. The first queued song begins loading as soon as the current song is identified, including while paused and before manual skips. Queue changes replace the speculative target; no later queue items are prefetched.
- Cached lyrics hand off without closing the lyric panel. An unfinished prefetch is reused after a skip, then the following queued song starts warming. Songs without lyrics retain manual show/hide and the hidden-until-available policy.
- Spotify and enabled backup lyric sources use the upcoming recording's own title, artist and duration. Low-RAM mode keeps its bounded cache and queue fallback reads are throttled.
- Tapping a playlist or album row starts that parent context at the selected song and continues through its queue. Native playback uses the same `skipTo.uri` and `skipTo.uid` fields as Spicetify's own Bookmark extension; playlist row UIDs distinguish duplicate recordings.
- Web playback fallback keeps the original row position. Playback is checked after each request, rather than assuming an acknowledged request changed the song. A newer tap cancels an older tap's fallback. Repeat-one adjustment cannot block a successful selection.

## Install this revised v1.9.6

This keeps the published version at **1.9.6** and replaces the existing v1.9.6 installer asset. Existing v1.9.6 users should download the revised full ZIP, extract it completely and rerun the installer. The in-app updater does not accept another build with the same version number.

If a v1.9.7 or v1.9.8 test runtime is still active after reinstalling, open **Settings → Updates → Restore installed version**, then confirm **Restore**. This selects the newly installed v1.9.6 runtime and retains preferences, history and lyric timing. The test version numbers were not published as releases.

Compatible older releases such as v1.9.5 can still update to v1.9.6 normally through Check now or the included update JSON.

## Validation

The queue lyric and track-tap changes passed 23 Chromium suites in a simulated Spotify host. The user then confirmed both behaviors working in Spotify. The final runtime matches that tested build apart from the requested version/build labels. Installer/update checksums, source matching, feed generation, ZIP contents and Git bundle import are verified during packaging. See `VALIDATION.md` for checks and reproduction commands.

## Other v1.9.6 changes

## Lyrics follow the current song

- Each song starts with the lyric pane hidden. Auto-show reveals it only after nonempty lyrics have loaded for that exact recording. Empty, unavailable and instrumental-only responses leave the pane hidden.
- The player’s Lyrics button overrides visibility for the current song only. It can show the pane even when no lyrics were found, so Reload and timing/source options remain accessible. Manually hiding it prevents a late response from reopening it.
- A track change cancels old lookups, clears the previous song’s lines and resets the manual override. Late responses cannot display the wrong lyrics.
- Settings → Lyrics → Auto-show available lyrics controls automatic lookup/display. An old globally saved player Lyrics Off is migrated to this new availability policy once; a new explicit auto-Off preference is preserved.

## Percentage settings

- Every numeric Settings slider and its +/− buttons now uses percentages in 5% increments, including opacity, blur, corner rounding, animation speeds, card-tap timing and swipe distances. Playback volume also moves in 5% steps; seeking and lyric timing retain real timestamps.
- 100% means normal timing, distance, rounding, blur strength or animation speed for that control. Existing physical timing/distance preferences retain their units internally and move to the closest supported 5% value on upgrade.
- Discrete choices such as clock format and saved-history play counts keep meaningful named/count options.

## Home stays recent

- A persistent Recently played row moves the latest playlist, album and artist to the front as playback changes, including context/metadata exposed by Spotify for playback started elsewhere. Up to twelve unique items are retained.
- Selecting playback from cards or detail pages also updates Home. Pauses and repeated UI ticks do not continually rewrite the row. Metadata that arrives late cannot reorder a newer playback context.
- Native Home snapshots now replace/reorder recommendations instead of only accumulating older cards. Focus, returning to Home and host changes refresh the available snapshot without forcing navigation away from the user’s page.
- Spotify must expose context/album/artist identifiers to identify remote playback; this is not a complete server-side account history.

## Low-RAM mode does less work

- Large grids begin with 24 cards; loaded detail song lists begin with 40 rows; Home starts with three recommendation shelves. Show more retains access to the rest. History also begins with a smaller batch. Saved history is not deleted.
- Hidden page fragments and adjacent-cover preloads are dropped. Detail caches are smaller. Unchanged playback events skip full control painting in all modes; progress updates avoid writing unchanged values and hidden seek controls.
- Low-RAM mode uses a 1-second fallback UI tick, throttles fallback player reads, coalesces native catalog scans and ignores native playback-bar mutations. Song/pause/volume actions still repaint on events.
- Blurred background image resources, decorative animation, CSS filters and shadows are disabled in this mode. Dominant-color image sampling is skipped; active synced lyric tracking uses a lighter interval. Gestures retain their actions with simpler transitions.
- These changes reduce LiquidTouch’s own DOM, rendering and background work. They do not promise a fixed Spotify RAM saving or eliminate every source of lag in the desktop client.

## Cleaner player and consistent gestures

- Removed the picture/settings shortcut over the player artwork. Artwork size remains in Settings → Now Playing.
- All default gesture distances now share the same 100% baseline. Legacy default distances migrate together; customized distances remain adjustable independently.
- One movement tolerance and an intent lock keep a swipe on its original action. Moving back below threshold, reversing across the starting point or cancellation returns without firing another action.
- Swipe across the player to change tracks; edge-right Back takes priority. Right swipes in detail pages go Back. Downward pulls at the top dismiss sheets, while scrolled lists retain vertical scrolling. Pull down on a page at the top for Quick Search; swipe up to dismiss it. Top-level horizontal swipes switch Home/Search/Library.
- Sliders, editable fields and keyboard keys keep their own interactions. Low-RAM mode uses the same gesture decisions as normal mode.
