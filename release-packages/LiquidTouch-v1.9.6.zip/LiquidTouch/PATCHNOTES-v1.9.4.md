# LiquidTouch v1.9.4 (revised)


HISTORY THAT STAYS
Listening history moves to a version-independent IndexedDB journal for the current Spotify profile. Existing local history is imported; updates do not reset it. Unlimited is the default. Settings → History & help and the history page offer 100, 500, 1,000, 5,000 or 10,000 saved plays. When a selected cap is reached, new plays replace the oldest. Reducing a cap removes the oldest excess plays. Unlimited stops future replacement; it cannot restore records already removed under a cap. Clear history has an explicit confirmation and affects listening history only. Storage failures never trigger automatic pruning; they show an error and retain existing saved records. History is local to this Spotify profile/device, not a cloud backup.

TOUCH CONTEXT MENUS
Hold a card, song row, history entry or the artwork in Now Playing for 550 ms to open a LiquidTouch action sheet. Includes Play, Radio where supported, Add to queue, Add to playlist, Save/remove or Follow/unfollow, Open and Copy link as appropriate for the item. Moving or cancelling the touch cancels the hold. Opening the menu consumes the release so it cannot also play or navigate. Mouse right-click and the context-menu key/Shift+F10 use the same menu. Playlist selection lists owned or collaborative playlists and supports more pages. Spotify may restrict actions for a device, account or unavailable recording; errors remain inside the sheet.

DEVICES AND QUEUE
The expanded player opens LiquidTouch device and queue sheets instead of switching to Spotify’s desktop interface. These sheets no longer duplicate the app’s minimize/maximize/close controls. Device discovery first reads the desktop client’s native Connect APIs, including cached and asynchronous device lists, with the Web API as a fallback. The list refreshes while open and late responses cannot replace another sheet. Native device transfer is preferred, with local-device and Web API fallbacks. Device transfer keeps the current play/pause state. Restricted devices are disabled. Queue shows the playing song and upcoming songs, with Play and Remove where the client provides queue item IDs. Both sheets include Refresh, Back/Close, and inline failures. Closing them restores the player.

PLAYER GLASS AND ARTWORK
The player header and body now share one continuous artwork/tint canvas. The former header opacity override controls the entire Now Playing window and preserves its saved value. The lyrics panel keeps its independent override. Large artwork stays below the header and pushes the song title and controls downward; overflowing content remains scrollable with scrollbars hidden. Portrait layouts keep the header outside the content scroller.

PREFERENCES AND COMMUNITY
Settings, lyric timing, update-feed preferences and the history database use stable storage keys across updates. Existing preferences are preserved. The README now explicitly welcomes ideas, recommendations and suggestions through GitHub Issues.

HISTORY AND QUICK SEARCH
The history Close button sits at the top-left of its compact header. The journal uses a centered reading width, a compact search/limit/clear toolbar, and consistent artwork slots for every row. Quick Search hides the top toolbar and window buttons while open and blurs the underlying page. Settings → Appearance & glass → Quick Search background blur adjusts 0–40 px (14 px by default), independently of opacity. Search, results and keyboard stay sharp. Close, an outside tap or the existing dismiss gesture restore the toolbar and page.

REVISED v1.9.4 INSTALLATION
This replaces the original v1.9.4 package. If you already run v1.9.4, download and reinstall the revised full ZIP; the original updater compares version numbers and cannot offer a same-version replacement. The newly installed loader prefers its bundled runtime over an equal-version old cache. Preferences and listening history are preserved. Users on versions below 1.9.4 can update through the official feed.
