# Requires Spotify desktop and an already working Spicetify installation.
[CmdletBinding()]
param([switch]$NoApply, [switch]$AutoStart)
. (Join-Path $PSScriptRoot 'tools/Common.ps1')

$configPath = Get-SpiceConfig
$configDir = Split-Path -Parent $configPath
$configText = [IO.File]::ReadAllText($configPath)
$statePath = Join-Path $configDir 'liquid-touch-state.json'
$themePath = Join-Path $configDir 'Themes/LiquidTouch'
$extensionPath = Join-Path $configDir 'Extensions/liquid-touch.js'
$stamp = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssffffZ')
$backupDir = Join-Path $configDir "liquid-touch-backups/$stamp"
$null = New-Item -ItemType Directory -Force -Path $backupDir
Copy-Item -LiteralPath $configPath -Destination (Join-Path $backupDir 'config-xpui.ini')
if (Test-Path -LiteralPath $themePath) { Copy-Item -LiteralPath $themePath -Destination (Join-Path $backupDir 'LiquidTouch') -Recurse }
if (Test-Path -LiteralPath $extensionPath) { Copy-Item -LiteralPath $extensionPath -Destination (Join-Path $backupDir 'liquid-touch.js') }

if (Test-Path -LiteralPath $statePath) {
    $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
} else {
    $previous = [ordered]@{}
    foreach ($key in @('current_theme', 'color_scheme', 'inject_css', 'replace_colors')) {
        $previous[$key] = Read-IniValue -Text $configText -Section 'Setting' -Key $key
    }
    $state = [pscustomobject]@{
        version = 1; previous = [pscustomobject]$previous; baseline_backup = $backupDir
        theme_existed = (Test-Path -LiteralPath $themePath)
        extension_existed = (Test-Path -LiteralPath $extensionPath)
        extension_enabled = (@((Read-IniValue $configText 'AdditionalOptions' 'extensions') -split '\|') -contains 'liquid-touch.js')
        autostart_created = $false
    }
}

# Capture this from the original baseline even when updating a 1.0.0 install.
if (-not $state.PSObject.Properties['apis_previous']) {
    $baselineConfig = Join-Path $state.baseline_backup 'config-xpui.ini'
    $baselineText = $configText
    if (Test-Path -LiteralPath $baselineConfig) { $baselineText = [IO.File]::ReadAllText($baselineConfig) }
    $previousAPIs = Read-IniValue $baselineText 'Preprocesses' 'expose_apis'
    $state | Add-Member -NotePropertyName 'apis_previous' -NotePropertyValue $previousAPIs
}

$null = New-Item -ItemType Directory -Force -Path $themePath, (Split-Path -Parent $extensionPath)
Copy-Item -Path (Join-Path $PSScriptRoot 'Themes/LiquidTouch/*') -Destination $themePath -Recurse -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Extensions/liquid-touch.js') -Destination $extensionPath -Force
foreach ($entry in @(@('current_theme', 'LiquidTouch'), @('color_scheme', 'Glass'), @('inject_css', '1'), @('replace_colors', '1'))) {
    $configText = Write-IniValue -Text $configText -Section 'Setting' -Key $entry[0] -Value $entry[1]
}
$extensions = @((Read-IniValue $configText 'AdditionalOptions' 'extensions') -split '\|' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
if ($extensions -notcontains 'liquid-touch.js') { $extensions += 'liquid-touch.js' }
$configText = Write-IniValue $configText 'AdditionalOptions' 'extensions' ($extensions -join '|')
$configText = Write-IniValue $configText 'Preprocesses' 'expose_apis' '1'
Save-Utf8 -Path $statePath -Text ($state | ConvertTo-Json -Depth 5)
Save-Utf8 -Path $configPath -Text $configText

if ($AutoStart) {
    $startup = [Environment]::GetFolderPath('Startup')
    $shortcutPath = Join-Path $startup 'LiquidTouchSpotify.lnk'
    if (-not (Test-Path -LiteralPath $shortcutPath)) {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = (Get-Command spicetify).Source
        $shortcut.Arguments = 'auto'
        $shortcut.WorkingDirectory = $configDir
        $shortcut.WindowStyle = 7
        $shortcut.Save()
        $state.autostart_created = $true
        Save-Utf8 $statePath ($state | ConvertTo-Json -Depth 5)
    }
}

Write-Host "LiquidTouch files installed. Previous configuration saved to $backupDir"
if (-not $NoApply) {
    try {
        $nativeBackup = Join-Path $configDir 'Backup'
        $hasBackup = (Test-Path -LiteralPath $nativeBackup) -and (@(Get-ChildItem -LiteralPath $nativeBackup -File -Recurse).Count -gt 0)
        if ($hasBackup) { Invoke-Spice -Arguments @('restore', 'backup', 'apply') }
        else { Invoke-Spice -Arguments @('backup', 'apply') }
    }
    catch { throw "Files are installed, but Spicetify could not finish applying them. Its original error is above this message. Your config backup is $backupDir. $($_.Exception.Message)" }
}
Write-Host 'Open Spotify. Use the settings button for touch size, glass tint, and the keyboard.'
