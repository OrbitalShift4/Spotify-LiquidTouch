LiquidTouch 1.9.2 — revised 1 November 2026

ORGANIZED SETTINGS
Settings opens to eight categories: Text & accessibility, Appearance & glass, Now Playing, Lyrics, Home & clock, Touch & keyboard, Updates, and History & help. Each category contains only related controls. All existing preferences are retained. Artwork sizing still opens its own category directly.

SETTINGS GESTURES
Swipe from left to right anywhere in Settings, away from input fields and sliders, to go Back. The previous category hub slides in with your finger; release past 80 px to confirm. At the hub, Back closes Settings. Pull the header down, or pull down on content when already at the top, to close the entire menu from any submenu. Release past 72 px to close; shorter, reversed or cancelled pulls return to their starting state. Reduce Motion retains the same thresholds without movement. Native content scrolling, text entry and sliders keep their usual behavior.

SAME-VERSION REBUILD
If the first v1.9.2 is already installed, download and reinstall the revised full package. Existing update checks compare version numbers and will not offer another build with the same number. Older compatible versions can still update normally.

LYRICS OPTIONS
Open the three-dot menu at the top right of the lyrics panel to choose Timing… or Reload lyrics. Timing retains Earlier, Later, Reset, and Match a line. The menu supports touch, keyboard navigation, Escape and outside-tap dismissal.

CLEANER LYRIC VIEW
Removed the Live Lyrics heading and the tap-to-seek instruction. Tapping a synced lyric still seeks to that line. Loading, source and availability status remain visible.

UPDATE FEED
New installations and empty feed settings use the official repository update feed. Existing custom addresses and disabled update checks are preserved.
