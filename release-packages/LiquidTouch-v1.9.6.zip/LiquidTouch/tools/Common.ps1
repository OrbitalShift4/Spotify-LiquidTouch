Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Invoke-Spice {
    param([string[]]$Arguments)
    & spicetify @Arguments
    if ($LASTEXITCODE -ne 0) { throw "spicetify $($Arguments -join ' ') failed (exit $LASTEXITCODE)." }
}

function Get-SpiceConfig {
    $null = Get-Command spicetify -ErrorAction Stop
    $output = @(& spicetify -c)
    if ($LASTEXITCODE -ne 0) { throw 'Could not locate Spicetify configuration. Run spicetify once first.' }
    $configPath = ($output | Select-Object -Last 1).Trim()
    if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
        throw "Spicetify configuration was not found: $configPath. Run spicetify once first."
    }
    return [IO.Path]::GetFullPath($configPath)
}

function Read-IniValue {
    param([string]$Text, [string]$Section, [string]$Key)
    $inside = $false
    foreach ($line in ($Text -split '\r?\n')) {
        if ($line -match '^\s*\[([^\]]+)\]') { $inside = $Matches[1] -ieq $Section }
        elseif ($inside -and $line -match ('^\s*' + [regex]::Escape($Key) + '\s*=(.*)$')) {
            return $Matches[1].Trim()
        }
    }
    return $null
}

function Write-IniValue {
    param([string]$Text, [string]$Section, [string]$Key, [AllowNull()][object]$Value)
    $lines = New-Object 'System.Collections.Generic.List[string]'
    foreach ($line in ($Text -split '\r?\n')) { $lines.Add($line) }
    $start = -1
    $end = $lines.Count
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '^\s*\[([^\]]+)\]') {
            if ($start -ge 0) { $end = $i; break }
            if ($Matches[1] -ieq $Section) { $start = $i }
        }
    }
    if ($start -lt 0) {
        if ($null -eq $Value) { return $Text }
        $lines.Add(''); $lines.Add("[$Section]"); $lines.Add("$Key = $Value")
    } else {
        $found = $false
        for ($i = $start + 1; $i -lt $end; $i++) {
            if ($lines[$i] -match ('^\s*' + [regex]::Escape($Key) + '\s*=')) {
                if ($null -eq $Value) { $lines.RemoveAt($i) }
                else { $lines[$i] = "$Key = $Value" }
                $found = $true; break
            }
        }
        if (-not $found -and $null -ne $Value) { $lines.Insert($end, "$Key = $Value") }
    }
    return ($lines -join "`r`n")
}

function Save-Utf8 {
    param([string]$Path, [string]$Text)
    [IO.File]::WriteAllText($Path, $Text, (New-Object System.Text.UTF8Encoding($false)))
}
