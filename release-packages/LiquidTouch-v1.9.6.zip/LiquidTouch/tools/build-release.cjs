const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const base=path.resolve(__dirname,'..');
function buildRelease(){
 const release=JSON.parse(fs.readFileSync(path.join(base,'updates/release.json'),'utf8'));
 const javascript=fs.readFileSync(path.join(base,'source/liquid-touch-app.js'),'utf8'),css=fs.readFileSync(path.join(base,'Themes/LiquidTouch/runtime.css'),'utf8');
 if(!javascript.includes(`const VERSION = "${release.version}"`))throw Error('Release and source versions disagree');
 const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
 const bundle={schema:1,app:'LiquidTouch',minimumLoader:'1.9.0',...release,javascript,css,integrity:hash(javascript+'\0'+css)};
 const contents=JSON.stringify(bundle,null,2)+'\n',filename=`LiquidTouch-Update-v${release.version}.json`;
 fs.writeFileSync(path.join(base,filename),contents);
 const template=fs.readFileSync(path.join(base,'source/runtime-loader.js'),'utf8');
 fs.writeFileSync(path.join(base,'Extensions/liquid-touch.js'),template.replace('/*__LIQUIDTOUCH_BUNDLE__*/null',JSON.stringify({...bundle,javascript:''}).replaceAll('<','\\u003c')).replace('/*__LIQUIDTOUCH_BOOT__*/null',()=>`function(){\n${javascript}\n}`));
 const manifest={schema:1,app:'LiquidTouch',version:release.version,bundleURL:'./'+filename,sha256:hash(contents),summary:release.summary};
 fs.writeFileSync(path.join(base,'updates/latest.example.json'),JSON.stringify(manifest,null,2)+'\n');
 return {bundle,filename};
}
module.exports={buildRelease};if(require.main===module)console.log('Built '+buildRelease().filename);
