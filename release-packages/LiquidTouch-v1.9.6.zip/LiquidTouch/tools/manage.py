#!/usr/bin/env python3
"""Local Linux/macOS installer. No downloads or third-party Python packages."""
import argparse
import datetime
import json
from pathlib import Path
import re
import shutil
import subprocess


def get_value(text, section, key):
    inside = False
    for line in text.splitlines():
        heading = re.match(r"\s*\[([^]]+)\]", line)
        if heading:
            inside = heading[1].casefold() == section.casefold()
        elif inside:
            match = re.match(r"\s*" + re.escape(key) + r"\s*=(.*)$", line, re.I)
            if match:
                return match[1].strip()
    return None


def set_value(text, section, key, value):
    lines = text.splitlines()
    start, end = None, len(lines)
    for i, line in enumerate(lines):
        heading = re.match(r"\s*\[([^]]+)\]", line)
        if heading:
            if start is not None:
                end = i
                break
            if heading[1].casefold() == section.casefold():
                start = i
    if start is None:
        if value is None:
            return text
        lines.extend(["", f"[{section}]", f"{key} = {value}"])
    else:
        for i in range(start + 1, end):
            if re.match(r"\s*" + re.escape(key) + r"\s*=", lines[i], re.I):
                if value is None:
                    del lines[i]
                else:
                    lines[i] = f"{key} = {value}"
                break
        else:
            if value is not None:
                lines.insert(end, f"{key} = {value}")
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["install", "uninstall"])
    parser.add_argument("source", type=Path)
    parser.add_argument("--no-apply", action="store_true")
    args = parser.parse_args()
    found = subprocess.check_output(["spicetify", "-c"], text=True).strip().splitlines()[-1]
    config = Path(found).expanduser().resolve(strict=True)
    base = config.parent
    text = config.read_text(encoding="utf-8-sig")
    state_path = base / "liquid-touch-state.json"
    theme = base / "Themes" / "LiquidTouch"
    extension = base / "Extensions" / "liquid-touch.js"
    keys = ("current_theme", "color_scheme", "inject_css", "replace_colors")
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")

    if args.action == "install":
        backup = base / "liquid-touch-backups" / stamp
        backup.mkdir(parents=True)
        shutil.copy2(config, backup / "config-xpui.ini")
        if theme.exists():
            shutil.copytree(theme, backup / "LiquidTouch")
        if extension.exists():
            shutil.copy2(extension, backup / "liquid-touch.js")
        if state_path.exists():
            state = json.loads(state_path.read_text())
        else:
            state = dict(version=1, previous={key: get_value(text, "Setting", key) for key in keys},
                         baseline_backup=str(backup), theme_existed=theme.exists(),
                         extension_existed=extension.exists(),
                         extension_enabled="liquid-touch.js" in (get_value(text, "AdditionalOptions", "extensions") or "").split("|"),
                         autostart_created=False)
        if "apis_previous" not in state:
            baseline = Path(state["baseline_backup"]) / "config-xpui.ini"
            original = baseline.read_text(encoding="utf-8-sig") if baseline.exists() else text
            state["apis_previous"] = get_value(original, "Preprocesses", "expose_apis")
        theme.parent.mkdir(parents=True, exist_ok=True)
        extension.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(args.source / "Themes" / "LiquidTouch", theme, dirs_exist_ok=True)
        shutil.copy2(args.source / "Extensions" / "liquid-touch.js", extension)
        for key, value in zip(keys, ("LiquidTouch", "Glass", "1", "1")):
            text = set_value(text, "Setting", key, value)
        extensions = [e.strip() for e in (get_value(text, "AdditionalOptions", "extensions") or "").split("|") if e.strip()]
        if "liquid-touch.js" not in extensions:
            extensions.append("liquid-touch.js")
        text = set_value(text, "AdditionalOptions", "extensions", "|".join(extensions))
        text = set_value(text, "Preprocesses", "expose_apis", "1")
        state_path.write_text(json.dumps(state, indent=2) + "\n")
        config.write_text(text)
        print(f"LiquidTouch installed. Previous configuration: {backup}")
        if not args.no_apply:
            commands = ["restore", "backup", "apply"] if any(p.is_file() for p in (base / "Backup").rglob("*")) else ["backup", "apply"]
            subprocess.run(["spicetify", *commands], check=True)
    else:
        if not state_path.exists():
            raise SystemExit("No installer record found. Follow manual removal in README.md.")
        state = json.loads(state_path.read_text())
        shutil.copy2(config, base / f"liquid-touch-uninstall-{stamp}.ini")
        if get_value(text, "Setting", "current_theme") == "LiquidTouch":
            for key in keys:
                text = set_value(text, "Setting", key, state["previous"][key])
        extensions = [e.strip() for e in (get_value(text, "AdditionalOptions", "extensions") or "").split("|") if e.strip()]
        if not state["extension_enabled"]:
            extensions = [e for e in extensions if e != "liquid-touch.js"]
        text = set_value(text, "AdditionalOptions", "extensions", "|".join(extensions))
        restore_apis = False
        if "apis_previous" in state and get_value(text, "Preprocesses", "expose_apis") == "1":
            restore_apis = state["apis_previous"] != "1"
            text = set_value(text, "Preprocesses", "expose_apis", state["apis_previous"])
        config.write_text(text)
        if theme.exists():
            shutil.rmtree(theme)
        extension.unlink(missing_ok=True)
        backup = Path(state["baseline_backup"])
        if state["theme_existed"]:
            shutil.copytree(backup / "LiquidTouch", theme)
        if state["extension_existed"]:
            shutil.copy2(backup / "liquid-touch.js", extension)
        state_path.unlink()
        if not args.no_apply:
            commands = ["restore", "backup", "apply"] if restore_apis and any(p.is_file() for p in (base / "Backup").rglob("*")) else ["apply"]
            subprocess.run(["spicetify", *commands], check=True)
        print("LiquidTouch removed. Other extensions and newer configuration edits were kept.")


if __name__ == "__main__":
    main()
