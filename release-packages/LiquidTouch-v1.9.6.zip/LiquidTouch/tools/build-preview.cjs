/* Optional developer tool: npm install --no-save sharp; node tools/build-preview.cjs */
const fs = require('node:fs');
const path = require('node:path');
const sharp = require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/sharp' : 'sharp');
const base = path.resolve(__dirname, '..');
const colors = [
  ['#101a3c', '#7b79a9', '#b2cee0', 'AFTERHOURS'],
  ['#092d43', '#417586', '#cae8da', 'BLUE HOUR'],
  ['#292142', '#916c9e', '#f1d0b4', 'IN ORBIT'],
  ['#3a3432', '#c1a37e', '#e6dfb7', 'SOFT SIGNAL'],
  ['#1f1835', '#7d719f', '#ed9cb7', 'NIGHT DRIVE'],
  ['#173c40', '#66948e', '#d2edce', 'SLOW MOTION']
];
async function build() {
  require('./build-release.cjs').buildRelease();
  const gallery=process.argv.includes("--gallery");
  const catalog=gallery ? JSON.parse(fs.readFileSync(path.join(base,"preview/gallery-catalog.json"),"utf8")) : null;
  const covers = [];
  for (let i = 0; !gallery && i < colors.length; i++) {
    const [dark, mid, light, title] = colors[i];
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="500" height="500" viewBox="0 0 500 500"><defs><linearGradient id="bg" x2=".8" y2="1"><stop stop-color="${mid}"/><stop offset="1" stop-color="${dark}"/></linearGradient><linearGradient id="orb" x2=".6" y2="1"><stop stop-color="${light}"/><stop offset=".6" stop-color="${mid}"/><stop offset="1" stop-color="${dark}"/></linearGradient><filter id="blur"><feGaussianBlur stdDeviation="18"/></filter></defs><rect width="500" height="500" fill="url(#bg)"/><ellipse cx="${290-i*12}" cy="200" rx="145" ry="155" fill="${light}" opacity=".15" filter="url(#blur)"/><circle cx="${280-i*8}" cy="215" r="126" fill="url(#orb)"/><path d="M-50 390 Q180 90 560 310L560 560H-50Z" fill="${dark}" opacity=".64"/><path d="M-50 412 Q220 190 560 370" fill="none" stroke="${light}" opacity=".17" stroke-width="1"/><path d="M-50 433 Q220 211 560 391" fill="none" stroke="${light}" opacity=".1" stroke-width="1"/><text x="36" y="445" fill="${light}" font-family="sans-serif" font-size="21" letter-spacing="4">${title}</text><text x="36" y="473" fill="${light}" opacity=".65" font-family="sans-serif" font-size="9" letter-spacing="3">LIQUIDTOUCH / DEMO RECORDINGS</text></svg>`;
    const png = await sharp(Buffer.from(svg)).png().toBuffer();
    covers.push('data:image/png;base64,' + png.toString('base64'));
  }
  if(gallery)for(const track of catalog.tracks)covers.push('data:image/jpeg;base64,'+fs.readFileSync(path.join(base,'preview',track.artwork)).toString('base64'));
  const galleryScript=gallery ? `window.LT_GALLERY=true;window.LT_DEMO_TRACKS=${JSON.stringify(catalog.tracks.map(({name,artist,album,duration,color,art})=>({name,artist,album,duration,color,art})))};try{if(!localStorage.getItem('liquid-touch.preferences.v1'))localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({updateChecks:false,keyboard:false,lyrics:false,lyricsFallback:false,lyricsTextFallback:false,textScale:120,uiScale:110}));}catch{}` : '';
  const css = fs.readFileSync(path.join(base, 'Themes/LiquidTouch/user.css'), 'utf8');
  const fixtureCSS = fs.readFileSync(path.join(base, 'preview/fixture.css'), 'utf8');
  const fixture = fs.readFileSync(path.join(base, 'preview/fixture.js'), 'utf8');
  const extension = fs.readFileSync(path.join(base, 'Extensions/liquid-touch.js'), 'utf8');
  const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="color-scheme" content="dark"><title>LiquidTouch — ${gallery ? "real music gallery demo" : "interactive offline preview"}</title><style id="lt-preview-host-css">${fixtureCSS}</style><style id="lt-installed-theme">${css}</style></head>
<body><div class="Root"><div class="Root__top-container"><div class="Root__globalNav">${gallery ? "Gallery demo · public music metadata · simulated playback" : "Spotify host preview · fictional music · no audio"}</div><aside class="Root__nav-bar"><div id="fixture-library" class="main-yourLibraryX-libraryContainer main-yourLibraryX-libraryRootlist"></div></aside><div class="Root__main-view"><div class="main-view-container"><div class="main-view-container__scroll-node"><main id="fixture-content" class="fixture-content"></main></div></div></div></div><footer class="Root__now-playing-bar"><span>Native Spotify controls</span><button id="fixture-device">Devices / Spotify Connect</button><span>Tap Touch UI to return</span></footer></div><script>window.LT_DEMO_COVERS=${JSON.stringify(covers)};${galleryScript}</script><script>${fixture}</script><script>${extension}</script></body></html>`;
  const output=gallery ? 'LiquidTouch-Gallery.html' : 'LiquidTouch-Preview.html';
  fs.writeFileSync(path.join(base, output), html);
  console.log('Built '+output+' (' + Buffer.byteLength(html) + ' bytes)');
}
build().catch(error => { console.error(error); process.exitCode = 1; });
