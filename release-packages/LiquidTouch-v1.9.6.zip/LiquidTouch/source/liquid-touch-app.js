// LiquidTouch 1.9.6 — MIT. Application source for the bundled runtime.
// Spotify keeps ownership of browsing, audio, authentication, and DRM.
(() => {
  "use strict";

  const VERSION = "1.9.6";
  const BUILD = "2026-11-03-queue";
  const LIVE_REPLACEMENT=Boolean(window.LiquidTouch?.version && window.LiquidTouch.version!==VERSION);
  try { window.LiquidTouch?.destroy?.(); } catch (error) { console.warn("[LiquidTouch] Previous instance cleanup:", error); }
  const STORE = "liquid-touch.preferences.v1";
  const OWN = "#lt-shell, .lt-dialog, #lt-rescue, #lt-toast, #lt-startup-status";
  const CHROME_QUEUE = Symbol.for("LiquidTouch.windowChromeQueue");
  const CHROME_BASE_HEIGHT = Symbol.for("LiquidTouch.nativeChromeHeight");
  function queueChrome(job) {
    const pending = (window[CHROME_QUEUE] || Promise.resolve()).catch(()=>{}).then(job);
    window[CHROME_QUEUE] = pending;
    return pending;
  }
  const DEFAULT_UPDATE_FEED = "https://raw.githubusercontent.com/OrbitalShift4/Spotify-LiquidTouch/main/latest.json";
  const MOTION_CONTROLS = [["pageSpeed", "Pages and tabs", "navigation"], ["navSpeed", "Navigation selection", "navigation"], ["surfaceSpeed", "Menus, sheets and search", "navigation"], ["settingsPageSpeed", "Settings submenus", "navigation"], ["settingsBackSpeed", "Settings swipe Back finish", "navigation"], ["settingsCloseSpeed", "Settings swipe close finish", "navigation"], ["springSpeed", "Cancelled swipe spring-back", "navigation"], ["playerOpenSpeed", "Now Playing expansion", "player"], ["playerCloseSpeed", "Now Playing collapse", "player"], ["trackSwipeSpeed", "Track artwork swipes", "player"], ["trackChangeSpeed", "Track details and cover change", "player"], ["miniPlayerSpeed", "Mini-player return", "player"], ["lyricsShowSpeed", "Lyrics switching on", "lyrics"], ["lyricsHideSpeed", "Lyrics switching off", "lyrics"], ["lyricsLayoutSpeed", "Artwork and controls reflow", "lyrics"], ["lyricLineSpeed", "Active lyric highlight", "lyrics"], ["lyricScrollSpeed", "Lyric auto-scroll", "lyrics"], ["keySpeed", "Keyboard key feedback", "feedback"], ["buttonSpeed", "Button press and hover", "feedback"], ["toggleSpeed", "Switch knob movement", "feedback"], ["windowSpeed", "Window button feedback", "feedback"], ["spinnerSpeed", "Search loading spinner", "feedback"]];
  const GESTURE_CONTROLS = [["backThreshold", "Page / edge Back"], ["settingsBackThreshold", "Settings swipe Back"], ["settingsCloseThreshold", "Settings swipe down to close"], ["sheetCloseThreshold", "History / update sheet dismissal"], ["playerOpenThreshold", "Expand Now Playing"], ["playerCloseThreshold", "Collapse Now Playing"], ["playerTrackThreshold", "Expanded-player track skip"], ["miniTrackThreshold", "Mini-player track skip"], ["quickOpenThreshold", "Open quick search"], ["quickCloseThreshold", "Close quick search"], ["tabThreshold", "Home / Search / Library swipe"]].map(([key,label])=>[key,label,80,20,240]);
  // Stored timing/distance values retain their units for upgrade compatibility.
  // Only the settings UI converts them to percentages of a documented baseline.
  const SETTING_BASES = {cardTapDelay:400,rounding:32,quickSearchBlur:20,...Object.fromEntries(GESTURE_CONTROLS.map(([key,,base])=>[key,base]))};
  const settingPercent = (key,value) => Math.round((SETTING_BASES[key] ? value/SETTING_BASES[key]*100 : value)/5)*5;
  const settingValue = (key,percent) => SETTING_BASES[key] ? percent/100*SETTING_BASES[key] : percent;
  const DEFAULTS = Object.freeze({
    motionSpeed:100,...Object.fromEntries(MOTION_CONTROLS.map(([key])=>[key,100])),...Object.fromEntries(GESTURE_CONTROLS.map(([key,,value])=>[key,value])),
    enabled: true, palette: "glass", size: "comfort", keyboard: true,
    lite: false, lowMemory: false, reduceMotion: false, startPlayer: false, updateChecks: true, updateFeed: DEFAULT_UPDATE_FEED, homeClock: false, clockFormat: '24', historySongLimit: 0, quickSearchBlur: 14, lyricsPolicy: 2, gesturePolicy: 2,
    textScale: 120, uiScale: 100, playerTextScale: 100, playerLyricsScale: 100, playerControlScale: 100, cardTapDelay: 400, keyboardHeight: 145, artworkSize: 135, glassOpacity: 35, headerOpacity: null, navOpacity: null, miniOpacity: null, playerHeaderOpacity: null, lyricsOpacity: null, settingsOpacity: null, historyOpacity: null, adaptive: true, windowControls: true, rounding: 32, welcome: "", welcomeSubtitle: "A little closer to the music.", lyrics: true, lyricsFallback: true, lyricsTextFallback: true
  });
  // A null override follows the universal setting, including future changes.
  const OPACITY_PANELS = [
    ['headerOpacity','--lt-header-opacity','Top toolbar'],
    ['navOpacity','--lt-nav-opacity','Floating navigation'],
    ['miniOpacity','--lt-mini-opacity','Mini player'],
    ['playerHeaderOpacity','--lt-player-header-opacity','Entire Now Playing window'],
    ['lyricsOpacity','--lt-lyrics-opacity','Lyrics panel'],
    ['settingsOpacity','--lt-settings-opacity','Entire Settings window'],
    ['historyOpacity','--lt-history-opacity','Entire history window']
  ];
  const paths = {
    home: '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
    search: '<circle cx="10.5" cy="10.5" r="7"/><path d="m16 16 5 5"/>',
    library: '<path d="M4 4v16M9 4v16m5-16 6 16M3 7h7M3 17h7"/>',
    back: '<path d="m14 5-7 7 7 7"/>',
    down: '<path d="m5 9 7 7 7-7"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    play: '<path d="m8 4 12 8-12 8Z" fill="currentColor" stroke="none"/>',
    pause: '<path d="M6 4h4v16H6zm8 0h4v16h-4z" fill="currentColor" stroke="none"/>',
    next: '<path d="m5 5 11 7-11 7Z" fill="currentColor" stroke="none"/><path d="M19 5v14"/>',
    previous: '<path d="m19 5-11 7 11 7Z" fill="currentColor" stroke="none"/><path d="M5 5v14"/>',
    shuffle: '<path d="M3 6h3c4 0 8 12 12 12h3m-4-4 4 4-4 4M3 18h3c1 0 2-1 3-2M15 8c1-1 2-2 3-2h3m-4-4 4 4-4 4"/>',
    repeat: '<path d="m17 2 4 4-4 4M3 11V8a2 2 0 0 1 2-2h16M7 22l-4-4 4-4m14-3v5a2 2 0 0 1-2 2H3"/>',
    repeatOne: '<path d="m17 2 4 4-4 4M3 11V8a2 2 0 0 1 2-2h16M7 22l-4-4 4-4m14-3v5a2 2 0 0 1-2 2H3m8-8 2-1v6"/>',
    plus: '<circle cx="12" cy="12" r="9"/><path d="M8 12h8m-4-4v8"/>',
    saved: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
    speaker: '<path d="M3 9h4l5-4v14l-5-4H3Zm13-1a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>',
    muted: '<path d="M3 9h4l5-4v14l-5-4H3Zm13 0 6 6m0-6-6 6"/>',
    queue: '<path d="M3 5h18M3 11h18M3 17h10m4-2 5 3-5 3Z"/>',
    devices: '<rect x="2" y="3" width="14" height="12" rx="2"/><path d="M9 15v5H5m4 0h4"/><rect x="17" y="10" width="5" height="11" rx="1"/>',
    settings: '<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="3" fill="currentColor"/><circle cx="16" cy="17" r="3" fill="currentColor"/>',
    keyboard: '<rect x="2" y="5" width="20" height="14" rx="3"/><path d="M6 9h.01M10 9h.01M14 9h.01M18 9h.01M6 13h.01M10 13h.01M14 13h.01M18 13h.01M8 16h8"/>',
    enter: '<path d="M20 5v8H4m5-5-5 5 5 5"/>',
    minimize: '<path d="M5 12h14"/>',
    maximize: '<rect x="5" y="5" width="14" height="14" rx="3"/>',
    restore: '<path d="M9 5V3h12v12h-2"/><rect x="3" y="9" width="12" height="12" rx="2"/>',
    desktop: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M12 17v4m-4 0h8"/>',
    history: '<path d="M3 11a9 9 0 1 1 2.6 7M3 4v7h7m2-5v6l4 2"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z" fill="currentColor" stroke="none"/>',
    spark: '<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5Z"/>',
    art: '<rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 5-5 4 4 4-6 5 7"/>'
  };
  function icon(name) {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.spark}</svg>`;
  }
  function button(action, label, glyph, extra = "") {
    // Arguments are compile-time strings. Spotify data is ONLY written with textContent.
    return `<button type="button" data-action="${action}" aria-label="${label}" ${extra}><span class="lt-icon">${icon(glyph)}</span></button>`;
  }
  function loadPreferences() {
    let stored = {};
    try { stored = JSON.parse(localStorage.getItem(STORE) || "{}"); } catch { /* reset invalid local preferences */ }
    const value = { ...DEFAULTS };
    // Legacy playerFullscreen is intentionally ignored: the player fills the
    // app window and never requests or exits display fullscreen.
    for (const key of ["enabled", "keyboard", "lite", "lowMemory", "reduceMotion", "startPlayer", "updateChecks", "homeClock", "adaptive", "windowControls", "lyrics", "lyricsFallback", "lyricsTextFallback"]) {
      // Before 1.9.6 the player's Lyrics button saved a global On/Off flag.
      // Do not let an old per-player Off disable the new availability policy.
      if (typeof stored?.[key] === "boolean" && (key!=='lyrics' || stored.lyricsPolicy===2)) value[key] = stored[key];
    }
    if (["glass", "ocean", "graphite"].includes(stored?.palette)) value.palette = stored.palette;
    if (["comfort", "large"].includes(stored?.size)) value.size = stored.size;
    if (["12", "24"].includes(stored?.clockFormat)) value.clockFormat = stored.clockFormat;
    if ([0,100,500,1000,5000,10000].includes(stored?.historySongLimit)) value.historySongLimit = stored.historySongLimit;
    for (const [key, lo, hi] of [["textScale",100,200],["uiScale",100,140],["playerTextScale",75,200],["playerLyricsScale",75,200],["playerControlScale",75,180],["cardTapDelay",200,700],["keyboardHeight",100,180],["artworkSize",60,200],["glassOpacity",0,100],["rounding",8,56],["quickSearchBlur",0,40],...OPACITY_PANELS.map(([key])=>[key,0,100]),["motionSpeed",25,400],...MOTION_CONTROLS.map(([key])=>[key,25,400]),...GESTURE_CONTROLS.map(([key,,,lo,hi])=>[key,lo,hi])]) {
      if (typeof stored?.[key] === "number" && Number.isFinite(stored[key])) value[key] = clamp(settingValue(key,settingPercent(key,stored[key])), lo, hi);
    }
    if(stored?.playerLyricsScale===undefined)value.playerLyricsScale=value.playerTextScale;
    if(stored?.gesturePolicy!==2){
      const oldDefaults={settingsCloseThreshold:72,sheetCloseThreshold:72,playerOpenThreshold:72,playerCloseThreshold:72,playerTrackThreshold:40,miniTrackThreshold:76,quickOpenThreshold:64,quickCloseThreshold:64};
      for(const [key,old] of Object.entries(oldDefaults))if(stored?.[key]===old)value[key]=DEFAULTS[key];
    }
    for(const key of ['settingsOpacity','historyOpacity'])if(stored?.[key]===undefined && typeof stored?.sheetOpacity==='number' && Number.isFinite(stored.sheetOpacity))value[key]=clamp(Math.round(stored.sheetOpacity/5)*5,0,100);
    for (const key of ["welcome","welcomeSubtitle"]) if(typeof stored?.[key]==="string")value[key]=stored[key].slice(0,160);
    if(typeof stored?.updateFeed==='string' && stored.updateFeed.trim())value.updateFeed=stored.updateFeed.trim().slice(0,2000);
    return value;
  }
  function read(fn, fallback) { try { const v = fn(); return v ?? fallback; } catch { return fallback; } }
  function number(value, fallback = 0) { return Number.isFinite(Number(value)) ? Number(value) : fallback; }
  function clamp(value, lo, hi) { return Math.min(hi, Math.max(lo, value)); }
  function time(ms) { const s = Math.floor(Math.max(0, number(ms)) / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; }
  function imageURL(value) {
    if (typeof value !== "string") return "";
    // Spotify puts animated playing indicators in the same cards as covers.
    // They are state icons, never entity artwork.
    if (/(?:equalis|equaliz|visualis|visualiz|playing[-_]?indicator|audio[-_]?bars|spinner)(?:[^/]*)(?:\.|\/|\?|$)/i.test(value)) return "";
    if (/^spotify:image:[a-zA-Z0-9]+$/.test(value)) return `https://i.scdn.co/image/${value.split(":")[2]}`;
    if(/^spotify:mosaic:(?:[a-f0-9]{40}:?){2,4}$/i.test(value))return "https://mosaic.scdn.co/640/"+value.slice(15).replaceAll(":","");
    // Raster data URLs also allow the offline preview to use original artwork.
    if (/^data:image\/(?:png|jpeg|webp);base64,[a-zA-Z0-9+/=]+$/.test(value)) return value;
    // Do not permit script, file, or SVG data URLs from track metadata.
    if (/^https?:\/\//i.test(value)) return value;
    return "";
  }
  function windowBar() {
    return `<div class="lt-windowbar" aria-label="Window title bar"><div class="lt-window-drag"><span class="lt-heading-mark">${icon("spark")}</span><span>LiquidTouch</span></div><div class="lt-caption-buttons lt-glass">${button("windowMinimize","Minimize Spotify","minimize")}${button("windowMaximize","Maximize or restore Spotify","maximize")}${button("windowClose","Close Spotify window","close")}</div></div>`;
  }
  function trackFromState(state) {
    if (!state || typeof state !== "object") return null;
    const item = state.item || state.track || state.currentTrack || state.current_track;
    if (!item || typeof item !== "object") return null;
    const value = item.data && (item.data.uri || item.data.name || item.data.metadata) ? item.data : item;
    const m = value.metadata || {};
    return value.uri || value.name || m.title ? value : null;
  }
  function colorRGB(value) {
    if (typeof value !== "string") return null;
    const match = value.trim().match(/^#?([\da-f]{6})$/i);
    if (match) return [0,2,4].map(i=>parseInt(match[1].slice(i,i+2),16));
    const rgb = value.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/i);
    return rgb ? rgb.slice(1).map(n=>clamp(Number(n),0,255)) : null;
  }

  const cleanText = (value, length=500) => typeof value === "string" ? value.trim().slice(0,length) : "";
  function uriInfo(raw) {
    if (typeof raw !== "string") return null;
    if (/^https:\/\/open\.spotify\.com\//.test(raw)) { try { raw=new URL(raw).pathname; } catch { return null; } }
    if (raw === "/collection/tracks" || raw === "spotify:collection:tracks" || /^spotify:user:[^:]+:collection$/.test(raw)) return {uri:raw.startsWith("spotify:user:") ? raw : "spotify:collection:tracks",path:"/collection/tracks",type:"collection"};
    const match=raw.match(/^(?:spotify:(album|playlist|artist|track|episode|show):|\/(album|playlist|artist|track|episode|show)\/)([\w-]+)(?:$|[?#/])/);
    if (!match) return null;
    const type=match[1] || match[2], id=match[3];
    return {uri:`spotify:${type}:${id}`,path:`/${type}/${id}`,type};
  }
  function normalizeEntity(input) {
    if (!input || typeof input !== "object") return null;
    const value=input.item?.data || input.item || input.data || input;
    const info=uriInfo(value.uri || value.link || input.uri || "");
    if (!info) return null;
    const artists=Array.isArray(value.artists) ? value.artists : Array.isArray(value.artists?.items) ? value.artists.items : [];
    const images=value.images?.items || value.images?.sources || value.images || value.album?.images || value.image?.sources || value.coverArt?.sources || [];
    const first=Array.isArray(images) ? images[0] : images;
    const rawImage=value.imageUrl || value.image_url || (typeof value.image === "string" ? value.image : value.image?.uri) || (typeof first==='string' ? first : first?.url || first?.uri) || first?.sources?.[0]?.url || value.metadata?.image_xlarge_url || "";
    return {...info,title:cleanText(value.name || value.profile?.name || value.title || value.metadata?.title) || (info.type === "collection" ? "Liked Songs" : "Your music"),
      subtitle:cleanText(value.subtitle || value.owner?.displayName || value.owner?.name || value.metadata?.artist_name || artists.map(a=>typeof a === "string" ? a : a.name || a.profile?.name).filter(Boolean).join(", ")) || ({playlist:"Playlist",album:"Album",artist:"Artist",track:"Song",episode:"Episode",show:"Podcast",collection:"Playlist"}[info.type]),
      image:imageURL(rawImage) || pickArtwork(value), section:cleanText(value.section,100)};
  }
  function node(tag, className, text) {
    const result=document.createElement(tag); result.className=className;
    if (text !== undefined) result.textContent=String(text);
    return result;
  }

  function pickArtwork(value,depth=0){
    if(!value || depth>5)return '';if(typeof value==='string')return imageURL(value);
    if(Array.isArray(value)){for(const item of value){const result=pickArtwork(item,depth+1);if(result)return result;}return '';}
    for(const key of ['url','imageUrl','image_url','uri','images','image','pictures','picture','coverArt','sources','items','album','albumOfTrack','visuals','avatarImage','playlist','data']){const result=pickArtwork(value[key],depth+1);if(result)return result;}return '';
  }
  class LiquidTouchController {
    constructor(S) {
      this.S = S;
      this.accountNamespace=cleanText(S.Platform?.LocalStorageAPI?.namespace,100) || 'device';
      this.player = S.Player;
      this.history = S.Platform.History;
      this.hadSavedPreferences=Boolean(read(()=>localStorage.getItem(STORE),''));
      this.prefs = loadPreferences();
      this.abort = new AbortController();
      this.timers = new Set();
      this.destroyed = false;
      this.enabled = false;
      this.libraryOpen = false;
      this.editing = new Set();
      this.lastURI = null;
      this.lastImage = null;
      this.pendingColor = 0;
      this.keyboardShift = false;
      this.keyboardSymbols = false;
      this.suppressOpenUntil = 0;
      this.focusBeforeModal = new WeakMap();
      this.eventState = null;
      this.platformState = null;
      this.stateSource = "none";
      this.colorCache = new Map();
      this.chromeMode = "native";
      this.chromeBusy = false;
      this.nativeChromeOwned = false;
      this.chromeAttempts = 0;
      this.entities = new Map(); this.homeEntities = new Map(); this.libraryEntities = new Map();
      this.libraryFilter = "all"; this.libraryQuery = ""; this.libraryOffset = 0; this.libraryHasMore = true;
      this.playHistory = this.loadRecords("play-history",Infinity).map((row,i)=>({...row,id:`legacy:${this.accountNamespace}:${row.at}:${row.uri}:${i}`}));
      this.sessionHistory = new Map();
      this.historyState = 'loading';
      this.historyReady = this.initHistory();
      this.historyWrites = this.historyReady;
      this.recentSearches = this.loadRecords("search-items",50);
      this.recentHome = this.loadRecords("home-recent",12).filter(entry=>['playlist','album','artist','collection'].includes(entry.type));
      this.searchQueries = this.loadRecords("search-queries",30);
      this.historyLimit = 100;
      this.routePath=this.history.location?.pathname || '/';this.viewStack=[];
      this.observedHostPath=this.routePath;this.tabViews=new Map();
      this.catalogVersion=0;this.searchCache=new Map();this.artCache=new Map();this.artJobs=[];this.artBusy=0;
      this.searchFlights=new Map();this.searchResultVersion=0;this.searchResults=[];this.searchFilter='all';
      this.lyricsCache=new Map();this.lyricLines=[];this.lyricIndex=-1;this.liveSearchToken=0;this.lyricsToken=0;
      this.motionAnimations=new Map();this.lyricOffsets=this.loadLyricOffsets();
      this.fastPointerClicks=new Map();
      this.browsePages=new Map();this.routeRequests=new Map();this.navigationSerial=0;
      this.detailPages=new Map();

    }
    later(fn, delay) {
      const id = setTimeout(() => { this.timers.delete(id); if (!this.destroyed) fn(); }, delay);
      this.timers.add(id);
      return id;
    }
    listen(node, type, fn, options = {}) {
      node.addEventListener(type, fn, { ...options, signal: this.abort.signal });
    }
    save() {
      try { localStorage.setItem(STORE, JSON.stringify(this.prefs)); }
      catch { this.notify("This session works, but your preferences could not be saved."); }
    }
    mount() {
      this.shell = document.createElement("div");
      this.shell.id = "lt-shell";
      this.shell.innerHTML = `
        ${windowBar()}
        <header class="lt-header lt-glass" aria-label="LiquidTouch toolbar">
          ${button("goBack", "Go back", "back")}
          <div class="lt-heading" id="lt-heading"><span class="lt-heading-mark">${icon("spark")}</span><span class="lt-heading-text" id="lt-page-title">Home</span></div>
          <form class="lt-search-form lt-glass" id="lt-search-form" role="search" hidden>
            <input id="lt-search-input" type="search" aria-label="Search Spotify" placeholder="Artists, songs, podcasts…" autocomplete="off" spellcheck="false" maxlength="300">
            ${button("keyboard", "Show or hide search keyboard", "keyboard", 'aria-expanded="false" aria-controls="lt-keyboard"')}
            <button type="submit" aria-label="Submit search"><span class="lt-icon">${icon("enter")}</span></button>
          </form>
          ${button("settings", "LiquidTouch settings", "settings")}
        </header>
        <main id="lt-browse" class="lt-browse lt-glass" aria-label="Music browser" hidden></main>
        <button type="button" class="lt-quick-backdrop" data-action="closeQuickSearch" aria-label="Dismiss quick search" tabindex="-1"></button>
        <form id="lt-quick-search" class="lt-quick-search lt-glass" role="search" hidden><span class="lt-icon">${icon("search")}</span><input id="lt-quick-input" type="search" aria-label="Quick search" placeholder="Find a song, artist, or playlist" maxlength="300">${button("closeQuickSearch","Close quick search","close")}</form>
        <section id="lt-search-preview" class="lt-search-preview lt-glass" aria-label="Live search preview" hidden></section>
        <div class="lt-footer">
          <section class="lt-mini lt-glass" aria-label="Now playing mini player">
            <button type="button" id="lt-mini-open" data-action="nowPlaying" aria-label="Open Now Playing">
              <span class="lt-mini-art-stage"><img class="lt-cover-small" id="lt-mini-art" alt="" hidden></span>
              <span class="lt-track-text"><span class="lt-track-title" id="lt-mini-title">Your next good listen</span><span class="lt-track-artist" id="lt-mini-artist">Choose something in Spotify</span></span>
            </button>
            ${button("togglePlay", "Play", "play")}${button("next", "Next track", "next")}
            <div class="lt-mini-progress" aria-hidden="true"><span id="lt-mini-fill"></span></div>
          </section>
          <nav class="lt-nav lt-glass" aria-label="Main navigation">
            <span class="lt-nav-selection" aria-hidden="true"></span>
            <button type="button" data-action="home" aria-label="Home"><span class="lt-icon">${icon("home")}</span><span>Home</span></button>
            <button type="button" data-action="search" aria-label="Search"><span class="lt-icon">${icon("search")}</span><span>Search</span></button>
            <button type="button" data-action="library" aria-label="Your Library"><span class="lt-icon">${icon("library")}</span><span>Your Library</span></button>
          </nav>
        </div>
        <section id="lt-keyboard" class="lt-keyboard lt-glass" aria-label="Search keyboard" hidden>
          <div class="lt-kb-inner"><div class="lt-kb-toolbar"><span>Search keyboard</span>${button("hideKeyboard", "Hide keyboard", "down")}</div><div id="lt-key-rows"></div></div>
        </section>`;
      this.keyPopup=node('output','lt-key-popup');this.keyPopup.hidden=true;this.keyPopup.setAttribute('aria-hidden','true');this.shell.append(this.keyPopup);
      this.nowPlaying = document.createElement("dialog");
      this.nowPlaying.id = "lt-now-playing";
      this.nowPlaying.className = "lt-dialog";
      this.nowPlaying.setAttribute("aria-labelledby", "lt-np-title");
      this.nowPlaying.innerHTML = `
        <div class="lt-player-wallpaper" aria-hidden="true"><img id="lt-player-background" alt=""></div>
        ${windowBar()}
        <header class="lt-np-header lt-glass" id="lt-np-header">
          ${button("closePlayer", "Close Now Playing", "down", "autofocus")}
          <div class="lt-context" aria-hidden="true"></div>
          ${button("playerSettings", "LiquidTouch settings", "settings")}
        </header>
        <div class="lt-np-layout">
          <div class="lt-np-record"><div class="lt-art-area" id="lt-art-swipe"><div class="lt-art-frame"><img id="lt-art" alt="Album artwork" hidden></div></div>
          <div class="lt-np-controls">
            <div class="lt-np-track"><div><h1 id="lt-np-title">Nothing playing yet</h1><p id="lt-np-artist">Pick a song to get started</p></div>${button("toggleHeart", "Save to your library", "plus", 'aria-pressed="false"')}</div>
            <input class="lt-range" id="lt-seek" type="range" min="0" max="1000" value="0" step="1" aria-label="Playback position" disabled>
            <div class="lt-timestamps"><span id="lt-elapsed">0:00</span><span id="lt-duration">0:00</span></div>
            <div class="lt-transport" aria-label="Playback controls">
              ${button("toggleShuffle", "Turn shuffle on", "shuffle", 'aria-pressed="false"')}
              ${button("back", "Previous track", "previous")}
              ${button("togglePlay", "Play", "play", 'class="lt-play-large"')}
              ${button("next", "Next track", "next")}
              ${button("toggleRepeat", "Repeat off", "repeat", 'aria-pressed="false"')}
            </div>
            <div class="lt-volume">${button("toggleMute", "Mute", "speaker", 'aria-pressed="false"')}<input class="lt-range" id="lt-volume" type="range" min="0" max="100" value="50" step="5" aria-label="Volume"><span id="lt-volume-text" aria-hidden="true">50%</span></div>
            <div class="lt-np-bottom">
              <button type="button" data-action="devices" aria-label="Choose playback device"><span class="lt-icon">${icon("devices")}</span><span>Devices</span></button>
              <button type="button" data-action="toggleLyrics" aria-label="Show or hide lyrics"><span class="lt-icon">${icon("queue")}</span><span>Lyrics</span></button><button type="button" data-action="queue" aria-label="Open play queue"><span class="lt-icon">${icon("queue")}</span><span>Queue</span></button>
            </div>
          </div>
          </div>
          <section id="lt-lyrics-panel" class="lt-lyrics-panel lt-glass" aria-label="Live lyrics"><header class="lt-lyrics-heading"><div class="lt-lyrics-tools"><button type="button" data-action="lyricsMenu" aria-label="Lyrics options" aria-haspopup="menu" aria-expanded="false" aria-controls="lt-lyrics-menu"><span aria-hidden="true">⋯</span></button><div id="lt-lyrics-menu" class="lt-glass" role="menu" aria-label="Lyrics options" hidden><button type="button" role="menuitem" data-action="lyricTiming" aria-label="Adjust lyrics timing" aria-expanded="false">Timing…</button><button type="button" role="menuitem" data-action="retryLyrics" aria-label="Retry loading lyrics">Reload lyrics</button></div></div></header><p id="lt-lyrics-status" role="status">Lyrics load when available.</p><section id="lt-lyric-timing" class="lt-lyric-timing lt-glass" aria-label="Lyrics timing for this recording" hidden><p id="lt-timing-note">Saved separately for this recording and lyric source.</p><output id="lt-timing-value" aria-live="polite">Original timing</output><div class="lt-timing-buttons"><button type="button" data-action="lyricsEarlier" aria-label="Show lyrics 0.25 seconds earlier">Earlier</button><button type="button" data-action="lyricsLater" aria-label="Show lyrics 0.25 seconds later">Later</button><button type="button" data-action="lyricsTimingReset">Reset</button><button type="button" data-action="lyricsMatchLine" aria-pressed="false">Match a line</button></div><p id="lt-timing-help">Lyrics late? Tap Earlier. Or choose Match a line, then tap the line you hear.</p></section><div id="lt-lyrics-lines"></div></section>
        </div>`;
      this.settings = document.createElement("dialog");
      this.settings.id = "lt-settings";
      this.settings.className = "lt-dialog lt-glass";
      this.settings.setAttribute("aria-labelledby", "lt-settings-title");
      const toggle = (key, label, help) => `<div class="lt-setting"><div><label id="lt-label-${key}">${label}</label><small>${help}</small></div><button type="button" class="lt-toggle" role="switch" data-pref="${key}" aria-checked="false" aria-labelledby="lt-label-${key}"></button></div>`;
      const scale = (key, label, help, min, max) => `<div class="lt-setting lt-setting-range"><div><label for="lt-${key}">${label}</label><small>${help}</small></div><div class="lt-scale-control"><button type="button" data-adjust="${key}" data-delta="-5" aria-label="Decrease ${label.toLowerCase()} by 5 percent">−</button><input id="lt-${key}" class="lt-range" type="range" min="${settingPercent(key,min)}" max="${settingPercent(key,max)}" step="5" data-pref="${key}" aria-label="${label}"><output id="lt-${key}-value" for="lt-${key}"></output><button type="button" data-adjust="${key}" data-delta="5" aria-label="Increase ${label.toLowerCase()} by 5 percent">+</button></div></div>`;
      const historyControl=()=>`<label class="lt-history-limit">Saved song limit<select data-history-limit aria-label="Saved history song limit">${[0,100,500,1000,5000,10000].map(limit=>`<option value="${limit}"${limit===this.prefs.historySongLimit ? ' selected' : ''}>${limit ? limit.toLocaleString()+' plays' : 'Unlimited'}</option>`).join('')}</select></label>`;
      // Keep related settings together; pages mount once and retain their values.
      const settingsSections = [
        {id:"accessibility",title:"Text & accessibility",subtitle:"Size, spacing and motion",glyph:"settings",content:`
          ${scale("textScale","Text size","Larger type across browsing, the player, and menus.",100,200,10)}
          ${scale("uiScale","Interface size","Roomier buttons, spacing, and text fields.",100,140,10)}
          <div class="lt-setting"><div><label for="lt-size">Touch controls</label><small>Comfort: 48 px. Large: 56 px.</small></div><select id="lt-size" data-pref="size"><option value="comfort">Comfort</option><option value="large">Large</option></select></div>
          ${toggle("reduceMotion", "Reduce motion", "Keep the shine. Skip the movement.")}
        `},
        {id:"appearance",title:"Appearance & glass",subtitle:"Tint, opacity and rounded corners",glyph:"spark",content:`
          <div class="lt-setting"><div><label for="lt-palette">Glass tint</label><small>A little atmosphere, without losing contrast.</small></div><select id="lt-palette" data-pref="palette"><option value="glass">Aurora</option><option value="ocean">Ocean</option><option value="graphite">Graphite</option></select></div>
          ${scale("glassOpacity","Universal glass opacity","0% clears the glass tint; 100% makes it solid. Text and artwork keep their full visibility.",0,100,1)}
          <details class="lt-opacity-options"><summary>Panel opacity overrides</summary><p class="lt-note">Every panel follows Universal by default. Enable Custom for a panel to choose its own 0–100% tint.</p>
            <button type="button" class="lt-pill" data-action="resetOpacity">Use universal for all panels</button>
            ${OPACITY_PANELS.map(([key,,label])=>`<section class="lt-opacity-panel"><div class="lt-opacity-mode"><span>${label}</span><span>Custom</span><button type="button" class="lt-toggle" role="switch" data-opacity-override="${key}" aria-checked="false" aria-label="Custom opacity for ${label.toLowerCase()}"></button></div>${scale(key,label+' opacity','Follow universal, or enable Custom above.',0,100,1)}</section>`).join('')}
          </details>
          ${scale("quickSearchBlur","Quick Search background blur","0% turns blur off; 100% is the normal blur strength.",0,40)}
          ${scale("rounding","Corner rounding","100% is normal rounding. Change in 5% steps.",8,56)}
          ${toggle("adaptive", "Artwork atmosphere", "Match backgrounds and glass to the current track’s artwork.")}
          ${toggle("windowControls", "Glass window buttons", "Matching minimize, maximize, and close controls when supported.")}
          ${toggle("lite", "Lighter glass", "Turn off blur for quieter, cooler mini PCs. Your opacity setting still applies.")}
          ${toggle("lowMemory", "Low-RAM mode", "Smaller batches of cards and songs, less background scanning, no blurred artwork or decorative animations, and fewer cached pages. Show more keeps all music accessible.")}
        `},
        {id:"player",title:"Now Playing",subtitle:"Artwork, text and controls",glyph:"play",content:`
          ${scale("artworkSize","Player artwork size","Shrink or enlarge the cover, with lyrics on or off.",60,200,5)}
          ${scale("playerTextScale","Now Playing text size","Scale song details without changing lyrics or other pages.",75,200,5)}
          ${scale("playerControlScale","Now Playing control size","Scale playback buttons, icons and sliders relative to the app interface. Touch targets stay at least 44 px.",75,180,5)}
          ${toggle("startPlayer", "Open in Now Playing", "Start on the expanded player next time Spotify opens.")}
        `},
        {id:"lyrics",title:"Lyrics",subtitle:"Size, sources and timing",glyph:"queue",content:`
          ${scale("playerLyricsScale","Lyrics text size","Scale lyric lines and their panel text independently of song details.",75,200,5)}
          ${toggle("lyrics", "Auto-show available lyrics", "Start each song with lyrics hidden. Show them only after lyrics load for that song. The player’s Lyrics button can always show or hide this song manually.")}
          ${toggle("lyricsFallback", "Broader lyric lookup", "Try LRCLIB exact lookup and recording-aware search when Spotify has no timed lyrics. No account is sent.")}
          ${toggle("lyricsTextFallback", "Additional text lyrics", "If no lyrics were found, also try lyrics.ovh. Text-only lyrics are readable but cannot seek. Uses track and artist names only.")}
          <div class="lt-setting"><div><label>Current song’s lyric timing</label><small>Correct a recording without changing other songs. Positive adjustment shows lyrics earlier.</small></div><button type="button" class="lt-pill" data-action="openLyricTiming">Adjust</button></div>
        `},
        {id:"home",title:"Home & clock",subtitle:"Greetings and local time",glyph:"home",content:`
          <div class="lt-setting lt-setting-range"><label for="lt-welcome">Home welcome</label><small>Leave blank for a time-of-day greeting, or use {greeting} in custom text. Good morning/afternoon/evening phrases follow the time of day.</small><input id="lt-welcome" class="lt-setting-text" data-text-pref="welcome" type="text" maxlength="160" placeholder="{greeting}, Saif."></div>
          <div class="lt-setting lt-setting-range"><label for="lt-welcomeSubtitle">Welcome subtitle</label><input id="lt-welcomeSubtitle" class="lt-setting-text" data-text-pref="welcomeSubtitle" type="text" maxlength="160"></div>
          ${toggle("homeClock", "Show Home clock", "Display your device’s local time beside the Home greeting.")}
          <div class="lt-setting"><div><label for="lt-clockFormat">Clock format</label><small>Choose 12-hour time with AM/PM or 24-hour time.</small></div><select id="lt-clockFormat" data-pref="clockFormat"><option value="12">12-hour</option><option value="24">24-hour</option></select></div>
        `},
        {id:"touch",title:"Touch & keyboard",subtitle:"Card taps and search keyboard",glyph:"keyboard",content:`
          ${scale("cardTapDelay","Card tap timing","100% is normal timing. Lower percentages play sooner; higher percentages allow more time for a double tap.",200,700)}
          ${toggle("keyboard", "Built-in keyboard", "A local English keyboard for search. Turn off to use your system keyboard, including Arabic.")}
          ${scale("keyboardHeight","Keyboard height","Taller keys without widening the keyboard. Height adapts to leave the search field accessible.",100,180,5)}
        `},
        {id:"animations",title:"Animation speeds",subtitle:"Overall and individual motion",glyph:"spark",content:`
          <p class="lt-note">100% is normal; 200% is twice as fast. Overall multiplies each individual speed. Reduce Motion turns movement off.</p>
          ${scale("motionSpeed","Overall animation speed","Change the speed of every interface animation.",25,400,25)}
          ${[['navigation','Navigation and menus'],['player','Now Playing and artwork'],['lyrics','Lyrics and layout'],['feedback','Buttons, keyboard and loading']].map(([group,label])=>`<details class="lt-motion-options"><summary>${label}</summary>${MOTION_CONTROLS.filter(row=>row[2]===group).map(([key,label])=>scale(key,label+' speed','Relative to the overall animation speed.',25,400,25)).join('')}</details>`).join('')}
          <button type="button" class="lt-pill" data-action="resetMotion">Restore animation speeds</button>
        `},
        {id:"gestures",title:"Swipe thresholds",subtitle:"Distance needed to confirm gestures",glyph:"settings",content:`
          <p class="lt-note">100% is the same normal distance for every gesture. Lower percentages need shorter swipes. Swipe right to go back, down at the top to dismiss a sheet, across the player to change tracks, and across pages to switch tabs. Text fields, sliders and scrolling keep their usual behavior.</p>
          ${GESTURE_CONTROLS.map(([key,label,,lo,hi])=>scale(key,label,'Percentage of the normal swipe distance; release to confirm.',lo,hi)).join('')}
          <button type="button" class="lt-pill" data-action="resetGestures">Restore swipe thresholds</button>
        `},
        {id:"updates",title:"Updates",subtitle:"Check, import and release notes",glyph:"restore",content:`
          <section class="lt-updates-settings"><p class="lt-note">Import one update file here. A trusted hosted release feed also enables Update / Later notifications.</p><label for="lt-update-feed">Release feed URL</label><input id="lt-update-feed" class="lt-setting-text" type="url" maxlength="2000" placeholder="https://your-release-host/latest.json"><p id="lt-update-status" class="lt-note" role="status">No hosted release feed is configured.</p>
          ${toggle("updateChecks","Check for updates","Check the configured feed at launch and about every six hours. Installation always asks first.")}
          <div class="lt-settings-actions"><button type="button" data-action="checkUpdates">Check now</button><button type="button" data-action="importUpdate">Import update file</button><button type="button" data-action="releaseNotes">What’s new</button><button type="button" data-action="restoreRuntime">Restore installed version</button></div><input id="lt-update-file" type="file" accept=".json,.ltupdate" hidden></section>
        `},
        {id:"help",title:"History & help",subtitle:"Listening journal and desktop",glyph:"history",content:`
          ${historyControl()}
          <p class="lt-note">Unlimited keeps every play until you clear it. With a limit, new plays replace the oldest. Choosing a smaller limit removes older saved plays. History and settings stay saved across LiquidTouch updates on this Spotify profile.</p>
          <button type="button" class="lt-pill lt-danger" data-action="clearHistory">Clear listening history…</button>
          <div class="lt-settings-actions"><button type="button" data-action="playHistory"><span class="lt-icon">${icon("history")}</span><span>Listening history</span></button><button type="button" data-action="desktop"><span class="lt-icon">${icon("desktop")}</span><span>Desktop interface</span></button></div>
          <p class="lt-note">Tap a card to play; double tap to open it. Hold a card or the player artwork for more options. Swipe artwork to skip, or swipe the player header down to close it. Devices and Queue open here. Ctrl + Alt + T switches interfaces.</p>
        `},
      ];
      this.settingsSections=new Map(settingsSections.map(section=>[section.id,section]));
      this.settingsScroll=new Map();this.settingsSection=null;
      this.settings.innerHTML = `
        ${windowBar()}
        <header class="lt-sheet-header">${button("settingsBack","Back to settings","back","hidden")}<div><h2 id="lt-settings-title" tabindex="-1">Make it yours.</h2><p id="lt-settings-subtitle">LiquidTouch · ${VERSION}</p></div>${button("closeSettings", "Close settings", "close", "autofocus")}</header>
        <div class="lt-settings-content">
          <nav id="lt-settings-categories" class="lt-settings-home" aria-label="Settings categories">
            ${settingsSections.map(section=>`<button type="button" class="lt-settings-category" data-settings-section="${section.id}" aria-controls="lt-settings-${section.id}"><span class="lt-icon">${icon(section.glyph)}</span><span class="lt-settings-category-copy"><strong>${section.title}</strong><span>${section.subtitle}</span></span><span class="lt-settings-chevron" aria-hidden="true">›</span></button>`).join('')}
          </nav>
          ${settingsSections.map(section=>`<section id="lt-settings-${section.id}" class="lt-settings-page" data-settings-page="${section.id}" aria-label="${section.title}" hidden>${section.content}</section>`).join('')}
        </div>`;
      this.historyPage=document.createElement("dialog");
      this.historyPage.id="lt-history"; this.historyPage.className="lt-dialog lt-glass";
      this.historyPage.setAttribute("aria-labelledby","lt-history-title");
      this.historyPage.innerHTML=`<header class="lt-np-header">${button("closeHistory","Close listening history","close")}<div class="lt-context"><h2 id="lt-history-title">Listening history</h2><p class="lt-history-caption">Your music, remembered.</p></div></header><div class="lt-history-tools"><label class="lt-field lt-glass"><span class="lt-icon">${icon("search")}</span><input id="lt-history-search" type="search" placeholder="Search songs, artists, albums, or dates" aria-label="Search listening history" maxlength="300"></label><div class="lt-history-actions">${historyControl()}<button type="button" class="lt-pill lt-danger" data-action="clearHistory">Clear history…</button></div><p id="lt-history-count" role="status"></p><p id="lt-history-status" class="lt-note" role="status"></p><p class="lt-history-note">Saved on this device · Local time</p></div><div id="lt-history-list" class="lt-history-list"></div>`;
      this.utility=document.createElement('dialog');this.utility.id='lt-utility';this.utility.className='lt-dialog lt-glass';this.utility.setAttribute('aria-labelledby','lt-utility-title');
      this.utility.innerHTML=`<div class="lt-utility-stage"><header class="lt-sheet-header">${button('utilityBack','Back','back','hidden')}<div><h2 id="lt-utility-title" tabindex="-1"></h2><p id="lt-utility-subtitle"></p></div>${button('closeUtility','Close menu','close')}</header><div class="lt-utility-content"><p id="lt-utility-status" role="status"></p><div id="lt-utility-body"></div></div></div>`;
      this.utilityStack=[];this.utilityToken=0;
      this.releaseDialog=document.createElement('dialog');this.releaseDialog.id='lt-release';this.releaseDialog.className='lt-dialog lt-glass';this.releaseDialog.setAttribute('aria-labelledby','lt-release-title');
      this.releaseDialog.innerHTML=`${windowBar()}<header class="lt-sheet-header"><div><h2 id="lt-release-title"></h2><p id="lt-release-subtitle"></p></div>${button('closeRelease','Close update window','close')}</header><div class="lt-release-content"><ul id="lt-release-summary"></ul><pre id="lt-full-release-notes" hidden></pre><p id="lt-release-status" role="status"></p><a href="#lt-full-release-notes" data-action="fullReleaseNotes">Full patch notes</a></div><footer class="lt-release-actions"><button type="button" data-action="confirmUpdate" class="lt-pill">Update</button><button type="button" data-action="closeRelease" class="lt-pill">Later</button></footer>`;
      this.atmosphere=node("div","lt-atmosphere"); this.atmosphere.id="lt-atmosphere";
      this.atmosphere.setAttribute("aria-hidden","true");
      this.ambientArt=node("img",""); this.ambientArt.alt=""; this.ambientArt.hidden=true;
      this.atmosphere.append(this.ambientArt);
      this.rescue = document.createElement("button");
      this.rescue.id = "lt-rescue";
      this.rescue.type = "button";
      this.rescue.setAttribute("aria-label", "Return to LiquidTouch interface");
      this.rescue.innerHTML = `${icon("spark")}<span>Touch UI</span>`;
      this.rescue.hidden = true;
      this.toast = document.createElement("div");
      this.toast.id = "lt-toast";
      this.toast.setAttribute("role", "status");
      this.toast.setAttribute("aria-live", "polite");
      this.toast.hidden = true;
      document.body.append(this.atmosphere, this.shell, this.nowPlaying, this.settings, this.historyPage, this.releaseDialog, this.utility, this.rescue, this.toast);
      this.$ = id => document.getElementById(id);
      // Keep the popup outside the lyric scroller so it cannot be clipped.
      this.nowPlaying.append(this.$("lt-lyrics-menu"));
      this.searchInput = this.$("lt-search-input");
      this.seek = this.$("lt-seek");
      this.volume = this.$("lt-volume");
      this.browse = this.$("lt-browse");
      this.refreshNative();
      this.applyPreferences();
      this.buildKeyboard();
      this.$('lt-art').closest('.lt-art-frame').tabIndex=0;this.$('lt-art').closest('.lt-art-frame').setAttribute('aria-label','Current artwork; hold or use the context-menu key for options');
      this.bind();
      this.enable(this.prefs.enabled, false);
      this.routeChanged();
      this.render();
      void this.syncWindowChrome();
      this.bindReleaseFeatures();
      this.later(()=>void this.loadLibrary(true),120);
      this.later(()=>this.queueReleaseNotes(),1000);this.later(()=>this.maybeCheckUpdates(),1800);
      if (this.prefs.startPlayer && this.enabled) void this.showPlayer();
      this.syncLyricClock();
      this.startRenderClock();
      if (this.S.Menu?.Item) {
        // Profile-menu APIs vary independently of playback. This convenience
        // entry must never prevent the entire touch interface from starting.
        try {
          this.menu = new this.S.Menu.Item("LiquidTouch settings", false, () => {
            this.enable(true); this.openDialog(this.settings);
          });
          this.menu.register();
        } catch (error) { console.warn("[LiquidTouch] Optional profile menu unavailable:", error); }
      }
    }
    startRenderClock(){
      clearInterval(this.interval);
      this.interval = setInterval(() => {
        if (this.enabled && !document.hidden) {
          if (this.observedHostPath !== this.history.location?.pathname)this.acceptHostRoute(this.history.location?.pathname || '/');
          this.render();
          if(Date.now()-(this.lastGreetingCheck || 0)>30000)this.refreshGreeting();
          if(this.prefs.homeClock)this.refreshHomeClock();
          if(!this.prefs.lowMemory || Date.now()-(this.lastPlatformCheck || 0)>4000){this.lastPlatformCheck=Date.now();this.refreshPlatformState();}
          if(this.utility.open && this.utilityState?.kind==='devices' && !this.utilityBusy && !this.deviceReadBusy && !this.pointerHeld && Date.now()-(this.lastDeviceRefresh || 0)>5000)void this.refreshDeviceList(this.utilityToken);
          if (++this.chromeAttempts % 4 === 0){void this.syncWindowChrome();this.flushReleasePrompt();this.maybeCheckUpdates();}
        }
      }, this.prefs.lowMemory ? 1000 : 500);
    }
    getRoutePath(){return this.routePath || this.history.location?.pathname || '/';}
    motionAllowed(){return !this.prefs.reduceMotion && !matchMedia('(prefers-reduced-motion: reduce)').matches;}
    stopMotion(){
      this.clearGestureMotion(false);this.clearTrackPeek(false);this.clearKeyFeedback();cancelAnimationFrame(this.lyricScrollFrame);
      this.cancelPlayerPresentation();if(this.nowPlaying?.open){this.setPlayerReveal(1);this.playerPhase='open';}
      for(const animation of this.motionAnimations.values())animation.cancel();this.motionAnimations.clear();this.lyricExitGhost?.remove();this.lyricExitGhost=null;
    }
    motionDuration(duration,key='surfaceSpeed'){
      return duration*100/this.prefs.motionSpeed*100/(this.prefs[key] || 100);
    }
    applyMotionPreferences(){
      for(const [property,base,key] of [['--lt-button-time',80,'buttonSpeed'],['--lt-toggle-time',160,'toggleSpeed'],['--lt-lyric-time',100,'lyricLineSpeed'],['--lt-spinner-time',800,'spinnerSpeed']])document.body.style.setProperty(property,this.motionDuration(base,key)+'ms');
      for(const key of ['motionSpeed',...MOTION_CONTROLS.map(([key])=>key),...GESTURE_CONTROLS.map(([key])=>key)]){
        const input=this.$('lt-'+key),value=settingPercent(key,this.prefs[key]);input.value=String(value);this.$('lt-'+key+'-value').textContent=value+'%';input.setAttribute('aria-valuetext',value+' percent');this.paintRange(input);
      }
    }
    playMotion(target,frames,options={}){
      if(!target || !target.isConnected || this.prefs.lowMemory || !this.motionAllowed() || !target.animate)return null;
      this.motionAnimations.get(target)?.cancel();
      const {motion='surfaceSpeed',...timing}=options;
      const animation=target.animate(frames,{easing:'cubic-bezier(.18,.8,.25,1)',fill:'none',...timing,duration:this.motionDuration(timing.duration ?? 140,motion)});
      this.motionAnimations.set(target,animation);
      const clean=()=>{if(this.motionAnimations.get(target)===animation)this.motionAnimations.delete(target);};
      animation.finished.then(clean,clean);return animation;
    }
    animateSurface(element,opening=true,motion='surfaceSpeed'){
      if(element===this.utility && this.utilityState?.kind==='context')return this.playMotion(element.querySelector('.lt-utility-stage'),[{opacity:0,transform:'translateY(12px) scale(.92)'},{opacity:1,transform:'none'}],{motion,duration:200});
      // Modal roots and caption controls stay stationary and fully opaque.
      const target=element===this.settings ? element.querySelector('.lt-settings-content') : element===this.nowPlaying ? element.querySelector('.lt-np-layout') : element===this.historyPage ? element.querySelector('.lt-history-list') : element===this.releaseDialog ? element.querySelector('.lt-release-content') : element===this.utility ? element.querySelector('.lt-utility-stage') : element;
      return this.playMotion(target,opening ? [{opacity:.65,transform:'translateY(9px)'},{opacity:1,transform:'none'}] : [{opacity:1,transform:'none'},{opacity:.65,transform:'translateY(9px)'}],{motion,duration:opening ? 120 : 100});
    }
    cancelPlayerPresentation(){this.playerMotionToken=(this.playerMotionToken || 0)+1;cancelAnimationFrame(this.playerMotionFrame);this.playerMotionFrame=0;}
    setPlayerReveal(value){
      const progress=clamp(value,0,1);this.playerReveal=progress;const offset=(1-progress)*innerHeight;
      this.nowPlaying.style.clipPath=progress>=.9999 ? '' : `inset(${offset}px 0 0 0)`;
      for(const target of [this.nowPlaying.querySelector('.lt-np-layout'),this.$('lt-np-header'),this.nowPlaying.querySelector('.lt-player-wallpaper')]){
        this.motionAnimations.get(target)?.cancel();target.style.transform=progress>=.9999 ? '' : `translate3d(0,${offset}px,0)`;
      }
    }
    animatePlayerReveal(target,duration=300,close=false,motion=close ? 'playerCloseSpeed' : 'playerOpenSpeed'){
      duration=this.motionDuration(duration,motion);if(this.prefs.lowMemory)duration=Math.min(duration,100);
      this.cancelPlayerPresentation();const token=this.playerMotionToken,start=this.playerReveal ?? 1,began=performance.now();this.playerPhase=target ? 'opening' : 'closing';
      const finish=()=>{if(token!==this.playerMotionToken || this.destroyed)return;this.playerMotionFrame=0;this.setPlayerReveal(target);this.playerPhase=target ? 'open' : 'closed';if(close)this.closeDialog(this.nowPlaying);};
      if(!this.motionAllowed() || Math.abs(target-start)<.001){finish();return;}
      const frame=now=>{if(token!==this.playerMotionToken || this.destroyed)return;const t=clamp((now-began)/duration,0,1);this.setPlayerReveal(start+(target-start)*(1-Math.pow(1-t,3)));if(t<1)this.playerMotionFrame=requestAnimationFrame(frame);else finish();};
      this.playerMotionFrame=requestAnimationFrame(frame);
    }
    preparePlayer(start=0){
      if(this.nowPlaying.open)return;
      this.playerReturn=this.snapshotView();this.hideSearchPreview();this.showQuickSearch(false);this.showKeyboard(false);this.setPlayerReveal(start);
      this.openDialog(this.nowPlaying);this.applyLyricsLayout();this.warmAdjacentArtwork();
    }
    requestPlayerClose(){if(!this.nowPlaying.open)return;this.activeGesture=null;this.animatePlayerReveal(0,280,true);}
    cancelPlayerGesture(g,animate=true){
      if(g?.playerPreview){if(animate)this.animatePlayerReveal(0,200,true,'springSpeed');else this.closeDialog(this.nowPlaying);}
      else if(g?.player && g.intent?.kind==='playerClose'){if(animate)this.animatePlayerReveal(1,220,false,'springSpeed');else{this.cancelPlayerPresentation();this.setPlayerReveal(1);this.playerPhase='open';}}
    }
    pageSurface(){return this.browse && !this.browse.hidden ? this.browse : this.main;}
    animatePageChange(direction=0,distance,duration=140){
      if(this.pageTransitionCommitting)return;
      const target=this.pageSurface();if(!target || this.nowPlaying?.open)return;
      const start=distance ?? (direction ? clamp(innerWidth*.09,32,88) : 9);
      this.playMotion(target,[{opacity:.72,transform:direction ? `translateX(${direction*start}px)` : `translateY(${start}px)`},{opacity:1,transform:'none'}],{motion:'pageSpeed',duration});
    }
    animateNavigation(previous){
      this.syncNavigation(true);
      const nav=this.shell.querySelector('.lt-nav'),next=nav.querySelector('[aria-current="page"]');if(!next || next===previous)return;
      this.playMotion(next.querySelector('.lt-icon'),[{transform:'translateY(3px) scale(.92)'},{transform:'none'}],{motion:'navSpeed',duration:140});
    }
    placeNavigation(index,animate=false,metrics){
      const nav=this.shell.querySelector('.lt-nav'),pill=nav.querySelector('.lt-nav-selection'),buttons=[...nav.querySelectorAll('button')];if(!pill || !buttons.length)return;
      const m=metrics || {left:buttons[0].offsetLeft,width:buttons[0].offsetWidth,step:buttons[1].offsetLeft-buttons[0].offsetLeft};
      const before=pill.style.transform || 'translateX(0px)',after=`translateX(${index*m.step}px)`;
      pill.style.left=m.left+'px';pill.style.width=m.width+'px';pill.style.transform=after;this.navVisualIndex=index;
      buttons.forEach((button,i)=>button.style.setProperty('--lt-nav-weight',String(Math.max(0,1-Math.abs(index-i)))));
      if(animate && before!==after)this.playMotion(pill,[{transform:before},{transform:after}],{motion:'navSpeed',duration:120});
    }
    syncNavigation(animate=false,force=false){
      if(!this.shell || !force && this.activeGesture?.intent?.kind==='tab')return;
      this.placeNavigation(Math.max(0,['home','search','library'].indexOf(document.body.dataset.ltPage)),animate);
    }
    adjacentTrack(method){
      const state=this.getPlayerState(),queue=read(()=>this.S.Queue,null),current=queue?.track?.uri || queue?.track?.contextTrack?.uri;
      const valid=queue && (!current || current===this.lastURI),rows=method==='next' ? valid && queue.nextTracks || state?.nextItems || state?.next_tracks || [] : valid && queue.prevTracks || state?.prevItems || state?.prev_tracks || [];
      const raw=method==='next' ? rows[0] : rows.at?.(-1),value=raw?.contextTrack || raw?.track || raw?.item?.data || raw?.item || raw?.data || raw;
      const info=uriInfo(typeof value==='string' ? value : value?.uri);if(!info || !['track','episode'].includes(info.type))return null;
      const image=imageURL(value?.metadata?.image_xlarge_url || value?.metadata?.image_large_url || value?.metadata?.image_url) || pickArtwork(value) || this.artCache.get(info.uri)?.image || '';
      return {...info,image,lyricMeta:this.queuedLyricInfo(value)};
    }
    warmAdjacentArtwork(){
      if(this.prefs.lowMemory)return;
      this.warmedArtwork ||= new Set();
      for(const method of ['next','back']){const entry=this.adjacentTrack(method);if(!entry)continue;if(!entry.image){this.queueArtwork(entry.uri);continue;}
        if(!this.warmedArtwork.has(entry.image)){this.warmedArtwork.add(entry.image);if(this.warmedArtwork.size>32)this.warmedArtwork.delete(this.warmedArtwork.values().next().value);const image=new Image();image.src=entry.image;image.decode?.().catch(()=>{});}
      }
    }
    drawTrackPeek(g,intent,dx){
      let peek=this.trackPeek;
      if(peek && (peek.g!==g || peek.method!==intent.method)){this.clearTrackPeek(false);peek=null;}
      if(!peek){
        const entry=this.adjacentTrack(intent.method);if(!entry)return false;
        const main=g.mini ? this.$('lt-mini-art') : this.$('lt-art'),stage=main.parentElement,width=stage.getBoundingClientRect().width;if(!width || main.hidden)return false;
        const incoming=node('img','lt-track-incoming');incoming.alt='';incoming.setAttribute('aria-hidden','true');incoming.dataset.uri=entry.uri;incoming.hidden=!entry.image;
        incoming.onerror=()=>{incoming.hidden=true;};
        if(entry.image)incoming.src=entry.image;else this.queueArtwork(entry.uri);stage.append(incoming);
        peek={g,method:intent.method,uri:entry.uri,main,incoming,width,dx:0};this.trackPeek=peek;
      }
      peek.dx=clamp(dx,-peek.width,peek.width);const offset=peek.method==='next' ? peek.width : -peek.width;
      peek.main.style.transform=`translate3d(${peek.dx}px,0,0)`;peek.main.style.willChange='transform';
      peek.incoming.style.transform=`translate3d(${peek.dx+offset}px,0,0)`;return true;
    }
    clearTrackPeek(animate=false){
      const peek=this.trackPeek || this.trackTransition;if(!peek)return;
      this.trackPeek=null;this.trackTransition=null;peek.cancelled=true;peek.main.style.removeProperty('will-change');peek.main.style.removeProperty('visibility');peek.outgoing?.remove();
      const from=peek.main.style.transform || 'none';peek.main.style.removeProperty('transform');
      if(animate){this.playMotion(peek.main,[{transform:from},{transform:'none'}],{motion:'trackSwipeSpeed',duration:130});const fromIncoming=peek.incoming.style.transform;peek.incoming.style.transform=`translateX(${peek.method==='next' ? peek.width : -peek.width}px)`;const a=this.playMotion(peek.incoming,[{transform:fromIncoming},{transform:peek.incoming.style.transform}],{motion:'trackSwipeSpeed',duration:130});if(a){a.finished.then(()=>peek.incoming.remove(),()=>peek.incoming.remove());return;}}
      this.motionAnimations.get(peek.incoming)?.cancel();peek.incoming.remove();
    }
    commitTrackPeek(peek){
      if(!peek)return;this.trackPeek=null;this.trackTransition=peek;
      const outgoing=peek.main.cloneNode(false);outgoing.removeAttribute('id');outgoing.className='lt-track-outgoing';outgoing.hidden=false;outgoing.style.transform=`translateX(${peek.dx}px)`;peek.main.parentElement.append(outgoing);peek.outgoing=outgoing;peek.main.style.visibility='hidden';
      const exit=`translateX(${peek.method==='next' ? -peek.width : peek.width}px)`;this.playMotion(outgoing,[{transform:outgoing.style.transform},{transform:exit}],{motion:'trackSwipeSpeed',duration:140});outgoing.style.transform=exit;
      const start=peek.incoming.style.transform;peek.incoming.style.transform='translateX(0px)';peek.main.style.removeProperty('transform');peek.main.style.removeProperty('will-change');
      const a=this.playMotion(peek.incoming,[{transform:start},{transform:'translateX(0px)'}],{motion:'trackSwipeSpeed',duration:140});
      const done=()=>{peek.settled=true;if(peek.confirmed && this.trackTransition===peek)this.clearTrackPeek(false);};if(a)a.finished.then(done,done);else done();
      this.later(()=>{if(this.trackTransition===peek)this.clearTrackPeek(true);},Math.max(1500,this.motionDuration(140,'trackSwipeSpeed')+500));
    }
    confirmTrackPeek(uri){
      const peek=this.trackTransition;if(!peek)return;
      if(uri===peek.uri){peek.confirmed=true;if(peek.settled)this.clearTrackPeek(false);}
      else if(uri!==this.lastURI)this.clearTrackPeek(false);
    }
    animateTrackChange(){
      if(this.prefs.lowMemory)return;
      const direction=this.nextTrackMotion || 0;this.nextTrackMotion=0;
      for(const target of [!this.trackTransition && this.$('lt-art-swipe').querySelector('.lt-art-frame'),!this.trackTransition && this.$('lt-mini-art'),this.nowPlaying.querySelector('.lt-np-track'),this.shell.querySelector('.lt-track-text')]){
        if(target && target.getBoundingClientRect().width)this.playMotion(target,[{opacity:.35,transform:`translateX(${direction*18}px) scale(.985)`},{opacity:1,transform:'none'}],{motion:'trackChangeSpeed',duration:130});
      }
    }
    lyricLayoutRects(){
      const result=new Map();for(const target of [this.$('lt-art-swipe').querySelector('.lt-art-frame'),this.nowPlaying.querySelector('.lt-np-controls')])if(target?.getBoundingClientRect().width)result.set(target,target.getBoundingClientRect());return result;
    }
    makeLyricExitGhost(){
      this.lyricExitGhost?.remove();this.lyricExitGhost=null;
      const panel=this.$('lt-lyrics-panel');if(!this.motionAllowed() || !this.nowPlaying.open || panel.hidden)return;
      const rect=panel.getBoundingClientRect(),base=this.nowPlaying.getBoundingClientRect();
      if(!rect.width || rect.bottom<0 || rect.top>innerHeight)return;
      const ghost=panel.cloneNode(true);ghost.classList.add('lt-lyrics-exit-ghost');ghost.setAttribute('aria-hidden','true');ghost.inert=true;
      const lines=ghost.querySelector('#lt-lyrics-lines');if(lines)lines.classList.add('lt-motion-lyric-lines');
      const status=ghost.querySelector('#lt-lyrics-status');if(status)status.classList.add('lt-motion-lyric-status');
      for(const n of [ghost,...ghost.querySelectorAll('*')]){n.removeAttribute('id');n.removeAttribute('data-action');n.removeAttribute('data-lyric-index');n.removeAttribute('aria-labelledby');}
      ghost.style.cssText=`left:${rect.left-base.left}px;top:${rect.top-base.top+this.nowPlaying.scrollTop}px;width:${rect.width}px;`;
      ghost.style.setProperty('height',rect.height+'px','important');this.nowPlaying.append(ghost);if(lines)lines.scrollTop=this.$('lt-lyrics-lines').scrollTop;
      this.lyricExitGhost=ghost;
      const animation=this.playMotion(ghost,[{opacity:1,transform:'none'},{opacity:0,transform:'translateX(25px) scale(.985)'}],{motion:'lyricsHideSpeed',duration:130});
      const remove=()=>{ghost.remove();if(this.lyricExitGhost===ghost)this.lyricExitGhost=null;};if(animation)animation.finished.then(remove,remove);else remove();
    }
    animateLyricLayout(previous,enabled){
      if(!this.nowPlaying.open || !this.motionAllowed())return;
      for(const [target,old] of previous){
        const rect=target.getBoundingClientRect();if(!rect.width || !old.width)continue;
        const scale=target.classList.contains('lt-art-frame') ? ` scale(${old.width/rect.width},${old.height/rect.height})` : '';
        this.playMotion(target,[{transformOrigin:'0 0',transform:`translate(${old.x-rect.x}px,${old.y-rect.y}px)${scale}`},{transformOrigin:'0 0',transform:'none'}],{motion:'lyricsLayoutSpeed',duration:160});
      }
      if(enabled)this.playMotion(this.$('lt-lyrics-panel'),[{opacity:0,transform:'translateX(24px)'},{opacity:1,transform:'none'}],{motion:'lyricsShowSpeed',duration:150});
    }
    clearGestureMotion(animate=false,keepNavigation=false,keepTrack=false){
      if(!this.pageTransitionCommitting)this.finishPageTransition();
      this.sheetTransitionToken=(this.sheetTransitionToken || 0)+1;
      if(this.utilityBackPreview){this.motionAnimations.get(this.utilityBackPreview)?.cancel();this.utilityBackPreview.remove();this.utilityBackPreview=null;}
      if(this.quickGesturePreview){this.quickGesturePreview.remove();this.quickGesturePreview=null;}
      this.clearPagePreview(animate);
      if(this.gestureSheet){const sheet=this.gestureSheet,clip=sheet.style.clipPath;sheet.style.removeProperty('clip-path');sheet.style.removeProperty('--lt-backdrop-fade');delete sheet.dataset.ltSheetDrag;if(animate && clip)this.playMotion(sheet,[{clipPath:clip},{clipPath:'inset(0px round var(--lt-radius))'}],{motion:'springSpeed',duration:150});this.gestureSheet=null;}
      cancelAnimationFrame(this.gestureFrame);this.gestureFrame=0;
      const targets=this.gestureTargets || [];this.gestureTargets=[];
      for(const target of targets){
        if(!target.isConnected)continue;
        const transform=target.style.transform,opacity=target.style.opacity;this.motionAnimations.get(target)?.cancel();target.style.removeProperty('transform');target.style.removeProperty('opacity');target.style.removeProperty('will-change');
        if(animate)this.playMotion(target,[{transform:transform || 'none',opacity:opacity || '1'},{transform:'none',opacity:1}],{motion:'springSpeed',duration:150,easing:'cubic-bezier(.2,.9,.3,1.12)'});
      }
      this.clearSettingsBackPreview();
      delete document.body.dataset.ltGesture;
      if(!keepTrack)this.clearTrackPeek(animate);
      if(!keepNavigation)this.syncNavigation(animate,true);
    }
    inertPreview(element){
      element.inert=true;element.setAttribute('aria-hidden','true');
      for(const item of [element,...element.querySelectorAll('*')]){item.removeAttribute('id');item.removeAttribute('autofocus');item.removeAttribute('aria-live');if(item.matches('input,textarea,select,button'))item.tabIndex=-1;}
      return element;
    }
    previewView(view){
      const saved={};for(const key of ['browse','browseSignature','browseKind','browseDetailPath','browsePages','libraryOpen','routePath','previewMode','pointerHeld','imageObserver','browseBuildCount','browseReuseCount','searchResults','searchResultBusy','searchError'])saved[key]=this[key];
      const custom=document.body.dataset.ltCustomPage,preview=node('div','lt-browse lt-glass lt-page-preview');
      try{
        Object.assign(this,{browse:preview,browseSignature:null,browseKind:null,browseDetailPath:null,browsePages:new Map(),libraryOpen:view.library,routePath:view.path,previewMode:true,pointerHeld:false,imageObserver:null});
        if(view.path.startsWith('/search/')){const cached=this.searchCache.get(this.queryFromPath(view.path).toLocaleLowerCase()+'|0');this.searchResults=cached?.entries || [];this.searchResultBusy=!cached;this.searchError='';}
        this.renderBrowse();preview.hidden=false;
      }finally{Object.assign(this,saved);document.body.dataset.ltCustomPage=custom;}
      preview.scrollTop=view.scroll || 0;return this.inertPreview(preview);
    }
    gestureDestination(intent){
      if(intent.kind==='tab'){const old=this.tabViews.get(intent.tab);return old || {path:intent.tab==='search' ? '/search' : '/',library:intent.tab==='library',scroll:0};}
      if(intent.kind==='back'){const current=this.viewKey(this.snapshotView());return [...this.viewStack].reverse().find(view=>this.viewKey(view)!==current) || (this.getRoutePath()!=='/' ? {path:'/',library:false,scroll:0} : null);}
      return null;
    }
    drawPagePreview(g,intent,dx){
      const view=this.gestureDestination(intent);if(!view)return false;
      const key=this.viewKey(view),surface=this.pageSurface(),r=surface.getBoundingClientRect(),direction=dx<0 ? 1 : -1;
      if(this.pagePreview?.key!==key){
        this.clearPagePreview(false);const element=this.previewView(view);
        Object.assign(element.style,{position:'fixed',inset:'auto',left:r.left+'px',top:r.top+'px',width:r.width+'px',height:r.height+'px',bottom:'auto',margin:'0'});
        element.dataset.previewView=key;this.shell.append(element);element.scrollTop=view.scroll || 0;
        this.pagePreview={element,surface,width:r.width,key,view,direction};
      }
      const p=this.pagePreview,move=clamp(dx,-p.width,p.width);p.direction=direction;p.dx=move;
      this.motionAnimations.get(surface)?.cancel();surface.style.transform=`translateX(${move}px)`;surface.style.willChange='transform';surface.style.opacity='1';
      p.element.style.transform=`translateX(${direction*p.width+move}px)`;this.gestureTargets=[surface];
      if(intent.kind==='tab'){const start=['home','search','library'].indexOf(document.body.dataset.ltPage),end=['home','search','library'].indexOf(intent.tab);this.placeNavigation(start+(end-start)*clamp(Math.abs(dx)/p.width,0,1),false,g.navMetrics);}
      return true;
    }
    clearPagePreview(animate=false){
      this.pageTransitionToken=(this.pageTransitionToken || 0)+1;this.pageTransitionRunning=false;
      const preview=this.pagePreview;this.pagePreview=null;if(!preview)return;
      this.motionAnimations.get(preview.element)?.cancel();
      if(animate){const a=this.playMotion(preview.element,[{transform:preview.element.style.transform},{transform:`translateX(${preview.direction*preview.width}px)`}],{motion:'springSpeed',duration:150});if(a){a.finished.then(()=>preview.element.remove(),()=>preview.element.remove());return;}}
      preview.element.remove();
    }
    finishPageTransition(){
      const transition=this.pageTransitionOverlays;if(!transition)return;
      this.pageTransitionOverlays=null;
      for(const element of [transition.incoming,transition.outgoing])this.motionAnimations.get(element)?.cancel();
      if(transition.owned && !this.prefs.lowMemory && !this.destroyed){
        for(const [element,id] of transition.ids)element.id=id;
        const fragment=document.createDocumentFragment();fragment.append(...transition.outgoing.childNodes);
        this.browsePages.set(transition.kind,{signature:transition.signature,fragment,scroll:transition.scroll});
      }
      transition.incoming.remove();transition.outgoing.remove();transition.surface.style.removeProperty('visibility');transition.surface.style.removeProperty('will-change');
    }
    settlePageGesture(g,intent,dx){
      const preview=this.pagePreview;if(!preview)return false;
      cancelAnimationFrame(this.gestureFrame);this.gestureConsumedUntil=Date.now()+700;this.pointerHeld=false;
      const surface=preview.surface,r=surface.getBoundingClientRect(),owned=surface===this.browse,outgoing=surface.cloneNode(!owned);
      outgoing.removeAttribute('id');outgoing.classList.add('lt-page-preview','lt-page-outgoing');outgoing.inert=true;outgoing.setAttribute('aria-hidden','true');
      const scroll=surface.scrollTop,kind=this.browseKind,signature=this.browseSignature;
      if(owned)outgoing.append(...surface.childNodes);const ids=[...outgoing.querySelectorAll('[id]')].map(element=>[element,element.id]);for(const [element] of ids)element.removeAttribute('id');
      Object.assign(outgoing.style,{position:'fixed',inset:'auto',left:r.left-dx+'px',top:r.top+'px',width:preview.width+'px',height:r.height+'px',margin:'0',visibility:'visible',transform:`translateX(${dx}px)`});
      this.shell.append(outgoing);outgoing.scrollTop=scroll;
      this.pagePreview=null;this.gestureTargets=[];surface.style.removeProperty('transform');surface.style.removeProperty('opacity');surface.style.visibility='hidden';
      if(owned){this.browseKind=null;this.browseSignature=null;}
      this.pageTransitionOverlays={incoming:preview.element,outgoing,surface,ids,kind,signature,scroll,owned};
      this.pageTransitionCommitting=true;
      try{if(intent.kind==='back')this.goBack();else this.switchTab(intent.tab);}finally{this.pageTransitionCommitting=false;}
      const animations=[this.playMotion(outgoing,[{transform:outgoing.style.transform},{transform:`translateX(${-preview.direction*preview.width}px)`}],{motion:'pageSpeed',duration:160}),this.playMotion(preview.element,[{transform:preview.element.style.transform},{transform:'translateX(0px)'}],{motion:'pageSpeed',duration:160})].filter(Boolean);
      const current=this.pageTransitionOverlays,finish=()=>{if(this.pageTransitionOverlays===current)this.finishPageTransition();};
      if(animations.length)Promise.allSettled(animations.map(a=>a.finished)).then(finish);else finish();return true;
    }
    clearSettingsBackPreview(){
      const preview=this.settingsBackPreview;if(!preview)return;
      this.settingsBackPreview=null;this.motionAnimations.get(preview)?.cancel();preview.remove();
    }
    drawSettingsBack(g,dx){
      if(!this.settingsSection)return;
      const scroller=this.settings.querySelector('.lt-settings-content');
      if(!this.settingsBackPreview){
        const rect=scroller.getBoundingClientRect(),sheet=this.settings.getBoundingClientRect();
        const preview=node('div','lt-settings-back-preview'),content=this.$('lt-settings-categories').cloneNode(true);
        content.hidden=false;preview.inert=true;preview.setAttribute('aria-hidden','true');
        for(const el of [content,...content.querySelectorAll('*')])for(const attr of ['id','data-settings-section','aria-controls'])el.removeAttribute(attr);
        preview.style.cssText=`left:${rect.left-sheet.left}px;top:${rect.top-sheet.top}px;width:${rect.width}px;height:${rect.height}px;`;
        preview.append(content);this.settings.append(preview);preview.scrollTop=this.settingsScroll.get(null) || 0;this.settingsBackPreview=preview;
      }
      this.settingsBackPreview.style.transform=`translateX(${-scroller.clientWidth+clamp(dx,0,scroller.clientWidth)}px)`;
    }
    drawUtilityBack(dx){
      const saved=this.utilityStack.at(-1)?.preview;if(!saved)return false;
      if(!this.utilityBackPreview){const preview=this.inertPreview(saved.cloneNode(true));preview.classList.add('lt-utility-back-preview');this.utility.append(preview);this.utilityBackPreview=preview;}
      this.utilityBackPreview.style.transform=`translateX(${-this.utility.clientWidth+dx}px)`;return true;
    }
    settleSheetGesture(g,intent){
      const sheet=g.dialog,token=this.sheetTransitionToken=(this.sheetTransitionToken || 0)+1,horizontal=intent.kind==='back';
      const targets=this.gestureTargets || [],incoming=this.utilityBackPreview,amount=horizontal ? sheet.clientWidth : sheet.clientHeight;
      const animations=targets.map(target=>this.playMotion(target,[{transform:target.style.transform || 'none'},{transform:horizontal ? `translateX(${amount}px)` : `translateY(${amount}px)`}],{motion:'surfaceSpeed',duration:160})).filter(Boolean);
      if(incoming){const a=this.playMotion(incoming,[{transform:incoming.style.transform},{transform:'none'}],{motion:'surfaceSpeed',duration:160});if(a)animations.push(a);}
      else if(sheet.style.clipPath){const a=this.playMotion(sheet,[{clipPath:sheet.style.clipPath},{clipPath:horizontal ? `inset(0 0 0 ${amount}px)` : `inset(${amount}px 0 0 0)`}],{motion:'surfaceSpeed',duration:160});if(a)animations.push(a);}
      this.gestureConsumedUntil=Date.now()+700;this.pointerHeld=false;
      const finish=()=>{if(this.destroyed || token!==this.sheetTransitionToken)return;this.clearGestureMotion(false);if(horizontal)this.goBack();else this.closeDialog(sheet);};
      if(animations.length)Promise.allSettled(animations.map(a=>a.finished)).then(finish);else finish();
    }
    settleSettingsGesture(g,intent){
      cancelAnimationFrame(this.gestureFrame);this.gestureFrame=0;
      const token=this.settingsGestureToken=(this.settingsGestureToken || 0)+1;
      this.settingsGestureRunning=true;this.gestureConsumedUntil=Date.now()+700;this.suppressOpenUntil=Date.now()+500;this.pointerHeld=false;
      const targets=this.gestureTargets || [],preview=this.settingsBackPreview,back=intent.kind==='back';
      const end=back ? `translateX(${this.settings.clientWidth}px)` : `translateY(${this.settings.clientHeight}px)`;
      const animations=targets.map(target=>this.playMotion(target,[{transform:target.style.transform || 'none',opacity:target.style.opacity || '1'},{transform:end,opacity:1}],{motion:back ? 'settingsBackSpeed' : 'settingsCloseSpeed',duration:170})).filter(Boolean);
      if(preview){const a=this.playMotion(preview,[{transform:preview.style.transform},{transform:'translateX(0px)'}],{motion:back ? 'settingsBackSpeed' : 'settingsCloseSpeed',duration:170});if(a)animations.push(a);}
      const finish=()=>{
        if(this.destroyed || token!==this.settingsGestureToken || !this.settings.open)return;
        this.settingsGestureRunning=false;this.clearGestureMotion(false);
        if(back && this.settingsSection)this.showSettingsSection(null,true,false);else this.closeDialog(this.settings);
      };
      if(animations.length)Promise.allSettled(animations.map(a=>a.finished)).then(finish);else finish();
    }
    showGestureMotion(g,intent,dx,dy){
      if(!intent)return;
      this.cancelPendingCardTap();
      const amount=intent.axis==='x' ? Math.abs(dx) : Math.abs(dy),progress=clamp(amount/intent.threshold,0,1);
      document.body.dataset.ltGesture=intent.kind;
      if(!this.motionAllowed())return;
      if(intent.kind==='playerOpen' || intent.kind==='playerClose'){
        if(intent.kind==='playerOpen' && !g.playerPreview){g.playerPreview=true;this.preparePlayer(g.openReveal || 0);}
        this.cancelPlayerPresentation();this.playerPhase='dragging';this.setPlayerReveal(intent.kind==='playerOpen' ? (g.openReveal || 0)-dy/innerHeight : (g.startReveal ?? 1)-dy/innerHeight);return;
      }
      cancelAnimationFrame(this.gestureFrame);
      this.gestureFrame=requestAnimationFrame(()=>{
        this.gestureFrame=0;if(this.activeGesture!==g)return;
        if(!this.prefs.lowMemory && !g.dialog && !g.player && ['tab','back'].includes(intent.kind) && this.drawPagePreview(g,intent,dx))return;
        if(intent.kind==='tab'){
          const buttons=this.shell.querySelector('.lt-nav').querySelectorAll('button');g.navMetrics ||= {left:buttons[0].offsetLeft,width:buttons[0].offsetWidth,step:buttons[1].offsetLeft-buttons[0].offsetLeft};
          const start=['home','search','library'].indexOf(document.body.dataset.ltPage),end=['home','search','library'].indexOf(intent.tab);this.placeNavigation(start+(end-start)*progress,false,g.navMetrics);
        }
        if(!this.prefs.lowMemory && intent.kind==='track' && this.drawTrackPeek(g,intent,dx))return;
        if(!this.prefs.lowMemory && intent.kind==='back' && g.dialog===this.settings)this.drawSettingsBack(g,dx);
        if(g.dialog && ['back','sheetClose'].includes(intent.kind)){
          const nested=intent.kind==='back' && (g.dialog===this.settings && this.settingsSection || g.dialog===this.utility && this.drawUtilityBack(dx));
          if(!nested){this.gestureSheet=g.dialog;g.dialog.dataset.ltSheetDrag='true';g.dialog.style.setProperty('--lt-backdrop-fade',String(1-progress));g.dialog.style.clipPath=intent.axis==='x' ? `inset(0 0 0 ${Math.max(0,dx)}px round var(--lt-radius))` : `inset(${Math.max(0,dy)}px 0 0 0 round var(--lt-radius))`;}
        }
        const targets=g.dialog===this.settings && (intent.kind==='sheetClose' || intent.kind==='back' && !this.settingsSection) ? [this.settings.querySelector('.lt-sheet-header'),this.settings.querySelector('.lt-settings-content')] : intent.kind==='playerClose' || intent.kind==='back' && g.player ? [this.nowPlaying.querySelector('.lt-np-layout'),this.$('lt-np-header')] : intent.kind==='track' ? [g.mini ? this.$('lt-mini-open') : this.$('lt-art-swipe').querySelector('.lt-art-frame')] : intent.kind==='sheetClose' || intent.kind==='back' && g.dialog ? [g.dialog.querySelector('.lt-settings-content,.lt-history-list,.lt-release-content,.lt-utility-content')] : [this.pageSurface()];
        if(g.dialog && g.dialog!==this.settings && ['back','sheetClose'].includes(intent.kind))targets.splice(0,targets.length,...(g.dialog===this.utility ? [g.dialog.querySelector('.lt-utility-stage')] : [g.dialog.querySelector('.lt-sheet-header,.lt-np-header'),g.dialog.querySelector('.lt-history-tools'),g.dialog.querySelector('.lt-settings-content,.lt-history-list,.lt-release-content'),g.dialog.querySelector('footer')]).filter(Boolean));
        if(intent.kind==='quickOpen'){
          if(!this.quickGesturePreview){const preview=this.inertPreview(this.$('lt-quick-search').cloneNode(true));preview.hidden=false;preview.classList.add('lt-quick-gesture-preview');this.shell.append(preview);this.quickGesturePreview=preview;}
          this.quickGesturePreview.style.transform=`translateY(${-(1-progress)*90}px)`;this.quickGesturePreview.style.opacity=String(progress);targets.splice(0,targets.length,this.shell.querySelector('.lt-header'));
        }else if(intent.kind==='quickClose')targets.splice(0,targets.length,this.$('lt-quick-search'));
        const prior=this.gestureTargets || [];for(const old of prior)if(!targets.includes(old)){old.style.removeProperty('transform');old.style.removeProperty('opacity');old.style.removeProperty('will-change');}
        this.gestureTargets=targets.filter(Boolean);
        for(const target of this.gestureTargets){
          this.motionAnimations.get(target)?.cancel();target.style.willChange='transform,opacity';
          const x=intent.axis==='x' ? Math.sign(dx)*Math.min(Math.abs(dx),g.dialog===this.settings ? this.settings.clientWidth : innerWidth*.56)*(intent.kind==='boundary' ? .2 : 1) : 0,y=intent.axis==='y' ? Math.sign(dy)*Math.min(Math.abs(dy),innerHeight*.58) : 0;
          target.style.transform=`translate3d(${x}px,${y}px,0)`+(intent.kind==='playerClose' ? ` scale(${1-progress*.035})` : '');
          target.style.opacity=String(1-progress*.18);
        }
      });
    }
    gestureIntent(g,dx,dy){
      if(g.lockedIntent)return Math.sign(g.lockedIntent.axis==='x' ? dx : dy)===g.direction ? g.lockedIntent : null;
      const horizontal=Math.abs(dx)>10 && Math.abs(dx)>Math.abs(dy)*1.4,vertical=Math.abs(dy)>10 && Math.abs(dy)>Math.abs(dx)*1.35;
      // Edge Back has the same priority as the Back button, including sheets
      // and the player. Swipes elsewhere keep their tab/track behavior.
      if(horizontal && dx>0 && g.dialog===this.settings)return {kind:'back',axis:'x',threshold:this.prefs.settingsBackThreshold,label:'go back in Settings'};
      if(horizontal && dx>0 && g.dialog)return {kind:'back',axis:'x',threshold:this.prefs.backThreshold,label:'go back'};
      if(horizontal && dx>0 && g.edge)return {kind:'back',axis:'x',threshold:this.prefs.backThreshold,label:'go back'};
      if(g.dialog && g.sheetPull && vertical && dy>0)return {kind:'sheetClose',axis:'y',threshold:g.dialog===this.settings ? this.prefs.settingsCloseThreshold : this.prefs.sheetCloseThreshold,label:'close '+(g.dialog===this.settings ? 'Settings' : 'history')};
      if(horizontal && (g.mini || g.player)){
        const method=dx<0 ? 'next' : 'back';if(this.nowPlaying.querySelector(`[data-action="${method}"]`).disabled)return null;
        return {kind:'track',axis:'x',threshold:g.player ? this.prefs.playerTrackThreshold : this.prefs.miniTrackThreshold,label:dx<0 ? 'play next track' : 'play previous track',method};
      }
      if(vertical && dy<0 && g.mini)return {kind:'playerOpen',axis:'y',threshold:this.prefs.playerOpenThreshold,label:'expand player'};
      if(vertical && dy>0 && g.player && g.playerPull)return {kind:'playerClose',axis:'y',threshold:this.prefs.playerCloseThreshold,label:'minimize player'};
      if(!g.player && vertical && !g.dialog){
        if(this.quickOpen && dy<0)return {kind:'quickClose',axis:'y',threshold:this.prefs.quickCloseThreshold,label:'close quick search'};
        if(dy>0 && (g.toolbar || (this.activeScroll()?.scrollTop || 0)<=1))return {kind:'quickOpen',axis:'y',threshold:this.prefs.quickOpenThreshold,label:'open quick search'};
      }
      if(horizontal && !g.player && !g.dialog){
        if(dx>0 && !g.nav && (g.edge || document.body.dataset.ltCustomPage==='' || document.body.dataset.ltCustomPage==='detail'))return {kind:'back',axis:'x',threshold:this.prefs.backThreshold,label:'go back'};
        const tabs=['home','search','library'],index=tabs.indexOf(document.body.dataset.ltPage),next=clamp(index+(dx<0 ? 1 : -1),0,2);
        if(index!==next)return {kind:'tab',axis:'x',threshold:this.prefs.tabThreshold,label:'open '+['Home','Search','Your Library'][next],tab:tabs[next]};
        return {kind:'boundary',axis:'x',threshold:Infinity,label:['Home','Search','Your Library'][next]};
      }
      return null;
    }
    commitGesture(g,intent,dx){
      if(!this.prefs.lowMemory && !g.dialog && !g.player && ['tab','back'].includes(intent.kind)){if(this.motionAllowed() && !this.pagePreview)this.drawPagePreview(g,intent,dx);if(this.settlePageGesture(g,intent,dx))return;}
      if(g.dialog===this.settings && ['back','sheetClose'].includes(intent.kind)){this.settleSettingsGesture(g,intent);return;}
      if(g.dialog && ['back','sheetClose'].includes(intent.kind)){this.settleSheetGesture(g,intent);return;}
      const peek=intent.kind==='track' ? this.trackPeek : null;
      this.clearGestureMotion(false,intent.kind==='tab',Boolean(peek));this.gestureConsumedUntil=Date.now()+700;this.suppressOpenUntil=Date.now()+500;this.pointerHeld=false;
      if(intent.kind==='track'){this.commitTrackPeek(peek);this.nextTrackMotion=dx<0 ? 1 : -1;void this.callPlayer(intent.method);}
      else if(intent.kind==='playerOpen'){if(!this.nowPlaying.open)this.preparePlayer(0);this.animatePlayerReveal(1,300);}
      else if(intent.kind==='playerClose')this.requestPlayerClose();
      else if(intent.kind==='sheetClose')this.closeDialog(g.dialog);
      else if(intent.kind==='quickOpen')this.showQuickSearch(true);
      else if(intent.kind==='quickClose')this.showQuickSearch(false);
      else{const previous=this.viewKey(this.snapshotView());this.nextPageMotion={direction:dx<0 ? 1 : -1,distance:48,duration:100};if(intent.kind==='back')this.goBack();else this.switchTab(intent.tab);if(previous===this.viewKey(this.snapshotView()))this.nextPageMotion=null;}
    }
    viewKey(view){return (view.library ? 'library:' : 'page:')+view.path;}
    activeScroll(){return this.browse && !this.browse.hidden ? this.browse : this.main?.querySelector('.main-view-container__scroll-node, [data-overlayscrollbars-viewport]');}
    snapshotView(){return {path:this.getRoutePath(),library:this.libraryOpen,scroll:this.activeScroll()?.scrollTop || 0};}
    rememberView(){const view=this.snapshotView(),last=this.viewStack.at(-1);if(!last || this.viewKey(last)!==this.viewKey(view))this.viewStack.push(view);if(this.viewStack.length>80)this.viewStack.shift();this.tabViews.set(document.body.dataset.ltPage,view);}
    restoreScroll(view){requestAnimationFrame(()=>{if(this.viewKey(this.snapshotView())===this.viewKey(view)){const scroll=this.activeScroll();if(scroll)scroll.scrollTop=view.scroll || 0;}});}
    acceptHostRoute(path){
      if(!path)return;const previousHost=this.observedHostPath;this.observedHostPath=path;
      const searchOwner=this.nativeSearchOwner;
      const nativeSearchAt=this.nativeSearchRoutes?.get(path) || 0;
      if(this.enabled && Date.now()-nativeSearchAt<12000 && (this.nativeNavAt || 0)<=nativeSearchAt)return;
      if(searchOwner && this.enabled && Date.now()-searchOwner.at<12000 && (path===searchOwner.path || path===searchOwner.previousPath) && (this.nativeNavAt || 0)<=searchOwner.at)return;
      const request=this.routeRequests.get(path),latest=this.latestRouteRequest;
      // Owned detail pages keep their own route while a previous host request
      // finishes underneath. A deliberate interaction with native Spotify exits.
      if((this.detailOwned || /^\/search(?:\/|$)/.test(this.routePath)) && this.enabled && (this.nativeNavAt || 0)<=Math.max(this.localDetailAt || 0,this.localSearchAt || 0)){if(request)request.pending=false;return;}
      if(!this.issuingRoute && request?.pending && latest && request.serial<latest.serial && Date.now()-request.at<5000 && (this.nativeNavAt || 0)<=latest.at){
        // A slow completion from an older tab must not replace the latest tab.
        request.pending=false;
        if(latest.local)return;
        if(this.history.location?.pathname!==latest.path){this.issuingRoute=true;try{this.history.push(latest.path);}finally{this.issuingRoute=false;}}
        return;
      }
      if(this.issuingRoute || path===this.pendingRoute?.path){if(request)request.pending=false;this.pendingRoute=null;return;}
      // An unchanged host route must not erase a local Library view. Pending
      // routing also prevents polling an old host URL from undoing a new page.
      if(path===previousHost)return;
      const automatic=this.pendingRoute && Date.now()-this.pendingRoute.at<5000 || this.lastRequestedAt && Date.now()-this.lastRequestedAt<1500 && (this.nativeNavAt || 0)<=this.lastRequestedAt;
      if(path!==this.getRoutePath() && !automatic)this.rememberView();
      const keepLibrary=this.libraryOpen && automatic;
      this.pendingRoute=null;this.libraryOpen=Boolean(keepLibrary);this.routeChanged(false,path);
    }
    switchTab(tab){
      const current=document.body.dataset.ltPage;
      if(current===tab && (this.libraryOpen || this.getRoutePath()==='/' || this.getRoutePath()==='/search'))return;
      if(tab==='library'){this.showLibrary();return;}
      const previous=this.tabViews.get(tab),path=tab==='home' ? '/' : previous?.path?.startsWith('/search') ? previous.path : '/search';
      this.navigate(path);if(previous?.path===path)this.restoreScroll(previous);
    }
    goBack(){
      if(this.utility.open){this.utilityBack();return;}
      if(this.releaseDialog.open){this.closeDialog(this.releaseDialog);return;}
      if(this.settings.open){if(this.settingsSection)this.showSettingsSection(null);else this.closeDialog(this.settings);return;}
      if(this.historyPage.open){this.closeDialog(this.historyPage);return;}
      if(!this.$('lt-lyrics-menu').hidden){this.showLyricsMenu(false,true);return;}
      if(this.nowPlaying.open || this.playerOpening){this.requestPlayerClose();return;}
      if(this.quickOpen){this.showQuickSearch(false);return;}
      this.hideSearchPreview();const current=this.viewKey(this.snapshotView());let previous;
      do{previous=this.viewStack.pop();}while(previous && this.viewKey(previous)===current);
      if(!previous){if(this.getRoutePath()!=='/')this.navigate('/',false);return;}
      this.nextPageMotion ||= {direction:-1};this.navigate(previous.path,false,previous.library);this.restoreScroll(previous);
    }
    async withTimeout(operation,timeout=3500){
      let timer;try{return await Promise.race([operation,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Spotify request timed out')),timeout);})]);}finally{clearTimeout(timer);}
    }
    async apiGet(url,timeout=3500){
      if(typeof this.S.CosmosAsync?.get!=='function')throw new Error('Spotify service unavailable');
      const result=await this.withTimeout(this.S.CosmosAsync.get(url),timeout);
      if(result?.error || result?.status>=400)throw new Error('Spotify request rejected');return result;
    }
    bindReleaseFeatures(){
      this.bindKeyFeedback();
      this.listen(this.searchInput,'input',()=>this.queueLiveSearch(this.searchInput.value));
      this.listen(this.$('lt-quick-input'),'input',e=>this.queueLiveSearch(e.target.value));
      this.listen(this.$('lt-quick-search'),'submit',e=>{e.preventDefault();this.submitSearch(this.$('lt-quick-input').value);});
      this.listen(this.settings,'input',e=>{
        const key=e.target.dataset.textPref;if(!['welcome','welcomeSubtitle'].includes(key))return;
        this.prefs[key]=cleanText(e.target.value,160);this.save();
        const hero=this.browse.querySelector('.lt-home-hero');
        if(hero){hero.querySelector('h1').textContent=this.welcomeText();hero.querySelector('p').textContent=this.prefs.welcomeSubtitle;}
      });
      this.listen(document,'pointerdown',e=>{this.pointerEpoch=(this.pointerEpoch || 0)+1;this.pointerHeld=true;if(!e.target.closest(OWN))this.nativeNavAt=Date.now();},{capture:true});
      const released=()=>{const epoch=this.pointerEpoch;requestAnimationFrame(()=>{if(epoch!==this.pointerEpoch)return;this.pointerHeld=false;if(this.browseDeferred){this.browseDeferred=false;this.renderBrowse();}});};
      this.listen(window,'pointerup',released,{capture:true});this.listen(window,'pointercancel',released,{capture:true});this.listen(window,'blur',()=>{const epoch=this.pointerEpoch;this.later(()=>{if(epoch===this.pointerEpoch && !document.hasFocus())released();},600);});
      for(const type of ['touchstart'])this.listen(document,type,()=>{this.fastClickBlock=null;if(!this.pointerHeld){this.pointerEpoch=(this.pointerEpoch || 0)+1;this.pointerHeld=true;}},{capture:true,passive:true});
      this.listen(window,'touchend',released,{capture:true,passive:true});this.listen(window,'touchcancel',released,{capture:true,passive:true});
      this.listen(document,'click',e=>{if(!e.target.closest('#lt-search-preview,#lt-search-form,#lt-quick-search'))this.hideSearchPreview();},{capture:true});
      this.bindGestures();
      this.listen(matchMedia('(prefers-reduced-motion: reduce)'),'change',()=>{if(!this.motionAllowed())this.stopMotion();});
      this.listen(document,'visibilitychange',()=>{this.syncLyricClock();if(document.hidden)cancelAnimationFrame(this.lyricScrollFrame);else{this.refreshGreeting();this.render();this.queueCatalogRefresh();if(this.nowPlaying.open){void this.loadLyrics();this.updateLyricPosition();}}});
      this.listen(window,'focus',()=>{if(this.enabled && !document.hidden){this.render();this.queueCatalogRefresh();}});
      this.listen(this.$('lt-lyrics-panel'),'wheel',()=>{this.lyricScrollUntil=Date.now()+5000;cancelAnimationFrame(this.lyricScrollFrame);},{passive:true});
      this.listen(this.$('lt-lyrics-panel'),'touchstart',()=>{this.lyricScrollUntil=Date.now()+5000;cancelAnimationFrame(this.lyricScrollFrame);},{passive:true});
      this.imageObserver=window.IntersectionObserver ? new IntersectionObserver(entries=>{for(const item of entries)if(item.isIntersecting){this.imageObserver.unobserve(item.target);this.queueArtwork(item.target.dataset.uri);}},{root:this.browse,rootMargin:'200px'}) : null;
      if(!this.previewMode)for(const card of this.browse.querySelectorAll('.lt-card[data-needs-art]'))this.imageObserver?.observe(card);
    }
    bindGestures(){
      this.listen(window,'pointerdown',e=>{
        this.settingsGestureToken=(this.settingsGestureToken || 0)+1;this.settingsGestureRunning=false;
        this.gestureConsumedUntil=0;this.suppressOpenUntil=0;this.clearGestureMotion(false);this.activeGesture=null;
        if(!this.enabled || e.pointerType==='mouse' || e.isPrimary===false || e.target.closest('input,select,textarea,[contenteditable="true"],.lt-caption-buttons,.lt-keyboard,.lt-search-preview'))return;
        const dialog=this.utility.open ? this.utility : this.releaseDialog.open ? this.releaseDialog : this.settings.open ? this.settings : this.historyPage.open ? this.historyPage : null;
        const scroll=e.target.closest('#lt-lyrics-lines,.lt-lyrics-panel,.lt-utility-content,.lt-history-list,.lt-release-content,.lt-settings-content,.lt-np-layout');
        const edge=e.clientX<=Math.min(120,Math.max(64,innerWidth*.12)),sheetPull=Boolean(e.target.closest('.lt-sheet-header,.lt-np-header')) || Boolean(scroll && scroll.scrollTop<=1);
        if(dialog && !sheetPull && !edge && e.target===dialog)return;
        const header=this.shell.querySelector('.lt-header').getBoundingClientRect();
        const playerTop=Math.min(220,Math.max(140,innerHeight*.25,this.$('lt-np-header').getBoundingClientRect().bottom+64));
        this.activeGesture={x:e.clientX,y:e.clientY,id:e.pointerId,at:Date.now(),player:this.nowPlaying.open && !dialog,dialog,
          startReveal:this.playerReveal ?? 1,openReveal:clamp(1-this.shell.querySelector('.lt-mini').getBoundingClientRect().top/innerHeight,0,1),
          top:e.clientY<=Math.min(280,Math.max(180,innerHeight*.3,header.bottom+96,this.quickOpen ? this.prefs.quickCloseThreshold+40 : 0)),
          edge,sheetPull,
          mini:Boolean(e.target.closest('#lt-mini-open')),art:Boolean(e.target.closest('#lt-art-swipe')),
          nav:Boolean(e.target.closest('.lt-nav')),
          toolbar:Boolean(e.target.closest('.lt-header')) || e.clientY<=header.bottom+36,
          playerPull:Boolean(e.target.closest('.lt-np-header,.lt-art-area')) || Boolean(scroll && scroll.scrollTop<=1) || this.nowPlaying.open && e.clientY<=playerTop,
          slop:14};
      },{capture:true});
      this.listen(window,'pointermove',e=>{
        const g=this.activeGesture;if(!g || e.pointerId!==g.id)return;
        const dx=e.clientX-g.x,dy=e.clientY-g.y;
        if(Math.hypot(dx,dy)<=g.slop){if(g.intent)this.showGestureMotion(g,g.intent,dx,dy);return;}
        const intent=this.gestureIntent(g,dx,dy);
        if(!intent){if(g.intent){this.cancelPlayerGesture(g);g.playerPreview=false;g.intent=null;this.clearGestureMotion(true);}return;}
        if(!g.lockedIntent){g.lockedIntent=intent;g.direction=Math.sign(intent.axis==='x' ? dx : dy);this.cancelHold();this.cancelPendingCardTap();}
        g.intent=intent;this.showGestureMotion(g,intent,dx,dy);
        if((intent.axis==='x' || intent.kind==='playerOpen' || intent.kind==='playerClose') && e.cancelable)e.preventDefault();
      },{capture:true,passive:false});
      this.listen(window,'touchmove',e=>{
        const g=this.activeGesture,t=e.touches[0];if(!g || !t || e.touches.length!==1)return;
        const dx=t.clientX-g.x,dy=t.clientY-g.y;
        const intent=this.gestureIntent(g,dx,dy);
        if(intent && Math.hypot(dx,dy)>g.slop && e.cancelable)e.preventDefault();
      },{capture:true,passive:false});
      this.listen(window,'pointercancel',()=>{const g=this.activeGesture;this.activeGesture=null;this.cancelPlayerGesture(g);this.clearGestureMotion(true);},{capture:true});
      this.listen(window,'blur',()=>{const g=this.activeGesture;this.activeGesture=null;this.cancelPlayerGesture(g,false);this.clearGestureMotion(false);});
      this.listen(window,'pointerup',e=>{
        const g=this.activeGesture;this.activeGesture=null;if(!g || g.id!==e.pointerId){this.clearGestureMotion(false);return;}
        const dx=e.clientX-g.x,dy=e.clientY-g.y,intent=this.gestureIntent(g,dx,dy),amount=intent?.axis==='x' ? Math.abs(dx) : Math.abs(dy);
        if(!intent || amount<=g.slop){this.cancelPlayerGesture(g);this.clearGestureMotion(Boolean(g.intent));return;}
        e.preventDefault();e.stopImmediatePropagation();
        if(amount>=intent.threshold && Date.now()-g.at<2500)this.commitGesture(g,intent,dx);
        else{this.cancelPlayerGesture(g);this.clearGestureMotion(true);this.gestureConsumedUntil=Date.now()+700;this.pointerHeld=false;}
      },{capture:true});
      this.listen(document,'click',e=>{if(e.isTrusted && Date.now()<(this.gestureConsumedUntil || 0)){this.gestureConsumedUntil=0;e.preventDefault();e.stopImmediatePropagation();}},{capture:true});
    }
    welcomeText(){
      const hour=new Date().getHours(),period=hour>=5 && hour<12 ? 'morning' : hour>=12 && hour<18 ? 'afternoon' : 'evening',greeting='Good '+period;
      return this.prefs.welcome ? this.prefs.welcome.replace(/\{greeting\}/gi,greeting).replace(/\{timeOfDay\}/gi,period).replace(/\bGood (?:morning|afternoon|evening)\b/gi,greeting) : greeting+'.';
    }
    refreshGreeting(){this.lastGreetingCheck=Date.now();const heading=this.browse?.querySelector('.lt-home-hero h1');if(heading && heading.textContent!==this.welcomeText())heading.textContent=this.welcomeText();this.refreshHomeClock();}
    refreshHomeClock(){
      const clock=this.browse?.querySelector('#lt-home-clock');if(!clock)return;
      clock.hidden=!this.prefs.homeClock;if(clock.hidden)return;
      const now=new Date(),hour=now.getHours(),minute=String(now.getMinutes()).padStart(2,'0'),local=String(hour).padStart(2,'0')+':'+minute;
      const label=this.prefs.clockFormat==='12' ? ((hour+11)%12+1)+':'+minute+' '+(hour<12 ? 'AM' : 'PM') : local;
      if(clock.textContent!==label){clock.textContent=label;clock.dateTime=local;clock.setAttribute('aria-label','Local time, '+label);}
    }
    showQuickSearch(show){
      const changed=this.quickOpen!==show;
      this.quickOpen=show;this.$('lt-quick-search').hidden=!show;document.body.dataset.ltQuick=String(show);
      if(show){if(changed)this.animateSurface(this.$('lt-quick-search'));this.$('lt-quick-input').focus({preventScroll:true});if(this.prefs.keyboard)this.showKeyboard(true);}else{this.hideSearchPreview();this.showKeyboard(false);this.$('lt-quick-input').blur();if(changed)this.animateSurface(this.shell.querySelector('.lt-header'));}
    }
    hideSearchPreview(){clearTimeout(this.searchDebounce);this.$('lt-search-preview').hidden=true;this.liveSearchToken++;}
    updateSearchPreviewBounds(){
      const panel=this.$('lt-search-preview');if(!panel?.isConnected)return;
      const keyboard=this.$('lt-keyboard'),top=parseFloat(getComputedStyle(panel).top) || 0;
      const bottom=keyboard.hidden ? innerHeight-12 : keyboard.getBoundingClientRect().top-8;
      const room=Math.max(0,Math.floor(bottom-top));
      panel.style.setProperty('--lt-preview-room',room+'px');panel.dataset.noRoom=String(room<64);
    }
    normalizeSearch(result){
      if(result?.body)result=typeof result.body==='string' ? JSON.parse(result.body) : result.body;
      const data=result?.data || result;
      const root=data?.searchV2 || data?.search || data?.searchModalResults || data;
      const entries=[],seen=new Set();let recognized=false,received=0;
      for(const [type,keys] of [['track',['tracksV2','tracks']],['artist',['artists']],['album',['albumsV2','albums']],['playlist',['playlists']]]){
        for(const key of keys){
          const group=root?.[key];if(!group)continue;
          const rows=Array.isArray(group) ? group : group.items || group.edges;
          if(!Array.isArray(rows))continue;recognized=true;
          for(const row of rows){
            let raw=row;
            for(let depth=0;depth<5 && raw && !raw.uri && !raw.id && !raw.link;depth++)raw=raw.item || raw.data || raw.node || raw[type] || raw;
            if(!raw)continue;
            received++;
            const entry=normalizeEntity({...raw,uri:raw.uri || raw.link || (raw.id ? `spotify:${type}:${raw.id}` : ''),name:raw.name || raw.profile?.name,title:raw.title,album:raw.album || raw.albumOfTrack});
            if(entry && !seen.has(entry.uri)){seen.add(entry.uri);entries.push(entry);}
          }
        }
      }
      if(!recognized)throw new Error('Unknown Spotify search response');
      if(!entries.length && (result?.errors?.length || received))throw new Error('Spotify search did not return usable results');
      return entries;
    }
    async searchMusic(query,offset=0){
      const key=query.toLocaleLowerCase()+'|'+offset,cached=this.searchCache.get(key);
      if(cached && Date.now()-cached.at<60000){this.searchSource=cached.source || 'web-api';return cached.entries;}
      if(this.searchFlights.has(key))return this.searchFlights.get(key);
      const job=(async()=>{
        let failure;
        for(let attempt=0;attempt<2;attempt++){
        if(attempt)await new Promise(resolve=>setTimeout(resolve,250));
        if(this.destroyed)throw new Error('Search session ended.');
        try{
        const gql=this.S.GraphQL;
        let entries,source='web-api';
        const definitions=[...new Set(['searchDesktop','searchDesktop2','searchModalResults'].flatMap(name=>[gql?.Definitions?.[name],gql?.QueryDefinitions?.[name]]).filter(Boolean))];
        for(const definition of definitions){
          if(typeof gql?.Request!=='function')break;
          try{
            const result=await this.withTimeout(gql.Request(definition,{searchTerm:query,offset,limit:10,numberOfTopResults:5,includeAudiobooks:false,includePreReleases:false,includeAuthors:false,enableEntityExtensionData:false}),2300);
            entries=this.normalizeSearch(result);source='spotify-client';break;
          }catch{ /* Fall through to the supported Web API in older wrappers. */ }
        }
        if(!entries){
          const result=await this.apiGet('https://api.spotify.com/v1/search?'+new URLSearchParams({q:query,type:'track,artist,album,playlist',limit:'10',offset:String(offset)}));
          entries=this.normalizeSearch(result);
        }
        this.searchSource=source;this.searchError='';this.searchCache.set(key,{at:Date.now(),entries,source});
        if(this.searchCache.size>(this.prefs.lowMemory ? 8 : 32))this.searchCache.delete(this.searchCache.keys().next().value);
        return entries;
        }catch(error){failure=error;}
        }
        // Some client builds expose no working search definition and reject the
        // public catalog endpoint. Reuse Spotify's own rendered search instead.
        if(!offset){try{return await this.searchNativeView(query,key);}catch(error){failure=error;}}
        throw failure;
      })();
      this.searchFlights.set(key,job);
      try{return await job;}finally{this.searchFlights.delete(key);}
    }
    currentSearchQuery(){return cleanText(this.quickOpen ? this.$('lt-quick-input').value : /^\/search(?:\/|$)/.test(this.getRoutePath()) ? this.searchInput.value || this.queryFromPath() : '',300);}
    async searchNativeView(query,key){
      const previous=this.nativeSearchQueue || Promise.resolve();
      const job=previous.catch(()=>{}).then(async()=>{
        if(this.destroyed || this.currentSearchQuery()!==query)throw new Error('Search superseded');
        const path='/search/'+encodeURIComponent(query),previousPath=this.history.location?.pathname || '/',at=Date.now();
        const owner={path,previousPath,at};this.nativeSearchOwner=owner;
        let changed=previousPath===path,lastChange=0;
        const observer=new MutationObserver(records=>{if(records.some(r=>!((r.target.nodeType===1 ? r.target : r.target.parentElement)?.closest(OWN)))){changed=true;lastChange=Date.now();}});
        observer.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['href','data-uri','aria-busy']});
        const visit=target=>{this.nativeSearchRoutes ||= new Map();this.nativeSearchRoutes.set(target,Date.now());while(this.nativeSearchRoutes.size>40)this.nativeSearchRoutes.delete(this.nativeSearchRoutes.keys().next().value);this.issuingRoute=true;try{(this.history.replace || this.history.push).call(this.history,target);}finally{this.issuingRoute=false;}};
        try{
          if(previousPath!==path)visit(path);
          while(Date.now()-at<4500){
            if(this.destroyed || this.currentSearchQuery()!==query || (this.nativeNavAt || 0)>at)throw new Error('Search superseded');
            const root=document.querySelector('.Root__main-view, .main-view-container, [data-testid="main-view"], #main-view');
            if(changed && Date.now()-lastChange>=160 && this.history.location?.pathname===path && root && !root.querySelector('[aria-busy="true"],[data-testid="loading"]')){
              const entries=[...this.collectNativeEntities(root).values()].filter(entry=>['track','artist','album','playlist'].includes(entry.type));
              if(entries.length || root.querySelector('[data-testid="search-empty-state"],[data-testid="search-no-results"],[data-testid="empty-search-results"],.main-search-emptyResults')){
                this.searchSource='spotify-view';this.searchError='';this.searchCache.set(key,{at:Date.now(),entries,source:'spotify-view'});
                while(this.searchCache.size>(this.prefs.lowMemory ? 8 : 32))this.searchCache.delete(this.searchCache.keys().next().value);
                return entries;
              }
            }
            await new Promise(resolve=>setTimeout(resolve,80));
          }
          throw new Error('Spotify search did not finish loading');
        }finally{
          observer.disconnect();
          // Quick Search borrows the native view, then restores its background.
          if(!this.destroyed && this.nativeSearchOwner===owner && this.history.location?.pathname===path && this.getRoutePath()!==path && (this.nativeNavAt || 0)<=at)visit(previousPath);
        }
      });
      this.nativeSearchQueue=job;return job;
    }
    queueLiveSearch(value){
      clearTimeout(this.searchDebounce);const query=cleanText(value,300);const token=++this.liveSearchToken;
      if(!query){this.hideSearchPreview();return;}
      const panel=this.$('lt-search-preview');panel.hidden=false;panel.replaceChildren(node('p','lt-preview-status','Searching…'));panel.setAttribute('aria-busy','true');this.updateSearchPreviewBounds();
      this.searchDebounce=setTimeout(()=>void this.searchPreview(query,token),100);
    }
    async searchPreview(query,token){
      try{
        const entries=await this.searchMusic(query);
        if(this.destroyed || token!==this.liveSearchToken)return;
        if(this.pointerHeld){this.later(()=>void this.searchPreview(query,token),30);return;}
        const panel=this.$('lt-search-preview');panel.replaceChildren();panel.setAttribute('aria-busy','false');
        panel.append(node('p','lt-preview-status',entries.length ? 'Quick results · tap to play, double tap to open' : 'No matches. Try another song or artist.'));
        const list=node('div','lt-preview-list');for(const entry of entries.slice(0,6)){list.append(this.makeCard(entry));if(!entry.image)this.queueArtwork(entry.uri);}panel.append(list);
        const all=node('button','lt-pill','See all results');all.type='button';all.dataset.action='submitLiveSearch';all.dataset.query=query;panel.append(all);
      }catch{
        if(this.destroyed || token!==this.liveSearchToken)return;
        this.searchError='Search could not connect to Spotify.';
        const panel=this.$('lt-search-preview');panel.setAttribute('aria-busy','false');panel.replaceChildren(node('p','lt-preview-status','Search could not connect. Press Enter for retry and desktop search options.'));
      }
    }
    queryFromPath(path=this.getRoutePath()){
      if(!path.startsWith('/search/'))return '';try{return decodeURIComponent(path.slice(8)).trim();}catch{return path.slice(8).trim();}
    }
    async loadSearchResults(query,more=false){
      if(!query)return;
      const token=(this.searchResultsToken || 0)+1;this.searchResultsToken=token;
      this.resultsQuery=query;this.searchResultBusy=true;this.searchError='';
      if(!more){this.searchOffset=0;this.searchResults=[];this.searchFilter='all';}
      this.searchResultVersion++;this.renderBrowse();
      try{
        const entries=await this.searchMusic(query,more ? this.searchOffset+10 : 0);
        if(this.destroyed || token!==this.searchResultsToken || this.queryFromPath()!==query)return;
        if(more)this.searchOffset+=10;
        const all=more ? [...this.searchResults,...entries] : entries;
        this.searchResults=[...new Map(all.map(entry=>[entry.uri,entry])).values()];
        this.searchHasMore=this.searchSource!=='spotify-view' && entries.length>0 && ['track','artist','album','playlist'].some(type=>entries.filter(entry=>entry.type===type).length>=10);
      }catch{
        if(token!==this.searchResultsToken || this.destroyed)return;
        this.searchError='Search is unavailable in this Spotify session. Retry, or open Spotify’s desktop search.';
        this.searchHasMore=false;
      }finally{
        if(token===this.searchResultsToken && !this.destroyed){this.searchResultBusy=false;this.searchResultVersion++;this.renderBrowse();}
      }
    }
    queueArtwork(uri){
      const cached=this.artCache.get(uri);if(cached && Date.now()-cached.at<300000){if(cached.image)this.applyEntityArtwork(uri,cached.image);return;}
      if(!uriInfo(uri) || this.artJobs.includes(uri) || this.artInFlight?.has(uri))return;
      this.artJobs.push(uri);this.pumpArtwork();
    }
    pumpArtwork(){
      this.artInFlight ||= new Set();
      while(this.artBusy<(this.prefs.lowMemory ? 1 : 3) && this.artJobs.length){const uri=this.artJobs.shift();this.artBusy++;this.artInFlight.add(uri);
        void this.fetchArtwork(uri).then(image=>{this.artCache.set(uri,{image,at:Date.now()});if(image&&!this.destroyed)this.applyEntityArtwork(uri,image);if(this.artCache.size>(this.prefs.lowMemory ? 32 : 200))this.artCache.delete(this.artCache.keys().next().value);}).finally(()=>{this.artBusy--;this.artInFlight.delete(uri);if(!this.destroyed)this.pumpArtwork();});
      }
    }
    async fetchArtwork(uri){
      const info=uriInfo(uri);if(!info || info.type==='collection')return '';
      try{
        if(info.type==='playlist' && typeof this.S.Platform?.PlaylistAPI?.getMetadata==='function'){
          const result=await this.S.Platform.PlaylistAPI.getMetadata(uri);const image=pickArtwork(result);if(image)return image;
        }
      }catch{}
      try{const id=info.path.split('/')[2],result=await this.apiGet(`https://api.spotify.com/v1/${info.type}s/${encodeURIComponent(id)}${info.type==='playlist' ? '/images' : ''}`);return pickArtwork(result);}catch{return '';}
    }
    applyEntityArtwork(uri,image){
      for(const peek of [this.trackPeek,this.trackTransition])if(peek?.uri===uri){peek.incoming.src=image;peek.incoming.hidden=false;}
      for(const map of [this.entities,this.homeEntities,this.libraryEntities]){const entry=map.get(uri);if(entry)entry.image=image;}
      for(const root of [this.shell,...[...this.browsePages.values()].map(page=>page.fragment)])for(const card of root.querySelectorAll('.lt-card'))if(card.dataset.uri===uri){const art=card.querySelector('.lt-card-art');let img=art.querySelector('img');if(!img){img=node('img','');img.alt='';img.loading='lazy';img.decoding='async';art.append(img);}img.hidden=false;img.src=image;delete card.dataset.needsArt;}
      for(const row of this.recentSearches)if(row.uri===uri)row.image=image;
      const page=this.detailPages.get(uri);if(page)page.entry.image=image;
      const hero=this.browse.querySelector('.lt-detail-hero');if(hero?.dataset.detailUri===uri){const art=hero.querySelector('.lt-detail-art');let img=art.querySelector('img');if(!img){img=node('img','');img.alt='';art.append(img);}img.src=image;}
    }
    parseLRC(text){
      const lines=[];let offset=0;const offsetMatch=String(text || '').match(/\[offset:([+-]?\d+)\]/i);if(offsetMatch)offset=number(offsetMatch[1]);
      for(const row of String(text || '').split(/\r?\n/)){
        const tags=[...row.matchAll(/\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g)];
        const words=cleanText(row.replace(/\[[^\]]*\]/g,''),1000);if(!words)continue;
        for(const tag of tags)lines.push({text:words,at:Math.max(0,(Number(tag[1])*60+Number(tag[2]))*1000+Number((tag[3] || '').padEnd(3,'0') || 0)+offset)});
      }
      return lines.sort((a,b)=>a.at-b.at);
    }
    lyricTitle(value){
      return String(value || '').replace(/\s*[([](?:feat\.?|ft\.?|featuring|from\b|remaster)[^\])]*[\])]/gi,'').replace(/\s*-\s*(?:\d{4}\s*)?remaster(?:ed)?(?:\s+\d{4})?\s*$/i,'').trim();
    }
    lyricName(value){return String(value || '').normalize('NFKD').replace(/\p{M}/gu,'').toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();}
    lyricVersion(value){return (String(value || '').toLocaleLowerCase().match(/\b(?:live|remix|acoustic|instrumental|karaoke|extended|radio edit)\b/g) || []).sort().join('|');}
    async lyricJSON(url,signal){
      const host=new URL(url).host;this.lyricCooldowns ||= new Map();
      if(signal.aborted || (this.lyricCooldowns.get(host) || 0)>Date.now())throw new Error('Lyric service cooling down');
      if(host==='lrclib.net' && this.lastLRCLIBAt){const remaining=200-(Date.now()-this.lastLRCLIBAt);if(remaining>0)await new Promise(resolve=>setTimeout(resolve,remaining));}
      if(signal.aborted)throw new Error('Lyrics cancelled');
      const abort=new AbortController(),cancel=()=>abort.abort();signal.addEventListener('abort',cancel,{once:true});
      const timer=setTimeout(cancel,host==='lrclib.net' ? 1800 : 2200);
      try{
        if(host==='lrclib.net')this.lastLRCLIBAt=Date.now();
        const response=await fetch(url,{credentials:'omit',referrerPolicy:'no-referrer',signal:abort.signal,headers:host==='lrclib.net' ? {'Lrclib-Client':`LiquidTouch/${VERSION} (Spicetify extension; https://spicetify.app)`} : {}});
        if(response.status===429 || response.status===503){const retry=response.headers.get('Retry-After'),seconds=number(retry,0) || Math.max(0,(Date.parse(retry)-Date.now())/1000) || 60;this.lyricCooldowns.set(host,Date.now()+seconds*1000*(1+Math.random()*.2));}
        if(!response.ok)throw new Error('Lyric service unavailable');return await response.json();
      }finally{clearTimeout(timer);signal.removeEventListener('abort',cancel);}
    }
    backupRecord(result,info,search=false){
      const title=this.lyricName(this.lyricTitle(info.title)),artist=this.lyricName(info.artists?.[0] || info.artist.split(/,\s+|\s+feat\.?\s+/i)[0]);
      if(search){
        const candidateArtist=this.lyricName(result.artistName);
        const raw=value=>String(value || '').normalize('NFKD').replace(/\p{M}/gu,'').toLocaleLowerCase().trim(),lead=raw(info.artists?.[0] || info.artist.split(/,\s+|\s+feat\.?\s+/i)[0]),credit=raw(result.artistName);
        const credited=credit.startsWith(lead) && /^(?:[,&;/]|feat\.?\b|ft\.?\b|with\b|and\b)/i.test(credit.slice(lead.length).trim());
        if(this.lyricName(this.lyricTitle(result.trackName || result.name))!==title || !(candidateArtist===artist || credited) || this.lyricVersion(result.trackName || result.name)!==this.lyricVersion(info.title))return null;
      }
      const expected=info.duration/1000,diff=result.duration && expected ? Math.abs(number(result.duration)-expected) : Infinity;
      if(diff>Math.max(10,expected*.04) && diff!==Infinity)return null;
      const synced=this.parseLRC(String(result.syncedLyrics || '').slice(0,200000)),timed=synced.length>0 && (diff<=2 || !search && diff===Infinity);
      const plain=String(result.plainLyrics || '').slice(0,200000).split(/\r?\n/).map(text=>({text:cleanText(text,1000),at:-1})).filter(line=>line.text);
      const lines=timed ? synced : plain.length ? plain : synced.map(line=>({text:line.text,at:-1}));
      if(!lines.length && !result.instrumental)return null;
      return {lines,timed,provider:'LRCLIB',source:'lrclib',instrumental:Boolean(result.instrumental),rank:(timed ? 100 : 0)+(diff<=2 ? 10-diff : 0)+(this.lyricName(result.albumName)===this.lyricName(info.album) ? 5 : 0)};
    }
    async fetchBackupLyrics(info,signal,allowText=true){
      if(!info?.title || !info?.artist)throw new Error('Track metadata unavailable');
      const query=new URLSearchParams({track_name:info.title,artist_name:info.artist,album_name:info.album || '',duration:String(Math.round(info.duration/1000))});
      let fallback=null;
      try{fallback=this.backupRecord(await this.lyricJSON('https://lrclib.net/api/get?'+query,signal),info);if(fallback?.timed || fallback?.instrumental)return fallback;}catch{}
      const title=this.lyricTitle(info.title),artist=info.artists?.[0] || info.artist.split(/,\s+|\s+feat\.?\s+/i)[0];
      for(const search of [new URLSearchParams({track_name:title,artist_name:artist}),new URLSearchParams({q:title+' '+artist})]){
        if(signal.aborted)throw new Error('Lyrics cancelled');
        try{const rows=await this.lyricJSON('https://lrclib.net/api/search?'+search,signal),matches=(Array.isArray(rows) ? rows : []).map(row=>this.backupRecord(row,info,true)).filter(Boolean).sort((a,b)=>b.rank-a.rank);if(matches[0]?.timed || matches[0]?.instrumental)return matches[0];fallback ||= matches[0];}catch{}
        if(fallback)break;
      }
      if(fallback)return fallback;
      if(allowText && this.prefs.lyricsTextFallback && !signal.aborted){
        const result=await this.lyricJSON(`https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`,signal);
        const lines=String(result.lyrics || '').slice(0,200000).split(/\r?\n/).map(text=>({text:cleanText(text,1000),at:-1})).filter(line=>line.text);
        if(lines.length)return {lines,timed:false,provider:'lyrics.ovh · text only',source:'lyrics-ovh',instrumental:false};
      }
      throw new Error('No matching lyrics');
    }
    queuedLyricInfo(raw){
      const value=raw?.contextTrack || raw?.track || raw?.item?.data || raw?.item || raw?.data || raw,m=value?.metadata || {};
      const uri=typeof value==='string' ? value : value?.uri;
      if(!/^spotify:track:[\w-]+$/.test(uri || ''))return null;
      const artistItems=Array.isArray(value?.artists) ? value.artists : value?.artists?.items;
      const artists=(Array.isArray(artistItems) ? artistItems : []).map(a=>typeof a==='string' ? a : a.name || a.profile?.name).filter(Boolean);
      return {uri,title:cleanText(value?.name || m.title),artist:artists.join(', ') || cleanText(m.artist_name || m.album_artist_name),artists,
        album:cleanText(value?.album?.name || m.album_title),duration:number(value?.duration_ms || value?.duration?.totalMilliseconds || value?.duration?.milliseconds || m.duration || value?.duration)};
    }
    cacheLyrics(uri,lyrics){
      if(!lyrics || !(lyrics.lines.length || lyrics.instrumental))return;
      this.lyricsCache.delete(uri);this.lyricsCache.set(uri,lyrics);
      while(this.lyricsCache.size>(this.prefs.lowMemory ? 4 : 32))this.lyricsCache.delete(this.lyricsCache.keys().next().value);
    }
    cancelLyricPrefetch(){
      this.lyricPrefetch?.abort.abort();this.lyricPrefetch=null;this.lyricPrefetchKey=null;this.lyricPrefetchTarget=null;
    }
    prefetchNextLyrics(uri=this.lastURI){
      // Keep exactly one queue item ahead, from the start of a song. This also
      // covers manual skips, seeking, pauses and skipping out of Repeat one.
      if(this.destroyed || !this.enabled || !this.prefs.lyrics || uri!==this.lastURI || !/^spotify:track:[\w-]+$/.test(uri || '')){
        if(this.lyricPrefetch?.from===uri && this.lyricPrefetch.uri!==uri)this.cancelLyricPrefetch();
        return;
      }
      const next=this.adjacentTrack('next');
      if(next){this.beginLyricPrefetch(next.lyricMeta);return;}
      const queue=read(()=>this.S.Queue,null),state=this.getPlayerState(),current=queue?.track?.contextTrack?.uri || queue?.track?.uri;
      // An exposed empty queue, ad or episode is authoritative; do not skip it.
      if(Array.isArray(queue?.nextTracks) && (!current || current===uri) || Array.isArray(state?.nextItems) || Array.isArray(state?.next_tracks)){
        if(this.lyricPrefetch?.from===uri)this.cancelLyricPrefetch();return;
      }
      if(this.lyricQueueFlight || Date.now()-(this.lyricQueueAt || 0)<(this.prefs.lowMemory ? 15000 : 10000))return;
      this.lyricQueueAt=Date.now();
      const flight=this.withTimeout(this.spotifyRequest('get','/v1/me/player/queue'),1800).then(result=>{
        if(this.destroyed || uri!==this.lastURI || !this.prefs.lyrics || !this.enabled)return;
        const current=result?.currently_playing?.uri;
        if(current && current!==uri)return;
        this.beginLyricPrefetch(this.queuedLyricInfo(result?.queue?.[0]));
      }).catch(()=>{}).finally(()=>{if(this.lyricQueueFlight===flight)this.lyricQueueFlight=null;});
      this.lyricQueueFlight=flight;
    }
    beginLyricPrefetch(info){
      if(!info || info.uri===this.lastURI){if(this.lyricPrefetch?.from===this.lastURI)this.cancelLyricPrefetch();return;}
      const key=this.lastURI+'|'+info.uri;
      if(this.lyricPrefetchKey===key)return;
      // A lookup adopted by the current track must finish before warming another.
      if(this.lyricPrefetch?.uri===this.lastURI && !this.lyricPrefetch.done)return;
      this.cancelLyricPrefetch();this.lyricPrefetchKey=key;this.lyricPrefetchTarget=info.uri;
      if(this.lyricsCache.has(info.uri))return;
      const job={uri:info.uri,from:this.lastURI,abort:new AbortController(),done:false};this.lyricPrefetch=job;
      job.promise=this.fetchTrackLyrics(info.uri,info,job.abort.signal).then(lyrics=>{
        if(job.abort.signal.aborted || this.destroyed || this.lyricPrefetch!==job)return null;
        this.cacheLyrics(info.uri,lyrics);return lyrics;
      }).catch(()=>null).finally(()=>{job.done=true;if(!this.destroyed && job.uri===this.lastURI)this.later(()=>this.prefetchNextLyrics(),0);});
    }
    async fetchTrackLyrics(uri,info,signal,onFallback=null){
      if(signal.aborted)throw new Error('Lyrics cancelled');
      let lyrics=null;
      try{
        const result=await this.apiGet(`https://spclient.wg.spotify.com/color-lyrics/v2/track/${encodeURIComponent(uri.split(':')[2])}?format=json&vocalRemoval=false&market=from_token`,2200);
        const data=result?.lyrics || result,timed=['LINE_SYNCED','SYLLABLE_SYNCED'].includes(data?.syncType);
        const lines=(data?.lines || []).map(line=>({text:cleanText(line.words,1000),at:timed ? number(line.startTimeMs,-1) : -1})).filter(line=>line.text && (!timed || line.at>=0));
        if(lines.length)lyrics={lines:timed ? lines.sort((a,b)=>a.at-b.at) : lines,timed,source:'spotify',provider:cleanText(data.providerDisplayName || data.provider,80) || 'Spotify'};
      }catch{ /* Spotify may not provide lyrics for this recording/session. */ }
      if(signal.aborted || this.destroyed)throw new Error('Lyrics cancelled');
      if((!lyrics || !lyrics.timed) && this.prefs.lyricsFallback){
        onFallback?.();
        // Queue entries sometimes contain only a URI. Resolve their own metadata,
        // never borrow the currently playing song's title, duration or artist.
        if(!info?.title || !info?.artist || !info.duration)try{
          const raw=await this.apiGet('https://api.spotify.com/v1/tracks/'+encodeURIComponent(uri.split(':')[2]),1600),full=this.queuedLyricInfo(raw);
          if(full?.uri===uri)info=full;
        }catch{}
        if(signal.aborted || this.destroyed)throw new Error('Lyrics cancelled');
        const abort=new AbortController(),cancel=()=>abort.abort();signal.addEventListener('abort',cancel,{once:true});
        const timer=setTimeout(cancel,7500);
        try{const backup=await this.fetchBackupLyrics(info,abort.signal,!lyrics);if(!lyrics || backup.timed)lyrics=backup;}catch(error){if(!lyrics)throw error;}finally{clearTimeout(timer);signal.removeEventListener('abort',cancel);}
      }
      if(signal.aborted || this.destroyed)throw new Error('Lyrics cancelled');
      if(!lyrics)throw new Error('Lyrics unavailable');return lyrics;
    }
    showTrackLyrics(uri,lyrics){
      this.lyricsLoadedURI=uri;this.lyricLines=lyrics.lines;this.lyricTimed=lyrics.timed;this.lyricProvider=lyrics.provider;this.lyricSource=lyrics.source || (lyrics.provider==='LRCLIB' ? 'lrclib' : 'spotify');this.matchLyricLine=false;
      this.lyricInstrumental=lyrics.instrumental;this.lyricState=lyrics.lines.length ? 'ready' : 'empty';this.lyricIndex=-2;
      this.paintLyrics();this.applyLyricsLayout();this.updateLyricPosition();
    }
    async loadLyrics(force=false){
      const uri=this.lastURI;if(!this.wantsLyricsLookup() || !/^spotify:track:[\w-]+$/.test(uri || ''))return;
      if(!force && (this.lyricsLoadedURI===uri || this.lyricsInFlight===uri))return;
      const cached=!force && this.lyricsCache.get(uri);
      if(cached){this.showTrackLyrics(uri,cached);return;}
      if(force && this.lyricPrefetch?.uri===uri)this.cancelLyricPrefetch();
      this.lyricsAbort?.abort();
      const warmed=!force && this.lyricPrefetch?.uri===uri && !this.lyricPrefetch.abort.signal.aborted && !this.lyricPrefetch.done ? this.lyricPrefetch : null;
      const abort=warmed?.abort || new AbortController();this.lyricsAbort=abort;
      const token=++this.lyricsToken;this.lyricsInFlight=uri;this.lyricState='loading';this.paintLyrics();
      try{
        const lyrics=warmed ? await warmed.promise : await this.fetchTrackLyrics(uri,{...this.currentTrackMeta},abort.signal,()=>{
          if(!this.destroyed && token===this.lyricsToken && uri===this.lastURI)this.$('lt-lyrics-status').textContent='Searching more lyric sources…';
        });
        if(!lyrics)throw new Error('Lyrics unavailable');
        if(this.destroyed || abort.signal.aborted || !this.wantsLyricsLookup() || token!==this.lyricsToken || uri!==this.lastURI)return;
        this.cacheLyrics(uri,lyrics);this.showTrackLyrics(uri,lyrics);
      }catch{
        if(!this.destroyed && !abort.signal.aborted && token===this.lyricsToken && uri===this.lastURI){this.lyricsLoadedURI=uri;this.lyricLines=[];this.lyricState='unavailable';this.paintLyrics();this.applyLyricsLayout();}
      }finally{if(token===this.lyricsToken)this.lyricsInFlight=null;}
    }
    loadLyricOffsets(){
      const offsets=new Map();
      try{
        const data=JSON.parse(localStorage.getItem(this.storageKey('lyric-timing')) || '[]');
        if(Array.isArray(data))for(const row of data.slice(-500))if(/^spotify:track:[\w-]+$/.test(row?.uri || '') && ['spotify','lrclib'].includes(row?.source) && Number.isFinite(row.ms))offsets.set(row.uri+'|'+row.source,{...row,ms:clamp(Math.round(row.ms),-15000,15000)});
      }catch{ /* Ignore corrupt timing records without changing other preferences. */ }
      return offsets;
    }
    lyricTimingKey(){return this.lastURI+'|'+(this.lyricSource || 'spotify');}
    lyricOffset(){return this.lyricOffsets.get(this.lyricTimingKey())?.ms || 0;}
    setLyricOffset(ms){
      if(!this.lastURI || !this.lyricTimed || !this.lyricLines.length)return;
      const value=clamp(Math.round(ms),-15000,15000),key=this.lyricTimingKey();
      this.lyricOffsets.delete(key);if(value)this.lyricOffsets.set(key,{uri:this.lastURI,source:this.lyricSource || 'spotify',ms:value,at:Date.now()});
      while(this.lyricOffsets.size>500)this.lyricOffsets.delete(this.lyricOffsets.keys().next().value);
      try{localStorage.setItem(this.storageKey('lyric-timing'),JSON.stringify([...this.lyricOffsets.values()]));}catch{this.notify('Timing works for this session, but could not be saved.');}
      this.matchLyricLine=false;this.lyricIndex=-2;this.lyricScrollUntil=0;this.updateTimingControls();this.updateLyricPosition();
    }
    showLyricsMenu(show, focus=false){
      const menu=this.$?.('lt-lyrics-menu');if(!menu || !show && menu.hidden)return;
      menu.hidden=!show;
      const trigger=this.nowPlaying.querySelector('[data-action="lyricsMenu"]');
      trigger.setAttribute('aria-expanded',String(show));
      if(show)this.positionLyricsMenu();
      if(focus){if(show)requestAnimationFrame(()=>{if(!this.destroyed && !menu.hidden && this.nowPlaying.open)menu.querySelector('button').focus({preventScroll:true});});else trigger.focus({preventScroll:true});}
    }
    positionLyricsMenu(){
      const menu=this.$('lt-lyrics-menu');if(menu.hidden)return;
      const anchor=this.nowPlaying.querySelector('[data-action="lyricsMenu"]').getBoundingClientRect(),rect=menu.getBoundingClientRect();
      if(anchor.bottom<0 || anchor.top>innerHeight){this.showLyricsMenu(false);return;}
      const top=anchor.bottom+8+rect.height<=innerHeight-12 ? anchor.bottom+8 : anchor.top-rect.height-8;
      menu.style.left=Math.max(12,Math.min(anchor.right-rect.width,innerWidth-rect.width-12))+'px';
      menu.style.top=Math.max(12,Math.min(top,innerHeight-rect.height-12))+'px';
    }
    showLyricTiming(show){
      this.showLyricsMenu(false,true);
      this.$('lt-lyric-timing').hidden=!show;this.matchLyricLine=false;
      this.nowPlaying.querySelector('[data-action="lyricTiming"]').setAttribute('aria-expanded',String(show));
      this.updateTimingControls();if(show)this.animateSurface(this.$('lt-lyric-timing'));else this.animateSurface(this.$('lt-lyrics-lines'));
    }
    updateTimingControls(){
      if(!this.$?.('lt-timing-value'))return;
      const offset=this.lyricOffset(),ready=this.lyricsVisible() && this.lyricTimed && this.lyricLines.length>0 && this.lyricState==='ready';
      this.$('lt-timing-value').textContent=offset ? `${(Math.abs(offset)/1000).toFixed(2)} s ${offset>0 ? 'earlier' : 'later'}` : 'Original timing';
      this.$('lt-timing-note').textContent='Saved for this recording.';
      this.$('lt-timing-help').textContent=this.matchLyricLine ? 'Tap the line you hear now. This adjusts timing without moving playback.' : ready ? 'Lyrics late? Tap Earlier. Or choose Match a line, then tap the line you hear.' : 'Timing controls become available with synced lyrics.';
      for(const action of ['lyricsEarlier','lyricsLater','lyricsTimingReset','lyricsMatchLine']){const button=this.nowPlaying.querySelector(`[data-action="${action}"]`);button.disabled=!ready;}
      this.nowPlaying.querySelector('[data-action="lyricsEarlier"]').disabled=!ready || offset>=15000;
      this.nowPlaying.querySelector('[data-action="lyricsLater"]').disabled=!ready || offset<=-15000;
      this.nowPlaying.querySelector('[data-action="lyricsMatchLine"]').setAttribute('aria-pressed',String(Boolean(this.matchLyricLine)));
      if(this.matchLyricLine)this.$('lt-lyrics-status').textContent='Tap the line you hear now to match timing.';
      else if(this.lyricState==='ready')this.$('lt-lyrics-status').textContent=(this.lyricTimed ? '' : 'Text-only lyrics · seeking unavailable');
      for(const b of this.$('lt-lyrics-lines').children){const line=this.lyricLines[Number(b.dataset.lyricIndex)];b.disabled=!this.lyricTimed || !line || line.at<0 || !this.matchLyricLine && this.seek.disabled;if(line)b.setAttribute('aria-label',`${this.matchLyricLine ? 'Match current playback to' : 'Seek to '+time(line.at-offset)+':'} ${line.text}`);}
    }
    paintLyrics(){
      const container=this.$?.('lt-lyrics-lines');if(!container)return;
      cancelAnimationFrame(this.lyricScrollFrame);container.replaceChildren();
      const status=this.lyricState==='loading' ? 'Finding lyrics…' : this.lyricLines.length ? (this.lyricTimed ? '' : 'Text-only lyrics · seeking unavailable') : this.lyricInstrumental ? 'Instrumental · no sung lyrics for this recording.' : this.lyricState==='unavailable' ? 'No lyrics found for this recording. Choose Reload lyrics from the options menu, or enable the backup source in Settings.' : 'Lyrics appear here when available.';
      this.$('lt-lyrics-status').textContent=status;
      this.$('lt-lyrics-panel').setAttribute('aria-busy',String(this.lyricState==='loading'));
      this.lyricLines.forEach((line,index)=>{const b=node('button','lt-lyric-line',line.text);b.type='button';b.dataset.lyricIndex=String(index);b.disabled=!this.lyricTimed || line.at<0 || this.seek.disabled;b.setAttribute('aria-label',this.lyricTimed ? `Seek to ${time(line.at-this.lyricOffset())}: ${line.text}` : line.text);container.append(b);});
      this.lyricsSeekDisabled=this.seek.disabled;this.updateTimingControls();
      if(this.nowPlaying.open && this.lyricsVisible() && this.lyricLines.length)this.animateSurface(container);
    }
    syncLyricClock(){
      const wanted=!this.destroyed && this.nowPlaying?.open && this.lyricsVisible() && this.lyricTimed && this.lyricLines.length>0 && !document.hidden;
      const period=this.prefs.lowMemory ? 200 : 80;
      if(this.lyricsInterval && this.lyricsPeriod!==period){clearInterval(this.lyricsInterval);this.lyricsInterval=null;}
      if(wanted && !this.lyricsInterval){this.lyricsPeriod=period;this.lyricsInterval=setInterval(()=>this.updateLyricPosition(),period);}
      else if(!wanted && this.lyricsInterval){clearInterval(this.lyricsInterval);this.lyricsInterval=null;}
    }
    scrollLyricsTo(panel,top){
      cancelAnimationFrame(this.lyricScrollFrame);
      const end=clamp(top,0,Math.max(0,panel.scrollHeight-panel.clientHeight)),start=panel.scrollTop;
      if(this.prefs.lowMemory || !this.motionAllowed() || Math.abs(end-start)<2){panel.scrollTop=end;return;}
      const began=performance.now();
      const duration=this.motionDuration(120,'lyricScrollSpeed');
      const tick=now=>{
        if(this.destroyed || !this.nowPlaying.open || !this.lyricsVisible() || Date.now()<(this.lyricScrollUntil || 0))return;
        const t=clamp((now-began)/duration,0,1);panel.scrollTop=start+(end-start)*(1-Math.pow(1-t,3));
        if(t<1)this.lyricScrollFrame=requestAnimationFrame(tick);else this.lyricScrollFrame=0;
      };
      this.lyricScrollFrame=requestAnimationFrame(tick);
    }
    updateLyricPosition(){
      if(!this.lyricsVisible() || !this.lyricTimed || !this.lyricLines.length)return;
      const progress=number(read(()=>this.player.getProgress(),0))+this.lyricOffset();let lo=0,hi=this.lyricLines.length;
      while(lo<hi){const mid=(lo+hi)>>1;if(this.lyricLines[mid].at<=progress)lo=mid+1;else hi=mid;}
      const index=lo-1;if(index===this.lyricIndex)return;this.lyricIndex=index;
      const children=this.$('lt-lyrics-lines').children;
      for(let i=0;i<children.length;i++){children[i].classList.toggle('lt-lyric-active',i===index);if(i===index)children[i].setAttribute('aria-current','true');else children[i].removeAttribute('aria-current');}
      const panel=this.$('lt-lyrics-lines'),active=children[index];
      if(active)this.playMotion(active,[{opacity:.7,transform:'translateY(3px)'},{opacity:1,transform:'none'}],{motion:'lyricLineSpeed',duration:100});
      if(this.lyricsVisible() && active && Date.now()>(this.lyricScrollUntil || 0)){
        const top=active.getBoundingClientRect().top-panel.getBoundingClientRect().top+panel.scrollTop-panel.clientHeight*.4;
        this.scrollLyricsTo(panel,top);
      }
    }
    lyricsVisible(){
      if(this.lyricOverride?.uri===this.lastURI)return this.lyricOverride.visible;
      return Boolean(this.prefs.lyrics && this.lastURI && this.lyricsLoadedURI===this.lastURI && this.lyricState==='ready' && this.lyricLines.length);
    }
    wantsLyricsLookup(){
      if(this.lyricOverride?.uri===this.lastURI)return this.lyricOverride.visible;
      return this.prefs.lyrics;
    }
    applyLyricsLayout(){
      if(!this.nowPlaying)return;
      const enabled=this.lyricsVisible(),changed=this.lastLyricsLayout!==undefined && this.lastLyricsLayout!==enabled;
      const previous=changed ? this.lyricLayoutRects() : new Map();
      if(changed && !enabled)this.makeLyricExitGhost();
      else if(enabled){this.lyricExitGhost?.remove();this.lyricExitGhost=null;}
      this.nowPlaying.dataset.lyrics=String(enabled);this.$('lt-lyrics-panel').hidden=!enabled;this.lastLyricsLayout=enabled;
      const b=this.nowPlaying.querySelector('[data-action="toggleLyrics"]');b?.setAttribute('aria-pressed',String(enabled));
      if(!enabled){this.showLyricsMenu(false);cancelAnimationFrame(this.lyricScrollFrame);}
      // A hidden panel may still be looking up this song. Do not cancel the
      // lookup simply because no lyrics have arrived yet.
      if(!this.wantsLyricsLookup()){this.lyricsToken++;this.lyricsAbort?.abort();this.lyricsInFlight=null;}
      else if(this.nowPlaying.open && !document.hidden)void this.loadLyrics();
      if(changed)this.animateLyricLayout(previous,enabled);
      this.updateTimingControls();this.syncLyricClock();
    }
    toggleLyrics(){
      this.lyricOverride={uri:this.lastURI,visible:!this.lyricsVisible()};this.applyLyricsLayout();
    }

    storageKey(name) {
      return `liquid-touch.${name}.v1:${this.accountNamespace}`;
    }
    async initHistory() {
      // This database and the preference key deliberately do not contain the
      // release version. Updating the runtime never resets personal data.
      const legacy=this.playHistory.slice();
      try {
        this.historyDB=await new Promise((resolve,reject)=>{
          const request=indexedDB.open('liquid-touch.history.v1',1);
          request.onupgradeneeded=()=>{const db=request.result,store=db.createObjectStore('plays',{keyPath:'id'});store.createIndex('account','account');db.createObjectStore('meta');};
          request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);
          request.onblocked=()=>reject(new Error('History storage is busy in another window.'));
        });
        const db=this.historyDB;
        db.onversionchange=()=>db.close();
        const rows=await new Promise((resolve,reject)=>{
          const tx=db.transaction(['plays','meta'],'readwrite'),store=tx.objectStore('plays'),meta=tx.objectStore('meta');let saved=[];
          const marker=meta.get('migrated:'+this.accountNamespace);
          marker.onsuccess=()=>{
            if(!marker.result){for(const row of legacy)store.put(this.historyRecord(row));meta.put(true,'migrated:'+this.accountNamespace);}
            const request=store.index('account').getAll(this.accountNamespace);request.onsuccess=()=>saved=request.result;
          };
          tx.oncomplete=()=>resolve(saved);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error || new Error('History import was interrupted.'));
        });
        if(this.destroyed)return;
        const merged=new Map(rows.map(row=>[row.id,row]));
        for(const [id,row] of this.sessionHistory)merged.set(id,row);
        this.playHistory=[...merged.values()].sort((a,b)=>b.at-a.at);
        this.historyState='saved';this.enforceHistoryLimit();
      } catch(error) {
        this.historyState='session';this.historyError='History storage is unavailable. Existing saved plays have not been removed. New plays will use local storage if possible.';
      }
      if(this.historyPage?.open)this.renderHistory();
    }
    historyRecord(row) {
      return {...row,account:this.accountNamespace,image:row.image?.length<2048 ? row.image : ''};
    }
    saveHistoryRow(row) {
      this.sessionHistory.set(row.id,row);
      this.historyWrites=this.historyWrites.then(async()=>{
        if(!this.historyDB){this.persistRecords('play-history',this.playHistory);return;}
        await new Promise((resolve,reject)=>{
          const tx=this.historyDB.transaction('plays','readwrite');tx.objectStore('plays').put(this.historyRecord(row));
          tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error || new Error('History was not saved.'));
        });
        if(this.sessionHistory.get(row.id)===row)this.sessionHistory.delete(row.id);
      }).catch(()=>{
        this.historyState='session';this.historyError='Storage is full or unavailable. Existing saved history is safe; new plays stay in this session until storage is available.';
        if(!this.destroyed){this.notify(this.historyError);if(this.historyPage.open)this.renderHistory();}
      });
    }
    enforceHistoryLimit() {
      const limit=this.prefs.historySongLimit;
      if(!limit || this.playHistory.length<=limit)return;
      const removed=this.playHistory.splice(limit),ids=new Set(removed.map(row=>row.id));
      for(const id of ids)this.sessionHistory.delete(id);
      this.historyWrites=this.historyWrites.then(async()=>{
        if(this.historyDB)await new Promise((resolve,reject)=>{
          const tx=this.historyDB.transaction('plays','readwrite');for(const id of ids)tx.objectStore('plays').delete(id);
          tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error || new Error('History limit could not be saved.'));
        });
        // Keep any legacy backup in agreement with a user-selected cap.
        if(!this.historyDB || localStorage.getItem(this.storageKey('play-history')))this.persistRecords('play-history',this.playHistory);
      }).catch(()=>{this.historyState='session';this.historyError='The selected history limit could not be saved. Older saved plays are still on this device.';if(!this.destroyed)this.notify(this.historyError);});
    }
    setHistoryLimit(value) {
      if(![0,100,500,1000,5000,10000].includes(value))return;
      this.prefs.historySongLimit=value;this.save();
      for(const input of document.querySelectorAll('[data-history-limit]'))input.value=String(value);
      // Wait for migration before deciding which records are oldest.
      void this.historyReady.then(()=>{if(this.destroyed)return;this.enforceHistoryLimit();this.renderHistory();});
    }
    async clearListeningHistory() {
      await this.historyReady;
      const ids=new Set(this.playHistory.map(row=>row.id));
      const task=this.historyWrites.then(async()=>{
        if(this.historyDB)await new Promise((resolve,reject)=>{
          const tx=this.historyDB.transaction(['plays','meta'],'readwrite'),store=tx.objectStore('plays');
          for(const id of ids)store.delete(id);
          tx.objectStore('meta').put(true,'migrated:'+this.accountNamespace);
          tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error || new Error('History could not be cleared.'));
        });
        // Delete the old import backup only after the database transaction has
        // committed. A failed clear must never erase the last saved copy.
        try{localStorage.removeItem(this.storageKey('play-history'));}catch{if(!this.historyDB)throw new Error('Local history could not be cleared.');}
        this.playHistory=this.playHistory.filter(row=>!ids.has(row.id));
        for(const id of ids)this.sessionHistory.delete(id);
        this.historyLimit=100;if(this.historyPage.open)this.renderHistory();
      });
      this.historyWrites=task.catch(()=>{});
      await task;
    }
    loadRecords(name, limit) {
      try {
        const parsed=JSON.parse(localStorage.getItem(this.storageKey(name)) || '[]');
        if(!Array.isArray(parsed))return [];
        return parsed.slice(0,limit).filter(row=>row && typeof row==='object').map(row=>{
          if(name==='search-queries')return {query:cleanText(row.query,300),at:number(row.at)};
          const entity=normalizeEntity({...row,name:row.title});
          return entity ? {...entity,artist:cleanText(row.artist),album:cleanText(row.album),at:number(row.at)} : null;
        }).filter(row=>row && (name!=='search-queries' || row.query));
      } catch { return []; }
    }
    persistRecords(name, records) {
      const serializable=()=>records.map(row=>({...row,image:row.image?.length<2048 ? row.image : ''}));
      try { localStorage.setItem(this.storageKey(name),JSON.stringify(serializable())); }
      catch {
        if(!this.storageWarning){this.storageWarning=true;this.notify('Local storage is full or unavailable. New history stays in this session.');}
      }
    }
    collectNativeEntities(root) {
      const found=new Map(); if(!root)return found;
      const selectors='a[href], [data-uri], [data-context-uri], [id^="listrow-title-spotify:"]';
      for(const element of root.querySelectorAll(selectors)){
        const raw=element.dataset.uri || element.dataset.contextUri || element.getAttribute('href') || element.id.replace(/^listrow-title-/,'');
        const info=uriInfo(raw);if(!info)continue;
        let card=element.closest('.main-card-card, [data-testid="card"], [data-testid="card-container"], [data-testid="grid-card"], [data-testid="shortcut"], [data-encore-id="card"], .main-yourLibraryX-listItem, [role="row"], [role="treeitem"], li');
        if(!card){
          let parent=element;
          for(let i=0;i<5 && parent && parent!==root;i++,parent=parent.parentElement){
            const count=parent.querySelectorAll('img').length;
            if(count===1){card=parent;break;}
          }
        }
        if(!card)continue;
        const titleNode=card.querySelector('[data-testid="entityTitle"], [id^="listrow-title-"], .main-cardHeader-text, .main-cardHeader-link, h3, h2, strong');
        const title=cleanText(titleNode?.textContent || element.getAttribute('aria-label') || element.textContent,300).replace(/^Play\s+/i,'');
        if(!title || title.length>250)continue;
        const images=[...card.querySelectorAll('img')].filter(image=>!image.closest('[data-testid*="equaliz"], [data-testid*="equalis"], [class*="equaliz"], [class*="equalis"], [data-testid="playing-indicator"], [aria-label="Playing"]'));
        const image=images.find(image=>image.matches('.main-cardImage-image, [data-testid="card-image"], [data-testid="cover-art-image"]') && imageURL(image.currentSrc || image.getAttribute('src'))) || images.find(image=>imageURL(image.currentSrc || image.getAttribute('src')));
        const subtitle=cleanText(card.querySelector('.main-cardSubHeader-root, [data-testid="entitySubtitle"], [class*="subtitle"]')?.textContent,300);
        const section=cleanText(card.closest('section, [data-testid="component-shelf"]')?.querySelector('h2,h3')?.textContent,100);
        const entity=normalizeEntity({...info,name:title,subtitle,imageUrl:image?.currentSrc || image?.getAttribute('src'),section});
        if(entity){
          // A lazy image or playing state must not erase an already known cover.
          entity.image ||= this.homeEntities.get(entity.uri)?.image || this.libraryEntities.get(entity.uri)?.image || this.entities.get(entity.uri)?.image || this.artCache.get(entity.uri)?.image || '';
          found.set(entity.uri,entity);
        }
      }
      return found;
    }
    captureNativeCatalog() {
      let changed=false;
      const merge=(source,target)=>{for(const [uri,entry] of source){
        const old=target.get(uri);
        if(old && target===this.libraryEntities && ['platform','rootlist'].includes(this.librarySource)){
          if(!old.image && entry.image){target.set(uri,{...old,image:entry.image});changed=true;}
          continue;
        }
        entry.image ||= old?.image || '';
        if(!old || old.title!==entry.title || old.image!==entry.image || old.section!==entry.section){target.set(uri,entry);changed=true;}
        this.entities.set(uri,target.get(uri));
      }};
      if((this.history.location?.pathname || '/')==='/'){
        const snapshot=this.collectNativeEntities(this.main);
        // Native Home is a snapshot, not an append-only list. Preserve its new
        // ordering and discard shelves Spotify has replaced after playback.
        if(snapshot.size){
          const signature=map=>JSON.stringify([...map].map(([uri,e])=>[uri,e.title,e.subtitle,e.image,e.section]));
          if(signature(snapshot)!==signature(this.homeEntities)){
            this.homeEntities=snapshot;for(const [uri,entry] of snapshot)this.entities.set(uri,entry);changed=true;
          }
        }
      }
      if(/^\/search\/?$/.test(this.history.location?.pathname || '')){
        for(const section of this.main?.querySelectorAll('section, [data-testid="recent-searches"]') || []){
          if(section.dataset.testid==='recent-searches' || /recent.*search|search.*recent/i.test(section.querySelector('h2,h3')?.textContent || '')){
            for(const entry of this.collectNativeEntities(section).values()){
              if(!this.recentSearches.some(row=>row.uri===entry.uri)){this.recentSearches.push({...entry,at:Date.now()});changed=true;}
            }
          }
        }
        if(this.recentSearches.length>50)this.recentSearches.length=50;
        if(changed)this.persistRecords('search-items',this.recentSearches);
      }
      merge(this.collectNativeEntities(this.library),this.libraryEntities);
      if(changed){this.catalogVersion++;if(this.browse)this.renderBrowse();}
    }
    async readLibraryPage(api) {
      const rows=result=>result?.items || result?.data?.items || result?.rows;
      if(!this.libraryLanes){
        try {
          const result=await api.getContents({filters:[],offset:this.libraryOffset,limit:100,flattenTree:true});
          const items=rows(result);
          if(!Array.isArray(items))throw new Error('Unknown library shape');
          if(items.length || this.libraryOffset>0)return result;
        }catch{ /* Older clients require explicit playlist/album/artist lanes. */ }
        this.libraryLanes=['2','0','1'].map(filter=>({filter,offset:0,more:true}));
      }
      const lanes=this.libraryLanes.filter(lane=>lane.more);
      const results=await Promise.allSettled(lanes.map(async lane=>({lane,result:await api.getContents({filters:[lane.filter],offset:lane.offset,limit:100,flattenTree:true})})));
      const items=[];let valid=0;
      results.forEach((response,i)=>{
        const lane=lanes[i];
        if(response.status!=='fulfilled'){lane.more=false;return;}
        const page=rows(response.value.result);if(!Array.isArray(page)){lane.more=false;return;}
        valid++;items.push(...page);lane.offset+=page.length;
        const total=response.value.result.totalLength ?? response.value.result.totalCount;
        lane.more=page.length>0 && (typeof total==='number' ? lane.offset<total : page.length>=100);
      });
      if(!valid && lanes.length)throw new Error('Library lanes unavailable');
      return {items,hasMore:this.libraryLanes.some(lane=>lane.more)};
    }
    async loadLibrary(reset=false) {
      if(this.libraryBusy || this.destroyed)return;
      if(!reset && !this.libraryHasMore)return;
      this.libraryBusy=true;
      if(reset){this.libraryOffset=0;this.libraryLanes=null;this.libraryHasMore=true;this.libraryEntities.clear();}
      const add=items=>{
        let added=0;
        for(const raw of items){
          const entry=normalizeEntity(raw);
          if(entry){if(!this.libraryEntities.has(entry.uri))added++;this.libraryEntities.set(entry.uri,entry);this.entities.set(entry.uri,entry);}
          if(Array.isArray(raw?.items))added+=add(raw.items);
          if(Array.isArray(raw?.children))added+=add(raw.children);
        }
        return added;
      };
      try {
        const api=this.S.Platform?.LibraryAPI;
        if(typeof api?.getContents==='function'){
          const result=await this.readLibraryPage(api);
          if(this.destroyed)return;
          const items=result?.items || result?.data?.items || result?.rows;
          if(!Array.isArray(items))throw new Error('Unrecognized library response');
          const added=add(items);this.libraryOffset+=items.length;
          const total=result.totalLength ?? result.totalCount ?? result.total;
          this.libraryHasMore=result.hasMore ?? (items.length>0 && (typeof total==='number' ? this.libraryOffset<total : items.length>=100));
          if(this.libraryOffset>items.length && !added)this.libraryHasMore=false;
          this.librarySource='platform';
        }else throw new Error('Library API unavailable');
      } catch {
        try {
          const root=this.S.Platform?.RootlistAPI;
          if(typeof root?.getContents!=='function')throw new Error('Rootlist unavailable');
          const result=await root.getContents();if(this.destroyed)return;
          const items=result?.items || result?.rows || result?.contents?.items;
          if(!Array.isArray(items))throw new Error('Unrecognized rootlist');
          add(items);this.librarySource='rootlist';
        } catch { this.librarySource='native'; }
        this.libraryHasMore=false;
      } finally {
        this.libraryBusy=false;
        if(!this.destroyed){this.catalogVersion++;this.captureNativeCatalog();this.renderBrowse();}
      }
    }
    detailInfo(path=this.getRoutePath()){const info=uriInfo(path);return info && path.startsWith('/') && info.path===path ? info : null;}
    detailState(info){
      let page=this.detailPages.get(info.uri);
      if(!page && this.previewMode)return {entry:this.entities.get(info.uri) || normalizeEntity({...info,name:'Your music'}),tracks:[],releases:[],loading:true,version:0,loadedAt:0,nextOffset:0,hasMore:false,error:''};
      if(!page){
        const entry=this.entities.get(info.uri) || this.homeEntities.get(info.uri) || this.libraryEntities.get(info.uri) || normalizeEntity({uri:info.uri,name:info.type==='collection' ? 'Liked Songs' : 'Your music'});
        page={entry:{...entry},tracks:[],releases:[],loading:true,version:0,loadedAt:0,nextOffset:0,hasMore:false,error:''};this.detailPages.set(info.uri,page);
        while(this.detailPages.size>(this.prefs.lowMemory ? 2 : 12)){const key=this.detailPages.keys().next().value;if(key===info.uri)break;this.detailPages.delete(key);}
        void Promise.resolve().then(()=>this.loadDetail(page));
      }
      return page;
    }
    detailRows(group){return Array.isArray(group) ? group : Array.isArray(group?.items) ? group.items : Array.isArray(group?.edges) ? group.edges : null;}
    detailItem(row){
      let value=row;
      for(let i=0;i<5 && value && typeof value==='object';i++){
        const next=value.item?.data || value.item || value.track?.data || value.track || value.episode?.data || value.episode || value.node || value.data;
        if(!next || next===value)break;value=next;
      }
      return value;
    }
    parseDetail(result,entry,offset=0){
      const data=result?.data || result;
      const names={playlist:['playlistV2','playlist'],album:['albumUnion','album'],artist:['artistUnion','artist'],track:['trackUnion','track'],episode:['episodeUnion','episode'],show:['podcastUnion','podcast','show'],collection:['me']};
      const root=(names[entry.type] || []).map(key=>data?.[key]).find(Boolean) || data;
      if(!root || typeof root!=='object' || Array.isArray(root))throw new Error('Unknown detail response');
      const group=entry.type==='artist' ? root.discography?.topTracks || root.topTracks || root.topTracksV2 || root.tracks : entry.type==='album' ? root.tracksV2 || root.tracks : entry.type==='show' ? root.episodesV2 || root.episodes : entry.type==='track' || entry.type==='episode' ? [root] : root.contents || root.content || root.tracks || root;
      const rows=this.detailRows(group);if(!rows)throw new Error('Detail items unavailable');
      const meta=normalizeEntity({...root,uri:entry.uri,name:root.name || root.profile?.name || root.metadata?.name || entry.title});
      if(meta){meta.image=pickArtwork(root.images || root.coverArt || root.visuals || root.image || root.metadata?.image_xlarge_url || root.metadata?.image_url) || entry.image;meta.subtitle=meta.subtitle==='Playlist' || meta.subtitle==='Album' || meta.subtitle==='Artist' ? entry.subtitle : meta.subtitle;}
      const tracks=[];
      rows.forEach((row,index)=>{const raw=this.detailItem(row),track=normalizeEntity(raw);if(track && ['track','episode'].includes(track.type))tracks.push({...track,uid:cleanText(row?.uid || row?.item?.uid || row?.track?.uid || row?.item?.data?.uid || raw?.uid,500),duration:number(raw?.duration?.totalMilliseconds || raw?.duration?.milliseconds || raw?.duration_ms || raw?.duration || raw?.metadata?.duration),unavailable:raw?.is_playable===false || raw?.isPlayable===false || raw?.playability?.playable===false,sourceIndex:offset+index});});
      const releases=[],seen=new Set();
      const visit=(value,depth=0)=>{if(!value || depth>5)return;if(Array.isArray(value)){for(const row of value)visit(row,depth+1);return;}const entity=normalizeEntity(this.detailItem(value));if(entity?.type==='album' && !seen.has(entity.uri)){seen.add(entity.uri);releases.push(entity);return;}for(const key of ['items','releases','albums','singles','data','item'])visit(value[key],depth+1);};
      if(entry.type==='artist')for(const key of ['albums','singles','all','popularReleases','latest'])visit(root.discography?.[key] || root[key]);
      const total=number(group?.totalCount ?? group?.totalLength ?? group?.total ?? root.totalLength,NaN),nextOffset=offset+rows.length;
      const hasMore=!['artist','track','episode'].includes(entry.type) && rows.length>0 && (Number.isFinite(total) ? nextOffset<total : typeof group?.next==='string' || rows.length>=50);
      return {meta,tracks,releases,total,nextOffset,hasMore,description:cleanText(root.description,1000).replace(/<[^>]*>/g,' ')};
    }
    async detailQuery(name,entry,offset){
      const gql=this.S.GraphQL,definition=gql?.Definitions?.[name] || gql?.QueryDefinitions?.[name];if(!definition || typeof gql.Request!=='function')throw new Error('Client query unavailable');
      return this.withTimeout(gql.Request(definition,{uri:entry.uri,locale:this.S.Platform?.Session?.locale || 'en',offset,limit:50,includePrerelease:true,includePreReleases:true},{persistCache:true}),2300);
    }
    async fetchDetail(entry,offset=0){
      const type=entry.type,id=encodeURIComponent(entry.path.split('/')[2] || ''),query=new URLSearchParams({limit:'50',offset:String(offset)}),platform=this.S.Platform;
      if(type==='playlist' && typeof platform?.PlaylistAPI?.getContents==='function'){
        try{
          const result=await this.withTimeout(platform.PlaylistAPI.getContents(entry.uri,{offset,limit:50}),2300),page=this.parseDetail(result,entry,offset);
          if(!offset && typeof platform.PlaylistAPI.getMetadata==='function'){
            void this.withTimeout(platform.PlaylistAPI.getMetadata(entry.uri),1800).then(meta=>this.updateDetailMetadata(entry.uri,meta)).catch(()=>{});
          }
          return page;
        }catch{ /* Try the installed query or authenticated catalog next. */ }
      }
      if(type==='collection' && typeof platform?.LibraryAPI?.getTracks==='function')try{return this.parseDetail(await this.withTimeout(platform.LibraryAPI.getTracks({offset,limit:50}),2300),entry,offset);}catch{}
      const definition={playlist:'FetchPlaylistContents',album:'getAlbum',artist:'queryArtistOverview',track:'getTrack',episode:'getEpisode',show:'queryPodcastEpisodes'}[type];
      if(definition)try{return this.parseDetail(await this.detailQuery(definition,entry,offset),entry,offset);}catch{}
      if(type==='album' && typeof platform?.LibraryAPI?.getAlbum==='function')try{return this.parseDetail(await this.withTimeout(platform.LibraryAPI.getAlbum(entry.uri,{offset,limit:50}),1800),entry,offset);}catch{}
      const get=path=>this.apiGet('https://api.spotify.com/v1/'+path,2600);
      if(type==='artist'){
        const results=await Promise.allSettled([get(`artists/${id}`),get(`artists/${id}/top-tracks`),get(`artists/${id}/albums?limit=50`)]);
        const value=index=>results[index].status==='fulfilled' ? results[index].value : null;
        const meta=value(0),top=value(1),albums=value(2);if(!Array.isArray(top?.tracks) && !Array.isArray(albums?.items))throw new Error('Artist items unavailable');
        return this.parseDetail({...meta,uri:entry.uri,name:meta?.name || entry.title,topTracks:{items:top?.tracks || []},albums:{items:albums?.items || []}},entry,0);
      }
      if(type==='playlist'){
        const result=await get(`playlists/${id}/tracks?${query}`),page=this.parseDetail(result,entry,offset);
        if(!offset)void get(`playlists/${id}`).then(meta=>this.updateDetailMetadata(entry.uri,meta)).catch(()=>{});
        return page;
      }
      if(type==='collection')return this.parseDetail(await get('me/tracks?'+query),entry,offset);
      if(type==='album' || type==='show'){
        if(!offset)return this.parseDetail(await get(`${type}s/${id}`),entry,offset);
        const group=await get(`${type}s/${id}/${type==='album' ? 'tracks' : 'episodes'}?${query}`);
        return this.parseDetail({[type==='album' ? 'tracks' : 'episodes']:group},entry,offset);
      }
      if(type==='track' || type==='episode')return this.parseDetail(await get(`${type}s/${id}`),entry,0);
      throw new Error('Unsupported detail type');
    }
    updateDetailMetadata(uri,raw){
      const page=this.detailPages.get(uri);if(!page || this.destroyed)return;
      const meta=normalizeEntity({...raw,uri,name:raw?.name || raw?.metadata?.name || page.entry.title});if(!meta)return;
      page.entry={...page.entry,...meta,image:meta.image || page.entry.image};page.description=cleanText(raw?.description,1000).replace(/<[^>]*>/g,' ');page.metaVersion=(page.metaVersion || 0)+1;page.version++;
      if(meta.image)this.applyEntityArtwork(uri,meta.image);
      if(this.detailInfo()?.uri===uri && !this.libraryOpen)this.renderBrowse();
    }
    async loadDetail(page,more=false){
      const uri=page.entry.uri;if(page.fetching || this.destroyed)return;
      page.fetching=true;page.loading=true;page.error='';page.version++;
      if(this.detailInfo()?.uri===uri && !this.libraryOpen)this.renderBrowse();
      const offset=more ? page.nextOffset : 0,metaVersion=page.metaVersion || 0;
      try{
        const result=await this.fetchDetail(page.entry,offset);if(this.destroyed || this.detailPages.get(uri)!==page)return;
        if(result.meta && (page.metaVersion || 0)===metaVersion)page.entry={...page.entry,...result.meta,image:result.meta.image || page.entry.image};
        page.tracks=more ? [...page.tracks,...result.tracks] : result.tracks;page.releases=result.releases.length ? result.releases : page.releases;
        Object.assign(page,{hasMore:result.hasMore,nextOffset:result.nextOffset,total:result.total,description:result.description || page.description,loadedAt:Date.now()});
      }catch{
        if(this.destroyed || this.detailPages.get(uri)!==page)return;
        page.retryMore=more;page.error=more ? 'More songs could not be loaded. Your loaded songs are still available.' : 'Songs could not be loaded in this Spotify session. Try again, or open this item in the desktop interface.';
      }finally{
        page.loading=false;page.fetching=false;page.version++;
        if(!this.destroyed && this.detailInfo()?.uri===uri && !this.libraryOpen)this.renderBrowse();
      }
    }
    renderDetail(page){
      const entry=page.entry,hero=node('section','lt-detail-hero lt-glass');hero.dataset.detailUri=entry.uri;
      const art=node('div','lt-detail-art lt-art-placeholder');art.innerHTML=icon(entry.type==='collection' ? 'heart' : entry.type==='artist' ? 'spark' : 'play');
      if(entry.image){const image=node('img','');image.src=entry.image;image.alt='';image.decoding='async';art.append(image);}
      else if(entry.type!=='collection')this.queueArtwork(entry.uri);
      const text=node('div','lt-detail-copy');text.append(node('span','lt-eyebrow',{playlist:'PLAYLIST',album:'ALBUM',artist:'ARTIST',track:'SONG',episode:'EPISODE',show:'PODCAST',collection:'YOUR FAVORITES'}[entry.type]),node('h1','',entry.title),node('p','',entry.subtitle));
      if(page.description)text.append(node('p','lt-detail-description',page.description));
      const actions=node('div','lt-quick-actions'),play=node('button','lt-pill lt-detail-play','Play');play.type='button';play.dataset.detailAction='play';play.setAttribute('aria-label',`Play ${entry.title}`);actions.append(play);
      const desktop=node('button','lt-pill','Open in Spotify');desktop.type='button';desktop.dataset.detailAction='desktop';actions.append(desktop);text.append(actions);hero.append(art,text);this.browse.append(hero);
      const refresh=node('button','lt-pill','Refresh');refresh.type='button';refresh.dataset.detailAction='refresh';refresh.disabled=page.loading;actions.append(refresh);
      const status=node('p','lt-detail-status',page.loading ? page.tracks.length ? 'Loading more songs…' : 'Loading songs…' : page.error || `${page.tracks.length} ${page.tracks.length===1 ? 'song' : 'songs'}${page.hasMore ? ' loaded' : ''}`);status.setAttribute('role','status');this.browse.append(status);this.browse.setAttribute('aria-busy',String(page.loading));
      if(page.tracks.length){
        const section=node('section','lt-detail-songs');section.append(node('h2','lt-section-title',entry.type==='artist' ? 'Popular songs' : entry.type==='show' ? 'Episodes' : 'Songs'));const list=node('div','lt-detail-tracklist');
        const trackLimit=this.previewMode ? 8 : this.prefs.lowMemory ? (page.visibleTracks || 40) : page.tracks.length;
        page.tracks.slice(0,trackLimit).forEach((track,index)=>{
          const row=node('button','lt-detail-track lt-glass');row.type='button';row.dataset.detailTrack=String(index);row.disabled=track.unavailable;row.setAttribute('aria-label',`${track.unavailable ? 'Unavailable' : 'Play'} ${track.title}, ${track.subtitle}`);
          const number=node('span','lt-detail-number',String(index+1));row.append(number);
          if(track.image){const image=node('img','');image.src=track.image;image.alt='';image.loading='lazy';image.decoding='async';row.append(image);}
          const copy=node('span','lt-detail-track-copy');copy.append(node('strong','',track.title),node('span','',track.subtitle));row.append(copy,node('span','lt-detail-duration',track.duration ? time(track.duration) : ''));list.append(row);
        });section.append(list);this.browse.append(section);
        if(!this.previewMode && trackLimit<page.tracks.length){const more=node('button','lt-pill lt-glass','Show more loaded songs');more.type='button';more.dataset.detailAction='visibleMore';this.browse.append(more);}
      }else if(!page.loading && !page.error)this.browse.append(node('p','lt-empty','No playable songs are available in this item.'));
      if(page.releases.length)this.appendGrid(this.browse,'Releases',page.releases);
      if(page.error){const retry=node('button','lt-pill lt-glass','Try again');retry.type='button';retry.dataset.detailAction=page.retryMore ? 'more' : 'retry';this.browse.append(retry);}
      else if(page.hasMore){const more=node('button','lt-pill lt-glass',page.loading ? 'Loading…' : 'Load more songs');more.type='button';more.disabled=page.loading;more.dataset.detailAction='more';this.browse.append(more);}
    }
    makeCard(entry) {
      this.entities.set(entry.uri,entry);
      const article=node('article','lt-card lt-glass');article.dataset.uri=entry.uri;
      const face=node('button','lt-card-face');face.type='button';face.dataset.ltCard=entry.uri;
      face.setAttribute('aria-label',`${entry.title}. ${entry.type==='album' || entry.type==='playlist' || entry.type==='collection' ? 'Tap to play, double tap to open' : entry.type==='artist' || entry.type==='show' ? 'Open' : 'Play'}`);
      const art=node('span','lt-card-art');
      art.classList.add('lt-art-placeholder');art.innerHTML=icon(entry.type==='collection' ? 'heart' : entry.type==='artist' ? 'spark' : 'play');
      if(entry.image){const img=node('img','');img.src=entry.image;img.alt='';img.loading='lazy';img.decoding='async';img.onerror=()=>{img.hidden=true;this.queueArtwork(entry.uri);};art.append(img);}
      else if(entry.type!=='collection'){article.dataset.needsArt='true';if(!this.previewMode)this.imageObserver?.observe(article);}
      const title=node('strong','lt-card-title',entry.title);const typeLabel={track:'Song',artist:'Artist',album:'Album',playlist:'Playlist',collection:'Playlist',episode:'Episode',show:'Podcast'}[entry.type] || '';const subtitle=node('span','lt-card-subtitle',entry.subtitle===typeLabel ? typeLabel : `${typeLabel} · ${entry.subtitle}`);
      face.append(art,title,subtitle);
      const open=node('button','lt-card-open','Open');open.type='button';open.dataset.openUri=entry.uri;open.setAttribute('aria-label',`Open ${entry.title}`);
      article.append(face,open);return article;
    }
    appendGrid(parent, title, entries) {
      if(!entries.length)return;
      const section=node('section','lt-card-section');section.append(node('h2','lt-section-title',title));
      const key=this.libraryOpen ? 'library' : this.getRoutePath()+'|'+title;
      const limit=this.previewMode ? 8 : this.prefs.lowMemory ? (this.gridLimits?.get(key) || 24) : entries.length;
      const grid=node('div','lt-card-grid');for(const entry of entries.slice(0,limit))grid.append(this.makeCard(entry));
      section.append(grid);
      if(!this.previewMode && limit<entries.length){const more=node('button','lt-pill lt-glass','Show more');more.type='button';more.dataset.gridMore=key;section.append(more);}
      parent.append(section);
    }
    renderBrowse() {
      if(!this.browse || this.destroyed)return;
      const path=this.getRoutePath();
      const detail=!this.libraryOpen && this.detailInfo(path),page=detail ? this.detailState(detail) : null;
      const kind=this.libraryOpen ? 'library' : path==='/' ? 'home' : /^\/search\/?$/.test(path) ? 'search' : path.startsWith('/search/') ? 'results' : detail ? 'detail' : '';
      document.body.dataset.ltCustomPage=kind;
      this.browse.hidden=!kind;
      if(!kind)return;
      if(this.pointerHeld){this.browseDeferred=true;return;}
      const signature=(kind==='detail' ? [kind,path,page.version] : kind==='home' ? [kind,this.catalogVersion,this.homeRecentVersion,this.welcomeText(),this.prefs.welcomeSubtitle] : kind==='library' ? [kind,this.catalogVersion,this.libraryQuery,this.libraryFilter,this.libraryBusy,this.libraryHasMore] : kind==='results' ? [kind,path,this.searchResultVersion,this.searchFilter] : [kind,this.catalogVersion]).concat(this.prefs.lowMemory,this.gridVersion || 0).join('|');
      if(signature===this.browseSignature && kind===this.browseKind){this.refreshGreeting();return;}
      const active=document.activeElement;
      const focusId=this.browse.contains(active) ? active.id : '';
      const selection=focusId && active.selectionStart;
      const previousKind=this.browseKind,previousScroll=this.browse.scrollTop,detailChanged=kind==='detail' && this.browseDetailPath!==path;
      if(!this.previewMode && previousKind && previousKind!==kind && !this.prefs.lowMemory){
        this.imageObserver?.disconnect();const fragment=document.createDocumentFragment();fragment.append(...this.browse.childNodes);
        this.browsePages.set(previousKind,{signature:this.browseSignature,fragment,scroll:previousScroll});
      }
      const cached=this.browsePages.get(kind),scroll=detailChanged ? 0 : kind===previousKind ? previousScroll : cached?.scroll || 0;this.browseDetailPath=kind==='detail' ? path : null;
      this.browseSignature=signature;this.browsePages.delete(kind);
      if(kind!==previousKind && cached?.signature===signature){
        this.browseKind=kind;this.browse.replaceChildren(cached.fragment);this.browse.scrollTop=scroll;this.browseReuseCount=(this.browseReuseCount || 0)+1;
        if(!['results','detail'].includes(kind))this.browse.removeAttribute('aria-busy');
        if(!this.previewMode)for(const card of this.browse.querySelectorAll('.lt-card[data-needs-art]'))this.imageObserver?.observe(card);
        this.refreshGreeting();return;
      }
      this.browseBuildCount=(this.browseBuildCount || 0)+1;
      this.browseKind=kind;this.browse.replaceChildren();
      if(kind==='detail')this.renderDetail(page);
      else if(kind==='home'){
        const hero=node('section','lt-home-hero');
        const greeting=node('div','lt-home-greeting'),clock=node('time','lt-home-clock lt-glass');clock.id='lt-home-clock';clock.hidden=!this.prefs.homeClock;
        greeting.append(node('h1','',this.welcomeText()),clock);
        hero.append(node('span','lt-eyebrow','YOUR SPACE, YOUR SOUND'),greeting,node('p','',this.prefs.welcomeSubtitle));
        const actions=node('div','lt-quick-actions');
        for(const [label,action] of [['Liked Songs','likedSongs'],['Listening history','playHistory']]){const b=node('button','lt-pill lt-glass',label);b.type='button';b.dataset.action=action;actions.append(b);}
        hero.append(actions);this.browse.append(hero);this.refreshHomeClock();
        const recent=this.recentHome || [];this.appendGrid(this.browse,'Recently played',recent);
        const groups=new Map();
        for(const entry of this.homeEntities.values()){
          if(recent.some(row=>row.uri===entry.uri))continue;
          const section=entry.section || 'Jump back in';if(!groups.has(section))groups.set(section,[]);groups.get(section).push(entry);
        }
        const shelves=[...groups],shelfLimit=this.previewMode ? 2 : this.prefs.lowMemory ? (this.homeShelfLimit || 3) : Infinity;
        for(const [title,entries] of shelves.slice(0,shelfLimit))this.appendGrid(this.browse,title,entries);
        if(!this.previewMode && shelves.length>shelfLimit){const more=node('button','lt-pill lt-glass','Show more shelves');more.type='button';more.dataset.action='moreHomeShelves';this.browse.append(more);}
        if(!groups.size)this.appendGrid(this.browse,'From your library',[...this.libraryEntities.values()].filter(entry=>!recent.some(row=>row.uri===entry.uri)).slice(0,12));
        if(!groups.size && !this.libraryEntities.size)this.browse.append(node('p','lt-empty','Spotify is loading your music. Your recommendations will appear here.'));
        const more=node('button','lt-pill lt-glass','More from Spotify');more.type='button';more.dataset.action='moreHome';this.browse.append(more);
      }else if(kind==='library'){
        const heading=node('div','lt-page-heading');heading.append(node('span','lt-eyebrow','A COLLECTION THAT SOUNDS LIKE YOU'),node('h1','','Your Library'));
        const tools=node('div','lt-library-tools');
        const field=node('label','lt-field lt-glass');field.innerHTML=icon('search');
        const input=node('input','');input.type='search';input.id='lt-library-search';input.placeholder='Search your library';input.setAttribute('aria-label','Search your library');input.value=this.libraryQuery;field.append(input);
        const refresh=node('button','lt-pill lt-glass','Refresh');refresh.type='button';refresh.dataset.action='refreshLibrary';
        tools.append(field,refresh);
        const filters=node('div','lt-filter-bar');
        for(const [type,label] of [['all','All'],['playlist','Playlists'],['album','Albums'],['artist','Artists']]){
          const b=node('button','lt-pill lt-glass',label);b.type='button';b.dataset.libraryFilter=type;b.setAttribute('aria-pressed',String(this.libraryFilter===type));filters.append(b);
        }
        heading.classList.add('lt-library-heading');
        const controls=node('div','lt-library-controls');controls.append(tools,filters);
        this.browse.append(heading,controls,node('p','lt-note','Tap to play. Double tap to explore.'));
        const liked=normalizeEntity({uri:'spotify:collection:tracks',name:'Liked Songs',subtitle:'Your favorites, together'});
        const all=[liked,...this.libraryEntities.values()].filter((item,i,rows)=>rows.findIndex(r=>r.uri===item.uri)===i);
        const visible=all.filter(entry=>(this.libraryFilter==='all' || entry.type===this.libraryFilter || this.libraryFilter==='playlist' && entry.type==='collection') && `${entry.title} ${entry.subtitle}`.toLocaleLowerCase().includes(this.libraryQuery.toLocaleLowerCase()));
        this.appendGrid(this.browse,`${visible.length} ${visible.length===1 ? 'item' : 'items'}${this.libraryHasMore ? ' · more available' : ''}`,visible);
        if(!visible.length)this.browse.append(node('p','lt-empty','No matches in the loaded library. Try another name.'));
        if(this.libraryHasMore){const more=node('button','lt-pill lt-glass',this.libraryBusy ? 'Loading…' : 'Load more');more.type='button';more.dataset.action='moreLibrary';more.disabled=this.libraryBusy;this.browse.append(more);}
        if(this.librarySource==='native')this.browse.append(node('p','lt-note','Showing items available from Spotify’s sidebar. Refresh after the library finishes loading; Desktop interface keeps access to its full library.'));
      }else if(kind==='results'){
        const query=this.queryFromPath(),heading=node('div','lt-page-heading');
        heading.append(node('span','lt-eyebrow','FIND YOUR NEXT FAVORITE'),node('h1','',`Results for “${query}”`));
        const status=node('p','lt-result-status',this.searchResultBusy ? 'Searching Spotify…' : this.searchError || `${this.searchResults.length} results loaded`);status.setAttribute('role','status');heading.append(status);this.browse.append(heading);
        this.browse.setAttribute('aria-busy',String(this.searchResultBusy));
        const filters=node('div','lt-filter-bar');
        for(const [type,label] of [['all','All'],['track','Songs'],['artist','Artists'],['album','Albums'],['playlist','Playlists']]){const b=node('button','lt-pill lt-glass',label);b.type='button';b.dataset.searchFilter=type;b.setAttribute('aria-pressed',String(this.searchFilter===type));filters.append(b);}this.browse.append(filters);
        if(this.searchFilter==='all')this.appendGrid(this.browse,'Top matches',this.searchResults);
        else for(const [type,label] of [['track','Songs'],['artist','Artists'],['album','Albums'],['playlist','Playlists']])if(this.searchFilter===type)this.appendGrid(this.browse,label,this.searchResults.filter(entry=>entry.type===type));
        if(!this.searchResultBusy && !this.searchError && !this.searchResults.length)this.browse.append(node('p','lt-empty','No matches. Try a different song, artist, or spelling.'));
        if(this.searchError){const row=node('div','lt-quick-actions');for(const [label,action] of [['Retry search','retrySearch'],['Open desktop search','nativeSearch']]){const b=node('button','lt-pill lt-glass',label);b.type='button';b.dataset.action=action;row.append(b);}this.browse.append(row);}
        if(this.searchHasMore){const more=node('button','lt-pill lt-glass',this.searchResultBusy ? 'Loading…' : 'Load more results');more.type='button';more.dataset.action='moreSearch';more.disabled=this.searchResultBusy;this.browse.append(more);}
      }else{
        const heading=node('div','lt-page-heading');heading.append(node('span','lt-eyebrow','PICK UP A THREAD'),node('h1','','Recent searches'),node('p','','Songs, albums, playlists, and artists you found here.'));this.browse.append(heading);
        this.appendGrid(this.browse,'Recently found',this.recentSearches);
        if(!this.recentSearches.length)this.browse.append(node('p','lt-empty','Your next discovery starts above. Items you play or open from search will appear here.'));
      }
      this.browse.scrollTop=scroll;
      if(!['results','detail'].includes(kind))this.browse.removeAttribute('aria-busy');
      if(!this.previewMode)for(const card of this.browse.querySelectorAll('.lt-card[data-needs-art]'))this.imageObserver?.observe(card);
      if(focusId){const input=this.$(focusId);if(input){input.focus({preventScroll:true});if(typeof selection==='number')try{input.setSelectionRange(selection,selection);}catch{}}}
    }
    handleBrowseClick(event) {
      const gridMore=event.target.closest('[data-grid-more]');
      if(gridMore){event.preventDefault();this.gridLimits ||= new Map();const key=gridMore.dataset.gridMore;this.gridLimits.set(key,(this.gridLimits.get(key) || 24)+24);while(this.gridLimits.size>20)this.gridLimits.delete(this.gridLimits.keys().next().value);this.gridVersion=(this.gridVersion || 0)+1;this.renderBrowse();return true;}
      const detailControl=event.target.closest('[data-detail-action],[data-detail-track]');
      if(detailControl){
        event.preventDefault();const page=this.detailPages.get(this.detailInfo()?.uri);if(!page)return true;
        if(detailControl.dataset.detailTrack!==undefined){const track=page.tracks[Number(detailControl.dataset.detailTrack)];if(track && !track.unavailable)void this.playDetailTrack(page,track);}
        else if(detailControl.dataset.detailAction==='play')void this.playEntity(page.entry);
        else if(detailControl.dataset.detailAction==='visibleMore'){page.visibleTracks=(page.visibleTracks || 40)+40;page.version++;this.renderBrowse();}
        else if(detailControl.dataset.detailAction==='desktop'){this.detailOwned=false;this.enable(false,false);this.history.push(page.entry.path);}
        else void this.loadDetail(page,detailControl.dataset.detailAction==='more');return true;
      }
      const lyric=event.target.closest('[data-lyric-index]');
      if(lyric){const line=this.lyricLines[Number(lyric.dataset.lyricIndex)];if(line && line.at>=0){if(this.matchLyricLine){const offset=line.at-number(read(()=>this.player.getProgress(),0));this.setLyricOffset(offset);if(Math.abs(offset)>15000)this.notify('Timing correction is limited to 15 seconds. Check the recording or lyric source.');else this.notify('Lyrics matched. Open Timing to adjust or reset.');}else if(!this.seek.disabled){this.lastUserSeek=Date.now();this.lyricScrollUntil=0;void this.callPlayer('seek',Math.round(clamp(line.at-this.lyricOffset(),0,this.duration)));this.lyricIndex=-2;this.updateLyricPosition();}}return true;}
      const live=event.target.closest('[data-action="submitLiveSearch"]');if(live){this.submitSearch(live.dataset.query);return true;}
      const face=event.target.closest('[data-lt-card]');
      if(face){
        event.preventDefault();const entry=this.entities.get(face.dataset.ltCard);if(!entry)return true;
        if(event.detail===0 && this.fastTapButton!==face){this.openEntity(entry);return true;}
        this.rememberSearch(entry);
        if(entry.type==='show')this.openEntity(entry);
        else this.queueCardTap(entry,face,()=>void this.playEntity(entry),()=>this.openEntity(entry));
        return true;
      }
      const open=event.target.closest('[data-open-uri]');if(open){this.openEntity(this.entities.get(open.dataset.openUri));return true;}
      const filter=event.target.closest('[data-library-filter]');if(filter){this.libraryFilter=filter.dataset.libraryFilter;this.renderBrowse();this.animateSurface(this.browse.querySelector('.lt-card-section'));return true;}
      const searchFilter=event.target.closest('[data-search-filter]');if(searchFilter){this.searchFilter=searchFilter.dataset.searchFilter;this.renderBrowse();this.animateSurface(this.browse.querySelector('.lt-card-section'));return true;}
      const query=event.target.closest('[data-search-query]');if(query){this.searchInput.value=query.dataset.searchQuery;this.submitSearch();return true;}
      const history=event.target.closest('[data-history-uri]');if(history){void this.callPlayer('playUri',history.dataset.historyUri);return true;}
      return false;
    }
    holdEntry(target) {
      if(target.closest?.('#lt-utility'))return null;
      const card=target.closest?.('[data-lt-card],.lt-card[data-uri]');
      if(card)return this.entities.get(card.dataset.ltCard || card.dataset.uri) || null;
      const track=target.closest?.('[data-detail-track]');
      if(track)return this.detailPages.get(this.detailInfo()?.uri)?.tracks[Number(track.dataset.detailTrack)] || null;
      const history=target.closest?.('[data-history-uri]');
      if(history)return this.playHistory.find(row=>row.uri===history.dataset.historyUri) || null;
      if(target.closest?.('#lt-art-swipe .lt-art-frame'))return this.currentPlayingEntry || null;
      return null;
    }
    cancelHold() { if(this.holdTimer){clearTimeout(this.holdTimer);this.timers.delete(this.holdTimer);}this.holdTimer=0;this.holdCandidate=null; }
    bindHoldMenus() {
      this.listen(document,'dragstart',event=>{if(this.enabled && this.holdEntry(event.target)){event.preventDefault();event.stopPropagation();}},{capture:true});
      this.listen(window,'pointerdown',event=>{
        this.cancelHold();this.heldPointer=null;this.heldClickUntil=0;
        if(!this.enabled || event.button!==0 || event.isPrimary===false)return;
        const entry=this.holdEntry(event.target);if(!entry || entry.unavailable)return;
        const held={id:event.pointerId,x:event.clientX,y:event.clientY,entry,target:event.target};this.holdCandidate=held;
        this.holdTimer=this.later(()=>{
          if(this.holdCandidate!==held || !held.target.isConnected)return;
          this.cancelHold();this.cancelPendingCardTap();this.activeGesture=null;this.clearGestureMotion(false);this.pointerHeld=false;
          this.heldPointer=held.id;this.fastPointerClicks.set(held.id,Date.now()+1800);this.heldClickUntil=Date.now()+900;
          this.openUtility('context',held.entry,false,held.target.getBoundingClientRect());
        },550);
      },{capture:true});
      this.listen(window,'pointermove',event=>{const held=this.holdCandidate;if(held && event.pointerId===held.id && Math.hypot(event.clientX-held.x,event.clientY-held.y)>14)this.cancelHold();},{capture:true,passive:true});
      this.listen(window,'pointerup',event=>{
        this.cancelHold();
        if(this.heldPointer===event.pointerId){this.heldPointer=null;event.preventDefault();event.stopImmediatePropagation();}
      },{capture:true});
      for(const type of ['pointercancel','blur'])this.listen(window,type,()=>{this.cancelHold();this.heldPointer=null;},{capture:true});
      this.listen(document,'scroll',()=>this.cancelHold(),{capture:true,passive:true});
      this.listen(window,'click',event=>{if(event.isTrusted && Date.now()<(this.heldClickUntil || 0) && !event.target.closest?.('#lt-utility')){event.preventDefault();event.stopImmediatePropagation();}},{capture:true});
      this.listen(document,'contextmenu',event=>{const entry=this.enabled && this.holdEntry(event.target);if(!entry)return;event.preventDefault();this.cancelHold();this.cancelPendingCardTap();this.openUtility('context',entry,false,event.target.getBoundingClientRect());});
      this.listen(document,'keydown',event=>{if(event.key!=='ContextMenu' && !(event.shiftKey && event.key==='F10'))return;const entry=this.enabled && this.holdEntry(event.target);if(entry){event.preventDefault();this.cancelPendingCardTap();this.openUtility('context',entry,false,event.target.getBoundingClientRect());}});
    }
    utilityButton(label,command,glyph='spark') {
      const b=node('button','lt-utility-option');b.type='button';b.dataset.utilityCommand=command;
      const mark=node('span','lt-icon');mark.innerHTML=icon(glyph);b.append(mark,node('span','',label));return b;
    }
    positionUtility(){
      if(this.utilityState?.kind!=='context' || !this.utility.open)return;
      const r=this.utility.getBoundingClientRect(),anchor=this.utilityState.anchor;
      const x=innerWidth<620 ? 12 : clamp(anchor ? anchor.right+12+r.width<innerWidth ? anchor.right+12 : anchor.left-r.width-12 : (innerWidth-r.width)/2,12,Math.max(12,innerWidth-r.width-12));
      const y=innerWidth<620 ? Math.max(12,innerHeight-r.height-12) : clamp(anchor ? anchor.top : (innerHeight-r.height)/2,12,Math.max(12,innerHeight-r.height-12));
      Object.assign(this.utility.style,{left:x+'px',top:y+'px',right:'auto',bottom:'auto',margin:'0'});
      this.utility.querySelector('.lt-utility-stage').style.transformOrigin=`${clamp((anchor?.left || x)-x,0,r.width)}px ${clamp((anchor?.top || y)-y,0,r.height)}px`;
    }
    openUtility(kind,entry=null,push=false,anchor=null) {
      this.utilityAnchor=anchor;
      this.cancelHold();this.cancelPendingCardTap();
      if(push && this.utilityState)this.utilityStack.push({...this.utilityState,preview:this.utility.querySelector('.lt-utility-stage').cloneNode(true)});else this.utilityStack=[];
      this.utilityState={kind,entry,anchor};this.utilityBusy=false;
      this.renderUtility();this.openDialog(this.utility);this.positionUtility();
    }
    renderUtility() {
      const state=this.utilityState,token=++this.utilityToken,body=this.$('lt-utility-body');body.replaceChildren();this.$('lt-utility-status').textContent='';
      this.utility.querySelector('[data-action="utilityBack"]').hidden=!this.utilityStack.length;
      this.utility.dataset.kind=state.kind;
      for(const key of ['left','top','right','bottom','margin','width'])this.utility.style.removeProperty(key);
      this.$('lt-utility-title').textContent=({context:'More options',queue:'Queue',devices:'Listen on',playlists:'Add to playlist',clearHistory:'Clear listening history?'}[state.kind]);
      this.$('lt-utility-subtitle').textContent=state.entry ? state.entry.title : state.kind==='devices' ? 'Choose where your music plays.' : '';
      if(state.kind==='context'){
        const entry=state.entry;
        if(entry.image){const image=node('img','lt-utility-cover');image.src=entry.image;image.alt='';body.append(image);}
        const options=[['Play','play','play']];
        if(['track','artist','album','playlist'].includes(entry.type))options.push([entry.type==='track' ? 'Go to song radio' : 'Start radio','radio','spark']);
        if(['track','episode','album','playlist','collection'].includes(entry.type))options.push(['Add to queue','addQueue','queue'],['Add to playlist…','addPlaylist','plus']);
        if(entry.type!=='collection')options.push([entry.type==='artist' ? 'Follow artist' : 'Save to your library','save','heart'],[entry.type==='artist' ? 'Unfollow artist' : 'Remove from your library','unsave','close']);
        options.push(['Open '+({track:'song',episode:'episode',show:'podcast',collection:'Liked Songs'}[entry.type] || entry.type),'open','art']);
        if(entry.type!=='collection')options.push(['Copy Spotify link','copy','restore']);
        for(const [label,command,glyph] of options)body.append(this.utilityButton(label,command,glyph));
      }else if(state.kind==='clearHistory'){
        body.append(node('p','lt-note','This removes saved listening history for this Spotify profile on this device. Your music, playlists, settings and search history are kept. This cannot be undone.'));
        const clear=this.utilityButton('Clear saved history','confirmClear','close');clear.classList.add('lt-danger');body.append(clear,this.utilityButton('Keep history','cancelClear','back'));
      }else void this.loadUtility(token);
      this.animateSurface(this.utility);
      if(this.utility.open)this.positionUtility();
    }
    utilityBack() {
      if(this.utilityStack.length){this.utilityState=this.utilityStack.pop();this.utilityBusy=false;this.renderUtility();}
      else this.closeDialog(this.utility);
    }
    utilityCurrent(token) { return !this.destroyed && token===this.utilityToken; }
    async spotifyRequest(method,path,body) {
      if(!path.startsWith('/v1/'))throw new Error('Unsupported Spotify request.');
      const api=this.S.CosmosAsync;if(typeof api?.[method]!=='function')throw new Error('This Spotify session does not expose that action.');
      const result=await api[method]('https://api.spotify.com'+path,...body===undefined ? [] : [body]);
      if(result?.error || result?.status>=400)throw new Error('Spotify declined the request.');
      return result;
    }
    connectDevice(raw,key='',active=null,api=null) {
      if(!raw || typeof raw!=='object')return null;
      const local=raw.isLocal===true || raw.is_local===true;
      const restId=cleanText(raw.id || raw.deviceId || raw.device_id || raw.connectStateId || key,300);
      const id=restId || (local ? 'local_device' : '');
      const name=cleanText(raw.name || raw.deviceName || raw.device_name || raw.displayName || raw.friendlyName);
      if(!id || !name)return null;
      const activeId=typeof active==='string' ? active : cleanText(active?.id || active?.deviceId || active?.device_id || active?.connectStateId);
      return {id,restId,name,local,api,type:cleanText(raw.type || raw.deviceType || raw.device_type,100) || (local ? 'This computer' : 'Spotify device'),
        is_active:raw.isActive===true || raw.is_active===true || id===activeId,
        is_restricted:raw.isRestricted===true || raw.is_restricted===true || raw.isControllable===false || raw.is_available===false};
    }
    connectDeviceRows(value,active,api) {
      const list=value?.devices || value?.data?.devices || value?.deviceList || value;
      if(!list || typeof list!=='object')return [];
      const entries=Array.isArray(list) ? list.map(row=>['',row]) : list instanceof Map ? [...list.entries()] : Object.entries(list);
      return entries.map(([key,row])=>this.connectDevice(row,key,active,api)).filter(Boolean);
    }
    async readDevices() {
      const platform=this.S.Platform,apis=[...new Set([platform?.ConnectAPI,platform?.ConnectDevicesAPI].filter(Boolean))];
      const activeDevices=[];
      // Native Connect is the desktop picker's source. REST can be empty or
      // unavailable with desktop tokens, so it is only a fallback here.
      const results=await Promise.allSettled(apis.map(async api=>{
        const state=read(()=>api.state,null) || read(()=>api._state,null) || {};
        const [devicesResult,activeResult]=await Promise.allSettled([
          typeof api.getDevices==='function' ? this.withTimeout(Promise.resolve().then(()=>api.getDevices()),1600) : Promise.resolve(null),
          typeof api.getActiveDevice==='function' ? this.withTimeout(Promise.resolve().then(()=>api.getActiveDevice()),1600) : Promise.resolve(null)
        ]);
        const response=devicesResult.status==='fulfilled' ? devicesResult.value : null;
        const active=(activeResult.status==='fulfilled' && activeResult.value) || response?.activeDevice || state.activeDevice || state.active_device || state.activeDeviceId;
        const current=this.connectDevice(active,'',active,api);if(current)activeDevices.push(current);
        const cached=this.connectDeviceRows(state.devices || state.deviceList,active,api),live=this.connectDeviceRows(response,active,api);
        return [...cached,...live];
      }));
      const merged=new Map();
      for(const result of results)if(result.status==='fulfilled')for(const device of result.value)merged.set(device.id,device);
      if(merged.size){this.devicesSource='connect';return [...merged.values()].sort((a,b)=>Number(b.is_active)-Number(a.is_active));}
      try {
        const result=await this.withTimeout(this.spotifyRequest('get','/v1/me/player/devices'),2500);
        if(!Array.isArray(result?.devices))throw new Error('Unknown device list');
        const rows=this.connectDeviceRows(result,null,null);
        if(rows.length){this.devicesSource='web-api';return rows;}
      }catch(error){
        if(!activeDevices.length){
          const current=this.connectDevice(this.getPlayerState()?.device);if(current)activeDevices.push(current);
          if(!activeDevices.length){this.devicesSource='unavailable';throw new Error('Spotify could not load devices. Open Spotify on the other device, then try Refresh.');}
        }
      }
      this.devicesSource=activeDevices.length ? 'connect-active' : 'empty';
      return activeDevices.map(device=>({...device,is_active:true}));
    }
    async refreshDeviceList(token,initial=false) {
      if(this.deviceReadToken===token)return;
      this.deviceReadToken=token;this.deviceReadBusy=true;this.lastDeviceRefresh=Date.now();
      const state=this.utilityState,body=this.$('lt-utility-body');
      try {
        const devices=await this.readDevices();
        if(!this.utilityCurrent(token) || state.kind!=='devices')return;
        if(!initial && (this.pointerHeld || this.utilityBusy))return;
        const signature=JSON.stringify(devices.map(({id,name,type,is_active,is_restricted})=>[id,name,type,is_active,is_restricted]));
        state.devices=devices;
        if(initial || state.deviceSignature!==signature){
          state.deviceSignature=signature;body.replaceChildren();
          for(const device of devices){
            const row=this.utilityButton(device.name,'transfer',device.local ? 'desktop' : 'devices');row.dataset.deviceId=device.id;
            row.disabled=device.is_restricted || device.is_active;row.setAttribute('aria-pressed',String(device.is_active));
            row.append(node('small','',device.is_active ? 'Playing here' : device.is_restricted ? 'Playback control unavailable' : device.type));body.append(row);
          }
          if(!devices.length)body.append(node('p','lt-empty','No devices are available yet. Open Spotify on another device; this list refreshes automatically.'));
          body.append(this.utilityButton('Refresh','refresh','restore'));
        }
        this.$('lt-utility-status').textContent='';
      }catch(error){
        if(!this.utilityCurrent(token))return;
        this.$('lt-utility-status').textContent=error.message || 'Devices could not be loaded.';
        if(!body.querySelector('[data-utility-command="refresh"]'))body.append(this.utilityButton('Try again','refresh','restore'));
      }finally{
        if(this.deviceReadToken===token){this.deviceReadToken=null;this.deviceReadBusy=false;this.lastDeviceRefresh=Date.now();}
      }
    }
    async transferDevice(device) {
      const api=device.api || this.S.Platform?.ConnectAPI;
      const wasPlaying=read(()=>this.player.isPlaying(),false);let transferred=false;
      if(typeof api?.transferPlayback==='function')try{await this.withTimeout(api.transferPlayback(device.local ? 'local_device' : device.id),6000);transferred=true;}catch{}
      if(!transferred && device.local && typeof api?.pullToLocal==='function')try{await this.withTimeout(api.pullToLocal({}),6000);transferred=true;}catch{}
      if(!transferred){
        if(!device.restId || device.restId==='local_device')throw new Error('This device cannot be selected in this Spotify session.');
        await this.withTimeout(this.spotifyRequest('put','/v1/me/player',{device_ids:[device.restId],play:false}),6000);
      }
      if(!wasPlaying && read(()=>this.player.isPlaying(),false) && typeof this.player.pause==='function')await this.player.pause();
    }
    async loadUtility(token) {
      const state=this.utilityState,body=this.$('lt-utility-body');this.$('lt-utility-status').textContent='Loading…';
      try {
        if(state.kind==='queue'){
          const raw=read(()=>this.S.Queue,null),queue=Array.isArray(raw?.nextTracks) ? raw : await this.spotifyRequest('get','/v1/me/player/queue');
          if(!this.utilityCurrent(token))return;
          const current=normalizeEntity(queue.track?.contextTrack || queue.track || queue.currently_playing),rows=queue.nextTracks || queue.queue;
          if(!Array.isArray(rows))throw new Error('Queue is unavailable in this Spotify session.');
          state.rows=rows.map(row=>({entry:normalizeEntity(row.contextTrack || row.track || row),raw:row.contextTrack || row.track || row})).filter(row=>row.entry);
          if(current){body.append(node('h3','','Playing now'));this.appendUtilityEntity(body,current);}
          body.append(node('h3','','Up next'));
          state.rows.forEach((row,index)=>{
            const wrapper=node('div','lt-utility-row');this.appendUtilityEntity(wrapper,row.entry,'queuePlay',index);
            if(row.raw.uid && (this.S.removeFromQueue || this.S.Platform?.PlayerAPI?.removeFromQueue)){const remove=this.utilityButton('Remove','queueRemove','close');remove.dataset.index=String(index);remove.setAttribute('aria-label','Remove '+row.entry.title+' from queue');wrapper.append(remove);}body.append(wrapper);
          });
          if(!state.rows.length)body.append(node('p','lt-empty','Your queue is empty. Hold a song card to add music.'));
        }else if(state.kind==='devices'){
          await this.refreshDeviceList(token,true);return;
        }else if(state.kind==='playlists'){
          const [me,page,uris]=await Promise.all([this.spotifyRequest('get','/v1/me'),this.spotifyRequest('get','/v1/me/playlists?limit=50&offset='+(state.offset || 0)),state.uris || this.entityTrackURIs(state.entry)]);
          if(!this.utilityCurrent(token))return;
          if(!me?.id || !Array.isArray(page?.items))throw new Error('Editable playlists are unavailable in this Spotify session.');
          state.uris=uris;state.offset=(state.offset || 0)+page.items.length;state.more=Boolean(page.next);
          const editable=page.items.filter(p=>p && (p.owner?.id===me.id || p.collaborative));
          for(const raw of editable){const entry=normalizeEntity(raw);if(entry)this.appendUtilityEntity(body,entry,'playlistAdd');}
          if(!body.children.length)body.append(node('p','lt-empty','No editable playlists on this page.'));
          if(state.more)body.append(this.utilityButton('More playlists','morePlaylists','plus'));
        }
        if(!this.utilityCurrent(token))return;
        this.$('lt-utility-status').textContent='';
        if(state.kind!=='playlists')body.append(this.utilityButton('Refresh','refresh','restore'));
      } catch(error) {
        if(!this.utilityCurrent(token))return;
        this.$('lt-utility-status').textContent=error.message || 'Spotify could not load this panel. Try Refresh.';
        body.append(this.utilityButton('Try again','refresh','restore'));
      }
    }
    appendUtilityEntity(parent,entry,command,index) {
      const row=node(command ? 'button' : 'div','lt-utility-entity');if(command){row.type='button';row.dataset.utilityCommand=command;row.dataset.uri=entry.uri;if(index!==undefined)row.dataset.index=String(index);}
      if(entry.image){const image=node('img','');image.src=entry.image;image.alt='';image.loading='lazy';row.append(image);}
      const text=node('span','lt-utility-copy');text.append(node('strong','',entry.title),node('small','',entry.subtitle));row.append(text);parent.append(row);return row;
    }
    async openSongRadio(seed,token) {
      const result=await this.withTimeout(this.S.CosmosAsync.get('https://spclient.wg.spotify.com/inspiredby-mix/v2/seed_to_playlist/'+seed.uri+'?response-format=json'),5000);
      const info=(result?.mediaItems || []).map(item=>uriInfo(item.uri)).find(item=>item?.type==='playlist');
      if(!info)throw new Error('Spotify did not return a Song Radio playlist. Try again in a moment.');
      const entry={...info,title:seed.title+' Radio',subtitle:'Song Radio by Spotify',image:seed.image};
      const resultPage=await this.fetchDetail(entry);
      if(!this.utilityCurrent(token))return;
      const tracks=[{...resultPage.tracks.find(track=>track.uri===seed.uri),...seed,unavailable:false},...resultPage.tracks.filter(track=>track.uri!==seed.uri)];
      const page={...resultPage,entry:{...entry,...resultPage.meta,title:resultPage.meta?.title || entry.title,image:resultPage.meta?.image || entry.image},tracks,releases:resultPage.releases || [],loading:false,fetching:false,version:1,loadedAt:Date.now(),radioSeed:seed.uri,error:'',description:'Song Radio by Spotify · Based on '+seed.title};
      this.detailPages.set(entry.uri,page);this.entities.set(entry.uri,page.entry);
      await this.player.playUri(seed.uri,{uri:entry.uri});
      if(!this.utilityCurrent(token))return;
      this.closeDialog(this.utility);this.openEntity(page.entry);
    }
    async entityTrackURIs(entry) {
      if(['track','episode'].includes(entry.type))return [entry.uri];
      const uris=[];let offset=0,more=true;
      while(more){
        const result=await this.fetchDetail(entry,offset);if(this.destroyed)throw new Error('This menu was closed for an update.');
        uris.push(...result.tracks.filter(track=>!track.unavailable).map(track=>track.uri));
        more=Boolean(result.hasMore);if(more && !(result.nextOffset>offset))throw new Error('Spotify did not return the next page of songs.');offset=result.nextOffset;
      }
      if(!uris.length)throw new Error('No playable songs are available for this item.');return uris;
    }
    async utilityCommand(command,target) {
      if(this.utilityBusy)return;
      if(command==='refresh'){this.utilityState.offset=0;this.renderUtility();return;}
      if(command==='morePlaylists'){this.renderUtility();return;}
      if(command==='cancelClear'){this.closeDialog(this.utility);return;}
      if(command==='addPlaylist'){this.openUtility('playlists',this.utilityState.entry,true);return;}
      const state=this.utilityState,token=this.utilityToken,entry=state.entry;
      const controls=[...this.$('lt-utility-body').querySelectorAll('button')].map(button=>[button,button.disabled]);
      this.utilityBusy=true;for(const [button] of controls)button.disabled=true;
      this.$('lt-utility-status').textContent='Working…';
      try {
        let message='Done.';
        if(command==='play')await this.player.playUri(entry.uri);
        else if(command==='open'){this.closeDialog(this.utility);this.openEntity(entry);return;}
        else if(command==='radio'){
          if(entry.type==='track'){await this.openSongRadio(entry,token);return;}
          const parts=entry.uri.split(':').slice(1),uri=this.S.URI?.stationURI ? this.S.URI.stationURI(parts).toString() : 'spotify:station:'+parts.join(':');
          await this.player.playUri(uri);message='Radio started.';
        }else if(command==='addQueue'){
          const uris=await this.entityTrackURIs(entry);
          if(typeof this.S.addToQueue==='function')await this.S.addToQueue(uris.map(uri=>({uri})));
          else if(typeof this.S.Platform?.PlayerAPI?.addToQueue==='function')await this.S.Platform.PlayerAPI.addToQueue(uris.map(uri=>({uri})));
          else for(const uri of uris)await this.spotifyRequest('post','/v1/me/player/queue?uri='+encodeURIComponent(uri));
          message=`Added ${uris.length===1 ? 'song' : uris.length+' songs'} to queue.`;
        }else if(command==='save' || command==='unsave'){
          const method=command==='save' ? 'put' : 'del',path=entry.type==='artist' ? '/v1/me/following?type=artist&ids='+encodeURIComponent(entry.uri.split(':')[2]) : '/v1/me/library?uris='+encodeURIComponent(entry.uri);
          await this.spotifyRequest(method,path);message=command==='save' ? 'Saved to your library.' : 'Removed from your library.';
          void this.loadLibrary(true);
        }else if(command==='copy'){
          const url='https://open.spotify.com'+entry.path;
          if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(url);else{const input=node('textarea','lt-copy-helper');input.value=url;this.utility.append(input);input.select();const copied=document.execCommand('copy');input.remove();if(!copied)throw new Error('Clipboard is unavailable.');}message='Link copied.';
        }else if(command==='confirmClear'){await this.clearListeningHistory();message='Listening history cleared.';}
        else if(command==='transfer'){
          const device=state.devices.find(d=>d.id===target.dataset.deviceId);if(!device || device.is_restricted || device.is_active)throw new Error('This device cannot be selected.');
          await this.transferDevice(device);
          if(this.utilityCurrent(token)){this.utilityBusy=false;this.renderUtility();this.$('lt-utility-status').textContent='Playback transferred to '+cleanText(device.name)+'.';}return;
        }else if(command==='queuePlay')await this.player.playUri(state.rows[Number(target.dataset.index)].entry.uri);
        else if(command==='queueRemove'){
          const raw=state.rows[Number(target.dataset.index)]?.raw;if(!raw?.uid)throw new Error('This queue item cannot be removed.');
          if(this.S.removeFromQueue)await this.S.removeFromQueue([raw]);else await this.S.Platform.PlayerAPI.removeFromQueue([raw]);
          if(this.utilityCurrent(token)){this.utilityBusy=false;this.renderUtility();}return;
        }else if(command==='playlistAdd'){
          const info=uriInfo(target.dataset.uri);if(info?.type!=='playlist')throw new Error('Invalid playlist.');
          let added=0;
          try{for(let i=0;i<state.uris.length;i+=100){const batch=state.uris.slice(i,i+100);await this.spotifyRequest('post','/v1/playlists/'+encodeURIComponent(info.uri.split(':')[2])+'/items',{uris:batch});added+=batch.length;}}
          catch(error){throw new Error(added ? `${added} songs were added before Spotify stopped. The remaining songs were not added. Close this menu before retrying to avoid duplicates.` : 'Spotify could not confirm the addition. Check the playlist before retrying to avoid duplicates.');}
          message=`Added ${added===1 ? 'song' : added+' songs'} to playlist.`;
        }
        if(this.utilityCurrent(token)){this.closeDialog(this.utility);this.notify(message);}
      }catch(error){if(this.utilityCurrent(token)){this.utilityBusy=false;for(const [button,disabled] of controls)if(button.isConnected)button.disabled=disabled;this.$('lt-utility-status').textContent=error.message || 'Spotify could not complete that action.';}}
      finally{if(this.utilityCurrent(token))this.utilityBusy=false;if(!this.destroyed && ['addQueue','queueRemove'].includes(command)){this.lyricQueueAt=0;this.prefetchNextLyrics();}}
    }
    cancelPendingCardTap(){const pending=this.pendingCardTap;if(!pending)return;clearTimeout(pending.timer);this.timers.delete(pending.timer);pending.face?.classList.remove('lt-card-pending');this.pendingCardTap=null;}
    reservePendingCardTap(target){
      const pending=this.pendingCardTap;if(!pending)return;
      const face=target.closest?.('[data-lt-card]'),info=face ? {uri:face.dataset.ltCard} : this.cardContext(target);
      if(info?.uri===pending.uri && pending.view===this.viewKey(this.snapshotView()) && Date.now()-pending.at<=this.prefs.cardTapDelay){clearTimeout(pending.timer);this.timers.delete(pending.timer);pending.reserved=true;}
      else if(info)this.cancelPendingCardTap();
    }
    queueCardTap(entry,face,play,open){
      const pending=this.pendingCardTap,view=this.viewKey(this.snapshotView());
      if(pending?.uri===entry.uri && pending.view===view && (pending.reserved || Date.now()-pending.at<=this.prefs.cardTapDelay)){this.cancelPendingCardTap();open();return;}
      this.cancelPendingCardTap();const next={uri:entry.uri,view,face,at:Date.now(),reserved:false};this.pendingCardTap=next;face?.classList.add('lt-card-pending');
      next.timer=this.later(()=>{if(this.pendingCardTap!==next)return;this.pendingCardTap=null;face?.classList.remove('lt-card-pending');if(this.enabled && view===this.viewKey(this.snapshotView()))play();},this.prefs.cardTapDelay);
    }
    openEntity(entry) { if(entry){this.cancelPendingCardTap();this.rememberSearch(entry);this.navigate(entry.path);} }
    async playEntity(entry) {
      const state=this.getPlayerState();
      if((state?.context?.uri || state?.context_uri)===entry.uri){if(!read(()=>this.player.isPlaying(),false))await this.callPlayer('play');this.rememberHome([entry]);return;}
      if(await this.callPlayer('playUri',entry.uri))this.rememberHome([entry]);
    }
    rememberHome(entries){
      const valid=entries.map(normalizeEntity).filter(entry=>entry && ['playlist','album','artist','collection'].includes(entry.type) && entry.title!=='Your music');
      if(!valid.length)return;
      const unique=[...new Map(valid.map(entry=>[entry.uri,entry])).values()];
      const next=[...unique.map(entry=>({...entry,at:Date.now()})),...(this.recentHome || []).filter(entry=>!unique.some(row=>row.uri===entry.uri))].slice(0,12);
      const signature=rows=>JSON.stringify(rows.map(({uri,title,subtitle,image})=>[uri,title,subtitle,image]));
      if(signature(next)===signature(this.recentHome || []))return;
      this.recentHome=next;this.homeRecentVersion=(this.homeRecentVersion || 0)+1;
      this.persistRecords('home-recent',next);this.browsePages?.delete('home');
      if(this.getRoutePath()==='/' && !this.libraryOpen && !this.nowPlaying.open)this.renderBrowse();
    }
    capturePlaybackHome(data,item){
      const rawContext=data?.context?.uri || data?.context_uri || item?.metadata?.context_uri;
      const info=uriInfo(rawContext),known=info && (this.entities.get(info.uri) || this.libraryEntities.get(info.uri) || this.homeEntities.get(info.uri) || this.recentHome?.find(entry=>entry.uri===info.uri));
      const context=known || info && normalizeEntity({...info,name:data?.context?.metadata?.context_description || data?.context?.name || data?.context_metadata?.context_description});
      const album=item?.album || (item?.metadata?.album_uri ? {uri:item.metadata.album_uri,name:item.metadata.album_title,imageUrl:this.lastImage} : null);
      const artists=Array.isArray(item?.artists) ? item.artists : item?.artists?.items || (item?.metadata?.artist_uri ? [{uri:item.metadata.artist_uri,name:item.metadata.artist_name}] : []);
      this.rememberHome([context,album,...artists].filter(Boolean));
      if(info && ['playlist','album','artist'].includes(info.type) && (!context || context.title==='Your music')){
        const uri=this.lastURI;
        this.homeContextRequests ||= new Map();
        if(!this.homeContextRequests.has(info.uri)){
          this.homeContextRequests.set(info.uri,true);
          while(this.homeContextRequests.size>16)this.homeContextRequests.delete(this.homeContextRequests.keys().next().value);
          void this.apiGet(`https://api.spotify.com/v1/${info.type}s/${encodeURIComponent(info.uri.split(':')[2])}${info.type==='playlist' ? '?fields=name,images' : ''}`).then(raw=>{
            const entry=normalizeEntity({...raw,uri:info.uri});
            if(!this.destroyed && entry && entry.title!=='Your music'){
              this.entities.set(entry.uri,entry);
              const current=this.getPlayerState(),contextURI=current?.context?.uri || current?.context_uri || trackFromState(current)?.metadata?.context_uri;
              if(this.lastURI===uri && contextURI===info.uri)this.rememberHome([entry,album,...artists].filter(Boolean));
            }
          }).catch(()=>{this.homeContextRequests.delete(info.uri);});
        }
      }
    }
    rememberSearch(entry) {
      if(!(this.getRoutePath().startsWith('/search') || this.quickOpen) || !entry)return;
      this.recentSearches=[{...entry,at:Date.now()},...this.recentSearches.filter(row=>row.uri!==entry.uri)].slice(0,50);
      this.persistRecords('search-items',this.recentSearches);this.catalogVersion++;
    }
    captureSearchSelection(target) {
      if(!this.history.location?.pathname?.startsWith('/search/') || target.closest(OWN))return;
      const link=target.closest('a[href], [data-uri]') || target.closest('.main-trackList-trackListRow')?.querySelector('a[href^="/track/"]');if(!link)return;
      const root=link.closest('.main-trackList-trackListRow, [data-testid="card-container"], [data-testid="card"], article') || link.parentElement;
      const info=uriInfo(link.dataset.uri || link.getAttribute('href'));if(!info)return;
      const entity=normalizeEntity({...info,name:cleanText(link.textContent || root?.querySelector('h3,strong')?.textContent),imageUrl:root?.querySelector('img')?.src});
      this.rememberSearch(entity);
    }
    bindFastTap(root) {
      let tap=null;
      const begin=(target,x,y,id)=>{
        const button=target.closest?.('button');if(!button || button.disabled)return null;
        const toolbar=button.closest('.lt-nav,.lt-header,.lt-np-header,.lt-sheet-header,.lt-caption-buttons');
        return {button,id,x,y,moved:false,tolerance:14};
      };
      const finish=(event,x,y,id)=>{
        const current=tap;tap=null;if(!current || current.id!==id || current.moved || !current.button.isConnected || Math.hypot(x-current.x,y-current.y)>current.tolerance)return;
        const r=current.button.getBoundingClientRect();
        if(!current.button.contains(event.target) && !(x>=r.left-6 && x<=r.right+6 && y>=r.top-6 && y<=r.bottom+6))return;
        if(root===this.shell && current.button.id==='lt-mini-open' && Date.now()<this.suppressOpenUntil)return;
        event.preventDefault();event.stopPropagation();this.fastClickBlock={button:current.button,x,y,until:Date.now()+450};
        // A layout-changing action can move the click target before the OS
        // compatibility click arrives. Match its pointer ID, not just pixels.
        if(typeof current.id==='number'){this.fastPointerClicks.set(current.id,Date.now()+1500);while(this.fastPointerClicks.size>16)this.fastPointerClicks.delete(this.fastPointerClicks.keys().next().value);}
        this.pointerHeld=false;this.fastTapButton=current.button;current.button.click();this.fastTapButton=null;
      };
      this.listen(root,'pointerdown',e=>{if(e.button>0 || e.isPrimary===false){tap=null;return;}tap=begin(e.target,e.clientX,e.clientY,e.pointerId);},{capture:true});
      this.listen(root,'pointermove',e=>{if(tap && Math.hypot(e.clientX-tap.x,e.clientY-tap.y)>tap.tolerance)tap.moved=true;},{capture:true,passive:true});
      this.listen(root,'pointercancel',()=>{tap=null;},{capture:true});
      this.listen(root,'pointerup',e=>finish(e,e.clientX,e.clientY,e.pointerId),{capture:true});
      this.listen(root,'touchstart',e=>{if(!tap && e.touches.length===1){const t=e.touches[0];tap=begin(e.target,t.clientX,t.clientY,'touch:'+t.identifier);}},{capture:true,passive:true});
      this.listen(root,'touchmove',e=>{const t=e.touches[0];if(tap && t && Math.hypot(t.clientX-tap.x,t.clientY-tap.y)>tap.tolerance)tap.moved=true;},{capture:true,passive:true});
      this.listen(root,'touchcancel',()=>{tap=null;},{capture:true});
      this.listen(root,'touchend',e=>{const t=e.changedTouches[0];if(t && typeof tap?.id==='string')finish(e,t.clientX,t.clientY,'touch:'+t.identifier);},{capture:true});
    }
    recordPlay(entry, playing, progress) {
      if(!uriInfo(entry.uri) || !['track','episode'].includes(uriInfo(entry.uri).type)){this.observedPlayback=null;return;}
      const previous=this.observedPlayback;
      const same=previous?.uri===entry.uri;
      const repeated=same && previous.progress>=this.duration-5000 && progress<5000 && Date.now()-(this.lastUserSeek || 0)>2500;
      const start=playing && (!same || !previous.recorded || repeated);
      this.observedPlayback={uri:entry.uri,progress,recorded:same && previous.recorded || playing};
      if(!start){
        const latest=this.playHistory[0];
        if(same && latest?.uri===entry.uri && (latest.title!==entry.title || latest.artist!==entry.artist || latest.album!==entry.album)){
          Object.assign(latest,entry);this.saveHistoryRow(latest);if(this.historyPage.open)this.renderHistory();
        }
        return;
      }
      const row={...entry,at:Date.now(),id:`${this.accountNamespace}:${Date.now()}:${crypto.randomUUID?.() || Math.random().toString(36).slice(2)}`};this.playHistory.unshift(row);
      this.lastRecordedURI=entry.uri;this.saveHistoryRow(row);this.enforceHistoryLimit();
      if(this.historyPage.open)this.renderHistory();
    }
    renderHistory() {
      if(!this.historyPage)return;
      const query=this.$('lt-history-search').value.trim().toLocaleLowerCase();
      const rows=this.playHistory.filter(row=>`${row.title} ${row.artist} ${row.album} ${new Date(row.at).toLocaleString()} ${new Date(row.at).toLocaleDateString('sv-SE')}`.toLocaleLowerCase().includes(query));
      this.$('lt-history-count').textContent=this.historyState==='loading' ? 'Loading saved history…' : `${rows.length.toLocaleString()} ${rows.length===1 ? 'play' : 'plays'}${query ? ' found' : ' saved locally'}${this.prefs.historySongLimit ? ' · limit '+this.prefs.historySongLimit.toLocaleString() : ' · unlimited'}`;
      this.$('lt-history-status').textContent=this.historyError || '';
      const list=this.$('lt-history-list');const scroll=list.scrollTop;list.replaceChildren();let previousDay='';
      for(const row of rows.slice(0,this.historyLimit)){
        const date=new Date(row.at);const day=date.toLocaleDateString(undefined,{weekday:'long',year:'numeric',month:'long',day:'numeric'});
        if(day!==previousDay){list.append(node('h3','lt-history-day',day));previousDay=day;}
        const b=node('button','lt-history-row lt-glass');b.type='button';b.dataset.historyUri=row.uri;b.setAttribute('aria-label',`Play ${row.title}, ${row.artist}, played ${date.toLocaleString()}`);
        if(row.image){const img=node('img','lt-history-art');img.src=row.image;img.alt='';img.loading='lazy';b.append(img);}
        else{const placeholder=node('span','lt-history-art lt-history-placeholder');placeholder.innerHTML=icon('art');placeholder.setAttribute('aria-hidden','true');b.append(placeholder);}
        const text=node('span','lt-history-text');text.append(node('strong','',row.title),node('span','',row.artist || row.subtitle),node('small','',row.album || ''));
        const stamp=node('time','',date.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit',second:'2-digit'}));stamp.dateTime=date.toISOString();b.append(text,stamp);list.append(b);
      }
      if(!rows.length)list.append(node('p','lt-empty',query ? 'No matching plays.' : 'Your listening journal starts with the next track you play.'));
      if(rows.length>this.historyLimit){const more=node('button','lt-pill lt-glass','Show more plays');more.type='button';more.dataset.action='moreHistory';list.append(more);}
      list.scrollTop=scroll;
    }

    queueCatalogRefresh(){
      if(this.catalogRefreshTimer || this.destroyed)return;
      this.catalogRefreshTimer=this.later(()=>{this.catalogRefreshTimer=null;if(!this.enabled || document.hidden || this.nowPlaying.open)return;if(this.pointerHeld){this.queueCatalogRefresh();return;}this.refreshNative();},this.prefs.lowMemory ? 1200 : 150);
    }
    refreshNative(scan=true) {
      const main = document.querySelector(".Root__main-view") || document.querySelector('[data-testid="main-view"]') || document.querySelector(".main-view-container");
      const library = document.querySelector(".Root__nav-bar") || document.querySelector(".main-yourLibraryX-libraryContainer");
      if (this.main !== main) {
        if (this.main) delete this.main.dataset.ltNative;
        this.main = main;
        if (main) main.dataset.ltNative = "main";
      }
      if (this.library !== library) {
        if (this.library) delete this.library.dataset.ltNative;
        this.library = library;
        if (library) library.dataset.ltNative = "library";
      }
      this.measureNativeLayout();
      if (!main && this.enabled && !this.detailOwned && !/^\/search(?:\/|$)/.test(this.routePath)) {
        if(Date.now()-(this.lastRequestedAt || 0)<1200){
          // History can unmount the old main before the new page is mounted.
          if(!this.nativeRetryTimer)this.nativeRetryTimer=this.later(()=>{this.nativeRetryTimer=null;this.refreshNative(false);},80);
        }else{
          this.enable(false, false);
          this.notify("Spotify’s layout changed. Desktop controls are available; tap Touch UI to retry.");
        }
      }
      if(scan && !this.nowPlaying.open){this.nativeScans=(this.nativeScans || 0)+1;this.captureNativeCatalog();}
      this.updateLayoutMetrics();
    }
    measureNativeLayout(){
      // Modern Spotify inserts additional scroll wrappers. Keep the measured
      // path, rather than relying on the legacy scroll-node being a direct child.
      const viewport=this.main?.querySelector('.main-view-container__scroll-node') || this.main?.querySelector('[data-overlayscrollbars-viewport], [data-testid="scroll-node"]');
      const path=[];
      for(let current=viewport?.parentElement;current && current!==this.main;current=current.parentElement)path.push(current);
      for(const previous of this.nativeLayoutPath || [])if(!path.includes(previous))delete previous.dataset.ltNativeLayout;
      if(this.nativeViewport && this.nativeViewport!==viewport)delete this.nativeViewport.dataset.ltNativeViewport;
      for(const current of path)current.dataset.ltNativeLayout='true';
      if(viewport)viewport.dataset.ltNativeViewport='true';
      this.nativeLayoutPath=path;this.nativeViewport=viewport;
    }
    bind() {
      // The old Update button can produce a compatibility click after its UI
      // has been replaced. A fresh pointer/key event always re-enables input.
      this.runtimeSwapUntil=LIVE_REPLACEMENT ? Date.now()+600 : 0;
      for(const type of ['pointerdown','keydown'])this.listen(window,type,()=>{this.runtimeSwapUntil=0;},{capture:true});
      this.listen(window,'click',e=>{if(e.isTrusted && Date.now()<this.runtimeSwapUntil){this.runtimeSwapUntil=0;e.preventDefault();e.stopImmediatePropagation();}},{capture:true});
      this.bindHoldMenus();
      for (const root of [this.shell, this.nowPlaying, this.settings, this.historyPage, this.releaseDialog, this.utility]) {
        this.bindFastTap(root);
        this.listen(root, "click", e => {
          const option=e.target.closest('[data-utility-command]');if(option){void this.utilityCommand(option.dataset.utilityCommand,option);return;}
          if(this.handleBrowseClick(e))return;
          const target = e.target.closest("button[data-action]");
          if (target && !target.disabled) void this.action(target.dataset.action);
          const category=e.target.closest('button[data-settings-section]');
          if(category)this.showSettingsSection(category.dataset.settingsSection);
          const preference = e.target.closest('button[data-pref][role="switch"]');
          if (preference) {
            const key = preference.dataset.pref;
            this.prefs[key] = !this.prefs[key];
            if(key==='lyrics'){this.lyricOverride=null;if(!this.prefs.lyrics)this.cancelLyricPrefetch();}
            if(['lyricsFallback','lyricsTextFallback'].includes(key)){this.cancelLyricPrefetch();this.lyricsCache.clear();this.lyricsLoadedURI=null;this.lyricsAbort?.abort();this.lyricsInFlight=null;this.lyricsToken++;}
            this.save(); this.applyPreferences();
          }
          const adjust = e.target.closest("button[data-adjust]");
          if (adjust) this.changeScale(adjust.dataset.adjust, Number(this.$('lt-'+adjust.dataset.adjust).value) + Number(adjust.dataset.delta));
          const opacity=e.target.closest('button[data-opacity-override]');
          if(opacity && OPACITY_PANELS.some(([key])=>key===opacity.dataset.opacityOverride)){
            const key=opacity.dataset.opacityOverride;this.prefs[key]=this.prefs[key]===null ? this.prefs.glassOpacity : null;
            this.save();this.applyGlassPreferences();
          }
        });
      }
      this.listen(this.settings,'pointerdown',e=>{if(e.target.closest('button[data-settings-section],button[data-action="settingsBack"]'))e.preventDefault();});
      this.listen(this.settings, "change", e => {
        if(e.target.id==='lt-update-feed'){try{this.saveUpdateFeed(e.target.value);}catch(error){this.setUpdateStatus(error.message);}return;}
        const key = e.target.dataset.pref;
        if ((key === "palette" && ["glass", "ocean", "graphite"].includes(e.target.value)) ||
            (key === "clockFormat" && ["12", "24"].includes(e.target.value)) ||
            (key === "size" && ["comfort", "large"].includes(e.target.value))) {
          this.prefs[key] = e.target.value; this.save(); this.applyPreferences();
        }
      });
      this.listen(this.$('lt-update-file'),'change',async e=>{const file=e.target.files?.[0];e.target.value='';if(!file)return;try{const bundle=await window.LiquidTouchUpdater.importFile(file);if(this.destroyed)return;if(bundle.version===VERSION){this.setUpdateStatus('This file is the version already running.');return;}this.showUpdatePrompt({bundle,version:bundle.version,summary:bundle.summary,source:file.name});}catch(error){this.setUpdateStatus(error.message);}});
      this.listen(this.releaseDialog,'click',e=>{if(e.target.closest('a[data-action="fullReleaseNotes"]')){e.preventDefault();void this.action('fullReleaseNotes');}});
      this.listen(this.settings, "input", e => {
        if (["textScale", "uiScale", "playerTextScale", "playerLyricsScale", "playerControlScale", "cardTapDelay", "keyboardHeight", "artworkSize", "glassOpacity", "rounding", "quickSearchBlur","motionSpeed",...MOTION_CONTROLS.map(([key])=>key),...GESTURE_CONTROLS.map(([key])=>key),...OPACITY_PANELS.map(([key])=>key)].includes(e.target.dataset.pref)) this.changeScale(e.target.dataset.pref, Number(e.target.value));
      });
      this.listen(document,'click',event=>{
        const handledUntil=this.fastPointerClicks.get(event.pointerId);
        if(event.isTrusted && handledUntil && Date.now()<handledUntil){this.fastPointerClicks.delete(event.pointerId);this.fastClickBlock=null;event.preventDefault();event.stopImmediatePropagation();return;}
        const block=this.fastClickBlock;
        if(event.isTrusted && block && Date.now()<block.until && (block.button.contains(event.target) || event.detail>0 && Math.hypot(event.clientX-block.x,event.clientY-block.y)<4)){
          this.fastClickBlock=null;event.preventDefault();event.stopImmediatePropagation();return;
        }
        this.captureSearchSelection(event.target);
      },{capture:true});
      this.listen(document,'pointerdown',event=>{this.fastClickBlock=null;this.fastPointerClicks.delete(event.pointerId);this.reservePendingCardTap(event.target);},{capture:true});
      this.listen(document,'pointercancel',()=>{if(this.pendingCardTap?.reserved)this.cancelPendingCardTap();},{capture:true});
      this.listen(this.browse,'input',event=>{if(event.target.id==='lt-library-search'){this.libraryQuery=event.target.value;this.renderBrowse();}});
      this.listen(this.browse,'scroll',()=>{
        if(this.libraryOpen && this.libraryHasMore && this.browse.scrollTop+this.browse.clientHeight>this.browse.scrollHeight-180)void this.loadLibrary();
      },{passive:true});
      this.listen(this.$('lt-history-search'),'input',()=>{this.historyLimit=100;this.renderHistory();this.$('lt-history-list').scrollTop=0;});
      for(const input of [this.searchInput,this.$('lt-quick-input'),this.$('lt-history-search')])this.listen(input,'focus',()=>{this.keyboardTarget=input;if(this.prefs.keyboard)this.showKeyboard(true);});
      for(const root of [this.settings,this.historyPage])this.listen(root,'change',e=>{if(e.target.matches('[data-history-limit]'))this.setHistoryLimit(Number(e.target.value));});
      this.listen(this.rescue, "click", () => this.enable(true));
      this.listen(this.$("lt-search-form"), "submit", e => { e.preventDefault(); this.submitSearch(); });
      this.listen(this.searchInput, "focus", () => { if (this.prefs.keyboard) this.showKeyboard(true); });
      this.listen(this.$("lt-key-rows"), "click", e => {
        const key = e.target.closest("button[data-key]");
        if(key?.dataset.key==='Backspace' && this.backspaceClickBlock?.button===key && Date.now()<this.backspaceClickBlock.until){this.backspaceClickBlock=null;e.preventDefault();return;}
        if (key) this.typeKey(key.dataset.key);
      });
      for (const dialog of [this.nowPlaying, this.settings, this.historyPage, this.releaseDialog, this.utility]) {
        this.listen(dialog, "cancel", e => { e.preventDefault(); if(dialog===this.utility){this.utilityBack();return;}if(dialog===this.settings && this.settingsSection){this.showSettingsSection(null);return;}if(dialog===this.nowPlaying && !this.$("lt-lyrics-menu").hidden){this.showLyricsMenu(false,true);return;}this.closeDialog(dialog); });
        this.listen(dialog, "click", e => {
          // Clicking a dialog's backdrop reports the dialog as the target.
          if ((dialog === this.settings || dialog===this.utility && this.utilityState?.kind==='context') && e.target === dialog) {
            const r = dialog.getBoundingClientRect();
            if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) this.closeDialog(dialog);
          }
        });
      }
      this.listen(document,'pointerdown',e=>{if(!e.target.closest?.('.lt-lyrics-tools,#lt-lyrics-menu'))this.showLyricsMenu(false);},{capture:true});
      this.listen(window,'resize',()=>this.showLyricsMenu(false));
      this.listen(document,'scroll',e=>{if(!this.$('lt-lyrics-menu').hidden && e.target.contains?.(this.nowPlaying.querySelector('[data-action="lyricsMenu"]')))this.positionLyricsMenu();},{capture:true,passive:true});
      this.listen(this.nowPlaying.querySelector('[data-action="lyricsMenu"]'),'pointerdown',e=>e.preventDefault());
      this.listen(this.nowPlaying.querySelector('[data-action="lyricsMenu"]'),'keydown',e=>{
        if(e.key==='ArrowDown' || e.key==='ArrowUp'){e.preventDefault();this.showLyricsMenu(true);const buttons=this.$('lt-lyrics-menu').querySelectorAll('button');buttons[e.key==='ArrowUp' ? buttons.length-1 : 0].focus({preventScroll:true});}
      });
      this.listen(this.$('lt-lyrics-menu'),'keydown',e=>{
        const buttons=[...e.currentTarget.querySelectorAll('button')],index=buttons.indexOf(document.activeElement);
        if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();buttons[e.key==='Home' ? 0 : e.key==='End' ? buttons.length-1 : (index+(e.key==='ArrowDown' ? 1 : -1)+buttons.length)%buttons.length].focus();}
        if(e.key==='Tab')this.showLyricsMenu(false,true);
      });
      this.listen(document, "keydown", e => {
        if(e.key==='Escape' && !this.$('lt-lyrics-menu').hidden){e.preventDefault();e.stopPropagation();this.showLyricsMenu(false,true);return;}

        if (e.ctrlKey && e.altKey && e.code === "KeyT") {
          e.preventDefault(); this.enable(!this.enabled); return;
        }
        if (e.key === "Escape" && !this.nowPlaying.open && !this.settings.open) {
          if (!this.$("lt-keyboard").hidden) { this.showKeyboard(false); this.searchInput.blur(); }
          else if (this.libraryOpen) { this.libraryOpen = false; this.routeChanged(false); }
        }
      });
      this.listen(this.seek, "input", () => {
        this.editing.add("seek");
        this.paintRange(this.seek);
        const ms = number(this.seek.value) / 1000 * this.duration;
        this.$("lt-elapsed").textContent = time(ms);
        this.seek.setAttribute("aria-valuetext", `${time(ms)} of ${time(this.duration)}`);
      });
      this.listen(this.seek, "change", () => {
        this.lastUserSeek=Date.now();
        const ratio = number(this.seek.value) / 1000;
        this.editing.delete("seek");
        // Milliseconds avoid the wrapper treating the integer ratio 1 as 1 ms.
        void this.callPlayer("seek", Math.round(ratio * this.duration));
      });
      this.listen(this.volume, "input", () => {
        this.editing.add("volume");
        this.paintRange(this.volume);
        this.$("lt-volume-text").textContent = `${this.volume.value}%`;
      });
      this.listen(this.volume, "change", () => {
        this.editing.delete("volume");
        void this.callPlayer("setVolume", number(this.volume.value) / 100);
      });
      for (const input of [this.seek, this.volume]) {
        this.listen(input, "pointercancel", () => { this.editing.clear(); this.render(); });
        this.listen(input, "blur", () => { this.editing.delete(input === this.seek ? "seek" : "volume"); });
      }
      this.bindNativeTrackTaps();
      this.bindNativeCardTaps();
      this.onPlayerEvent = event => {
        const state = event?.data || event?.detail?.data || event?.detail;
        if (state && typeof state === "object") this.eventState = state;
        else if(event && (event.type === "songchange" || event.data === null))this.eventState=null;
        this.render();
      };
      for (const event of ["songchange", "onplaypause"]) this.player.addEventListener(event, this.onPlayerEvent);
      if (typeof this.history.listen === "function") this.unlisten = this.history.listen(event => {
        const path=event?.location?.pathname || event?.pathname || this.history.location?.pathname || '/';
        this.acceptHostRoute(path);
      });
      this.observer = new MutationObserver(records => {
        if (!this.enabled || document.hidden || this.nowPlaying.open || !records.some(record => {
          const node = record.target.nodeType === 1 ? record.target : record.target.parentElement;
          return !node?.closest(OWN+',.Root__now-playing-bar,[data-testid="now-playing-bar"]');
        })) return;
        this.queueCatalogRefresh();
      });
      this.observer.observe(document.querySelector(".Root") || document.body, { childList: true, subtree: true });
      if (window.ResizeObserver) {
        this.resizeObserver = new ResizeObserver(() => {
          if (this.destroyed) return;
          if (!this.$("lt-keyboard").hidden) document.body.style.setProperty("--lt-keyboard-height", `${this.$("lt-keyboard").offsetHeight}px`);
          this.updateLayoutMetrics();
        });
        this.resizeObserver.observe(this.$("lt-keyboard"));
        this.resizeObserver.observe(this.shell.querySelector(".lt-footer"));
        this.resizeObserver.observe(this.shell.querySelector(".lt-header"));
      }
      this.listen(window, "resize", () => { this.updateLayoutMetrics(); void this.syncWindowChrome();clearTimeout(this.windowMotionTimer);if(!this.nowPlaying.open)this.windowMotionTimer=this.later(()=>this.animatePageChange(0),80); });
      this.listen(document, "fullscreenchange", () => { void this.syncWindowChrome(); this.updateLayoutMetrics(); });
      this.listen(window, "beforeunload", () => { void this.restoreNativeChrome(true); });
    }
    bindNativeTrackTaps() {
      // A short, stationary finger tap activates Spotify's own row play button,
      // preserving playlist context. Scrolling, mouse input, artist links, and
      // existing buttons retain their native behavior.
      let candidate = null;
      const start = e => {
        candidate = null;
        if (!this.enabled || e.pointerType !== "touch" || e.target.closest(OWN)) return;
        const row = e.target.closest(".main-trackList-trackListRow");
        if (!row || e.target.closest('button, input, select, [role="button"]')) return;
        const anchor = e.target.closest("a");
        if (anchor && !/^\/track\//.test(anchor.getAttribute("href") || "")) return;
        const play = row.querySelector('.main-trackList-rowSectionStart button, [data-testid="play-button"]');
        if (!play || play.disabled) return;
        candidate = { row, play, id: e.pointerId, x: e.clientX, y: e.clientY, at: Date.now() };
      };
      this.listen(document, "pointerdown", start, { capture: true });
      this.listen(document, "pointercancel", () => { candidate = null; }, { capture: true });
      this.listen(document, "pointerup", e => {
        const tap = candidate; candidate = null;
        if (!tap || tap.id !== e.pointerId || !tap.row.isConnected || !tap.row.contains(e.target)) return;
        if (Date.now() - tap.at > 600 || Math.hypot(e.clientX - tap.x, e.clientY - tap.y) > 12) return;
        this.nativeTouchBlock = { row: tap.row, until: Date.now() + 500 };
        e.preventDefault(); tap.play.click();
      }, { capture: true });
      this.listen(document, "click", e => {
        if (e.isTrusted && this.nativeTouchBlock && Date.now() < this.nativeTouchBlock.until && this.nativeTouchBlock.row.contains(e.target)) {
          e.preventDefault(); e.stopPropagation(); this.nativeTouchBlock = null;
        }
      }, { capture: true });
    }
    cardContext(target) {
      if (!target?.closest || target.closest(OWN) || target.closest('.main-trackList-trackListRow, input, select, textarea, [role="menu"], [role="dialog"]')) return null;
      let card=target.closest('.main-card-card, [data-testid="card"], [data-testid="grid-card"], [data-testid="card-container"], [data-encore-id="card"], .main-yourLibraryX-listItem, [data-testid="shortcut"]');
      let link=target.closest('a[href]');
      if (!card && link) {
        let parent=link;
        for(let i=0;i<5 && parent;i++,parent=parent.parentElement){
          const rect=parent.getBoundingClientRect();
          if(parent.querySelector('img') && rect.width>=100 && rect.width<=650 && rect.height>=44 && rect.height<=550){card=parent;break;}
        }
      }
      if (!card) return null;
      const control=target.closest('button, [role="button"]');
      if(control && !control.querySelector('img') && !control.matches('[data-lt-card-open]'))return null;
      link=link || card.querySelector('a[href^="/playlist/"],a[href^="/album/"],a[href^="spotify:playlist:"],a[href^="spotify:album:"],a[href^="/artist/"],a[href^="spotify:artist:"]');
      let raw=card.dataset.uri || card.dataset.contextUri || link?.getAttribute('href') || '';
      if(/^https:\/\/open\.spotify\.com\//.test(raw)){try{raw=new URL(raw).pathname;}catch{return null;}}
      const match=raw.match(/^(?:spotify:(album|playlist|artist):|\/(album|playlist|artist)\/)([\w-]+)/);
      if(!match)return null;
      const type=match[1] || match[2], id=match[3];
      return {card,uri:`spotify:${type}:${id}`,path:`/${type}/${id}`};
    }
    bindNativeCardTaps() {
      let candidate=null;
      this.listen(document,'pointerdown',event=>{
        candidate=null;
        if(!this.enabled || event.button>0 || event.isPrimary===false)return;
        const info=this.cardContext(event.target);
        if(info){candidate={...info,id:event.pointerId,x:event.clientX,y:event.clientY,at:Date.now()};event.stopPropagation();}
      },{capture:true});
      this.listen(document,'pointercancel',()=>{candidate=null;},{capture:true});
      this.listen(document,'pointerup',event=>{
        const tap=candidate;candidate=null;
        if(!tap || tap.id!==event.pointerId || !tap.card.isConnected || !tap.card.contains(event.target))return;
        if(Date.now()-tap.at>650 || Math.hypot(event.clientX-tap.x,event.clientY-tap.y)>12)return;
        event.preventDefault();event.stopPropagation();
        this.cardClickBlock={card:tap.card,until:Date.now()+700};
        this.queueCardTap(tap,tap.card,()=>void this.playCard(tap),()=>this.navigate(tap.path));
      },{capture:true});
      this.listen(document,'click',event=>{
        if(event.isTrusted && event.detail>0 && this.cardClickBlock && Date.now()<this.cardClickBlock.until && this.cardClickBlock.card.contains(event.target)){
          event.preventDefault();event.stopImmediatePropagation();
        }
      },{capture:true});
      this.listen(document,'dblclick',event=>{
        if(this.enabled && this.cardContext(event.target)){event.preventDefault();event.stopImmediatePropagation();}
      },{capture:true});
    }
    async playCard(info) {
      const state=this.getPlayerState();
      const context=state?.context?.uri || state?.context_uri;
      if(context===info.uri){
        if(!read(()=>this.player.isPlaying(),false))await this.callPlayer('play');
        return;
      }
      this.rememberSearch(this.entities.get(info.uri) || normalizeEntity({uri:info.uri,name:info.card.querySelector('a,h3,strong')?.textContent,imageUrl:info.card.querySelector('img')?.src}));
      await this.callPlayer('playUri',info.uri);
    }
    showSettingsSection(id, focus=true, animate=true){
      this.settingsGestureToken=(this.settingsGestureToken || 0)+1;
      if(this.settingsGestureRunning || this.activeGesture?.dialog===this.settings){this.settingsGestureRunning=false;this.activeGesture=null;this.clearGestureMotion(false);}
      const section=this.settingsSections.get(id),next=section?.id || null;
      const scroller=this.settings.querySelector('.lt-settings-content'),previous=this.settingsSection;
      if(previous!==next)this.settingsScroll.set(previous,scroller.scrollTop);
      this.settingsSection=next;
      this.$('lt-settings-categories').hidden=Boolean(section);
      for(const page of this.settings.querySelectorAll('[data-settings-page]'))page.hidden=page.dataset.settingsPage!==next;
      this.$('lt-settings-title').textContent=section?.title || 'Make it yours.';
      this.$('lt-settings-subtitle').textContent=section?.subtitle || `LiquidTouch · ${VERSION} · revised`;
      this.settings.querySelector('[data-action="settingsBack"]').hidden=!section;
      scroller.scrollTop=this.settingsScroll.get(next) || 0;
      if(focus){
        const target=section ? this.$('lt-settings-title') : this.settings.querySelector(`[data-settings-section="${previous}"]`);
        requestAnimationFrame(()=>{if(!this.destroyed && this.settings.open && this.settingsSection===next)target?.focus({preventScroll:true});});if(animate)this.animateSurface(scroller,true,'settingsPageSpeed');
      }
    }
    applyPreferences() {
      const d = document.body.dataset;
      d.ltPalette = this.prefs.palette;
      d.ltSize = this.prefs.size;
      d.ltLite = String(this.prefs.lite);
      d.ltLowMemory=String(this.prefs.lowMemory);
      this.applyMemoryPolicy();
      d.ltMotion = this.prefs.reduceMotion ? "reduce" : "auto";
      if (this.lastWindowPreference !== this.prefs.windowControls) {
        this.chromeFailed = false; this.lastWindowPreference = this.prefs.windowControls;
      }
      if(!this.motionAllowed())this.stopMotion();
      const style = document.body.style;
      const text = this.prefs.textScale / 100, scale = this.prefs.uiScale / 100;
      style.setProperty("--lt-text-scale", String(text));
      style.setProperty("--lt-ui-scale", String(scale));
      style.setProperty("--lt-app-text-scale",String(text));style.setProperty("--lt-app-ui-scale",String(scale));
      style.setProperty("--lt-player-lyrics-scale",String(this.prefs.playerLyricsScale/100));style.setProperty("--lt-player-text-scale",String(this.prefs.playerTextScale/100));style.setProperty("--lt-player-control-scale",String(this.prefs.playerControlScale/100));
      style.setProperty("--lt-keyboard-scale", String(this.prefs.keyboardHeight/100));
      style.setProperty("--lt-artwork-scale", String(this.prefs.artworkSize/100));
      style.setProperty("--lt-quick-search-blur",this.prefs.quickSearchBlur+"px");
      this.applyGlassPreferences();this.applyMotionPreferences();
      style.setProperty("--lt-touch", `${(this.prefs.size === "large" ? 56 : 48) * scale}px`);
      style.setProperty("--lt-row", `${Math.max((this.prefs.size === "large" ? 72 : 64) * scale, 44 * text + 20)}px`);
      style.setProperty("--lt-header", `${Math.max((this.prefs.size === "large" ? 72 : 64) * scale, 32 * text + 24)}px`);
      style.setProperty("--lt-mini", `${Math.max((this.prefs.size === "large" ? 80 : 72) * scale, 44 * text + 24)}px`);
      style.setProperty("--lt-nav", `${Math.max((this.prefs.size === "large" ? 80 : 72) * scale, 26 * scale + 19 * text + 20)}px`);
      style.setProperty("--lt-radius", `${this.prefs.rounding}px`);
      d.ltExpandedText = String(text >= 1.6);
      d.ltRoomy = String(text >= 1.6 || scale >= 1.3);
      for(const input of [this.searchInput,this.$("lt-quick-input"),this.$("lt-history-search")])input.setAttribute("inputmode",this.prefs.keyboard ? "none" : "search");
      for(const key of ["welcome","welcomeSubtitle"])this.$(`lt-${key}`).value=this.prefs[key];
      this.$('lt-update-feed').value=this.prefs.updateFeed;
      for (const key of ["palette", "size"]) this.$(`lt-${key}`).value = this.prefs[key];
      this.$('lt-clockFormat').value=this.prefs.clockFormat;this.$('lt-clockFormat').disabled=!this.prefs.homeClock;this.refreshHomeClock();
      for (const key of ["textScale", "uiScale", "playerTextScale", "playerLyricsScale", "playerControlScale", "cardTapDelay", "keyboardHeight", "artworkSize", "rounding", "quickSearchBlur"]) {
        const value=settingPercent(key,this.prefs[key]);this.$(`lt-${key}`).value = String(value);
        this.$(`lt-${key}-value`).textContent = `${value}%`;
        this.$(`lt-${key}`).setAttribute("aria-valuetext", `${value} percent`);
        this.paintRange(this.$(`lt-${key}`));
      }
      for (const node of this.settings.querySelectorAll('[role="switch"][data-pref]')) node.setAttribute("aria-checked", String(this.prefs[node.dataset.pref]));
      if (!this.prefs.keyboard) this.showKeyboard(false);
      this.applyLyricsLayout();
      this.applyArtworkColor(this.currentColor || [62,82,108]);
      this.updateLayoutMetrics();
      if (this.enabled){void this.syncWindowChrome();this.renderBrowse();}
    }
    applyMemoryPolicy(){
      if(this.lastMemoryPolicy===this.prefs.lowMemory)return;
      this.lastMemoryPolicy=this.prefs.lowMemory;this.startRenderClock();this.syncLyricClock();
      this.gridLimits?.clear();this.homeShelfLimit=3;this.gridVersion=(this.gridVersion || 0)+1;
      this.lastPlayerSignature=null;this.browseSignature=null;this.lastColorKey=null;
      if(!this.prefs.lowMemory){if(this.lastImage){this.ambientArt.src=this.lastImage;this.$('lt-player-background').src=this.lastImage;}return;}
      this.stopMotion();
      for(const page of this.detailPages.values())page.visibleTracks=40;
      this.ambientArt?.removeAttribute('src');this.$('lt-player-background')?.removeAttribute('src');
      this.browsePages.clear();this.warmedArtwork?.clear();
      for(const [cache,limit] of [[this.searchCache,8],[this.artCache,32],[this.lyricsCache,4],[this.colorCache,12],[this.detailPages,2]])while(cache.size>limit){const key=[...cache.keys()].find(key=>cache!==this.detailPages || key!==this.detailInfo()?.uri);if(key===undefined)break;cache.delete(key);}
      this.artJobs=this.artJobs.filter(uri=>this.browse?.querySelectorAll('[data-uri]') && [...this.browse.querySelectorAll('[data-uri]')].some(card=>card.dataset.uri===uri)).slice(0,12);
    }
    changeScale(key, value) {
      const input = this.$(`lt-${key}`);
      if (!input) return;
      const percent=clamp(Math.round(value/5)*5,Number(input.min),Number(input.max));
      this.prefs[key] = settingValue(key,percent);
      this.save();
      if(key==='glassOpacity' || OPACITY_PANELS.some(([name])=>name===key)){this.applyGlassPreferences();return;}
      if(key==='motionSpeed' || MOTION_CONTROLS.some(([name])=>name===key) || GESTURE_CONTROLS.some(([name])=>name===key)){this.applyMotionPreferences();return;}
      this.applyPreferences();
      if(this.enabled)this.renderBrowse();
      if (this.nativeResizeTimer) { clearTimeout(this.nativeResizeTimer); this.timers.delete(this.nativeResizeTimer); }
      this.nativeResizeTimer = this.later(() => window.dispatchEvent(new Event("resize")), 100);
    }
    applyGlassPreferences(){
      const style=document.body.style;style.setProperty('--lt-glass-opacity',String(this.prefs.glassOpacity/100));
      for(const [key,property] of OPACITY_PANELS){
        if(this.prefs[key]===null)style.removeProperty(property);else style.setProperty(property,String(this.prefs[key]/100));
      }
      for(const [key,target] of [['navOpacity',this.shell.querySelector('.lt-nav')],['miniOpacity',this.shell.querySelector('.lt-mini')],['settingsOpacity',this.settings],['settingsOpacity',this.releaseDialog],['historyOpacity',this.historyPage],['settingsOpacity',this.utility],['playerHeaderOpacity',this.nowPlaying]]){
        const opacity=(this.prefs[key] ?? this.prefs.glassOpacity)/100;
        target.style.setProperty('--lt-surface-opacity',String(opacity));target.dataset.ltClear=String(opacity===0);target.dataset.ltSolid=String(opacity===1);
      }
      for(const key of ['glassOpacity',...OPACITY_PANELS.map(([name])=>name)]){
        const inherited=this.prefs[key]===null,value=inherited ? this.prefs.glassOpacity : this.prefs[key],input=this.$('lt-'+key);
        input.value=String(value);input.disabled=inherited;input.setAttribute('aria-valuetext',`${value} percent${inherited ? ', follows universal' : ''}`);this.paintRange(input);
        this.$('lt-'+key+'-value').textContent=value+'%';
        const panel=input.closest('.lt-opacity-panel');
        if(panel){
          panel.querySelector('[data-opacity-override]').setAttribute('aria-checked',String(!inherited));
          panel.querySelector('small').textContent=inherited ? `Following universal: ${value}%.` : 'Custom tint. Turn off Custom to follow Universal again.';
          for(const button of panel.querySelectorAll('[data-adjust]'))button.disabled=inherited;
        }
      }
    }
    updateLayoutMetrics() {
      if (!this.shell || this.destroyed) return;
      this.updateSearchPreviewBounds();
      this.syncNavigation();
      document.body.style.setProperty("--lt-card-columns",String(Math.min(4,Math.max(1,Math.floor((innerWidth-64)/Math.max(180*this.prefs.uiScale/100,145*this.prefs.textScale/100))))));
      const footer = this.shell.querySelector(".lt-footer");
      if (footer && footer.getBoundingClientRect().height) {
        const size = Math.ceil(footer.getBoundingClientRect().height + Math.max(10, innerHeight - footer.getBoundingClientRect().bottom) + 8);
        const value = `${size}px`;
        if (document.body.style.getPropertyValue("--lt-footer-measured") !== value) document.body.style.setProperty("--lt-footer-measured", value);
      }
    }
    windowCapabilities() {
      const platform = this.S.Platform;
      const client = platform?.FocusMainWindowAPI?._windowStateClient;
      const control = [platform?.ControlMessageAPI?._updateUiClient, platform?.UpdateAPI?._updateUiClient].find(value =>
        typeof value?.updateTitlebarHeight === "function" && typeof value?.setButtonsVisibility === "function");
      return client && control && ["setWindowState", "getWindowState", "closeWindow"].every(key => typeof client[key] === "function") ? {client,control} : null;
    }
    nativeTitlebarHeight() {
      const os = String(this.S.Platform?.operatingSystem || this.S.Platform?.PlatformData?.os_name || navigator.platform || "").toLowerCase();
      if (this.originalNativeChromeHeight !== undefined) return this.originalNativeChromeHeight;
      if (!/win|mac|osx/.test(os)) return 0;
      const known = document.querySelector('.Titlebar, [data-testid="window-controls"], .main-topBar-windowControls');
      const height = known?.getBoundingClientRect().bottom;
      return height && height > 1 && height < 130 ? Math.ceil(height) : /mac|osx/.test(os) ? 40 : 64;
    }
    customChromeGeometry() {
      const scale=this.prefs.uiScale/100;
      document.body.style.setProperty("--lt-chrome-height", `${innerWidth<=650 ? Math.max(52,48*scale+8) : 0}px`);
      document.body.style.setProperty("--lt-caption-width", `${132*scale+14}px`);
    }
    async syncWindowChrome() {
      if (this.destroyed || this.chromeBusy) return;
      const capability = this.windowCapabilities();
      const wanted = this.enabled && this.prefs.windowControls && Boolean(capability) && !this.chromeFailed;
      if (!wanted) {
        if (this.nativeChromeOwned) await this.restoreNativeChrome();
        this.chromeMode = "native";
        document.body.dataset.ltWindow = "native";
        document.body.style.setProperty("--lt-chrome-height", `${this.enabled && !document.fullscreenElement ? this.nativeTitlebarHeight() : 0}px`);
        return;
      }
      if(this.originalNativeChromeHeight===undefined){
        this.originalNativeChromeHeight=window[CHROME_BASE_HEIGHT] ?? this.nativeTitlebarHeight();
        window[CHROME_BASE_HEIGHT]=this.originalNativeChromeHeight;
      }
      this.customChromeGeometry();
      if (this.chromeMode === "custom" && this.nativeChromeOwned) {
        if(Date.now()-(this.chromeRefreshed || 0)>6000){this.chromeRefreshed=Date.now();void queueChrome(async()=>{if(!this.enabled || this.destroyed)return;await capability.control.updateTitlebarHeight({height:1});await capability.control.setButtonsVisibility({showButtons:false});}).catch(()=>{});}
        return;
      }
      this.chromeBusy = true;
      try {
        this.windowClient = capability.client;
        this.windowControlClient = capability.control;
        // Custom controls already exist before the native strip is collapsed.
        document.body.dataset.ltWindow = "custom";
        this.customChromeGeometry();
        this.nativeChromeOwned = true;
        await queueChrome(async()=>{
          await capability.control.updateTitlebarHeight({height:1});
          await capability.control.setButtonsVisibility({showButtons:false});
        });
        if (this.destroyed || !this.enabled || !this.prefs.windowControls) { await this.restoreNativeChrome(); return; }
        this.chromeMode = "custom";
      } catch (error) {
        this.chromeFailed = true;
        console.warn("[LiquidTouch] Window controls:", error);
        await this.restoreNativeChrome();
      } finally { this.chromeBusy = false; this.updateLayoutMetrics(); }
    }
    async restoreNativeChrome(immediate=false) {
      if (!this.nativeChromeOwned) return;
      this.nativeChromeOwned = false; this.chromeMode = "native";
      document.body.dataset.ltWindow = "native";
      document.body.style.setProperty("--lt-chrome-height", `${this.enabled && !document.fullscreenElement ? this.nativeTitlebarHeight() : 0}px`);
      const control = this.windowControlClient;
      if (!control) return;
      // Restore on desktop mode, teardown, unloading, or any bridge failure.
      const calls = [() => control.updateTitlebarHeight({height:Math.max(1,this.originalNativeChromeHeight ?? 64)}), () => control.setButtonsVisibility({showButtons:true})];
      if(immediate){
        // Both IPC requests must be sent before an unloading renderer disappears.
        for(const call of calls){try{Promise.resolve(call()).catch(()=>{});}catch{}}
        return;
      }
      await queueChrome(async()=>{
        for (const call of calls) { try { await call(); } catch (error) { console.warn("[LiquidTouch] Restoring native controls:", error); } }
      });
    }
    async windowAction(action) {
      const current=this.settings.open ? this.settings : this.historyPage.open ? this.historyPage : this.nowPlaying.open ? this.nowPlaying : this.shell;
      this.playMotion(current.querySelector('.lt-caption-buttons'),[{transform:'scale(.96)'},{transform:'none'}],{motion:'windowSpeed',duration:100});
      const api = this.windowCapabilities()?.client;
      if (!api) { await this.restoreNativeChrome(); this.notify("Spotify’s system window controls are available."); return; }
      try {
        if (action === "windowMinimize") await api.setWindowState({state:3});
        else if (action === "windowClose") await api.closeWindow({});
        else {
          const result = await api.getWindowState({});
          await api.setWindowState({state:result.state === 2 ? 1 : 2});
        }
      } catch (error) {
        this.chromeFailed = true;
        console.warn("[LiquidTouch] Native window action:", error);
        await this.restoreNativeChrome();
        this.notify("Spotify’s system window controls have been restored.");
      }
    }
    enable(enabled, persist = true) {
      if(!enabled){this.cancelPendingCardTap();this.cancelLyricPrefetch();}
      if (enabled) {
        this.refreshNative();
        const themed = getComputedStyle(document.documentElement).getPropertyValue("--lt-header").trim();
        if ((!this.main && !this.detailInfo()) || !themed) {
          this.enabled = false;
          document.body.classList.remove("lt-active");
          this.rescue.hidden = false;
          this.notify(themed ? "Spotify’s main view is not ready. Try Touch UI again in a moment." : "Select the LiquidTouch theme and run spicetify apply first.");
          return;
        }
      }
      this.enabled = enabled;
      if (persist) { this.prefs.enabled = enabled; this.save(); }
      if (!enabled) {
        this.closeDialog(this.utility);this.closeDialog(this.releaseDialog);this.closeDialog(this.settings); this.closeDialog(this.nowPlaying); this.closeDialog(this.historyPage);
        this.showKeyboard(false); this.libraryOpen = false;
      }
      document.body.classList.toggle("lt-active", enabled);
      this.rescue.hidden = enabled;
      if (enabled) { this.routeChanged(false); this.render(); }
      void this.syncWindowChrome();
    }
    routeChanged(clearLibrary = true, requestedPath) {
      const previousNav=this.shell.querySelector('.lt-nav [aria-current="page"]'),oldTab=previousNav?.dataset.action;
      if (clearLibrary) this.libraryOpen = false;
      const path = requestedPath || this.getRoutePath();
      this.routePath=path;this.lastRoutePath = this.history.location?.pathname;
      this.detailOwned=!this.libraryOpen && Boolean(this.detailInfo(path));if(this.detailOwned)this.localDetailAt=Date.now();
      const tab = this.libraryOpen ? "library" : path.startsWith("/search") ? "search" : "home";
      document.body.dataset.ltPage = tab;
      this.$("lt-page-title").textContent = this.libraryOpen ? "Your Library" : path === "/" ? "Home" : path.startsWith("/queue") ? "Queue" : path.startsWith("/search") ? "Search" : "Your music";
      this.$("lt-heading").hidden = tab === "search";
      this.$("lt-search-form").hidden = tab !== "search";
      for (const node of this.shell.querySelectorAll(".lt-nav button")) {
        if (node.dataset.action === tab) node.setAttribute("aria-current", "page");
        else node.removeAttribute("aria-current");
      }
      if (tab !== "search") this.showKeyboard(false);
      if (tab === "search") {
        const segment = path.slice("/search/".length);
        if (path.startsWith("/search/") && document.activeElement !== this.searchInput) {
          try { this.searchInput.value = decodeURIComponent(segment); } catch { /* malformed route */ }
        }
        if(/^\/search\/?$/.test(path))this.searchInput.value='';
      }
      this.queueCatalogRefresh();
      this.renderBrowse();
      if(this.browse.hidden){
        this.refreshNative(false);
        // React can replace the main view in the frame after History.push.
        const route=path;requestAnimationFrame(()=>{if(!this.destroyed && this.getRoutePath()===route && this.browse.hidden)this.refreshNative(false);});
      }
      const view=this.libraryOpen ? 'library' : this.viewKey(this.snapshotView());
      if(this.lastMotionView && view!==this.lastMotionView){
        const tabs=['home','search','library'],motion=this.nextPageMotion || {direction:oldTab===tab ? 0 : Math.sign(tabs.indexOf(tab)-tabs.indexOf(oldTab))};this.nextPageMotion=null;
        this.animatePageChange(motion.direction,motion.distance,motion.duration);this.animateNavigation(previousNav);
      }
      this.lastMotionView=view;
      if(!this.navVisualIndex || oldTab===tab)this.syncNavigation();
      const query=this.queryFromPath(path);if(!this.libraryOpen && query && query!==this.resultsQuery)void this.loadSearchResults(query);
    }
    navigate(path, remember=true,library=false) {
      if(this.currentSearchQuery()!==this.queryFromPath(path))this.nativeSearchOwner=null;
      this.cancelPendingCardTap();
      if(!this.nextPageMotion && path!==this.getRoutePath() && path!=='/' && path!=='/search' && !library)this.nextPageMotion={direction:1};
      if(remember && (path!==this.getRoutePath() || this.libraryOpen))this.rememberView();
      this.lastRequestedAt=Date.now();this.routePath=path;this.pendingRoute={path,at:Date.now()};this.hideSearchPreview();this.showQuickSearch(false);
      const local=Boolean(this.detailInfo(path)) || /^\/search(?:\/|$)/.test(path);this.detailOwned=Boolean(this.detailInfo(path)) && !library;this.localDetailAt=this.lastRequestedAt;if(/^\/search(?:\/|$)/.test(path))this.localSearchAt=this.lastRequestedAt;
      const request={path,local,at:this.lastRequestedAt,serial:++this.navigationSerial,pending:!local && this.history.location?.pathname!==path};this.latestRouteRequest=request;this.routeRequests.set(path,request);
      while(this.routeRequests.size>40)this.routeRequests.delete(this.routeRequests.keys().next().value);
      this.closeDialog(this.settings); this.closeDialog(this.nowPlaying); this.closeDialog(this.historyPage);
      this.closeDialog(this.utility);this.closeDialog(this.releaseDialog);
      this.showKeyboard(false); this.libraryOpen = library;
      if(!local && this.history.location?.pathname!==path){this.issuingRoute=true;try{this.history.push(path);}finally{this.issuingRoute=false;}}
      this.routeChanged(false,path);
      if(local)this.pendingRoute=null;
      if(this.pendingRoute && this.history.location?.pathname===path){request.pending=false;this.observedHostPath=path;this.pendingRoute=null;}
      this.queueCatalogRefresh();
    }
    showLibrary() {
      this.cancelPendingCardTap();
      if(!this.libraryOpen)this.rememberView();
      if(!this.main?.isConnected || !this.library?.isConnected)this.refreshNative(false);
      if (!this.library && !this.libraryEntities.size && !this.S.Platform?.LibraryAPI) {
        this.enable(false, false);
        this.notify("This Spotify layout needs its desktop library. Tap Touch UI to return.");
        return;
      }
      this.closeDialog(this.settings); this.closeDialog(this.nowPlaying);
      this.libraryOpen = true;this.detailOwned=false;
      this.routeChanged(false,this.getRoutePath());
      if(!this.libraryOffset)void this.loadLibrary(true);
      // Expand Spotify's own library if it is in icon-only mode. Stable test
      // identifiers first; the English accessible-name fallback is optional.
      const expand = this.library?.querySelector('[data-testid="your-library-expand"], .main-yourLibraryX-collapseButton[aria-expanded="false"], button[aria-label="Expand Your Library"], button[aria-label="Expand your library"]');
      if (expand) expand.click();
    }
    showKeyboard(show) {
      if (show && !this.prefs.keyboard) return;
      const keyboard=this.$('lt-keyboard'),history=show && this.keyboardTarget===this.$('lt-history-search') && this.historyPage.open;
      const parent=history ? this.historyPage : this.shell;
      if(keyboard.parentElement!==parent)parent.append(keyboard);
      document.body.dataset.ltHistoryKeyboard=String(Boolean(history));
      keyboard.classList.toggle('lt-history-keyboard',Boolean(history));
      const changed=this.$('lt-keyboard').hidden===show;
      this.$("lt-keyboard").hidden = !show;
      if(!show){this.stopBackspaceRepeat();this.clearKeyFeedback();}
      document.body.dataset.ltKeyboard = String(show);
      this.shell.querySelector('[data-action="keyboard"]').setAttribute("aria-expanded", String(show));
      if (show) document.body.style.setProperty("--lt-keyboard-height", `${keyboard.offsetHeight}px`);
      if(history)this.historyPage.style.setProperty('--lt-history-keyboard-height',keyboard.offsetHeight+'px');
      else this.historyPage.style.removeProperty('--lt-history-keyboard-height');
      if(!show)this.keyboardTarget=null;
      this.updateSearchPreviewBounds();
      if(changed){if(show)this.animateSurface(this.$('lt-keyboard'));else this.animateSurface(this.shell.querySelector('.lt-header'));}
    }
    buildKeyboard() {
      this.stopBackspaceRepeat();
      const rows = this.keyboardSymbols ? [Array.from("1234567890"), Array.from("@#$&-+()/"), Array.from(".,?!':;%")] : [Array.from("qwertyuiop"), Array.from("asdfghjkl"), Array.from("zxcvbnm")];
      const container = this.$("lt-key-rows");
      container.replaceChildren();
      const makeKey = (key, text, className = "", label = text) => {
        const b = document.createElement("button");
        b.type = "button"; b.dataset.key = key; b.textContent = text;
        b.className = className; b.setAttribute("aria-label", label);
        return b;
      };
      for (let i = 0; i < rows.length; i++) {
        const row = document.createElement("div"); row.className = "lt-kb-row";
        if (i === 2 && !this.keyboardSymbols) row.append(makeKey("Shift", "⇧", "lt-kb-wide", "Shift"));
        for (const value of rows[i]) row.append(makeKey(value, this.keyboardShift && !this.keyboardSymbols ? value.toUpperCase() : value));
        if (i === 2) row.append(makeKey("Backspace", "⌫", "lt-kb-wide", "Backspace"));
        container.append(row);
      }
      const bottom = document.createElement("div"); bottom.className = "lt-kb-row";
      bottom.append(makeKey("Symbols", this.keyboardSymbols ? "ABC" : "123", "lt-kb-wide", this.keyboardSymbols ? "Letters" : "Numbers and symbols"),
        makeKey("Clear", "Clear", "lt-kb-wide", "Clear search"), makeKey(" ", "space", "lt-kb-space", "Space"),
        makeKey("Submit", "Search", "lt-kb-wide lt-kb-submit", "Search now"));
      container.append(bottom);
    }
    clearKeyFeedback(){
      this.keyFeedbackToken=(this.keyFeedbackToken || 0)+1;this.keyFeedbackButton?.classList.remove('lt-key-held');this.keyFeedbackButton=null;if(this.keyPopup)this.keyPopup.hidden=true;
    }
    pressKeyFeedback(button){
      this.clearKeyFeedback();this.keyFeedbackButton=button;button.classList.add('lt-key-held');
      const r=button.getBoundingClientRect(),label=button.dataset.key===' ' ? 'space' : button.textContent;
      const width=clamp(Math.max(r.width*1.12,label.length>2 ? 100 : 56),56,160),height=Math.max(60,Math.min(86,r.height));
      this.keyPopup.textContent=label;this.keyPopup.style.cssText=`width:${width}px;height:${height}px;left:${clamp(r.x+r.width/2-width/2,6,innerWidth-width-6)}px;top:${Math.max(4,r.y-height-6)}px;`;
      this.keyPopup.hidden=false;this.playMotion(this.keyPopup,[{transform:'translateY(4px) scale(.9)'},{transform:'none'}],{motion:'keySpeed',duration:70});
    }
    releaseKeyFeedback(){const token=this.keyFeedbackToken;this.later(()=>{if(token===this.keyFeedbackToken)this.clearKeyFeedback();},this.motionDuration(110,'keySpeed'));}
    bindKeyFeedback(){
      this.listen(window,'pointerdown',e=>{const b=e.target.closest?.('#lt-keyboard button[data-key]');if(b && !b.disabled && e.isPrimary!==false && e.button===0){this.pressKeyFeedback(b);if(b.dataset.key==='Backspace'){e.preventDefault();this.startBackspaceRepeat(b,e.pointerId);}}},{capture:true});
      this.listen(window,'pointerup',e=>{if(this.backspaceRepeat?.id===e.pointerId)this.stopBackspaceRepeat();},{capture:true});
      this.listen(window,'pointercancel',()=>this.stopBackspaceRepeat(),{capture:true});
      this.listen(window,'pointermove',e=>{const hold=this.backspaceRepeat;if(hold && e.pointerId===hold.id){const r=hold.button.getBoundingClientRect();if(e.clientX<r.left-8 || e.clientX>r.right+8 || e.clientY<r.top-8 || e.clientY>r.bottom+8)this.stopBackspaceRepeat();}},{capture:true,passive:true});
      this.listen(window,'blur',()=>this.stopBackspaceRepeat());
      this.listen(document,'visibilitychange',()=>{if(document.hidden)this.stopBackspaceRepeat();});
      this.listen(document,'focusin',e=>{if(this.backspaceRepeat && e.target!==this.backspaceRepeat.input)this.stopBackspaceRepeat();});
      this.listen(window,'pointerup',()=>{if(this.keyFeedbackButton)this.releaseKeyFeedback();},{capture:true});
      this.listen(window,'pointercancel',()=>this.clearKeyFeedback(),{capture:true});this.listen(window,'blur',()=>this.clearKeyFeedback());
      this.listen(this.$('lt-key-rows'),'click',e=>{const b=e.target.closest('button[data-key]');if(b && this.keyFeedbackButton!==b){this.pressKeyFeedback(b);this.releaseKeyFeedback();}},{capture:true});
    }
    stopBackspaceRepeat(){
      const hold=this.backspaceRepeat;if(!hold)return;
      clearTimeout(hold.timer);this.backspaceRepeat=null;
      this.backspaceClickBlock={button:hold.button,until:Date.now()+1500};
    }
    startBackspaceRepeat(button,id){
      this.stopBackspaceRepeat();this.backspaceClickBlock=null;
      const input=this.keyboardTarget?.isConnected ? this.keyboardTarget : this.quickOpen ? this.$('lt-quick-input') : this.searchInput;
      const hold={button,id,input,timer:0};this.backspaceRepeat=hold;
      this.backspaceClickBlock={button,until:Date.now()+60000};
      const erase=()=>{
        if(this.backspaceRepeat!==hold)return;
        if(this.destroyed || this.$('lt-keyboard').hidden || !button.isConnected || this.keyboardTarget && this.keyboardTarget!==input || !input.isConnected){this.stopBackspaceRepeat();return;}
        this.typeKey('Backspace');
        if(this.backspaceRepeat!==hold)return;
        if((input.selectionStart ?? input.value.length)===0 && (input.selectionEnd ?? input.value.length)===0){this.stopBackspaceRepeat();return;}
        hold.timer=setTimeout(erase,65);
      };
      this.typeKey('Backspace');
      if(this.backspaceRepeat===hold)hold.timer=setTimeout(erase,380);
    }
    typeKey(key) {
      const input = this.keyboardTarget?.isConnected ? this.keyboardTarget : this.quickOpen ? this.$('lt-quick-input') : this.searchInput;
      if (key === "Submit") { if(input===this.$('lt-history-search')){this.showKeyboard(false);input.blur();}else this.submitSearch(input.value); return; }
      if (key === "Shift") { this.keyboardShift = !this.keyboardShift; this.buildKeyboard(); return; }
      if (key === "Symbols") { this.keyboardSymbols = !this.keyboardSymbols; this.buildKeyboard(); return; }
      input.focus({ preventScroll: true });
      let start = input.selectionStart ?? input.value.length;
      let end = input.selectionEnd ?? start;
      if (key === "Clear") input.value = "";
      else if (key === "Backspace") {
        if (start === end && start > 0) start = Array.from(input.value.slice(0, start)).slice(0, -1).join("").length;
        input.setRangeText("", start, end, "end");
      } else if (input.value.length < 300) {
        input.setRangeText(this.keyboardShift && !this.keyboardSymbols ? key.toUpperCase() : key, start, end, "end");
        if (this.keyboardShift) { this.keyboardShift = false; this.buildKeyboard(); }
      }
      input.dispatchEvent(new Event("input", { bubbles: true }));
    }
    submitSearch(value) {
      const query = cleanText(value ?? this.searchInput.value,300);
      this.hideSearchPreview();this.showQuickSearch(false);
      if(query){this.searchQueries=[{query,at:Date.now()},...this.searchQueries.filter(row=>row.query.toLocaleLowerCase()!==query.toLocaleLowerCase())].slice(0,30);this.persistRecords('search-queries',this.searchQueries);}
      this.searchInput.blur();
      this.navigate(query ? `/search/${encodeURIComponent(query)}` : "/search");
    }
    setUpdateStatus(message){this.$('lt-update-status').textContent=message;}
    saveUpdateFeed(value){
      const address=value.trim() ? window.LiquidTouchUpdater.normalizeFeed(value.trim()) : '';
      if(address===this.prefs.updateFeed)return;
      this.prefs.updateFeed=address;this.save();this.updateCheckToken=(this.updateCheckToken || 0)+1;this.updateCheckBusy=false;this.updateCheckManual=false;this.pendingUpdatePrompt=null;
      this.setUpdateStatus(address ? 'Feed saved. Use Check now to check it.' : 'No hosted release feed is configured.');
    }
    queueReleaseNotes(){
      const seen=read(()=>localStorage.getItem('liquid-touch.seen-release'),'');
      if(seen===VERSION)return;
      if(!seen && (window.LT_DEMO_COVERS || !this.hadSavedPreferences)){try{localStorage.setItem('liquid-touch.seen-release',VERSION);}catch{}return;}
      this.pendingFirstRelease=true;this.flushReleasePrompt();
    }
    flushReleasePrompt(){
      if(!this.enabled || this.destroyed || this.pointerHeld || this.pendingCardTap || this.releaseDialog.open || this.settings.open || this.historyPage.open || this.nowPlaying.open || this.utility.open)return;
      if(this.pendingFirstRelease){this.pendingFirstRelease=false;this.showReleaseNotes();return;}
      if(this.pendingUpdatePrompt){const item=this.pendingUpdatePrompt;this.pendingUpdatePrompt=null;this.showUpdatePrompt(item);}
    }
    paintRelease(summary,full=false){
      const list=this.$('lt-release-summary');list.replaceChildren();for(const line of summary || [])list.append(node('li','',line));list.hidden=full;
      this.$('lt-full-release-notes').hidden=!full;this.releaseDialog.querySelector('a[data-action=fullReleaseNotes]').hidden=full;
      this.$('lt-release-status').textContent='';
    }
    showReleaseNotes(){
      this.updateCandidate=null;const release=window.LiquidTouchUpdater?.release?.() || window.LiquidTouchRelease || {version:VERSION,summary:['LiquidTouch '+VERSION],notes:''};
      this.$('lt-release-title').textContent='What’s new';this.$('lt-release-subtitle').textContent='LiquidTouch '+release.version;this.paintRelease(release.summary);
      this.releaseDialog.querySelector('[data-action=confirmUpdate]').hidden=true;this.releaseDialog.querySelector('footer [data-action=closeRelease]').textContent='Done';
      this.openDialog(this.releaseDialog);try{localStorage.setItem('liquid-touch.seen-release',VERSION);}catch{}
    }
    showUpdatePrompt(item){
      this.updateCandidate=item;this.$('lt-release-title').textContent=item.restore ? 'Restore installed version?' : 'Update available';
      this.$('lt-release-subtitle').textContent=`LiquidTouch ${VERSION} → ${item.version} · ${item.source}`;this.paintRelease(item.summary);
      const button=this.releaseDialog.querySelector('[data-action=confirmUpdate]');button.hidden=false;button.disabled=false;button.textContent=item.restore ? 'Restore' : 'Update';
      this.releaseDialog.querySelector('footer [data-action=closeRelease]').textContent='Later';this.openDialog(this.releaseDialog);
    }
    async preparedUpdate(){
      const candidate=this.updateCandidate;if(!candidate || candidate.restore)return null;if(candidate.bundle)return candidate.bundle;
      candidate.download ||= window.LiquidTouchUpdater.download(candidate).then(bundle=>{candidate.bundle=bundle;return bundle;}).catch(error=>{candidate.download=null;throw error;});return candidate.download;
    }
    async showFullReleaseNotes(){
      try{
        const candidate=this.updateCandidate;this.$('lt-release-status').textContent='Loading patch notes…';const bundle=candidate && !candidate.restore ? await this.preparedUpdate() : window.LiquidTouchUpdater?.release?.();
        if(this.destroyed || candidate!==this.updateCandidate)return;this.paintRelease([],true);this.$('lt-full-release-notes').textContent=bundle?.notes || 'Full notes are not available for this version.';
      }catch(error){if(!this.destroyed)this.$('lt-release-status').textContent=error.message;}
    }
    async confirmUpdate(){
      const candidate=this.updateCandidate;if(!candidate)return;const button=this.releaseDialog.querySelector('[data-action=confirmUpdate]');button.disabled=true;
      try{this.$('lt-release-status').textContent=candidate.restore ? 'Restoring installed version…' : 'Verifying and installing…';if(candidate.restore)window.LiquidTouchUpdater.restore();else await window.LiquidTouchUpdater.apply(await this.preparedUpdate());}
      catch(error){if(!this.destroyed){this.$('lt-release-status').textContent=error.message;button.disabled=false;}}
    }
    maybeCheckUpdates(){
      if(!this.enabled || !this.prefs.updateChecks || !this.prefs.updateFeed || this.updateCheckBusy)return;
      if(this.lastUpdateFeed!==this.prefs.updateFeed){this.lastUpdateFeed=this.prefs.updateFeed;const saved=read(()=>JSON.parse(localStorage.getItem('liquid-touch.update-check') || '{}'),{});this.nextUpdateCheck=saved.url===this.prefs.updateFeed ? number(saved.at)+21600000 : 0;}
      if(Date.now()>=this.nextUpdateCheck)void this.checkForUpdates(false);
    }
    async checkForUpdates(manual=false){
      if(manual){try{this.saveUpdateFeed(this.$('lt-update-feed').value);}catch(error){this.setUpdateStatus(error.message);return;}}
      if(this.updateCheckBusy){if(manual)this.updateCheckManual=true;return;}if(!this.prefs.updateFeed){if(manual)this.setUpdateStatus('No release feed is configured. Import an update file, or add a trusted HTTPS release-feed URL.');return;}
      const address=this.prefs.updateFeed,token=this.updateCheckToken=(this.updateCheckToken || 0)+1;this.updateCheckBusy=true;this.nextUpdateCheck=Date.now()+21600000;
      try{localStorage.setItem('liquid-touch.update-check',JSON.stringify({url:address,at:Date.now()}));}catch{}
      this.setUpdateStatus('Checking for updates…');
      try{
        const release=await window.LiquidTouchUpdater.check(address);if(this.destroyed || token!==this.updateCheckToken || address!==this.prefs.updateFeed)return;
        this.setUpdateStatus(release.newer ? `LiquidTouch ${release.version} is available.` : 'You are up to date.');
        if(release.newer){if(manual || this.updateCheckManual){this.pendingUpdatePrompt=null;this.showUpdatePrompt(release);}else{this.pendingUpdatePrompt=release;this.flushReleasePrompt();}}
      }catch(error){if(!this.destroyed && token===this.updateCheckToken)this.setUpdateStatus(error.message);}
      finally{if(token===this.updateCheckToken){this.updateCheckBusy=false;this.updateCheckManual=false;}}
    }
    openDialog(dialog) {
      this.cancelHold();
      if(dialog!==this.nowPlaying)this.showLyricsMenu(false);
      this.showKeyboard(false);
      if (dialog.open) return;
      if(dialog===this.settings)this.showSettingsSection(null,false);
      this.focusBeforeModal.set(dialog, document.activeElement);
      if(dialog!==this.nowPlaying && this.nowPlaying.open){this.cancelPlayerPresentation();this.setPlayerReveal(1);this.playerPhase='open';}
      dialog.showModal();if(dialog!==this.nowPlaying)this.animateSurface(dialog);
      this.render();
    }
    closeDialog(dialog, immediate=false) {
      if(dialog.contains(this.$('lt-keyboard')))this.showKeyboard(false);
      this.cancelHold();
      if(dialog===this.utility){this.utilityToken++;this.utilityBusy=false;this.utilityStack=[];}
      if(dialog===this.settings){this.settingsGestureToken=(this.settingsGestureToken || 0)+1;this.settingsGestureRunning=false;this.clearGestureMotion(false);}
      this.showLyricsMenu(false);
      if(dialog===this.nowPlaying){this.cancelPlayerPresentation();this.setPlayerReveal(1);this.playerPhase='closed';this.playerOpening=false;this.activeGesture=null;this.clearGestureMotion(false);}
      if (!dialog.open) return;
      // Closing is synchronous. A queued fade completion must never close a
      // newly reopened player or restore a page after the next navigation.
      delete dialog.dataset.closing;dialog.getAnimations().forEach(animation=>animation.cancel());
      dialog.close();
      if(dialog===this.nowPlaying){
        this.syncLyricClock();cancelAnimationFrame(this.lyricScrollFrame);this.queueCatalogRefresh();
        const previous=this.playerReturn;if(previous && this.viewKey(this.snapshotView())===this.viewKey(previous))this.restoreScroll(previous);
        this.playerReturn=null;
      }
      if (this.toast && dialog.contains(this.toast)) (this.utility.open ? this.utility : this.historyPage.open ? this.historyPage : this.settings.open ? this.settings : this.nowPlaying.open ? this.nowPlaying : document.body).append(this.toast);
      const before = this.focusBeforeModal.get(dialog);
      if (before?.isConnected && this.enabled) before.focus({ preventScroll: true });
      if(this.enabled && !this.destroyed){if(this.nowPlaying.open)this.animateSurface(this.nowPlaying);else this.animatePageChange(0);if(dialog===this.nowPlaying)this.playMotion(this.shell.querySelector('.lt-mini'),[{transform:'scale(.975)',opacity:.65},{transform:'none',opacity:1}],{motion:'miniPlayerSpeed',duration:130});}
    }
    showPlayer() {
      if(this.nowPlaying.open){if(this.playerPhase==='closing')this.animatePlayerReveal(1,240);return;}
      this.preparePlayer(0);this.animatePlayerReveal(1,340);
    }
    async action(action) {
      try {
        switch (action) {
          case "home": case "library": this.switchTab(action);break;
          case "search": this.switchTab('search');if(this.getRoutePath()==='/search')this.searchInput.focus({preventScroll:true});break;
          case "likedSongs": this.navigate('/collection/tracks'); break;
          case "retrySearch": void this.loadSearchResults(this.queryFromPath());break;
          case "moreSearch": void this.loadSearchResults(this.queryFromPath(),true);break;
          case "nativeSearch": {const path=this.getRoutePath();this.enable(false,false);this.history.push(path);break;}
          case "lyricsMenu": this.showLyricsMenu(this.$("lt-lyrics-menu").hidden,true);break;
          case "retryLyrics": this.showLyricsMenu(false,true);void this.loadLyrics(true);break;
          case "lyricTiming": this.showLyricTiming(this.$('lt-lyric-timing').hidden);break;
          case "lyricsEarlier": this.setLyricOffset(this.lyricOffset()+250);break;
          case "lyricsLater": this.setLyricOffset(this.lyricOffset()-250);break;
          case "lyricsTimingReset": this.setLyricOffset(0);break;
          case "lyricsMatchLine": this.matchLyricLine=!this.matchLyricLine;if(this.matchLyricLine){this.$('lt-lyric-timing').hidden=true;this.nowPlaying.querySelector('[data-action="lyricTiming"]').setAttribute('aria-expanded','false');this.animateSurface(this.$('lt-lyrics-lines'));}this.updateTimingControls();break;
          case "openLyricTiming": this.closeDialog(this.settings);this.lyricOverride={uri:this.lastURI,visible:true};this.applyLyricsLayout();await this.showPlayer();this.showLyricTiming(true);break;
          case "refreshLibrary": void this.loadLibrary(true); break;
          case "moreLibrary": void this.loadLibrary(); break;
          case "moreHome": {
            const scroll=this.main?.querySelector('.main-view-container__scroll-node, [data-overlayscrollbars-viewport]');
            if(scroll){scroll.scrollTop+=Math.max(scroll.clientHeight*.85,400);scroll.dispatchEvent(new Event('scroll',{bubbles:true}));}
            this.captureNativeCatalog();break;
          }
          case "playHistory": this.historyLimit=this.prefs.lowMemory ? 40 : 100;this.closeDialog(this.settings);this.renderHistory();this.openDialog(this.historyPage);break;
          case "closeUtility": this.closeDialog(this.utility);break;
          case "utilityBack": this.utilityBack();break;
          case "clearHistory": this.openUtility('clearHistory');break;
          case "closeHistory": this.closeDialog(this.historyPage);break;
          case "moreHistory": this.historyLimit+=this.prefs.lowMemory ? 40 : 100;this.renderHistory();break;
          case "goBack": this.goBack();break;
          case "releaseNotes": this.showReleaseNotes();break;
          case "closeRelease": this.closeDialog(this.releaseDialog);break;
          case "fullReleaseNotes": await this.showFullReleaseNotes();break;
          case "checkUpdates": await this.checkForUpdates(true);break;
          case "importUpdate": this.$('lt-update-file').click();break;
          case "confirmUpdate": await this.confirmUpdate();break;
          case "restoreRuntime": this.showUpdatePrompt({restore:true,version:window.LiquidTouchUpdater.installedVersion,summary:['Restore the version bundled with your last normal installation. Preferences and listening history remain saved.'],source:'Installed package'});break;
          case "closeQuickSearch": this.showQuickSearch(false);break;
          case "resetMotion": for(const key of ['motionSpeed',...MOTION_CONTROLS.map(([key])=>key)])this.prefs[key]=DEFAULTS[key];this.save();this.applyMotionPreferences();break;
          case "moreHomeShelves": this.homeShelfLimit=(this.homeShelfLimit || 3)+3;this.gridVersion=(this.gridVersion || 0)+1;this.renderBrowse();break;
          case "resetGestures": for(const [key] of GESTURE_CONTROLS)this.prefs[key]=DEFAULTS[key];this.save();this.applyMotionPreferences();break;
          case "resetOpacity": for(const [key] of OPACITY_PANELS)this.prefs[key]=null;this.save();this.applyGlassPreferences();break;
          case "toggleLyrics": this.toggleLyrics();break;
          case "nowPlaying": if (Date.now() > this.suppressOpenUntil) this.showPlayer(); break;
          case "closePlayer": this.requestPlayerClose(); break;
          case "settings": case "playerSettings": if(this.playerOpening)this.closeDialog(this.nowPlaying);this.openDialog(this.settings); break;
          case "settingsBack": this.showSettingsSection(null);break;
          case "closeSettings": this.closeDialog(this.settings); break;
          
          case "keyboard":
            if (!this.prefs.keyboard) { this.notify("Built-in keyboard is off. Use the system touch keyboard, or enable it in settings."); break; }
            this.showKeyboard(this.$("lt-keyboard").hidden);
            break;
          case "hideKeyboard": {const input=this.keyboardTarget;this.showKeyboard(false);input?.blur();break;}
          case "queue": this.openUtility("queue"); break;
          case "windowMinimize": case "windowMaximize": case "windowClose": await this.windowAction(action); break;
          case "devices": this.openUtility("devices"); break;
          case "desktop": this.enable(false); break;
          default: await this.callPlayer(action);
        }
      } catch (error) {
        console.warn("[LiquidTouch]", action, error);
        this.notify("Spotify could not complete that action. Try again in its desktop interface.");
      }
    }
    async confirmContextPlayback(track,contextURI,token,timeout=1200){
      const until=Date.now()+timeout;
      do{
        if(this.destroyed || token!==this.trackPlayToken)return false;
        const state=this.getPlayerState(),item=trackFromState(state),metadata=item?.metadata || {};
        const uri=item?.uri,context=state?.context?.uri || state?.context_uri || metadata.context_uri;
        const sameTrack=uri===track.uri || metadata.linked_from_uri===track.uri;
        const sameContext=!context || context===contextURI;
        const uid=item?.uid || state?.index?.uid;
        if(sameTrack && sameContext && (!track.uid || !uid || uid===track.uid) && read(()=>this.player.isPlaying(),!(state?.isPaused ?? state?.is_paused ?? true)))return true;
        await new Promise(resolve=>setTimeout(resolve,80));
      }while(Date.now()<until);
      return false;
    }
    async playDetailTrack(page,track){
      const contextual=['album','playlist','collection'].includes(page.entry.type);
      if(!contextual)return this.callPlayer('playUri',track.uri);
      const contextURI=page.entry.uri,index=Number.isInteger(track.sourceIndex) ? track.sourceIndex : null;
      const token=this.trackPlayToken=(this.trackPlayToken || 0)+1,active=()=>!this.destroyed && token===this.trackPlayToken;
      const record=(stage,error='')=>{if(active())this.lastTrackPlayback={track:track.uri,context:contextURI,stage,error:String(error?.message || error).slice(0,300)};};
      try{
        let started=false;
        record('native');
        try{
          // Match Spicetify's own Bookmark extension: context URI is the target;
          // skipTo uses uri/uid, not trackUri/trackIndex. Keep the row UID so
          // duplicate recordings select the tapped occurrence in a playlist.
          const options={skipTo:{uri:track.uri,...track.uid ? {uid:track.uid} : {}},seekTo:0};
          const api=this.S.Platform?.PlayerAPI || this.player.origin;
          const request=()=>typeof this.player.playUri==='function' ? this.player.playUri(contextURI,{},options) : typeof api?.play==='function' ? api.play({uri:contextURI},{},options) : Promise.reject(new Error('Native context playback unavailable'));
          const result=await this.withTimeout(Promise.resolve().then(request),2500);
          if(result?.error || result?.status>=400)throw new Error('Native player declined the request');
          started=await this.confirmContextPlayback(track,contextURI,token);
          if(!started)record('native-unconfirmed','The native request did not select the requested track/context.');
        }catch(error){record('native-failed',error);}
        if(!active())return false;
        if(!started && ['album','playlist'].includes(page.entry.type)){
          record('web');
          await this.withTimeout(this.spotifyRequest('put','/v1/me/player/play',{context_uri:contextURI,offset:index===null ? {uri:track.uri} : {position:index},position_ms:0}),2500);
          // A resolved request alone is not proof of playback. Some sessions
          // accept the Web request while leaving the current song untouched.
          started=await this.confirmContextPlayback(track,contextURI,token,1800);
        }
        if(!active())return false;
        if(!started)throw new Error('Spotify did not confirm playback of the selected track in its context.');
        record('playing');this.rememberHome([page.entry]);this.render();
        // Repeat adjustment must not block a successful tap if its API fails.
        if(number(read(()=>this.player.getRepeat(),0))===2){
          try{
            const api=this.S.Platform?.PlayerAPI || this.player.origin;
            await this.withTimeout(Promise.resolve().then(()=>typeof api?.setRepeat==='function' ? api.setRepeat(0) : typeof this.player.setRepeat==='function' ? this.player.setRepeat(0) : this.spotifyRequest('put','/v1/me/player/repeat?state=off')),900);
          }catch(error){if(active())record('playing-repeat-unchanged',error);}
        }
        if(active())this.render();return true;
      }catch(error){
        if(!active())return false;
        record('failed',error);console.warn('[LiquidTouch] context playback:',error);
        this.notify('Spotify could not start this playlist or album at the selected track. Check the current device and try again.');return false;
      }
    }
    async callPlayer(method, value, context) {
      try {
        if(method==='next' || method==='back')this.nextTrackMotion=method==='next' ? 1 : -1;
        if (typeof this.player[method] !== "function") throw new Error(`Player.${method} is unavailable`);
        await this.player[method](...(value === undefined ? [] : context===undefined ? [value] : [value,context]));
        if (!this.destroyed) { this.render(); this.later(() => this.render(), 250); }
        return true;
      } catch (error) {
        console.warn("[LiquidTouch] player action:", method, error);
        this.notify("Spotify could not complete that playback action. Check the current device and your account’s playback controls.");
        return false;
      }
    }
    paintRange(input) {
      const min=number(input.min),span=number(input.max,100)-min;
      const fill=clamp((number(input.value)-min)/Math.max(1,span)*100,0,100),value=`${fill}%`;
      if(input.style.getPropertyValue("--lt-fill")!==value)input.style.setProperty("--lt-fill",value);
    }
    paintButtons(action, { glyph, label, pressed, disabled } = {}) {
      this.playerButtons ||= new Map();
      if(!this.playerButtons.has(action))this.playerButtons.set(action,[this.shell,this.nowPlaying].flatMap(root=>[...root.querySelectorAll(`button[data-action="${action}"]`)]));
      for (const b of this.playerButtons.get(action)) {
        if (glyph && b.dataset.icon !== glyph) { b.querySelector(".lt-icon").innerHTML = icon(glyph); b.dataset.icon = glyph; }
        if (label && b.getAttribute("aria-label") !== label) b.setAttribute("aria-label", label);
        if (pressed !== undefined && b.getAttribute("aria-pressed")!==String(pressed)) b.setAttribute("aria-pressed", String(pressed));
        if (disabled !== undefined && b.disabled!==disabled) b.disabled = disabled;
      }
    }
    getPlayerState() {
      const origin = read(() => this.player.origin?._state, null);
      const wrapper = read(() => this.player.data, null);
      const platform = read(() => this.S.Platform?.PlayerAPI?._state, null);
      const sources = [["origin", origin], ["platform", platform], ["event", this.eventState], ["wrapper", wrapper], ["platform-getState", this.platformState]];
      for (const [name, state] of sources) if (trackFromState(state)) { this.stateSource = name; return state; }
      this.stateSource = "none";
      return origin || wrapper || platform || this.platformState || null;
    }
    refreshPlatformState() {
      if (this.destroyed || this.platformReadBusy || trackFromState(read(() => this.player.origin?._state, null)) || trackFromState(read(() => this.player.data, null))) return;
      const api = this.S.Platform?.PlayerAPI;
      if (typeof api?.getState !== "function") return;
      this.platformReadBusy = true;
      Promise.resolve().then(() => api.getState()).then(result => {
        if (!this.destroyed && result && typeof result === "object") { this.platformState = result; this.render(); }
      }).catch(() => {}).finally(() => { this.platformReadBusy = false; });
    }
    nativeTrackDetails() {
      const region = document.querySelector('.Root__now-playing-bar, [data-testid="now-playing-bar"]');
      if (!region) return {};
      const title = region.querySelector('[data-testid="context-item-info-title"], .main-nowPlayingWidget-nowPlaying .main-trackInfo-name a, .main-trackInfo-name a, a[href^="/track/"]');
      const artist = region.querySelector('[data-testid="context-item-info-subtitles"], .main-trackInfo-artists, .main-trackInfo-artists a');
      const image = region.querySelector('[data-testid="cover-art-image"], .main-nowPlayingWidget-coverArt img, img');
      const href = title?.getAttribute("href") || title?.querySelector('a[href]')?.getAttribute('href') || "";
      const match = href.match(/^\/(track|episode)\/([\w-]+)/);
      return { title: title?.textContent?.trim() || "", artist: artist?.textContent?.trim() || "", image: imageURL(image?.getAttribute("src") || ""), uri: match ? `spotify:${match[1]}:${match[2]}` : "" };
    }
    paintPlaybackProgress(progress){
      if(this.nowPlaying.open && !this.editing.has("seek")){
        const value=String(this.duration ? progress/this.duration*1000 : 0);
        if(this.seek.value!==value)this.seek.value=value;
        this.paintRange(this.seek);this.setText('lt-elapsed',time(progress));this.setText('lt-duration',time(this.duration));
        const label=`${time(progress)} of ${time(this.duration)}`;
        if(this.seek.getAttribute('aria-valuetext')!==label)this.seek.setAttribute('aria-valuetext',label);
      }
      const fill=this.$('lt-mini-fill'),width=`${this.duration ? Math.round(progress/this.duration*1000)/10 : 0}%`;
      if(fill.style.width!==width)fill.style.width=width;
    }
    render() {
      if (this.destroyed) return;
      this.renderPasses=(this.renderPasses || 0)+1;
      const data = this.getPlayerState();
      const item = trackFromState(data);
      const m = item?.metadata || {};
      const native = item?.name && (item?.album?.images?.length || m.image_xlarge_url || m.image_url) ? {} : this.nativeTrackDetails();
      const uri = item?.uri || native.uri || "";
      const title = item?.name || m.title || native.title || (uri ? "Untitled" : "Your next good listen");
      const hasItem = Boolean(item || native.uri || native.title);
      const artistItems=Array.isArray(item?.artists) ? item.artists : item?.artists?.items;
      const artists=Array.isArray(artistItems) ? artistItems : [];
      const artist = artists.map(a => typeof a === "string" ? a : a.name || a.profile?.name).filter(Boolean).join(", ") || m.artist_name || m.album_artist_name || native.artist || (hasItem ? "Spotify" : "Choose something in Spotify");
      const duration = number(read(() => this.player.getDuration(), item?.duration?.milliseconds || data?.duration || m.duration || 0));
      this.duration = Math.max(0, duration);
      const progress = clamp(number(read(() => this.player.getProgress(), 0)), 0, this.duration);
      const playing = Boolean(read(() => this.player.isPlaying(), data ? !(data.isPaused ?? data.is_paused ?? true) : false));
      const r = data?.restrictions || {};
      const denied = (capability, legacy) => r[capability] === false || (Array.isArray(r[legacy]) && r[legacy].length > 0);
      const repeat = clamp(number(read(() => this.player.getRepeat(), data?.repeat || 0)), 0, 2);
      const shuffled = Boolean(read(() => this.player.getShuffle(), data?.shuffle || false));
      const saved = Boolean(read(() => this.player.getHeart(), m["collection.in_collection"] === "true"));
      const volume = read(() => this.player.getVolume(), null);
      const muted = Boolean(read(() => this.player.getMute(), false));
      const image = imageURL(m.image_xlarge_url || m.image_large_url || m.image_url || item?.album?.images?.[0]?.url || item?.images?.[0]?.url || native.image || "");
      const contextURI=data?.context?.uri || data?.context_uri || m.context_uri || '';
      const artistKeys=artists.map(a=>typeof a==='string' ? a : [a.uri,a.name || a.profile?.name]);
      const signature=JSON.stringify([uri,title,artist,this.duration,hasItem,playing,r,repeat,shuffled,saved,volume,muted,image,contextURI,item?.album?.uri,item?.album?.name || m.album_title,artistKeys,this.nowPlaying.open]);
      if(uri===this.lastURI)this.prefetchNextLyrics(uri);
      if(signature===this.lastPlayerSignature){
        this.paintPlaybackProgress(progress);
        this.recordPlay({uri,title,artist,album:cleanText(item?.album?.name || m.album_title),subtitle:artist,image},playing,progress);
        return;
      }
      this.lastPlayerSignature=signature;this.playerPaints=(this.playerPaints || 0)+1;
      this.setText("lt-mini-title", title);
      this.setText("lt-mini-artist", artist);
      this.setText("lt-np-title", hasItem ? title : "Nothing playing yet");
      this.setText("lt-np-artist", hasItem ? artist : "Pick a song to get started");
      this.$("lt-mini-open").setAttribute("aria-label", hasItem ? `Open Now Playing: ${title}, ${artist}` : "Open Now Playing");
      this.paintButtons("togglePlay", { glyph: playing ? "pause" : "play", label: playing ? "Pause" : "Play", disabled: !hasItem || denied(playing ? "canPause" : "canResume", playing ? "disallow_pausing_reasons" : "disallow_resuming_reasons") });
      this.paintButtons("next", { disabled: !hasItem || denied("canSkipNext", "disallow_skipping_next_reasons") });
      this.paintButtons("back", { disabled: !hasItem || denied("canSkipPrevious", "disallow_skipping_prev_reasons") });
      this.paintButtons("toggleHeart", { glyph: saved ? "saved" : "plus", label: saved ? "Remove from your library" : "Save to your library", pressed: saved, disabled: !uri || m["collection.can_add"] === "false" && !saved });
      this.paintButtons("toggleShuffle", { label: shuffled ? "Turn shuffle off" : "Turn shuffle on", pressed: shuffled, disabled: !hasItem || denied("canToggleShuffle", "disallow_toggling_shuffle_reasons") });
      this.paintButtons("toggleRepeat", { glyph: repeat === 2 ? "repeatOne" : "repeat", label: `Repeat ${["off", "all", "one"][repeat]}`, pressed: repeat > 0, disabled: !hasItem || (r.canToggleRepeatContext === false && r.canToggleRepeatTrack === false) });
      this.paintButtons("toggleMute", { glyph: muted ? "muted" : "speaker", label: muted ? "Unmute" : "Mute", pressed: muted, disabled: typeof volume !== "number" || !Number.isFinite(volume) });
      this.seek.disabled = !hasItem || !this.duration || denied("canSeek", "disallow_seeking_reasons");
      if(this.lyricsSeekDisabled!==this.seek.disabled){this.lyricsSeekDisabled=this.seek.disabled;this.updateTimingControls();}
      this.paintPlaybackProgress(progress);
      this.volume.disabled = typeof volume !== "number" || !Number.isFinite(volume);
      if (!this.editing.has("volume")) {
        this.volume.value = String(Math.round(clamp(number(volume, .5), 0, 1) * 100));
        this.paintRange(this.volume);
        this.setText("lt-volume-text", `${this.volume.value}%`);
        this.volume.setAttribute("aria-valuetext", `${this.volume.value} percent`);
      }
      this.confirmTrackPeek(uri);
      if (image !== this.lastImage) {
        this.lastImage = image;
        for (const id of (this.prefs.lowMemory ? ["lt-art", "lt-mini-art"] : ["lt-art", "lt-mini-art", "lt-player-background"])) {
          const img = this.$(id);
          img.hidden = !image;
          img.onerror = () => { img.hidden = true; };
          if (image) img.src = image; else img.removeAttribute("src");
        }
        this.$('lt-mini-art').parentElement.hidden=!image;
        this.ambientArt.hidden=!image || !this.prefs.adaptive;
        if(image && !this.prefs.lowMemory)this.ambientArt.src=image;else this.ambientArt.removeAttribute('src');
      }
      this.currentPlayingEntry=normalizeEntity({...item,uri,name:title,subtitle:artist,imageUrl:image});
      this.currentTrackMeta={uri,title,artist,artists:artists.map(a=>typeof a==='string' ? a : a.name || a.profile?.name).filter(Boolean),album:cleanText(item?.album?.name || m.album_title),duration:this.duration};
      if (uri !== this.lastURI) {
        const changed=Boolean(this.lastURI);if(changed)this.animateTrackChange();
        this.showLyricsMenu(false);
        this.lyricsAbort?.abort();this.lyricsToken++;this.lyricsInFlight=null;this.lyricOverride=null;
        if(this.lyricPrefetch?.uri!==uri)this.cancelLyricPrefetch();
        this.lyricPrefetchKey=null;this.lyricPrefetchTarget=null;this.lyricQueueAt=0;this.lastURI = uri;
        this.warmAdjacentArtwork();
        this.lyricLines=[];this.lyricIndex=-2;this.lyricsLoadedURI=null;this.lyricInstrumental=false;this.lyricState='idle';this.matchLyricLine=false;this.lyricSource='spotify';this.lyricProvider='';this.paintLyrics();
        const cached=this.wantsLyricsLookup() && this.lyricsCache.get(uri);
        if(cached)this.showTrackLyrics(uri,cached);else this.applyLyricsLayout();
        this.editing.delete("seek");
      }
      this.prefetchNextLyrics(uri);
      const homeKey=JSON.stringify([uri,contextURI,item?.album?.uri || m.album_uri,item?.album?.name || m.album_title,artistKeys,m.artist_uri]);
      if(playing && homeKey!==this.playbackHomeKey){this.playbackHomeKey=homeKey;this.capturePlaybackHome(data,item);}
      if (`${uri}|${image}` !== this.lastColorKey) { this.lastColorKey = `${uri}|${image}`; void this.updateArtworkColor(uri, image); }
      this.recordPlay({uri,title,artist,album:cleanText(item?.album?.name || m.album_title),subtitle:artist,image},playing,progress);
    }
    setText(id, value) { const node = this.$(id); if (node.textContent !== value) node.textContent = value; }
    applyArtworkColor(rgb) {
      this.currentColor = rgb;
      const base = this.prefs.palette === "ocean" ? [9,21,32] : this.prefs.palette === "graphite" ? [16,17,20] : [12,16,28];
      const selected = this.prefs.adaptive ? rgb : [53,68,100];
      const factor = Math.min(1, 210/Math.max(1,...selected));
      const color = selected.map(value=>Math.round(value*factor));
      const blend = color.map((n,i)=>Math.round(n*.28 + base[i]*.72));
      const glass = color.map((n,i)=>Math.round(n*.45 + base[i]*.55));
      const style = document.body.style;
      style.setProperty("--lt-art-rgb", color.join(", "));
      style.setProperty("--lt-art-color", `rgb(${color.join(", ")})`);
      style.setProperty("--lt-bg", `rgb(${blend.join(", ")})`);
      style.setProperty("--lt-glass-rgb", glass.join(", "));
      if(this.ambientArt)this.ambientArt.hidden=this.prefs.lowMemory || !this.lastImage || !this.prefs.adaptive;
    }
    sampleArtwork(image) {
      return new Promise(resolve => {
        if (!image) { resolve(null); return; }
        const img = new Image(); img.crossOrigin = "anonymous";
        img.onload = () => {
          try {
            const canvas = document.createElement("canvas"); canvas.width = canvas.height = 24;
            const ctx = canvas.getContext("2d", {willReadFrequently:true}); ctx.drawImage(img,0,0,24,24);
            const pixels = ctx.getImageData(0,0,24,24).data;
            const sum = [0,0,0]; let weights = 0;
            for (let i=0;i<pixels.length;i+=4) {
              const r=pixels[i],g=pixels[i+1],b=pixels[i+2];
              const light=(r+g+b)/765;
              if (pixels[i+3]<128 || light<.06 || light>.94) continue;
              const weight=1+(Math.max(r,g,b)-Math.min(r,g,b))/128;
              sum[0]+=r*weight;sum[1]+=g*weight;sum[2]+=b*weight;weights+=weight;
            }
            resolve(weights ? sum.map(n=>Math.round(n/weights)) : [100,110,125]);
          } catch { resolve(null); }
        };
        img.onerror=()=>resolve(null); img.src=image;
      });
    }
    async updateArtworkColor(uri, image) {
      const request = ++this.pendingColor;
      if(this.prefs.lowMemory || !this.prefs.adaptive){this.applyArtworkColor([53,68,100]);return;}
      const key=`${uri}|${image}`;
      if (this.colorCache.has(key)) { this.applyArtworkColor(this.colorCache.get(key)); return; }
      if (!uri && !image) { this.applyArtworkColor([53,68,100]); return; }
      let apiColor = false;
      const apply = rgb => {
        if (!rgb || this.destroyed || request!==this.pendingColor) return;
        this.colorCache.set(key,rgb);
        if(this.colorCache.size>(this.prefs.lowMemory ? 12 : 48))this.colorCache.delete(this.colorCache.keys().next().value);
        this.applyArtworkColor(rgb);
      };
      void this.sampleArtwork(image).then(rgb=>{if(!apiColor)apply(rgb);});
      if (!uri || !this.S.colorExtractor) return;
      try {
        const colors = await this.S.colorExtractor(uri);
        const rgb = colorRGB(colors.VIBRANT_NON_ALARMING || colors.VIBRANT || colors.PROMINENT || colors.DARK_VIBRANT);
        if (rgb) { apiColor=true;apply(rgb); }
      } catch { /* Artwork colors are decorative; never block playback. */ }
    }
    notify(message) {
      if (!this.toast || this.destroyed) return;
      this.toast.textContent = message; this.toast.hidden = false;
      if (this.toastTimer) { clearTimeout(this.toastTimer); this.timers.delete(this.toastTimer); }
      this.toastTimer = this.later(() => { this.toast.hidden = true; }, 6500);
      if (this.utility.open || this.nowPlaying.open || this.settings.open || this.historyPage.open) {
        // Notifications in Spotify's own toast layer can otherwise sit below a
        // native <dialog>. Keep the same status node inside the topmost modal.
        (this.utility.open ? this.utility : this.historyPage.open ? this.historyPage : this.settings.open ? this.settings : this.nowPlaying).append(this.toast);
      } else document.body.append(this.toast);
    }
    diagnostics() {
      const prefetched=this.lyricPrefetchTarget || this.lyricPrefetch?.uri || '';
      const prefetchState=prefetched && this.lyricsCache.has(prefetched) ? 'ready' : this.lyricPrefetch ? this.lyricPrefetch.done ? 'unavailable' : 'loading' : 'idle';
      return { version: VERSION, phase: "mounted", enabled: this.enabled, nativeMainFound: Boolean(this.main), nativeLibraryFound: Boolean(this.library), librarySource:this.librarySource || 'loading', libraryItems:this.libraryEntities.size, libraryHasMore:this.libraryHasMore, historyItems:this.playHistory.length, historyStorage:this.historyState, utilityOpen:this.utility.open, devicesSource:this.devicesSource || 'not requested', playerAvailable: Boolean(this.player), playerDataReady: Boolean(trackFromState(this.getPlayerState())), stateSource:this.stateSource, playerOpen:this.nowPlaying.open, playerOpening:Boolean(this.playerOpening), playerPhase:this.playerPhase || 'closed', playerReveal:this.playerReveal ?? 1, cardTapPending:Boolean(this.pendingCardTap), fullscreen:Boolean(document.fullscreenElement), route:this.getRoutePath(), backSteps:this.viewStack.length, searchSource:this.searchSource || 'not requested', searchError:this.searchError || '', lyricsVisible:this.lyricsVisible(),trackPlayback:this.lastTrackPlayback || null,renderPasses:this.renderPasses || 0,playerPaints:this.playerPaints || 0,nativeScans:this.nativeScans || 0,lyricsState:this.lyricState || 'idle',lyricsPrefetchURI:prefetched,lyricsPrefetchState:prefetchState, lyricsProvider:this.lyricProvider || '', lyricSource:this.lyricSource || '', lyricOffsetMs:this.lyricOffset(), gestureActive:Boolean(this.activeGesture), animatingSurfaces:this.motionAnimations.size, browseBuilds:this.browseBuildCount || 0, browseReuses:this.browseReuseCount || 0, pagePreview:Boolean(this.pagePreview),memoryCaches:{pages:this.browsePages.size,artwork:this.artCache.size,search:this.searchCache.size,lyrics:this.lyricsCache.size,details:this.detailPages.size}, windowControls:this.chromeMode, windowBridgeAvailable:Boolean(this.windowCapabilities()), spicetifyVersion: this.S.Config?.version || "unknown", viewport: `${innerWidth}×${innerHeight}`, preferences: { ...this.prefs } };
    }
    destroy() {
      this.stopBackspaceRepeat();
      this.cancelHold();this.utilityToken++;
      this.cancelPendingCardTap();this.cancelPlayerPresentation?.();
      this.destroyed = true;
      this.enabled = false;
      this.activeGesture=null;this.stopMotion();clearTimeout(this.windowMotionTimer);
      this.fastPointerClicks.clear();
      void this.historyWrites.finally(()=>this.historyDB?.close());
      this.warmedArtwork?.clear();
      void this.restoreNativeChrome();
      clearTimeout(this.searchDebounce);this.liveSearchToken++;this.lyricsToken++;this.lyricsAbort?.abort();this.cancelLyricPrefetch();
      this.abort.abort();
      this.observer?.disconnect(); this.resizeObserver?.disconnect();
      clearInterval(this.interval);clearInterval(this.lyricsInterval);this.imageObserver?.disconnect();
      for (const timer of this.timers) clearTimeout(timer);
      this.timers.clear();
      for (const event of ["songchange", "onplaypause"]) this.player.removeEventListener?.(event, this.onPlayerEvent);
      if (typeof this.unlisten === "function") this.unlisten();
      try { this.menu?.deregister(); } catch { /* Optional profile-menu cleanup. */ }
      this.clearPagePreview(false);this.browsePages.clear();this.routeRequests.clear();this.detailPages.clear();
      for (const node of [this.shell, this.nowPlaying, this.settings, this.historyPage, this.releaseDialog, this.utility, this.atmosphere, this.rescue, this.toast]) node?.remove();
      if (this.main) delete this.main.dataset.ltNative;
      if (this.library) delete this.library.dataset.ltNative;
      for(const current of this.nativeLayoutPath || [])delete current.dataset.ltNativeLayout;
      if(this.nativeViewport)delete this.nativeViewport.dataset.ltNativeViewport;
      document.body.classList.remove("lt-active");
      for (const key of Object.keys(document.body.dataset)) if (key.startsWith("lt")) delete document.body.dataset[key];
      for (const property of [...document.body.style]) if(property.startsWith("--lt-"))document.body.style.removeProperty(property);
    }
  }

  let cancelled = false, startupTimer, statusNode, controller;
  let deadline = Date.now() + 60000;
  let phase = "waiting", lastError = "";
  const startedAt = Date.now();
  function startupDiagnostics() {
    const S = window.Spicetify;
    return { version: VERSION, build: BUILD, phase, lastError, spicetifyVersion: S?.Config?.version || "unknown",
      theme: S?.Config?.current_theme || "unknown", extensionConfigured: S?.Config?.extensions?.includes("liquid-touch.js") ?? "unknown",
      themeCSS: Boolean(document.documentElement && getComputedStyle(document.documentElement).getPropertyValue("--lt-header").trim()),
      wrapperFound: Boolean(S), playerEvents: typeof S?.Player?.addEventListener === "function",
      navigation: typeof S?.Platform?.History?.push === "function",
      nativeMain: Boolean(document.querySelector(".Root__main-view, .main-view-container, [data-testid='main-view']")) };
  }
  function destroyStartup() {
    cancelled = true; clearTimeout(startupTimer); statusNode?.remove();
    controller?.destroy();
  }
  function retry() {
    if (cancelled) return;
    controller?.destroy(); controller = null;
    phase = "waiting"; lastError = ""; deadline = Date.now() + 60000;
    clearTimeout(startupTimer); boot();
  }
  function exposeStartup() {
    window.LiquidTouch = Object.freeze({ version: VERSION, diagnostics: startupDiagnostics, retry, enable: retry, destroy: destroyStartup });
  }
  function showStartupStatus(message) {
    if (!document.body || cancelled) return;
    if (!statusNode) {
      // Inline styles make the diagnostic visible even if inject_css is off.
      // Build this small panel without innerHTML so it also survives HTML-sink
      // restrictions and can report failures from the main markup injection.
      statusNode = document.createElement("section"); statusNode.id = "lt-startup-status";
      statusNode.style.cssText = "position:fixed;right:16px;bottom:100px;z-index:2147483000;max-width:calc(100vw - 32px);width:390px;padding:18px;border:1px solid #b4eedc80;border-radius:18px;background:#152438;color:#f6f8fc;font:14px/1.5 Segoe UI,sans-serif;box-shadow:0 12px 40px #0008;";
      const title = document.createElement("strong"); title.textContent = "LiquidTouch startup";
      const text = document.createElement("p"); text.id = "lt-startup-message";
      text.setAttribute("role", "status"); text.style.cssText = "margin:8px 0 12px;white-space:normal";
      const row = document.createElement("div"); row.style.cssText = "display:flex;gap:8px";
      for (const [label, handler] of [["Retry", retry], ["Copy details", async () => {
        const details = JSON.stringify(startupDiagnostics(), null, 2);
        try {
          if (window.Spicetify?.Platform?.ClipboardAPI?.copy) await window.Spicetify.Platform.ClipboardAPI.copy(details);
          else if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(details);
          else throw new Error("Clipboard unavailable");
          text.textContent = "Details copied. Paste them into this chat.";
        } catch { text.textContent = "Clipboard unavailable. Open DevTools and run LiquidTouch.diagnostics()."; }
      }]]) {
        const b = document.createElement("button"); b.type = "button"; b.textContent = label;
        b.style.cssText = "min-height:44px;padding:8px 16px;border:1px solid #b4eedc60;border-radius:12px;color:#f6f8fc;background:#2b4057;font:inherit;cursor:pointer";
        b.addEventListener("click", handler); row.append(b);
      }
      statusNode.append(title, text, row); document.body.append(statusNode);
    }
    const text = statusNode.querySelector("#lt-startup-message");
    if (text.textContent !== message) text.textContent = message;
    if (!statusNode.isConnected) document.body.append(statusNode);
  }
  exposeStartup();
  function boot() {
    if (cancelled) return;
    const S = window.Spicetify;
    const main = document.querySelector(".Root__main-view, .main-view-container, [data-testid='main-view']");
    if (!document.body || !main || !S?.Player?.addEventListener || !S?.Platform?.History?.push) {
      const missing = [];
      if (!S) missing.push("Spicetify wrapper");
      if (!S?.Player?.addEventListener) missing.push("player API");
      if (!S?.Platform?.History?.push) missing.push("navigation API");
      if (!main) missing.push("Spotify main view");
      if (Date.now() - startedAt > 3000) showStartupStatus(`Waiting for ${missing.join(", ")}. If this persists, enable expose_apis and update Spicetify, then restore / backup / apply.`);
      if (Date.now() < deadline) startupTimer = setTimeout(boot, 500);
      else {
        phase = "timed-out"; lastError = `Missing: ${missing.join(", ")}`;
        showStartupStatus(`${lastError}. Copy details so the startup failure can be diagnosed.`);
        console.warn("[LiquidTouch] Startup timed out; Spotify's desktop interface was left available.");
      }
      return;
    }
    try {
      controller = new LiquidTouchController(S);
      controller.mount();
      phase = "mounted";
      if (controller.enabled) statusNode?.remove();
      else if (!startupDiagnostics().themeCSS) showStartupStatus("LiquidTouch JavaScript loaded, but its CSS is missing. Enable inject_css, select LiquidTouch, and apply.");
      else statusNode?.remove();
      window.LiquidTouch = Object.freeze({
        version: VERSION,
        enable: () => controller.enable(true), disable: () => controller.enable(false),
        destroy: destroyStartup, retry, diagnostics: () => ({ ...startupDiagnostics(), ...controller.diagnostics() })
      });
    } catch (error) {
      try { controller?.destroy(); } catch { /* Preserve the original startup error. */ }
      controller = null; phase = "failed"; lastError = `${error.name}: ${error.message}`;
      exposeStartup();
      showStartupStatus(`The touch interface could not start. ${lastError}. Use Copy details to report this.`);
      console.error("[LiquidTouch] Startup failed; native Spotify restored:", error);
    }
  }
  boot();
})();
