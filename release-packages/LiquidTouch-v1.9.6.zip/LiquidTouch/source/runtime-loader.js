// Stable LiquidTouch runtime loader. Generated releases embed their fallback below.
(() => {
  'use strict';
  const BUNDLED=/*__LIQUIDTOUCH_BUNDLE__*/null;
  const launchBundled=/*__LIQUIDTOUCH_BOOT__*/null;
  const CACHE='liquid-touch.runtime.v1',MAX=1200000;
  window.LiquidTouchUpdater?.dispose?.();
  let active=BUNDLED,disposed=false,requestAbort=null,applying=false;
  const version=value=>typeof value==='string' && /^\d+\.\d+\.\d+$/.test(value);
  const compare=(a,b)=>{const x=a.split('.').map(Number),y=b.split('.').map(Number);for(let i=0;i<3;i++)if(x[i]!==y[i])return Math.sign(x[i]-y[i]);return 0;};
  const digest=async text=>{
    if(!crypto?.subtle)throw new Error('This Spotify build does not expose update verification. Use the normal installer.');
    return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text))),n=>n.toString(16).padStart(2,'0')).join('');
  };
  const validURL=value=>{const url=new URL(value);if(url.protocol!=='https:' || url.username || url.password)throw new Error('Use a trusted HTTPS update address.');return url;};
  async function verify(raw){
    if(!raw || raw.schema!==1 || raw.app!=='LiquidTouch' || !version(raw.version) || typeof raw.javascript!=='string' || typeof raw.css!=='string' || raw.javascript.length>800000 || raw.css.length>250000 || typeof raw.integrity!=='string' || !/^[a-f0-9]{64}$/.test(raw.integrity))throw new Error('Not a supported LiquidTouch update file.');
    if(await digest(raw.javascript+'\0'+raw.css)!==raw.integrity)throw new Error('Update verification failed. The current installation was kept.');
    if(raw.minimumLoader && (!version(raw.minimumLoader) || compare(raw.minimumLoader,BUNDLED.version)>0))throw new Error('This release needs a normal package installation first.');
    try{new Function(raw.javascript);}catch(error){throw new Error(error.name==='EvalError' ? 'This Spotify build blocks in-app code updates. Use the normal installer.' : 'The update contains invalid JavaScript. The current installation was kept.');}
    const summary=Array.isArray(raw.summary) ? raw.summary.filter(v=>typeof v==='string').slice(0,8).map(v=>v.slice(0,400)) : [];
    return Object.freeze({schema:1,app:'LiquidTouch',version:raw.version,minimumLoader:raw.minimumLoader || '1.9.0',javascript:raw.javascript,css:raw.css,integrity:raw.integrity,summary,notes:typeof raw.notes==='string' ? raw.notes.slice(0,60000) : ''});
  }
  function run(bundle){
    const ready=getComputedStyle(document.documentElement).getPropertyValue('--lt-theme-installed').trim()==='1';
    let style=document.getElementById('lt-runtime-theme');
    if(ready){if(!style){style=document.createElement('style');style.id='lt-runtime-theme';document.head.append(style);}style.textContent=bundle.css;}else style?.remove();
    active=bundle;window.LiquidTouchRelease={version:bundle.version,summary:bundle.summary,notes:bundle.notes};
    if(bundle===BUNDLED)launchBundled();else new Function(bundle.javascript)();
  }
  async function fetchText(url,limit,signal){
    const response=await fetch(url,{credentials:'omit',referrerPolicy:'no-referrer',cache:'no-store',signal});
    if(!response.ok)throw new Error('The update source could not be reached.');
    if(new URL(response.url || url).origin!==new URL(url).origin)throw new Error('The update source redirected to another host.');
    if(Number(response.headers.get('Content-Length'))>limit)throw new Error('The update response is too large.');
    if(!response.body?.getReader){const text=await response.text();if(new TextEncoder().encode(text).length>limit)throw new Error('The update response is too large.');return text;}
    const reader=response.body.getReader(),decoder=new TextDecoder('utf-8',{fatal:true});let size=0,text='';
    for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>limit){await reader.cancel();throw new Error('The update response is too large.');}text+=decoder.decode(value,{stream:true});}return text+decoder.decode();
  }
  async function request(job){
    requestAbort?.abort();const abort=new AbortController();requestAbort=abort;const timer=setTimeout(()=>abort.abort(),8000);
    try{const value=await job(abort.signal);if(disposed)throw new Error('Update session ended.');return value;}finally{clearTimeout(timer);if(requestAbort===abort)requestAbort=null;}
  }
  async function check(address){
    const url=validURL(address);
    return request(async signal=>{
      const raw=JSON.parse(await fetchText(url.href,64000,signal));
      if(raw.schema!==1 || raw.app!=='LiquidTouch' || !version(raw.version) || typeof raw.bundleURL!=='string' || !/^[a-f0-9]{64}$/.test(raw.sha256 || ''))throw new Error('Invalid LiquidTouch release feed.');
      const bundleURL=validURL(new URL(raw.bundleURL,url).href);if(bundleURL.origin!==url.origin)throw new Error('The update file must use the same host as the release feed.');
      return {version:raw.version,newer:compare(raw.version,active.version)>0,bundleURL:bundleURL.href,sha256:raw.sha256,source:url.hostname,summary:Array.isArray(raw.summary) ? raw.summary.filter(v=>typeof v==='string').slice(0,8).map(v=>v.slice(0,400)) : []};
    });
  }
  async function download(manifest){
    if(!manifest?.newer || !version(manifest.version))throw new Error('There is no newer release to install.');
    return request(async signal=>{const text=await fetchText(validURL(manifest.bundleURL).href,MAX,signal);if(await digest(text)!==manifest.sha256)throw new Error('Downloaded update checksum did not match the release feed.');const bundle=await verify(JSON.parse(text));if(bundle.version!==manifest.version)throw new Error('The update version did not match the release feed.');return bundle;});
  }
  async function mounted(expected){
    const began=Date.now();
    while(!disposed && Date.now()-began<4000){const state=window.LiquidTouch?.diagnostics?.();if(state?.phase==='failed' || state?.phase==='timed-out')return false;if(state?.phase==='mounted' && window.LiquidTouch.version===expected)return true;await new Promise(resolve=>setTimeout(resolve,40));}return false;
  }
  async function apply(bundle){
    if(applying || disposed)throw new Error('An update is already running.');
    const verified=await verify(bundle);if(compare(verified.version,active.version)<=0)throw new Error('This update is not newer than the running version.');
    const old=active,previous=localStorage.getItem(CACHE);applying=true;let started=false;
    try{
      localStorage.setItem(CACHE,JSON.stringify(verified)); // One atomic record; quota failures leave the running UI intact.
      started=true;
      run(verified);if(!await mounted(verified.version))throw new Error('The new interface could not start.');
    }catch(error){
      if(started){if(previous===null)localStorage.removeItem(CACHE);else localStorage.setItem(CACHE,previous);run(old);window.Spicetify?.showNotification?.('Update could not start. The previous LiquidTouch interface was restored.');}throw error;
    }finally{applying=false;}
  }
  async function importFile(file){if(!file || file.size>MAX)throw new Error('Choose a LiquidTouch update JSON file smaller than 1.2 MB.');const bundle=await verify(JSON.parse(await file.text()));if(compare(bundle.version,active.version)<=0)throw new Error('This file is not newer than the running version.');return bundle;}
  function restore(){if(applying)throw new Error('Wait for the current update.');localStorage.removeItem(CACHE);run(BUNDLED);}
  window.LiquidTouchUpdater=Object.freeze({installedVersion:BUNDLED.version,currentVersion:()=>active.version,release:()=>({version:active.version,summary:active.summary,notes:active.notes}),check,download,apply,importFile,restore,normalizeFeed:value=>validURL(value).href,dispose:()=>{disposed=true;requestAbort?.abort();}});
  const clearCache=()=>{try{localStorage.removeItem(CACHE);}catch{}};
  let cached;try{cached=JSON.parse(localStorage.getItem(CACHE) || 'null');}catch{clearCache();}
  if(cached && version(cached.version) && compare(cached.version,BUNDLED.version)>0){
    void verify(cached).then(bundle=>{if(!disposed)run(bundle);}).catch(()=>{if(!disposed){clearCache();run(BUNDLED);}});
  }else{if(cached)clearCache();run(BUNDLED);}
})();
