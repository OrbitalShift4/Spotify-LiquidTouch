/* Offline demonstration of Spotify's host interfaces. THIS DOES NOT PLAY AUDIO.
   The unmodified production extension is loaded after this fixture. */
(() => {
  "use strict";
  const covers = window.LT_DEMO_COVERS;
  const tracks = window.LT_DEMO_TRACKS || [
    { name: "Afterhours", artist: "Solstice", album: "Afterhours EP", color: "#465384", art: 0, duration: 238000 },
    { name: "Blue Hour", artist: "Luma & The Coast", album: "Blue Hour", color: "#1f626c", art: 1, duration: 204000 },
    { name: "In Orbit", artist: "Astra", album: "Signals", color: "#70577f", art: 2, duration: 271000 },
    { name: "Soft Signal", artist: "Low Tide", album: "Soft Signal", color: "#726246", art: 3, duration: 193000 },
    { name: "Night Drive", artist: "Velour", album: "Night Drive", color: "#584b7d", art: 4, duration: 256000 },
    { name: "Slow Motion", artist: "Sunday Club", album: "Slow Motion", color: "#446c66", art: 5, duration: 219000 }
  ];
  const listeners = new Map();
  const navigation = new Set();
  const entries = [{ pathname: "/" }];
  let historyIndex = 0, index = 0, position = 74000, playing = true, volume = .64, muted = false, repeat = 0, shuffle = false;
  const saved = new Set();
  const log = [];
  let restrictions = {};
  let empty = false;
  let wrapperMissing = false, overrideItem = null, currentContext = 'spotify:playlist:demo-0';
  let windowState = 1, windowFailure = false;
  const host = document.getElementById("fixture-content");
  function emit(type) { for (const fn of listeners.get(type) || []) fn(); }
  function trackItem(i) {
    const t = tracks[i];
    return { uri: `spotify:track:demo${i}`, name: t.name, artists: [{ name: t.artist }],
      album: { name: t.album, images: [{ url: covers[t.art] }] }, duration: { milliseconds: t.duration },
      metadata: { title: t.name, artist_name: t.artist, album_title: t.album,
        image_xlarge_url: covers[t.art], "collection.in_collection": String(saved.has(i)) } };
  }
  function currentItem(){return trackItem(index);}
  function demoEntity(uri){const i=Number(uri.match(/demo-?(\d+)/)?.[1] || 0)%tracks.length,t=tracks[i],type=uri.split(':')[1];return {uri,name:type==='artist' ? t.artist : t.album,images:[{url:covers[t.art]}],artists:[{name:t.artist}],description:window.LT_GALLERY ? 'Public music metadata in a simulated LiquidTouch library.' : 'Fictional music for the offline LiquidTouch preview.'};}
  function demoRows(uri,offset=0,limit=50){const start=Number(uri.match(/demo-?(\d+)/)?.[1] || 0)%tracks.length;return {items:Array.from({length:tracks.length},(_,n)=>({track:trackItem((start+n)%tracks.length)})).slice(offset,offset+limit),totalCount:tracks.length};}
  function choose(i,context) { index = (i + tracks.length) % tracks.length; empty = false; overrideItem=null; if(context)currentContext=context; position = 0; playing = true; emit("songchange"); }
  function state() {return empty ? null : {item:overrideItem || currentItem(),restrictions,duration:tracks[index].duration,isPaused:!playing,repeat,shuffle,context:{uri:currentContext}};}
  function element(tag, className, text) { const node = document.createElement(tag); node.className = className; if (text) node.textContent = text; return node; }
  function art(t, className) { const image = element("img", className); image.src = covers[t.art]; image.alt = ""; return image; }
  function title(text, sub) { const h = element("div", "fixture-title"); const heading=element("h2", "", text);heading.dataset.encoreId='text';h.append(heading); if (sub){const p=element("p", "", sub);p.dataset.encoreId='text';h.append(p);} return h; }
  function renderHome() {
    host.append(title("Good evening.", "A little less noise. A little more music."));
    const quick = element("div", "fixture-quick");
    for (const [name, route] of [["Liked songs", "/collection/tracks"], ["Recently played", "/playlist/recent"], ["Made for you", "/playlist/for-you"]]) {
      const b = element("button", "fixture-pill", name); b.onclick = () => History.push(route); quick.append(b);
    }
    host.append(quick, element("h3", "fixture-section", "In your orbit"));
    const grid = element("div", "fixture-grid");
    for (let i = 0; i < tracks.length; i++) {
      const t = tracks[i];
      const type=window.LT_GALLERY ? 'album' : i%2 ? 'album' : 'playlist';
      const card = element("article", "main-card-card fixture-card");
      card.dataset.uri=`spotify:${type}:demo-${i}`;
      const open = element("button", "fixture-card-open");
      open.setAttribute("aria-label", `Open ${t.album}`);
      open.append(art(t, "main-cardImage-image"), element("strong", "main-cardHeader-text", t.album), element("span", "main-cardSubHeader-root", t.artist));
      open.onclick = () => History.push(`/${type}/demo-${i}`);
      const play = element("button", "fixture-card-play", "▶"); play.dataset.testid='play-button';play.setAttribute("aria-label", `Play ${t.name}`); play.onclick = () => {log.push(['cardPlay',`spotify:${type}:demo-${i}`]);choose(i,`spotify:${type}:demo-${i}`);};
      card.append(open, play); grid.append(card);
    }
    host.append(grid);
  }
  function renderRows(indices) {
    const list = element("div", "fixture-track-list"); list.setAttribute("role", "table"); list.setAttribute("aria-label", "Tracks");
    for (const i of indices) {
      const t = tracks[i];
      const row = element("div", "main-trackList-trackListRow fixture-track-row"); row.setAttribute("role", "row");
      const start = element("div", "main-trackList-rowSectionStart");
      const play = element("button", "fixture-row-play", "▶"); play.setAttribute("aria-label", `Play ${t.name}`); play.onclick = () => choose(i); start.append(play);
      const track = element("div", "fixture-row-title"); track.append(art(t, ""));
      const name = element("div", ""); const link=element("a", "main-trackList-rowTitle", t.name);link.href=`/track/demo${i}`;link.onclick=e=>{e.preventDefault();History.push(`/track/demo${i}`);};name.append(link,element("span", "main-trackList-rowSubTitle", t.artist));track.append(name);
      const album = element("div", "main-trackList-rowSectionVariable", t.album);
      const end = element("div", "main-trackList-rowSectionEnd", `${Math.floor(t.duration / 60000)}:${String(Math.floor(t.duration / 1000) % 60).padStart(2, "0")}`);
      row.append(start, track, album, end); list.append(row);
    }
    host.append(list);
  }
  function renderNative() {
    host.replaceChildren();
    host.append(element("div", "fixture-demo-label", window.LT_GALLERY ? 'GALLERY DEMO · REAL MUSIC METADATA · NO AUDIO' : 'OFFLINE PREVIEW · NO AUDIO'));
    const path = History.location.pathname;
    if (path === "/") renderHome();
    else if (path.startsWith("/search")) {
      let query = ""; try { query = decodeURIComponent(path.slice(8)); } catch { /* keep empty */ }
      host.append(title(query ? `Results for “${query}”` : "Find your next favorite.", window.LT_GALLERY ? 'Search the six gallery recordings.' : 'Preview search uses the six fictional demo tracks.'));
      const indices = tracks.map((_, i) => i).filter(i => `${tracks[i].name} ${tracks[i].artist} ${tracks[i].album}`.toLowerCase().includes(query.toLowerCase()));
      if (indices.length) {
        renderRows(indices);
        const grid=element('div','fixture-grid');
        for(const i of indices)for(const type of ['album','playlist','artist']){
          const card=element('article','e-modern-card');card.dataset.testid='card-container';
          const link=element('a','');link.href=`/${type}/demo-${i}`;
          link.append(art(tracks[i],''),element('strong','',type==='artist' ? tracks[i].artist : tracks[i].album),element('span','',type));
          link.onclick=e=>{e.preventDefault();History.push(`/${type}/demo-${i}`);};card.append(link);grid.append(card);
        }
        host.append(grid);
      }
      else host.append(element("p", "fixture-empty", "No matches. Try “Astra”, “Night”, or “Blue”."));
    } else if (path.startsWith("/queue")) {
      host.append(title("Up next", "Your play queue.")); renderRows(tracks.map((_, i) => (index + i + 1) % tracks.length));
    } else {
      const hit = path.match(/demo-(\d+)/);
      const start = hit ? Number(hit[1]) % tracks.length : 0;
      host.append(title(path === "/collection/tracks" ? "Liked songs" : hit ? tracks[start].album : "Made for your moment", "A demo playlist. Real Spotify provides your own content."));
      const play = element("button", "fixture-play-all", "▶   Play"); play.onclick = () => choose(start); host.append(play);
      renderRows(tracks.map((_, i) => (start + i) % tracks.length));
    }
  }
  const History = {
    get location() { return entries[historyIndex]; },
    get entries() { return entries; },
    push(path) { entries.splice(historyIndex + 1); entries.push({ pathname: path }); historyIndex++; renderNative(); for (const fn of navigation) fn(this.location); },
    goBack() { if (historyIndex > 0) historyIndex--; renderNative(); for (const fn of navigation) fn(this.location); },
    listen(fn) { navigation.add(fn); return () => navigation.delete(fn); }
  };
  const Player = {
    get data() { return wrapperMissing ? null : state(); },
    origin:{get _state(){return state();}},
    addEventListener(type, fn) { if (!listeners.has(type)) listeners.set(type, new Set()); listeners.get(type).add(fn); },
    removeEventListener(type, fn) { listeners.get(type)?.delete(fn); },
    getDuration() { return empty ? 0 : tracks[index].duration; },
    getProgress() { return position; },
    isPlaying() { return playing && !empty; },
    getVolume() { return volume; },
    getMute() { return muted; },
    getRepeat() { return repeat; },
    getShuffle() { return shuffle; },
    getHeart() { return saved.has(index); },
    togglePlay() { log.push(["togglePlay"]); playing = !playing; emit("onplaypause"); },
    play() {log.push(['play']);playing=true;emit('onplaypause');},
    pause() {log.push(['pause']);playing=false;emit('onplaypause');},
    playUri(uri,context,options={}) {log.push(['playUri',uri,...context ? [context] : [],...Object.keys(options).length ? [options] : []]);const selected=options.skipTo?.uri || uri,hit=selected.match(/demo-?(\d+)/);choose(hit ? Number(hit[1]) : 0,context?.uri || uri);return Promise.resolve();},
    next() { log.push(["next"]); choose(index + 1); },
    back() { log.push(["back"]); choose(index - 1); },
    // Matches the wrapper's distinction between integer ms and fractional ratios.
    seek(value) { log.push(["seek", value]); position = !Number.isInteger(value) && value >= 0 && value <= 1 ? value * tracks[index].duration : value; },
    setVolume(value) { log.push(["setVolume", value]); volume = value; },
    toggleMute() { log.push(["toggleMute"]); muted = !muted; },
    toggleRepeat() { log.push(["toggleRepeat"]); repeat = (repeat + 1) % 3; },
    setRepeat(value) { log.push(['setRepeat',value]);repeat=Math.max(0,Math.min(2,Number(value)||0));emit('onplaypause'); },
    toggleShuffle() { log.push(["toggleShuffle"]); shuffle = !shuffle; },
    toggleHeart() { log.push(["toggleHeart"]); if (saved.has(index)) saved.delete(index); else saved.add(index); }
  };
  const library = document.getElementById("fixture-library");
  library.append(element("h2", "fixture-library-heading", "Your Library"));
  for (const [name, route] of (window.LT_GALLERY ? [["Liked songs", "/collection/tracks"], ...tracks.map((t,i)=>[t.album,`/album/demo-${i}`])] : [["Liked songs", "/collection/tracks"], ["Afterhours", "/playlist/demo-0"], ["Blue Hour", "/playlist/demo-1"], ["In Orbit", "/playlist/demo-2"], ["Night Drive", "/playlist/demo-4"]])) {
    const row = element("button", "main-yourLibraryX-listItem fixture-library-row");
    if(route.startsWith('/playlist/'))row.dataset.uri='spotify:playlist:'+route.split('/')[2];
    row.append(art(tracks[Number(route.match(/demo-(\d+)/)?.[1] || 0) % tracks.length], ""), element("strong", "", name), element("span", "", "Playlist  →"));
    row.onclick = () => History.push(route); library.append(row);
  }
  document.getElementById("fixture-device").onclick = () => alert("Offline preview: your real Spotify devices appear here after installation.");
  const nativeChrome=document.createElement('div');nativeChrome.id='fixture-native-chrome';nativeChrome.className='Titlebar';nativeChrome.textContent='Native app menu · minimize · maximize · close';document.body.append(nativeChrome);
  const windowClient={
    async getWindowState(){if(windowFailure)throw new Error('Window bridge unavailable');return{state:windowState};},
    async setWindowState(value){if(windowFailure)throw new Error('Window bridge unavailable');windowState=value.state;log.push(['windowState',value.state]);},
    async closeWindow(){if(windowFailure)throw new Error('Window bridge unavailable');log.push(['closeWindow']);}
  };
  const chromeClient={
    async updateTitlebarHeight(value){log.push(['titlebarHeight',value.height]);nativeChrome.style.height=value.height+'px';},
    async setButtonsVisibility(value){log.push(['nativeVisible',value.showButtons]);nativeChrome.style.visibility=value.showButtons?'visible':'hidden';}
  };
  const libraryItems=Array.from({length:window.LT_GALLERY ? 18 : 145},(_,i)=>{
    const t=tracks[i%tracks.length],type=i%5===4 ? 'artist' : window.LT_GALLERY ? 'album' : i%2 ? 'album' : 'playlist';
    return {uri:`spotify:${type}:demo-${i}`,name:(type==='artist' ? t.artist : t.album)+(!window.LT_GALLERY && i>=6 ? ` · ${Math.floor(i/6)+1}` : ''),images:[{url:covers[t.art]}],artists:[{name:t.artist}]};
  });
  const LibraryAPI={async getContents({offset=0,limit=100}={}){log.push(['libraryPage',offset]);return {items:libraryItems.slice(offset,offset+limit),totalLength:libraryItems.length};}};
  LibraryAPI.getTracks=async({offset=0,limit=50}={})=>demoRows('spotify:collection:tracks',offset,limit);
  const PlaylistAPI={async getContents(uri,{offset=0,limit=50}={}){log.push(['playlistContents',uri,offset]);return demoRows(uri,offset,limit);},async getMetadata(uri){return demoEntity(uri);}};
  const GraphQL={Definitions:{getAlbum:'getAlbum',queryArtistOverview:'queryArtistOverview'},async Request(definition,{uri,offset=0,limit=50}){
    log.push(['detailQuery',definition,uri,offset]);
    if(definition==='getAlbum')return {data:{albumUnion:{...demoEntity(uri),tracksV2:demoRows(uri,offset,limit)}}};
    if(definition==='queryArtistOverview'){
      const meta=demoEntity(uri),albums=tracks.slice(0,4).map((t,i)=>({releases:{items:[demoEntity('spotify:album:demo-'+i)]}}));
      return {data:{artistUnion:{uri,profile:{name:meta.name},visuals:{avatarImage:{sources:meta.images}},discography:{topTracks:demoRows(uri),albums:{items:albums}}}}};
    }
    throw new Error('Unknown preview query');
  }};
  window.Spicetify = { Player, GraphQL, Platform: { History, LibraryAPI, PlaylistAPI, LocalStorageAPI:{namespace:'demo'}, operatingSystem:'Windows',FocusMainWindowAPI:{_windowStateClient:windowClient},ControlMessageAPI:{_updateUiClient:chromeClient} }, colorExtractor: async () => ({ DARK_VIBRANT: tracks[index].color }),
    Menu: { Item: class { register() {} deregister() {} } }, showNotification: message => console.info(message) };
  let queueExtra=[],removedQueue=new Set(),activeDevice='desktop';
  window.Spicetify.addToQueue=async rows=>{log.push(['addToQueue',rows]);queueExtra.push(...rows.map((row,i)=>({...row,uid:'extra-'+i})));};
  window.Spicetify.removeFromQueue=async rows=>{log.push(['removeFromQueue',rows]);for(const row of rows)removedQueue.add(row.uid);};
  Object.defineProperty(window.Spicetify,'Queue',{configurable:true,get:()=>{
    const provided=i=>{const n=(i+tracks.length)%tracks.length,t=tracks[n];return {uri:`spotify:track:demo${n}`,uid:'queue-'+n,metadata:{title:t.name,artist_name:t.artist,image_xlarge_url:covers[t.art]}};};
    return {track:provided(index),nextTracks:[...(window.LT_GALLERY ? Array.from({length:5},(_,i)=>provided(index+i+1)) : [provided(index+1)]),...queueExtra].filter(row=>!removedQueue.has(row.uid)),prevTracks:[provided(index-1)],queueRevision:String(index)};
  }});
  let searchDelay=0,fullscreen=false;
  Object.defineProperty(document,'fullscreenElement',{configurable:true,get:()=>fullscreen ? document.documentElement : null});
  document.documentElement.requestFullscreen=async()=>{fullscreen=true;log.push(['fullscreen',true]);document.dispatchEvent(new Event('fullscreenchange'));};
  document.exitFullscreen=async()=>{fullscreen=false;log.push(['fullscreen',false]);document.dispatchEvent(new Event('fullscreenchange'));};
  window.Spicetify.CosmosAsync={async get(url){
    log.push(['apiGet',url]);
    if(url.includes('/inspiredby-mix/v2/seed_to_playlist/'))return {mediaItems:[{uri:'spotify:playlist:radio-demo-0'}]};
    if(url.endsWith('/v1/me'))return {id:'demo-user',display_name:'Preview listener'};
    if(url.includes('/v1/me/player/devices'))return {devices:[{id:'desktop',name:'This computer',type:'Computer',is_active:activeDevice==='desktop',is_restricted:false},{id:'speaker',name:'Living room',type:'Speaker',is_active:activeDevice==='speaker',is_restricted:false},{id:'locked',name:'Restricted device',type:'Speaker',is_active:false,is_restricted:true}]};
    if(url.includes('/v1/me/playlists'))return {items:[{uri:'spotify:playlist:editable',name:'My playlist',owner:{id:'demo-user'},images:[{url:covers[0]}]},{uri:'spotify:playlist:other',name:'Someone else’s playlist',owner:{id:'other'},collaborative:false}],next:null};
    if(url.includes('/v1/search?')){
      const query=new URL(url).searchParams.get('q').toLowerCase();const delay=searchDelay;if(delay)await new Promise(r=>setTimeout(r,delay));
      const indices=tracks.map((t,i)=>i).filter(i=>`${tracks[i].name} ${tracks[i].artist} ${tracks[i].album}`.toLowerCase().includes(query));
      const make=(type,i)=>({uri:`spotify:${type}:demo-${i}`,name:type==='artist' ? tracks[i].artist : type==='track' ? tracks[i].name : tracks[i].album,images:[{url:covers[i]}],album:{images:[{url:covers[i]}]},artists:[{name:tracks[i].artist}]});
      return Object.fromEntries(['track','artist','album','playlist'].map(type=>[type+'s',{items:indices.map(i=>make(type,i))}]));
    }
    if(window.LT_GALLERY && url.includes('color-lyrics'))throw new Error('Lyrics are not supplied in the gallery demo.');
    if(url.includes('color-lyrics'))return {lyrics:{syncType:'LINE_SYNCED',providerDisplayName:'LiquidTouch demo',lines:[{startTimeMs:'0',words:'A quiet street, a silver sky'},{startTimeMs:'10000',words:'The city lights are drifting by'},{startTimeMs:'25000',words:'We leave a little room to breathe'},{startTimeMs:'60000',words:'And carry home the melody'},{startTimeMs:'120000',words:'A softer light is all we need'}]}};
    const route=new URL(url),parts=route.pathname.split('/'),type=parts[2]?.replace(/s$/,''),id=parts[3],uri=`spotify:${type}:${id}`,offset=Number(route.searchParams.get('offset') || 0);
    if(parts[2]==='me' && parts[3]==='tracks')return demoRows('spotify:collection:tracks',offset);
    if(['album','playlist','artist','track','episode','show'].includes(type) && id){
      if(parts[4]==='images')return demoEntity(uri).images;
      if(parts[4]==='tracks' || parts[4]==='episodes')return demoRows(uri,offset);
      if(parts[4]==='top-tracks')return {tracks:tracks.map((t,i)=>trackItem(i))};
      if(parts[4]==='albums')return {items:tracks.map((t,i)=>demoEntity('spotify:album:demo-'+i))};
      if(type==='track' || type==='episode'){const i=Number(id.match(/\d+/)?.[0] || 0)%tracks.length;return {...trackItem(i),uri};}
      return {...demoEntity(uri),...(type==='album' ? {tracks:demoRows(uri)} : type==='show' ? {episodes:demoRows(uri)} : {})};
    }
    const hit=url.match(/demo-?(\d+)/);return [{url:covers[(hit ? Number(hit[1]) : 0)%covers.length]}];
  },async put(url,body){log.push(['apiPut',url,body]);if(url.endsWith('/v1/me/player'))activeDevice=body.device_ids[0];if(url.endsWith('/v1/me/player/play') && body.context_uri){const start=Number(body.context_uri.match(/demo-?(\d+)/)?.[1] || 0),selected=body.offset?.uri,hit=selected?.match(/demo-?(\d+)/);choose(hit ? Number(hit[1]) : start+Number(body.offset?.position || 0),body.context_uri);}if(url.includes('/v1/me/player/repeat?state=off'))repeat=0;return {};},async post(url,body){log.push(['apiPost',url,body]);return {snapshot_id:'preview'};},async del(url,body){log.push(['apiDel',url,body]);return {};}};
  window.__ltMock = { log, tracks, libraryItems, choose, emit, setSearchDelay(value){searchDelay=value;}, setPosition(value){position=value;emit("onplaypause");}, setEmpty(value) { empty = value; emit("songchange"); },
    setRestrictions(value) { restrictions = value; emit("onplaypause"); },
    setMetadata(value) {overrideItem=value;emit("songchange");},
    setWrapperMissing(value){wrapperMissing=value;emit('songchange');},
    failWindowActions(value){windowFailure=value;},
    listenerCount() { return [...listeners.values()].reduce((n, x) => n + x.size, 0) + navigation.size; } };
  renderNative();
  setInterval(() => { if (playing && !empty && !document.hidden) { position += 500; if (position >= tracks[index].duration) choose(index + 1); } }, 500);
})();
