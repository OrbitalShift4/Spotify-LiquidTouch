# Gallery album artwork

These six raster thumbnails correspond to the verified public catalog records in
../gallery-catalog.json. See ../../docs/screenshots/README.md for song, artist,
release-edition and catalog links. Artwork remains the property of its respective
rights holders and is not covered by the project’s MIT license. No audio is included.

Use `node tools/build-preview.cjs --gallery` from the project root to embed this
metadata and these covers into the self-contained LiquidTouch-Gallery.html.
