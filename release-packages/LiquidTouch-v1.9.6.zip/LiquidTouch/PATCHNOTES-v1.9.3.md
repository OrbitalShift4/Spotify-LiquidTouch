LiquidTouch 1.9.3 — 2 November 2026

CLEANER LYRICS
Removed internal lyric provider labels such as Musixmatch from the player and timing panel. The unused status row collapses and the lyric area grows into its space. Loading/error and text-only status still appear when relevant. Synced lyric seeking and timing corrections remain available.

ANIMATION SPEEDS
Settings → Animation speeds includes an overall speed and individual controls grouped under Navigation and menus, Now Playing and artwork, Lyrics and layout, and Buttons, keyboard and loading. 100% retains the original timing; 200% is twice as fast and 50% is half speed. Speeds multiply with Overall. Dragging always follows your finger. Reduce Motion overrides movement. Playback, lyric timestamps, network timeouts and card double-tap timing are unaffected. Restore animation speeds resets only motion preferences.

SWIPE THRESHOLDS
Settings → Swipe thresholds exposes separate confirmation distances for Back, Settings Back, Settings dismissal, history/update sheets, expanded-player opening/closing, expanded/mini-player track skipping, quick-search opening/closing and tab swiping. Thresholds apply to preview progress and commit on release. Inputs, sliders and native scrolling retain their behavior. Restore swipe thresholds restores the prior defaults without changing other preferences.

Preferences are saved locally and existing settings are preserved. The official update feed remains prefilled.
