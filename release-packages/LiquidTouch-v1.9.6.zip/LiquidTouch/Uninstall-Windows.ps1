[CmdletBinding()]
param([switch]$NoApply)
. (Join-Path $PSScriptRoot 'tools/Common.ps1')
$configPath = Get-SpiceConfig
$configDir = Split-Path -Parent $configPath
$statePath = Join-Path $configDir 'liquid-touch-state.json'
if (-not (Test-Path -LiteralPath $statePath)) {
    throw 'No LiquidTouch installer record was found. Use the manual removal instructions in README.md.'
}
$state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
$text = [IO.File]::ReadAllText($configPath)
$recovery = Join-Path $configDir ('liquid-touch-uninstall-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssffffZ') + '.ini')
Copy-Item -LiteralPath $configPath -Destination $recovery
if ((Read-IniValue $text 'Setting' 'current_theme') -eq 'LiquidTouch') {
    foreach ($key in @('current_theme', 'color_scheme', 'inject_css', 'replace_colors')) {
        $text = Write-IniValue $text 'Setting' $key $state.previous.$key
    }
}
$extensions = @((Read-IniValue $text 'AdditionalOptions' 'extensions') -split '\|' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
if (-not $state.extension_enabled) { $extensions = @($extensions | Where-Object { $_ -ne 'liquid-touch.js' }) }
$text = Write-IniValue $text 'AdditionalOptions' 'extensions' ($extensions -join '|')
$restoreAPIs = $false
if ($state.PSObject.Properties['apis_previous'] -and (Read-IniValue $text 'Preprocesses' 'expose_apis') -eq '1') {
    $restoreAPIs = $state.apis_previous -ne '1'
    $text = Write-IniValue $text 'Preprocesses' 'expose_apis' $state.apis_previous
}
Save-Utf8 $configPath $text
$themePath = Join-Path $configDir 'Themes/LiquidTouch'
$extensionPath = Join-Path $configDir 'Extensions/liquid-touch.js'
if (Test-Path -LiteralPath $themePath) { Remove-Item -LiteralPath $themePath -Recurse -Force }
if (Test-Path -LiteralPath $extensionPath) { Remove-Item -LiteralPath $extensionPath -Force }
if ($state.theme_existed) { Copy-Item -LiteralPath (Join-Path $state.baseline_backup 'LiquidTouch') -Destination $themePath -Recurse }
if ($state.extension_existed) { Copy-Item -LiteralPath (Join-Path $state.baseline_backup 'liquid-touch.js') -Destination $extensionPath }
if ($state.autostart_created) {
    $shortcut = Join-Path ([Environment]::GetFolderPath('Startup')) 'LiquidTouchSpotify.lnk'
    if (Test-Path -LiteralPath $shortcut) { Remove-Item -LiteralPath $shortcut -Force }
}
Remove-Item -LiteralPath $statePath -Force
if (-not $NoApply) {
    $nativeBackup = Join-Path $configDir 'Backup'
    $hasBackup = (Test-Path -LiteralPath $nativeBackup) -and (@(Get-ChildItem -LiteralPath $nativeBackup -File -Recurse).Count -gt 0)
    if ($restoreAPIs -and $hasBackup) { Invoke-Spice -Arguments @('restore', 'backup', 'apply') }
    else { Invoke-Spice -Arguments @('apply') }
}
Write-Host 'LiquidTouch removed. Your other extensions and newer configuration edits were kept.'
