# v1.9.6 validation — 3 November 2026

Current build: `2026-11-03-qol`. The following checks ran against the v1.9.6
production source and rebuilt extension, with simulated Spotify interfaces.

| Check | Result |
| --- | --- |
| Complete built extension in a DOM host | 23 suites passed |
| Existing search, held Backspace and artwork-drag controller regressions | 12 suites passed |
| Existing installer integration tests against a fake Spicetify CLI | 7 tests passed |
| v1.9.5 to v1.9.6 loader update | Passed inside the 23 DOM suites |
| JavaScript syntax, generated-runtime equality and update SHA-256 | Passed |
| Installer ZIP contents/checksum and generated publishing feed | Passed |
| Full Git bundle verification, clean clone and publisher-style import | Passed |

The DOM suites load the complete generated extension and shipped host fixture.
They cover pending/failed/empty lyrics, per-song manual state, late-response
rejection, automatic lookup disabled with manual retry, every numeric Settings
slider, preference migration, Home context/album/artist updates and persistence,
control paint counts, restrictions/volume, Low-RAM cache/image/poll policies,
tab/player/sheet gestures, slider/scroll exclusions, the real-song gallery and
an actual update through the v1.9.5 loader. A 100-event unchanged-state stress
case produced zero additional full control paints; progress continued updating.
This is a DOM-work result, not a measured frame-rate or total-RAM claim.

To reproduce from the extracted package (Node.js and Python 3):

```bash
npm install --no-save jsdom
node tests/release-196-dom.cjs
node tests/revised-195.cjs
python3 -m unittest discover -s tests -p test_installer.py -v
```

Set `LT_PREVIOUS_PREVIEW` to the extracted v1.9.5 `LiquidTouch-Preview.html` to
include the 23rd suite, which applies the new JSON through the previous loader.
Without it, the current-release DOM tests run 22 suites. `LT_JSDOM_PATH` may
point at an existing jsdom installation instead of installing it in the package.

Not performed: Chromium rendering/screenshot tests, signed-in Windows Spotify,
physical touchscreen checks, real PC memory/frame-time measurements, or
execution of Windows PowerShell/COM installers. The attempted Chromium download
could not produce a valid browser archive. JSDOM supplies DOM/event behavior
but has no layout or graphics engine. These checks therefore do not establish
live API compatibility, a specific RAM saving, or smoothness on the user's PC.
Installer scripts are unchanged. Older browser results below are historical.

---

# Validation — LiquidTouch 1.9.5 revised

Build `2026-11-03-r1`, checked 3 November 2026.

`node tests/revised-195.cjs`: **12 suites passed** against the production
controller in an isolated simulated host. Coverage includes alternate client
query definitions, wrapped/nested/partial responses, empty results and retry;
full/Quick native-view recovery with visible-route preservation and stale-query
cancellation; held Backspace in all three fields, cancellation/leave/focus/blur/
visibility cleanup, selection and Unicode deletion; and drag cancellation for
holdable artwork while preserving unrelated drags.

JavaScript syntax, generated runtime/source/CSS integrity, feed SHA-256 and ZIP
CRC/contents were verified. The source, generated loader and both offline demos
were rebuilt together. Installer scripts and stored-settings/history keys are
unchanged. Version remains 1.9.5, so an existing 1.9.5 user must reinstall the
revised full ZIP; its old updater cannot import a same-version runtime.

No signed-in Spotify session or physical touchscreen was available. Chromium
was not installed in this environment and its download failed, so the browser
suites were not rerun for this revision. Native DOM selectors and live search
compatibility still need confirmation in the user's Spotify client.

The original release's validation record follows for reference.

# Original v1.9.5 validation (historical)

Checked 3 November 2026 with Chrome for Testing 151.0.7922.34 and Playwright.

69 browser suites passed against simulated Spotify services:

- 12 v1.9.5 suites: lyrics-off centering at 1024×600 and 1920×1080 with
  130% text/120% interface; modal history keyboard routing and Enter behavior;
  cold first full/quick searches, late client bindings, stale host Home events,
  valid empty results and bounded retry; real incoming tab/Back previews,
  below-threshold cancellation, unique IDs and visibility after commit;
  dynamic sheet dismissal; animated anchored holds/nested Back; native Song
  Radio playlist resolution/seed-first playback and inline unavailable errors;
  Low-RAM caches/background release and persisted settings; actual published
  revised v1.9.4 → v1.9.5 import/restart with settings and history retained.
- 13 retained v1.9.4 suites: history migration beyond 10,000 plays, reloads,
  timestamps/search, oldest-first caps/Unlimited/Clear/storage failures;
  exclusive touch hold/single/double taps; context actions and inline errors;
  Queue/Devices, four-size player/artwork flow, continuous tint, hidden player
  scrollbars, Quick Search blur and upper-left history Close.
- 13 revised v1.9.4 suites: four-size history/accessibility layout, native
  Connect discovery and common response formats, transfers, pause preservation,
  fallback/timeouts, automatic refresh and stale response isolation.
- 11 v1.9.3 motion/threshold suites: 23 speed controls and 11 thresholds,
  independent persistence/reset, player/lyric/Settings/search/navigation motion,
  threshold commit/cancel and Reduce Motion.
- 20 retained updater/card/player suites using a fictional future v1.9.6
  candidate: separate lyric/player sizing, exclusive card taps, dynamic player
  expansion/collapse, history/scroll return, approved update/restore, integrity
  checks, quota errors, rollback and duplicate-listener prevention.

The v1.9.5 published-loader test used the revised v1.9.4 ZIP with SHA-256
25245944dc94ff1ad8e84f93064bff9f8f73cc4e3ddeff21774fa197cd9ca8fa.
The older optional v1.9.3/1.9.2 upgrade and original-v1.9.4 reinstall cases in
retained suites were not rerun; their results below are historical.

Six gallery screenshots were inspected with verified real-song metadata and
album artwork. The gallery builder captures the production UI unchanged;
playback/timestamps/library contents are simulated. Gallery lyrics are disabled
to avoid attributing fictional fixture lyrics to real recordings.

JavaScript syntax, version/generated-source equality, runtime integrity, ZIP CRC
and packaged file contents are checked before publication. Installer scripts are
unchanged. A signed-in Windows Spotify client and physical touchscreen were not
available; Spotify APIs, lyrics, Connect devices and Windows bridges were mocked.
Low-RAM mode bounds retained LiquidTouch resources; no fixed whole-process RAM
saving is claimed. External catalog/Connect availability still depends on the
installed Spotify client and session.

Earlier results below are historical.

# Validation — revised LiquidTouch 1.9.4

Checked 2 November 2026 with Chrome for Testing 151.0.7922.34 and Playwright.

39 browser suites passed for this revision:

- 14 suites in tests/revised-194.cjs: balanced history and upper-left Close at
  1920×1080, 1024×600, 800×480 and 480×800 (including 200% text / 140% interface);
  native Connect with REST unavailable; removal of system window controls from
  action sheets; cached, asynchronous Map and split-API device formats; native
  and local-device transfer; preserving paused playback; REST transfer fallback;
  native request timeouts; automatic discovery while open; stale-response
  isolation; and reinstalling this same version over an original v1.9.4 runtime
  cache while keeping preferences and listening history.
- 14 existing 1.9.4 suites passed: durable history, caps and Clear, storage
  failures, real touch holds/single/double taps, context actions, Queue/Devices,
  player layout/opacity, Quick Search blur, revised Close placement, and an
  actual v1.9.3 → v1.9.4 runtime upgrade.
- 11 motion/threshold suites passed in tests/release-193.cjs, including history
  sheet gestures, player gestures and the existing speed/threshold controls.

JavaScript syntax, version agreement, generated-source equality, runtime
integrity, ZIP CRC and packaged file contents were verified. Installer scripts
are unchanged from the original v1.9.4 package. Screenshots of history, Queue
and Devices were inspected. Spotify Connect, Web API responses, lyric sources
and Windows hooks were simulated; no signed-in live Windows Spotify client or
physical touchscreen was available.

The original v1.9.4 package used for the same-version reinstall test has SHA-256
080d31d46ad566845235b4a5466e2a995d301aad78a853a36b9d17584cc2767d.
Native Connect method shapes were checked against the first-party implementation
at https://github.com/Todd5540/lumen-player/blob/main/src/spotify/devices.js.

Earlier validation below describes the original v1.9.4 and older releases.

# Validation — LiquidTouch 1.9.4

Checked 2 November 2026 with Chrome for Testing 151.0.7922.34 and Playwright.

- 14 new browser suites passed in tests/release-194.cjs: one-time migration of
  more than 10,000 historical plays, persisted reloads/search/timestamps,
  oldest-first limits and Unlimited, confirmed Clear, storage-quota failures,
  real CDP touch holds/cancels, exclusive single/double taps, player-artwork
  context actions, playlist selection, library mutations and inline failures,
  owned Queue/Devices, large-art layout at four viewport sizes, matching player
  tint, Quick Search blur/toolbar behavior and the saved 0 px blur setting,
  history Close placement, and an actual published 1.9.3 → 1.9.4 runtime update.
- 20 updater/card/player suites passed in tests/release-190.cjs using a fictional
  future 1.9.5 candidate, including integrity checks, update approval, storage
  failure, startup rollback, persistent preferences and player gesture behavior.
- 11 motion/threshold suites passed in tests/release-193.cjs (without the optional
  older-release import case), including all 23 speed and 11 threshold controls.
- 11 Settings suites passed in tests/settings-192.cjs, including submenu gestures,
  independent preferences, focus/Back and accessibility at four viewport sizes.
- 7 Python installer tests passed. 7 PowerShell tests were skipped because
  PowerShell is unavailable here; this is not a live Windows installer test.
- JavaScript syntax, version agreement, generated-source equality, runtime
  integrity, ZIP CRC and packaged source-content checks passed.
- Screenshots inspected for portrait player flow, history Close placement and
  Quick Search’s sharp foreground/blurred background.

Spotify services, lyric sources, output devices and Windows hooks were simulated.
No physical touchscreen or signed-in live Windows Spotify client was available.
The actual published v1.9.3 package used for the upgrade test has SHA-256
364c1bd43ade7d69e64dc8ec7fd3fdd688c33d90690f8fc22aa3a0789f189807.

Some earlier legacy tests still target the removed flat Settings layout or
native Queue/Devices and localStorage-only history; those older expectations are
superseded by the 1.9.4 suites. Earlier results below are historical, not claims
about the current release.

# Validation — LiquidTouch 1.9.3

Prepared 1 November 2026 for the scheduled 2 November release.

**89 relevant Chromium suites and seven installer checks passed.**
The 12 release-193 suites cover reclaimed lyric space compared with the actual
revised 1.9.2 preview; retained lyric seeking; all 23 speed controls and 11 gesture
controls; independent persistence/reset; real Web Animations and CSS durations;
slow/fast player motion; independent lyric show/hide/reflow; every gesture's changed
confirmation distance; short/cancelled release behavior; bounds and Reduce Motion;
and import/restart through the actual published revised 1.9.2 loader.

The retained suites were release-150 (12), release-170 (15), release-190 (20),
release-191 (11), release-192 (8), and settings-192 (11). They cover timing corrections,
track art, opacity, navigation, current/source loader updates, rollback, clock settings,
grouped controls, touch cancellation and enlarged layout. The one-time optional
same-version fixture case in settings-192 was not rerun for this newer version.
Other historical suites were not rerun. Old provider-label assertions now inspect
diagnostics, and menu outside-click checks use visible header space.

Run release-193 with LT_OLD_PREVIEW pointing to the preview extracted from the
published revised 1.9.2 ZIP. Set LT_CHROME to Chromium. Earlier loader tests use
the saved 1.9.0 and 1.9.1 previews respectively. Installer/helper sources are unchanged.
Visual QA inspected the player and the two new Settings submenus. Syntax, source
version/hash agreement and ZIP integrity/content checks passed.

Spotify, lyric services and Windows hooks were simulated. No live Windows Spotify
client or physical touchscreen was available. Publication is deliberately deferred;
the prepared release is staged separately from the live main branch.

Earlier validation follows as historical results.

# Validation — revised LiquidTouch 1.9.2

Checked 1 November 2026.

**78 relevant browser suites and seven installer checks passed.**
The 66 retained suites are release-150 (12), release-170 (15), release-190 (20),
release-191 (11) and release-192 (8). The 12 new settings-192 suites cover the
category hub, every submenu, saved values, Escape/Back, artwork and timing
shortcuts, enlarged text/layout, dynamic rightward Back, dynamic downward close,
short/long/reversed/cancelled pulls, inert incoming category previews, slider
exclusion, and Reduced Motion. Touch events are trusted Chromium inputs.

Reinstallation was simulated with the first v1.9.2 runtime already cached: the
revised installed bundle replaces that cache while preserving preferences.
Because the original updater compares version numbers, users already running
v1.9.2 need the revised full installer package. Older 1.9.0/1.9.1 loader imports
were checked with the actual previous previews and the revised runtime JSON.

The settings navigation helpers now open the appropriate category before using
its controls. Existing timing, opacity, scale, clock, updates and gesture tests
use the new navigation. The older immediate-dismiss assertions now wait for the
requested gesture settling animation, and Back checks include the category hub.
Other historical suites were not rerun for this revision.

Use LT_ORIGINAL_192 for settings-192.cjs to point to the runtime JSON extracted
from the first v1.9.2 ZIP. LT_OLD_PREVIEW selects the 1.9.0 preview for
release-191.cjs and the 1.9.1 preview for release-192.cjs. LT_CHROME selects Chromium.
Visual QA inspected the category hub and Appearance page. JS syntax, generated
source/hash agreement, package contents and archive integrity were checked.
Spotify services, lyrics and Windows hooks were simulated; no physical touchscreen
or live Windows Spotify client was available.

Historical results for the original v1.9.2 build follow.

# Validation — LiquidTouch 1.9.2

Checked 1 November 2026.

**66 relevant browser suites and seven Python installer checks passed.**
These comprise release-150 (12), release-170 (15), release-190 (20),
release-191 (11) and release-192 (8). Other historical suites were not rerun
for this small release. Spotify services, lyrics and Windows hooks are simulated;
a physical touchscreen and a live Windows Spotify client were not available.

The new suites exercise trusted touch on the single three-dot menu, keyboard
arrows/Home/End/Escape, outside dismissal, Timing/Reset, one Reload request,
retained lyric seeking, track changes, lyrics off and player close/reopen.
They confirm the heading and seek instruction are absent, menu bounds and
44 px minimum targets at 1920×1080, 1024×600 and 480×800 with enlarged text,
and the independent lyric opacity override. Visual QA checked the open menu.

The exact previews from the saved v1.9.0 and v1.9.1 full packages import the
new v1.9.2 JSON through their real loaders. First-launch notes, one runtime after
restart, custom feed addresses, disabled checks, clock settings and independent
lyric sizes are preserved. New/empty feed settings adopt the official raw URL.
The updater suite also exercises approval, checksums, newer-loader rejection,
failed startup rollback, cache failures and restore of the installed version.

Run the two upgrade tests with LT_OLD_PREVIEW pointing respectively to the
preview from the saved 1.9.0 ZIP (release-191.cjs) and 1.9.1 ZIP
(release-192.cjs). Set LT_CHROME to the installed Chromium executable.
Generated JS/CSS hashes, source/version consistency and ZIP integrity were checked.

Earlier validation follows, as historical results for those releases.

# Validation — LiquidTouch 1.9.1

Checked 31 October 2026.

## Release 1.9.1 checks

**179 browser suites and seven installer checks passed.** The 11 new suites
exercise trusted Chromium touch and the actual 1.9.0 loader upgrading to this
1.9.1 JSON. The retained 168 suites cover browsing, search, details, independent
sizing, gestures, player lifetime, artwork, lyrics, window controls and updates.

New coverage:

- Home clock starts off; its accessible toggle also enables the format control.
- 12/24-hour formatting handles midnight/noon and persists across reload.
- Minute ticks change only the clock, without card rebuilds or service requests;
  returning to cached Home refreshes its time and the clock can be hidden again.
- Clock/greeting layout stays within bounds at 1920×1080, 800×480 and 480×800,
  including 200% text and 140% interface. Small displays wrap instead of clipping.
- Left-edge Back follows actual history and restores Library scroll, including
  swipes over the floating navigation.
- Short or cancelled pulls do not navigate; non-edge artwork swipes still skip;
  edge Back closes the player without changing tracks.
- Nested update/Settings/player/history layers close one at a time with no
  invisible modal left open. Gutter and dialog-backdrop touches remain active.
- Vertical scrolling and input selection in the edge region keep their normal
  behavior instead of being treated as Back.
- The previous release's actual loader accepts this JSON, retains lyric sizing,
  shows first-launch notes without a stray tap opening Now Playing, and preserves
  the new clock preferences after restart.

The lazy artwork regression explicitly scrolls a missing-cover card into view
before checking its metadata lookup; the original assumption about its screen
position no longer applies to every header layout. Installer/helper sources are
unchanged. Syntax, generated-source/hash agreement and package integrity checks
also pass. Internal visual QA images are excluded from deliverables.

Run `tests/release-191.cjs` with `LT_OLD_PREVIEW` pointing to the preview extracted
from the saved 1.9.0 ZIP to include the exact previous-loader upgrade case.
Use `LT_CHROME` for a Chromium executable when needed. The existing test list
in README includes every retained suite and the new release test.

Spotify services, lyrics and Windows hooks are simulated. No physical touchscreen
or live Windows Spotify client was available. Publishing is verified separately
through the repository workflow and public feed; these browser checks do not
claim compatibility with every Spotify/Electron build.

Earlier validation follows.

# Validation — LiquidTouch 1.9.0

Checked 30 October 2026.

## Release 1.9.0 checks

**168 browser suites and seven Python installer tests passed.** The 148 retained
suites cover the previous functionality with revised expectations for exclusive
single/double taps, independent lyric sizing and slower player settling. The 20
new suites run the actual generated loader and app in Chromium with trusted touch
and simulated Spotify/update services.

New coverage:

- Legacy lyric sizing migrates once; measured song/lyric fonts change independently
  and persist after reload.
- A single card tap waits then plays once; double taps open without playback,
  including artists, a held second touch and navigation cancellation.
- Tap timing is adjustable in milliseconds, with a pending-card visual response.
- Player opening exceeds the old 120 ms duration. The root stays opaque and
  untransformed; tap dismissal settles before closing.
- Held opening/closing gestures follow the finger, cancel below threshold, commit
  on release above threshold and restore Library/scroll. Pointer cancellation and
  reopening during dismissal cannot leave an invisible modal.
- Reduced Motion settles without animation.
- No configured feed means no update-network requests.
- Local import needs approval, updates JS/CSS together, persists across restart,
  retains a single interface/listener set, displays full/brief notes, shows first
  notes once and restores the installed version on request.
- Hosted checks offer Update / Later. Automatic prompts defer while Settings is
  open and do not download code before approval or an explicit notes request.
- HTTPS without URL credentials, same-host bundle URLs and downloaded SHA-256
  are enforced before execution. Corrupt bundles cannot write or execute.
- Minimum-loader mismatches request a package installation.
- Blocking dynamic code compilation leaves the installed literal fallback usable
  and produces an installer instruction for runtime imports.
- A cache quota failure leaves the existing interface nodes connected.
- Startup failure restores the prior UI/cache; corrupt cached runtime data falls
  back without executing it.

The seven installer tests cover copies/config/backup/restore/reinstallation with
an isolated fake CLI. Installer, uninstaller and installer-helper source is
unchanged from 1.8.0. JavaScript and Bash syntax checks, generated JS/CSS/integrity
checks, production preview embedding and ZIP extraction integrity also pass.
Internal visual checks cover independent-size Settings, the player and held
sheet reveal, and the release-notes sheet. QA screenshots are excluded from
all deliverables.

A live Spotify client, Windows/Electron CSP, real hosted release service and
physical touchscreen were not available. No live update host was deployed or
configured. Mocked tests establish the implementation's behavior under the
exercised contracts, not compatibility with every Spotify build or actual
physical touch feel. Runtime updates need the 1.9 loader, usable local storage,
SHA-256 support and host permission to compile update code. Otherwise the normal
installer remains the update path.

## Reproduce

Set `LT_CHROME` to your Chromium executable if needed, and make Playwright
available through Node resolution (or `CODEX_PRIMARY_RUNTIME_NODE_MODULES`).

```bash
node tools/build-preview.cjs
node tests/ui.cjs
node tests/features.cjs
node tests/browse-history.cjs
node tests/release-130.cjs
node tests/release-140.cjs
node tests/release-150.cjs
node tests/release-151.cjs
node tests/release-160.cjs
node tests/release-161.cjs
node tests/release-170.cjs
node tests/release-171.cjs
node tests/release-180.cjs
node tests/release-190.cjs
python3 tests/test_installer.py
```

Earlier 1.8.0 validation follows for the owned detail-page coverage.

# Validation — LiquidTouch 1.8.0

Checked 30 October 2026.

## Release 1.8.0 checks

**148 browser suites and seven Python installer tests passed.** JavaScript/Bash
syntax, production source/preview equality and archive integrity also passed.
Installer/uninstaller/helper source is unchanged from 1.7.1.

Seventeen new suites cover:

- Actual playlist, album and artist contents remain visible when the native
  router throws and its root is hidden. Selecting a row plays once and preserves
  album/playlist context; Back restores the prior Home/Library (three suites).
- A searched song opens its owned page and Back retains the search results.
- Missing installed APIs fall back to authenticated album/artist/playlist catalog
  data, with real songs and available releases.
- Playlist paging advances 50/100/105 items, including repeated recordings.
- Failed paging retains the loaded songs and retries the same offset correctly.
- Unrecognized client response shapes fall back instead of showing an empty page.
- Liked Songs opens its collection and passes context on row playback.
- Failed initial loading keeps a readable hero, Play/Retry and a desktop exit;
  Retry restores contents and the desktop exit opens the native item explicitly.
- Late detail responses and background host routing cannot replace the active page.
- Closing the player preserves detail scroll; revisiting reuses data and Refresh
  explicitly reloads the item.
- Two taps can be 0.55 seconds apart, but matching URIs across tabs do not combine.
- Saved text/control sizing is independent of artwork and browsing; measured title
  font and playback-button height change by their chosen factors and persist.
- Maximum player text/control/artwork at Text 200% / Interface 140% preserves
  reachable 44 px playback targets at 800×480 and 480×800 (two suites).
- Player text sizing also enlarges lyrics; timed taps still seek exactly and the
  lyric scrollbar remains hidden.

The retained 131 suites follow the new owned detail contract. Native queue routing
still exercises replacement scroll wrappers, brief native unmounts and canonical
redirect Back handling. Older scrollbar tests now verify invisible scrollbars
with preserved overflow scrolling, and the removed header label is expected empty.
Keyboard, artwork previews, glass, gestures, lyric timing and window controls
remain covered. Internal screenshots are excluded from deliverables.

Tests run Chromium with trusted touch and simulated Spotify/catalog/Windows/lyric
responses. They cannot establish live API coverage, actual audio/queue behavior,
physical touch feel or compatibility with the user's exact Spotify/Electron build.
The owned UI exposes an error and explicit desktop exit if content APIs fail.

## Release 1.7.1 checks

**131 browser suites and seven Python installer tests passed.** JavaScript/Bash
syntax, preview/source equality and archive integrity checks passed. Installer,
uninstaller and installer helper source is unchanged from 1.7.0.

Eleven new browser suites check:

- Double-tapped playlists, albums and artists expose actual, hit-testable native
  detail content and playback controls; the second tap does not restart playback,
  and Back restores the prior tab (three suites).
- A late replacement main view, a modern viewport without the legacy class, and
  collapsed intermediate scrolling wrappers recover; teardown removes markers.
- A brief native unmount during routing keeps Touch UI enabled until remount.
- A playing equalizer inserted before a cover, or replacing it, cannot overwrite
  known art or a cached Home view.
- An active artist keeps its known portrait.
- An unknown cover with only a playing graphic hydrates from metadata.
- Both footer bars have equal computed material at equal 0/35/73/100% values;
  independent overrides and returning to Universal still work.
- Fitting artwork/controls have no scrollbar; increasing art restores scrolling,
  and reducing art hides it again.
- Resizing between large and small viewports at Text 130% / Interface 120%
  updates overflow visibility and preserves scrolling to playback controls.

The retained 120 browser suites also pass. Tests run production source/CSS in
Chromium with trusted touch input and fictional music; Spotify services, Windows
IPC and public lyrics are simulated. This does not verify the exact installed
Spotify/Electron build or physical touchscreen. Translucent bars still show the
content underneath their different positions. Internal screenshots are excluded
from the package and deliverables.

## Release 1.7.0 checks

**120 browser suites and seven Python installer tests passed.** JavaScript/Bash
syntax, preview/source equality and archive integrity checks passed. Installer,
uninstaller and installer helper source is unchanged from 1.6.1.

Fifteen new suites check:

- Held keys enlarge/show a popup before release, type once and clean up.
- Reduced Motion preserves readable feedback without transforms; cancellation
  does not type.
- Actual next/previous queue images follow the finger before audio changes;
  a release sends one playback action and removes the transition image layers.
- Reversal/cancel does not skip; the mini player has the same cover preview.
- A client without queue data keeps working without a fabricated cover.
- Legacy sheet/header preferences migrate to one whole-window Settings control,
  with a transparent header and separately scrolling content.
- Navigation 0/50/100% opacity controls tint, blur and highlights after navigation;
  hidden native content cannot show through custom pages.
- Navigation selection/icon emphasis follows swipe progress, returns on cancel,
  and stays linked across content swipes, tab taps and navigation-bar swipes.
- The cover's direct size button exposes the 60–200% setting and changes its size.
- LRCLIB searches normalized remaster/guest metadata, rejecting unrelated artists,
  live versions and incompatible recording lengths.
- lyrics.ovh text fallback follows both LRCLIB misses, is labelled, cannot seek
  and sends no Spotify credentials/cookies.
- Retry-After is honored across search variants and immediate Reload.
- Disabling broader lookup blocks public lyric requests.
- Obsolete lyric requests cannot overwrite a newly selected song.
- URI-only queue entries hydrate their artwork during a held drag without
  premature playback.

Retained tests now expect a single Settings/history glass surface and moving
cover images inside a stable artwork frame. Real Chromium touch/fullscreen and
the production source/CSS are exercised, with fictional tracks and lyric text.
Spotify, Windows IPC and public lyric responses are simulated. Actual queue
availability, provider coverage, client performance and touch feel require the
target mini PC. Internal screenshots are not packaged or delivered.

## Release 1.6.1 checks

**105 browser suites and seven Python installer tests passed.** JavaScript/Bash
syntax, preview/source equality and archive integrity checks passed. Installer,
uninstaller and installer helper source is unchanged from 1.6.0.

Ten new suites cover:

- An enabled legacy fullscreen preference cannot call requestFullscreen or
  exitFullscreen. The player stays open at full app-viewport size without any
  internal close/reopen, including external fullscreen/resize notifications.
- Repeated trusted player/Settings/close cycles preserve the prior Library and
  scroll, with no delayed dismissal or invisible input layer.
- Visible artwork changes at 100%, 135% and 160%, persistence/reload, both lyric
  layouts and retirement of the old fullscreen preference.
- A measured increase above the 100% base at 800 × 480, 1024 × 600 and 480 × 800;
  controls remain reachable after increasing artwork to 180% (three suites).
- Default keyboard keys are about 45% taller at Interface 100%, retain their
  width, and support trusted typing/backspace and the 100% height setting.
- Maximum keyboard height at Text 150% / Interface 140% at the same three display
  sizes: keys and search field stay within the viewport, typing works and live
  search cannot block Hide keyboard (three suites).

Retained fullscreen tests now assert the requested app-viewport behavior. A real
Chromium fullscreen session entered by the test host before opening the player
is preserved through repeated player open/close. The UI geometry check scrolls
each record-column control into view before checking its bounds and touch size,
since intentionally larger artwork may require scrolling on short displays.

All retained 95 browser suites passed. Spotify services/Windows IPC are simulated;
physical Spotify/Electron behavior and touch feel still need the target mini PC.
Internal screenshots are excluded from the deliverables.

## Release 1.6.0 checks

**95 browser suites and seven Python installer tests passed.** JavaScript/Bash
syntax checks passed. Installer/uninstaller/helper source is unchanged from 1.5.1.
The production source/CSS are embedded unchanged in the rebuilt offline preview.

Twelve new browser suites check:

- Immediate interactive opening with an unresolved fullscreen request, sharing
  the pending request on reopen.
- Late fullscreen completion while nested Settings is open; live playback input
  and correct fullscreen ownership after returning to the player.
- Dismissal before fullscreen settles, with no phantom reopen or leftover fullscreen.
- Repeated open/close under real Chromium fullscreen with trusted touch input,
  no modal-root animation and correct hit testing.
- Larger 360-pixel art and smaller controls at Text 130% / Interface 120%, lyrics
  toggling, and no duplicate player-header title.
- Universal 0%, 63% and 100% tint across browsing/cards, both search forms, live
  preview, keyboard, navigation, mini player, sheets/headers, lyrics and timing.
  Text opacity remains one and track artwork remains visible.
- Seven explicit overrides including 0%/100%, persistence, one-action reset,
  and inherited panels following subsequent universal changes.
- Scrubbing all 101 opacity values without rebuilding browsing or reloading lyrics.
- Trusted quick-search pulls at the left edge, center and right edge, including
  the toolbar band on a scrolled page; caption drags retain their own behavior.
- Reachable art/controls at Text 130% / Interface 120% at 800 × 480, 1024 × 600,
  and 480 × 800 (three suites).

All retained 83 browser suites passed. Real Chromium fullscreen and touch are
exercised; Spotify services and Windows IPC remain simulated. Physical mini-PC
performance, Spotify/Electron fullscreen behavior and touch feel require the
target computer. Internal QA screenshots are excluded from the deliverables.

## Release 1.5.1 checks

**83 browser suites and seven Python installer tests passed.** JavaScript/Bash
syntax and archive integrity checks passed. Installer source is unchanged.

Seven new browser suites cover HUD removal with motion retained; repeated trusted
tab swipes reusing the same Home/Library card nodes; out-of-order route completion;
canonical redirects to previously opened routes; live/custom time-of-day greetings;
40 px expanded-player skips with smaller/mini gestures excluded; and full-width
top pull-down without stealing caption or lower lyric scrolling.

The previous motion suites now assert that no HUD exists. Other existing UI,
browse/history, player, search, lyric timing, installer and fullscreen regressions
remain part of the release checks. Spotify services and Windows IPC are simulated;
real Chromium touch/fullscreen is exercised. Physical touch feel and Spotify’s
own cold-start/network time require the target computer.

## Release 1.5.0 checks

**76 browser suites passed** (the previous 64 plus 12 new motion/timing suites),
along with all seven Python installer tests. JavaScript/Bash syntax checks and
archive integrity passed. Installer/uninstaller source is unchanged from 1.4.0.

The new tests exercise trusted Chromium touch input with motion enabled:

- In-progress transforms and progress cues before a tab change; short release,
  threshold commitment, reversal and pointer cancellation.
- Interactive player pull-down with no animated/transparent modal root, exact
  single track skips, quick-search pulls, and nested Settings pull-down.
- Page/native detail/Back/history transition coverage.
- Lyrics layout movement, inert ID-free exit copies, rapid-toggle cleanup.
- Exact lyric boundaries, 250 ms adjustments, corrected seeking, persistence,
  recording isolation and Spotify/LRCLIB source isolation.
- Match a line without seeking; Reset and bounded corrections.
- Pause/seek boundary updates, OS reduced-motion cancellation, teardown/reload.

No audio analysis or live comparison of the named songs was possible. Tests use
original fictional lyric lines and simulated Spotify data. Timing controls are
verified against exact timestamps; listening accuracy needs the target recording,
provider and playback device. Physical Windows IPC remains simulated.

## Release 1.4.0 checks

**64 browser suites passed**: 15 UI, 10 feature, 14 browse/history,
13 retained 1.3 regressions, and **12 new 1.4 regressions**. All seven Python
installer tests, JavaScript syntax checks and Bash syntax checks also passed.
The installer scripts are unchanged from the prior releases.

The new tests exercise real Chromium Fullscreen API and trusted touch input
in addition to simulated Spotify APIs:

- Player visibility, hit testing, playback and custom captions after real
  fullscreen; artwork-area pull-down returns to the prior tab and scroll.
- Rapid open/close with motion enabled; no root opacity/transform animation or
  delayed close; 120 ms maximum opening transition; late fullscreen completion.
- Installed-client search response shapes, nested artwork, full result filters,
  artist playback, Web API fallback, retry/desktop failure UI and request sharing.
- Trusted swipes over page content, a wider left edge and below the toolbar;
  no accidental playback; repeated first-touch navigation.
- Exact reverse Back ordering across Home, search landing, submitted results and
  Library, including a 700 ms asynchronous native router update.
- Simultaneous art/compact controls/lyrics geometry, timed seeking, saved Settings
  toggle, and a mocked public LRCLIB response with offsets/multiple LRC timestamps.
- Window controls remain operable at Text 130% / Interface 120%; stock controls
  remain hidden; cards no longer require individual live backdrop filters.

Live Spotify catalog/lyrics responses and Windows desktop IPC are simulated.
Actual fullscreen testing establishes browser modal behavior, not compatibility
with a particular Spotify/Electron version or physical Windows touchscreen.

## Release 1.3.0 checks

**13 release suites** reproduce the 1.2.0 hidden-parent blank-page rule against a
fixture with Spotify's `.Root__top-container`, then verify the corrected native
album and search views. They also exercise artist tap/play/open, live search
loading/cache/stale-response behavior, item-card recents, welcome persistence,
finger drift and pressed-card preservation, fullscreen lifecycle and gestures,
local Back and automatic redirects, timed/untimed lyrics, missing-art recovery,
unified header styling, and reduced-motion transitions. Services are simulated. The retained checks were adapted to the 1.4 result/lyrics layout and passed; fullscreen teardown was also checked through the simulated host.

The unchanged installer/uninstaller scripts retain their prior PowerShell 7
validation; Python installer checks and Bash syntax were rerun for this release.

## Retained regression coverage

- JavaScript syntax checks for the production extension and offline fixture.
- Bash syntax checks for both installer entry points.
- **15 Chromium UI/contract suites** using the production extension and CSS:
  - Home, player, and keyboard at 800 × 480, 1024 × 600, 1280 × 720,
    480 × 800, and 600 × 1024.
  - Visible extension controls fit the viewport and meet a 44 px minimum.
  - Large mode maintains 56 px primary controls at 800 × 480 and 480 × 800.
  - Expanded player fills the viewport and fits the standard tested profiles.
  - Modal focus, nested settings, and Escape dismissal.
  - Playback, seek, volume, mute, shuffle, all repeat modes, save/remove,
    library navigation, queue navigation, and native stationary track taps.
  - Scroll gestures do not accidentally activate native track playback.
  - Local keyboard, shift, URI-encoded search, system keyboard selection,
    preferences, and reload persistence.
  - Artwork and header swipes, native devices handoff, return button, and
    Ctrl + Alt + T recovery.
  - Playback restrictions, empty player state, untrusted metadata text,
    rejected script artwork URLs, and clean removal of listeners/UI.
  - Extension reload without duplicates and recovery when a native view disappears.
  - Delayed player data, unavailable optional profile menu, routing without a
    listener, missing API diagnostics, startup exceptions, missing CSS, and retry.
  - Seeking to the end sends milliseconds rather than the ambiguous integer 1.
- **10 feature suites** exercise:
  - Live origin metadata, artwork, and controls with `Player.data` missing.
  - Legacy track records, native widget metadata, and asynchronous platform state.
  - Artwork-derived page colors, including pixel sampling when the extractor fails.
  - Album/playlist single-tap play and double-tap open with no duplicate playback.
  - Scroll gestures leave playback alone; keyboard activation still opens.
  - 200% text, 140% interface size, and 20% glass opacity at 800 × 480,
    480 × 800, and 1920 × 1080; content separation and saved preferences.
  - Enlarged player layouts can scroll to their bottom actions.
  - Matching minimize/maximize/close controls use the native client interface.
  - A rejected window command restores native controls and reserves its hit area.
- **14 browse/history suites** serve the unchanged preview on a local HTTP
  origin and use trusted Chromium touch input to exercise:
  - First tap plays; second opens; only one playback request is sent.
  - Scroll gestures do not start music; first-touch navigation works repeatedly.
  - A 145-item library loads in pages, scrolls, and uses no more than four columns
    at 1920 × 1080, 1024 × 600, 800 × 480, and 480 × 800.
  - Final cards can scroll fully above the floating footer.
  - Recent search song, playlist, album and artist cards survive reload.
  - Local history stores track starts, skips duplicate pause/resume entries,
    searches artists, retains timestamps, and survives reload.
  - Artwork updates page and floating-surface colors; card/sheet rounding is
    retained while the expanded player is edge-to-edge; native chrome is hidden at Text 130% / Interface 120%.
  - Text 200% / Interface 140% / rounding 56 px remain usable at 800 × 480.
  - Settings remains tappable after changing rounding and scrolling its content.
  - Explicit library filters, nested rootlist data, sidebar-only fallback, and
    removal of stale API items during refresh.
  - Paused first tracks, repeat loops, and user seeking do not corrupt play counts.
  - Identifiable native recent-search cards are adopted.
  - A 230-entry local journal pages older plays, searches past the displayed
    page, and replays the selected URI.
- **7 Python/Linux installer tests:** repeated installation, backup retention,
  empty/missing INI settings, preexisting resources, unrelated newer extensions,
  newer theme selection, exact CLI apply arguments, and restoration. Added API
  exposure preservation, restore-before-backup selection, and 1.0.0 state migration.
- **7 PowerShell installer tests:** the same real installer/uninstaller scripts
  exercised under PowerShell 7.5.4 on Linux against the isolated fake CLI.
- An additional compatibility reproduction used Spicetify v2.44.0's actual
  profile-menu implementation with ReactJSX not ready: 1.0.0 removed its touch
  UI during startup; 1.0.1 kept the interface mounted under the same condition.
  This reproduces one color-only failure path; it does not establish which
  dependency was missing in the user's running Spotify instance.
- ZIP integrity and expected installer/theme/extension/preview contents.

## Limits of this validation

The Spotify host and playback APIs in these checks are simulated. No live
Spotify session, real audio output, Spotify update/patch operation, physical
touchscreen, or Windows desktop was available. These checks do not establish
compatibility with a particular Spotify client version.

Live LibraryAPI/RootlistAPI response shapes and recommendation DOM, native
row-button selectors, native Connect UI,
Spotify fullscreen integration, Windows PowerShell 5.1, the optional Windows COM startup
shortcut, and actual touch feel require a check on the target machine.
DesktopWindowState calls and native titlebar visibility are also checked through
a simulated native bridge; they have not been run against a physical Windows client.

Local `file:` browser storage intermittently disappeared before the preview
script loaded in this Chromium runtime. Persistence checks therefore use a
normal HTTP origin; this does not add a server dependency to the extension.

Browser screenshots were used for internal visual inspection and are not
included in the deliverables. The supplied HTML is the reproducible preview.

See README.md for installation, recovery, and reproducible check commands.
