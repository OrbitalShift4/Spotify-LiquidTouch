#!/usr/bin/env bash
set -euo pipefail
task_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
command -v spicetify >/dev/null || { echo 'Install Spicetify first: https://spicetify.app/docs/getting-started' >&2; exit 1; }
command -v python3 >/dev/null || { echo 'The Linux/macOS installer needs Python 3. Manual installation is in README.md.' >&2; exit 1; }
python3 "$task_dir/tools/manage.py" install "$task_dir" "$@"
