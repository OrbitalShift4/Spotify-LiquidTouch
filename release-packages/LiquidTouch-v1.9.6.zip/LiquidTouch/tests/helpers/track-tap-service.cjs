// Test service: the public wrapper below matches upstream core.js. Native
// skipTo.uri/uid follows upstream Extensions/bookmark.js. Unknown keys do not
// select a track. Web requests may acknowledge without changing playback.
async function contextService(page,kind,order,options={}){
 await page.evaluate(({kind,order,options})=>{
  window.__order=order;window.__position=0;window.__contextURI='spotify:'+kind+':selected';window.__nativeRequests=[];window.__webRequests=[];window.__repeatCalls=[];
  window.__nativeMode=options.nativeMode||'play';window.__webMode=options.webMode||'noop';window.__repeat=options.repeat||0;window.__repeatFailure=options.repeatFailure||false;
  const track=(id,index)=>id===null?null:{uri:'spotify:track:demo'+id,name:__ltMock.tracks[id].name,artists:[{name:__ltMock.tracks[id].artist}],duration_ms:__ltMock.tracks[id].duration,uid:'row-'+index};
  const contents=()=>({items:order.map((id,index)=>({uid:'row-'+index,track:track(id,index)})),totalLength:order.length});
  const choose=index=>{window.__position=index;__ltMock.choose(order[index],__contextURI);__ltMock.setMetadata({...Spicetify.Player.data.item,uid:'row-'+index});};
  Spicetify.Platform.PlaylistAPI.getContents=async()=>contents();
  const gql=Spicetify.GraphQL.Request;Spicetify.GraphQL.Request=(def,args)=>def==='getAlbum'?Promise.resolve({data:{albumUnion:{uri:__contextURI,name:'Test album',tracksV2:contents()}}}):gql(def,args);
  const get=Spicetify.CosmosAsync.get,put=Spicetify.CosmosAsync.put;
  Spicetify.CosmosAsync.get=url=>url.includes('/'+kind+'s/selected')?Promise.resolve({...contents(),uri:__contextURI,name:'Test context',tracks:contents()}):get(url);
  Spicetify.CosmosAsync.put=async(url,body)=>{
   if(url.endsWith('/me/player/play')){
    __webRequests.push({url,body});
    if(__webMode==='reject')throw Error('Web API disabled');if(__webMode==='hang')return new Promise(()=>{});
    if(__webMode==='play'){if(body.context_uri!==__contextURI)throw Error('Wrong Web context');choose(body.offset.position??order.findIndex((id,index)=>track(id,index)?.uri===body.offset.uri));}
    return {};
   }
   return put(url,body);
  };
  Spicetify.Player.origin.play=async(target,context,playbackOptions)=>{
   __nativeRequests.push({target,context,options:playbackOptions});
   if(__nativeMode==='reject')throw Error('Native playback disabled');if(__nativeMode==='hang')return new Promise(()=>{});if(__nativeMode==='noop')return {};
   const skip=playbackOptions?.skipTo;
   // The old trackUri/trackIndex fields are intentionally not interpreted.
   if(target.uri!==__contextURI || !skip?.uri)return {};
   const index=skip.uid?order.findIndex((id,index)=>track(id,index)?.uid===skip.uid&&track(id,index)?.uri===skip.uri):order.findIndex((id,index)=>track(id,index)?.uri===skip.uri);
   if(index<0)throw Error('Selected row unavailable');
   if(__nativeMode==='delayed')setTimeout(()=>choose(index),240);else choose(index);return {};
  };
  // Upstream src/jsHelper/spicetifyWrapper/core.js, playUri.
  Spicetify.Player.playUri=async(uri,context={},playbackOptions={})=>await Spicetify.Player.origin.play({uri},context,playbackOptions);
  Spicetify.Player.origin.setRepeat=async value=>{__repeatCalls.push(value);if(__repeatFailure)throw Error('Repeat control unavailable');__repeat=value;};
  Spicetify.Player.getRepeat=()=>__repeat;
  Spicetify.Player.next=()=>{let next=__position+1;while(order[next]===null)next++;if(next<order.length)choose(next);};
  Object.defineProperty(Spicetify,'Queue',{configurable:true,get:()=>({track:track(order[__position],__position),nextTracks:order.slice(__position+1).map((id,index)=>track(id,index+__position+1)).filter(Boolean),prevTracks:[]})});
  Spicetify.Platform.History.push('/'+kind+'/selected');
 },{kind,order,options});
 await page.waitForSelector('.lt-detail-track');
}
module.exports={contextService};
