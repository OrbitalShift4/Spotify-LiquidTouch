const {revealSetting}=require('./settings-navigation.cjs');
/* 1.7.1: detail handoff, stable covers, matching glass and conditional scrolling. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
let origin,passed=0;
async function open(browser,prefs={},width=1024,height=600){
 const context=await browser.newContext({viewport:{width,height},hasTouch:true,reducedMotion:'reduce'}),page=await context.newPage(),errors=[];page.setDefaultTimeout(8000);page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(p=>localStorage.getItem('liquid-touch.preferences.v1') || localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,textScale:130,uiScale:120,...p})),prefs);
 await page.goto(origin);await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted' && document.querySelector('#lt-browse .lt-card'));return {context,page,errors};
}
function pass(name,errors){assert.deepEqual(errors,[]);passed++;console.log('PASS '+name);}
async function range(page,key,value){await revealSetting(page,key);await page.locator('#lt-'+key).evaluate((n,v)=>{n.value=String(v);n.dispatchEvent(new Event('input',{bubbles:true}));},value);}
async function nativeVisible(page){
 await page.waitForFunction(()=>{const n=document.querySelector('.fixture-row-title a');if(!n)return false;const r=n.getBoundingClientRect();return r.width>20 && r.height>10 && document.elementFromPoint(r.x+10,r.y+r.height/2)===n;});
 assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'');
 assert.equal(await page.locator('#lt-browse').isVisible(),false);
 assert.equal(await page.locator('.Root').evaluate(n=>getComputedStyle(n).opacity),'1');
 assert.equal(await page.locator('[data-lt-native=main]').evaluate(n=>getComputedStyle(n).opacity),'1');
}
async function glass(page,selector){return page.locator(selector).evaluate(n=>{const s=getComputedStyle(n);return {bg:s.background,filter:s.backdropFilter,border:s.borderTopColor,shadow:s.boxShadow,opacity:s.getPropertyValue('--lt-surface-opacity').trim(),clear:n.dataset.ltClear,solid:n.dataset.ltSolid};});}
async function main(){
 const html=fs.readFileSync(path.resolve(__dirname,'../LiquidTouch-Preview.html')),server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(html);});await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox']});
 try{
  for(const [uri,tab] of [['spotify:playlist:demo-0','home'],['spotify:album:demo-1','home'],['spotify:artist:demo-4','library']]){
   const {page,context,errors}=await open(browser);
   if(tab==='library')await page.locator('.lt-nav [data-action=library]').tap();
   // Reproduce a host fade that was left hidden while the custom page was up.
   await page.evaluate(()=>{document.querySelector('.Root').style.opacity='0';document.querySelector('.Root__main-view').style.opacity='0';});
   const face=page.locator('#lt-browse [data-lt-card="'+uri+'"]');await face.tap();const firstPlays=await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length);await face.tap();await page.waitForSelector('.lt-detail-track');
   assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length),firstPlays);assert.ok(firstPlays<=1);
   assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().route),'/'+uri.split(':').slice(1).join('/'));
   await page.locator('.lt-detail-track').first().tap();assert.ok(await page.evaluate(()=>Spicetify.Player.isPlaying()));
   await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),tab);
   pass('double-tapping '+uri.split(':')[1]+' opens owned songs despite faded native content, keeps playback live and returns to the prior tab',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{
    const push=Spicetify.Platform.History.push.bind(Spicetify.Platform.History);Spicetify.Platform.History.push=path=>{push(path);if(!path.startsWith('/queue'))return;
     requestAnimationFrame(()=>{
      const old=document.querySelector('.Root__main-view'),replacement=document.createElement('div');replacement.dataset.testid='main-view';replacement.style.opacity='0';
      replacement.append(...old.childNodes);old.replaceWith(replacement);
      const view=replacement.querySelector('.main-view-container__scroll-node'),a=document.createElement('div'),b=document.createElement('div');a.style.cssText='height:0;flex:0;min-height:0';b.style.cssText='height:0;flex:0;min-height:0';view.before(a);a.append(b);b.append(view);view.classList.remove('main-view-container__scroll-node');view.dataset.overlayscrollbarsViewport='';
     });
    };
   });
   await page.locator('#lt-mini-open').tap();await page.locator('#lt-now-playing [data-action=queue]').tap();await nativeVisible(page);
   assert.equal(await page.locator('[data-lt-native-layout]').count(),3);assert.ok((await page.locator('[data-lt-native-viewport]').boundingBox()).height>150);
   await page.locator('.fixture-row-play').first().tap();assert.equal(await page.locator('#lt-mini-title').textContent(),'Blue Hour');
   await page.evaluate(()=>LiquidTouch.destroy());assert.equal(await page.locator('[data-lt-native-layout],[data-lt-native-viewport]').count(),0);
   pass('late main-view replacement and collapsed modern scroll wrappers recover without a timer-based blank page or leftover layout markers',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{const push=Spicetify.Platform.History.push.bind(Spicetify.Platform.History);Spicetify.Platform.History.push=path=>{push(path);if(!path.startsWith('/queue'))return;const main=document.querySelector('.Root__main-view'),parent=main.parentElement;main.remove();setTimeout(()=>parent.append(main),240);};});
   await page.locator('#lt-mini-open').tap();await page.locator('#lt-now-playing [data-action=queue]').tap();assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().enabled),true);await nativeVisible(page);assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().enabled),true);await page.locator('.fixture-row-play').first().tap();assert.equal(await page.locator('#lt-mini-title').textContent(),'Blue Hour');
   pass('a brief native unmount during routing does not disable the touch interface before the replacement page arrives',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);const old=await page.locator('#lt-browse [data-uri="spotify:playlist:demo-0"] img').getAttribute('src');
   await page.evaluate(()=>{const card=document.querySelector('#fixture-content [data-uri="spotify:playlist:demo-0"]'),image=document.createElement('img');image.src='https://open.spotifycdn.com/cdn/images/equaliser-animated-green.fake.gif';card.prepend(image);});
   await page.waitForTimeout(450);assert.equal(await page.locator('#lt-browse [data-uri="spotify:playlist:demo-0"] img').getAttribute('src'),old);
   await page.evaluate(()=>{const card=document.querySelector('#fixture-content [data-uri="spotify:playlist:demo-0"]');card.querySelector('.main-cardImage-image').remove();card.querySelector('img').src='https://open.spotifycdn.com/cdn/images/equaliser-animated-green.new.gif';});
   await page.waitForTimeout(450);assert.equal(await page.locator('#lt-browse [data-uri="spotify:playlist:demo-0"] img').getAttribute('src'),old);
   await page.locator('.lt-nav [data-action=search]').tap();await page.locator('.lt-nav [data-action=home]').tap();assert.equal(await page.locator('#lt-browse [data-uri="spotify:playlist:demo-0"] img').getAttribute('src'),old);
   pass('a playing equalizer before the cover, or replacing the cover entirely, cannot overwrite the known artwork or the cached Home page',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{const card=document.querySelector('#fixture-content [data-uri="spotify:album:demo-1"]');card.dataset.uri='spotify:artist:demo-1';card.querySelector('.main-cardHeader-text').textContent='Tidal';});
   await page.waitForFunction(()=>document.querySelector('#lt-browse [data-uri="spotify:artist:demo-1"] img'));const old=await page.locator('#lt-browse [data-uri="spotify:artist:demo-1"] img').getAttribute('src');
   await page.evaluate(()=>{const card=document.querySelector('#fixture-content [data-uri="spotify:artist:demo-1"]');card.querySelector('img').src='https://open.spotifycdn.com/cdn/images/playing-indicator.gif';card.append(document.createElement('span'));});
   await page.waitForTimeout(450);assert.equal(await page.locator('#lt-browse [data-uri="spotify:artist:demo-1"] img').getAttribute('src'),old);
   pass('the same cover-preservation rule keeps the active artist portrait instead of a generic playing visualizer',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{const card=document.querySelector('#fixture-content [data-uri="spotify:album:demo-1"]');card.dataset.uri='spotify:playlist:missing-cover';card.querySelector('img').src='https://open.spotifycdn.com/cdn/images/equaliser-animated-green.fake.gif';card.querySelector('.main-cardHeader-text').textContent='A missing cover';});
   await page.locator('#lt-browse [data-uri="spotify:playlist:missing-cover"]').evaluate(n=>n.scrollIntoView({block:'center'}));
   await page.waitForFunction(()=>{const img=document.querySelector('#lt-browse [data-uri="spotify:playlist:missing-cover"] img');return img && img.src.startsWith('data:image/png');});
   assert.equal(await page.locator('#lt-browse [data-uri="spotify:playlist:missing-cover"] img').getAttribute('src'),await page.evaluate(()=>LT_DEMO_COVERS[0]));
   pass('an initially unknown cover triggers metadata hydration instead of caching the equalizer as art',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.locator('#lt-shell .lt-header [data-action=settings]').tap();
   for(const opacity of [0,35,73,100]){await range(page,'glassOpacity',opacity);assert.deepEqual(await glass(page,'.lt-mini'),await glass(page,'.lt-nav'));}
   await revealSetting(page,'opacity');await page.locator('.lt-opacity-options summary').tap();await revealSetting(page,'opacity');await page.locator('[data-opacity-override=miniOpacity]').tap();await revealSetting(page,'opacity');await page.locator('[data-opacity-override=navOpacity]').tap();await range(page,'miniOpacity',20);await range(page,'navOpacity',75);
   assert.equal((await glass(page,'.lt-mini')).filter,'blur(3.6px) saturate(1.6)');assert.equal((await glass(page,'.lt-nav')).filter,'blur(13.5px) saturate(1.6)');
   await revealSetting(page,'opacity');await page.locator('[data-opacity-override=miniOpacity]').tap();await revealSetting(page,'opacity');await page.locator('[data-opacity-override=navOpacity]').tap();await range(page,'glassOpacity',40);assert.deepEqual(await glass(page,'.lt-mini'),await glass(page,'.lt-nav'));
   pass('both footer bars use identical material at equal opacity, including clear/solid endpoints, while independent overrides still work',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{artworkSize:60},1280,720);await page.locator('#lt-mini-open').tap();
   await page.waitForFunction(()=>{const n=document.querySelector('.lt-np-record');return n.scrollHeight<=n.clientHeight+1;});
   const fit=await page.locator('.lt-np-record').evaluate(n=>({scroll:n.scrollHeight,height:n.clientHeight,width:getComputedStyle(n).scrollbarWidth,buttons:getComputedStyle(n,'::-webkit-scrollbar-button').display}));assert.ok(fit.scroll-fit.height<=1);assert.equal(fit.width,'none');assert.equal(fit.buttons,'none');
   await page.locator('[data-action=artworkSettings]').tap();await range(page,'artworkSize',200);await page.locator('#lt-settings [data-action=closeSettings]').tap();
   await page.waitForFunction(()=>{const n=document.querySelector('.lt-np-record');return n.scrollHeight>n.clientHeight+1;});assert.equal(await page.locator('.lt-np-record').evaluate(n=>getComputedStyle(n).scrollbarWidth),'none');
   await page.locator('.lt-np-record').evaluate(n=>n.scrollTop=n.scrollHeight);assert.ok(await page.locator('.lt-np-record').evaluate(n=>n.scrollTop>0));
   await page.locator('#lt-now-playing [data-action=playerSettings]').tap();await range(page,'artworkSize',60);await page.locator('#lt-settings [data-action=closeSettings]').tap();await page.waitForFunction(()=>{const n=document.querySelector('.lt-np-record');return n.scrollHeight<=n.clientHeight+1;});
   pass('scrollbars stay hidden while enlarging art enables real scrolling and shrinking it fits the deck again',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{artworkSize:135},1280,900);await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>{const n=document.querySelector('.lt-np-record');return n.scrollHeight<=n.clientHeight+1;});
   await page.setViewportSize({width:800,height:480});await page.waitForFunction(()=>{const n=document.querySelector('.lt-np-record');return n.scrollHeight>n.clientHeight+1;});await page.locator('.lt-np-record').evaluate(n=>n.scrollTop=n.scrollHeight);assert.ok(await page.locator('.lt-np-record').evaluate(n=>n.scrollTop>0));
   await page.setViewportSize({width:1280,height:900});await page.waitForFunction(()=>{const n=document.querySelector('.lt-np-record');return n.scrollHeight<=n.clientHeight+1;});
   assert.equal(await page.locator('.lt-np-record').evaluate(n=>getComputedStyle(n).scrollbarWidth),'none');
   pass('viewport resizing preserves scroll access with no visible player scrollbar at either size',errors);await context.close();
  }
  console.log(passed+' release 1.7.1 suites passed with simulated Spotify services.');
 }finally{await browser.close();await new Promise(r=>server.close(r));}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
