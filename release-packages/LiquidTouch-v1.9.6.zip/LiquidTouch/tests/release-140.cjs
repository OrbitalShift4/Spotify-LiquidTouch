const {revealSetting}=require('./settings-navigation.cjs');
/* Regressions for 1.4.0. Uses real Chromium touch/fullscreen plus simulated Spotify APIs. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
const base=path.resolve(__dirname,'..');let origin,passed=0;
async function open(browser,width=1024,height=600,prefs={}){
 const context=await browser.newContext({viewport:{width,height},hasTouch:true,reducedMotion:'reduce'}),page=await context.newPage(),errors=[];
 page.setDefaultTimeout(6000);page.on('pageerror',error=>errors.push(error.message));
 await page.addInitScript(value=>{if(!localStorage.getItem('liquid-touch.preferences.v1'))localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,...value}));},prefs);
 await page.goto(origin);await page.waitForFunction(()=>window.LiquidTouch?.diagnostics().phase==='mounted');
 return {page,context,errors};
}
function pass(name,errors){assert.deepEqual(errors,[]);console.log('PASS '+name);passed++;}
async function swipe(page,x,y,endX,endY){
 const session=await page.context().newCDPSession(page);
 await session.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y,id:1}]});
 for(let i=1;i<=8;i++)await session.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x+(endX-x)*i/8,y:y+(endY-y)*i/8,id:1}]});
 await session.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await session.detach();
}
async function submitted(page,query){await page.locator('.lt-nav [data-action=search]').tap();await page.locator('#lt-search-input').fill(query);await page.locator('#lt-search-input').press('Enter');await page.waitForFunction(()=>document.body.dataset.ltCustomPage==='results' && document.querySelector('#lt-browse').getAttribute('aria-busy')==='false');}
async function main(){
 const server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(fs.readFileSync(path.join(base,'LiquidTouch-Preview.html')));});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox'],headless:true});
 try{
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{delete document.fullscreenElement;delete document.documentElement.requestFullscreen;delete document.exitFullscreen;});
   await page.locator('.lt-nav [data-action=library]').tap();await page.locator('#lt-browse').evaluate(n=>n.scrollTop=250);
   await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>document.querySelector('#lt-now-playing').open);assert.equal(await page.evaluate(()=>Boolean(document.fullscreenElement)),false);
   await page.waitForTimeout(400);
   assert.equal(await page.evaluate(()=>document.querySelector('#lt-now-playing').contains(document.elementFromPoint(500,300))),true);
   assert.equal(await page.locator('#lt-now-playing .lt-caption-buttons [data-action=windowClose]').isVisible(),true);
   await page.locator('#lt-now-playing [data-action=next]').tap();assert.equal(await page.locator('#lt-np-title').textContent(),'Blue Hour');
   await swipe(page,240,150,245,290);await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open && !document.fullscreenElement);
   assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');
   assert.ok(await page.locator('#lt-browse').evaluate(n=>n.scrollTop>=240));
   pass('viewport-only player preserves visible modal, live controls, custom captions and return tab/scroll without entering display fullscreen',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.emulateMedia({reducedMotion:'no-preference'});
   for(let i=0;i<5;i++){
    await page.locator('#lt-mini-open').tap();await page.locator('#lt-now-playing').waitFor({state:'visible'});
    const result=await page.locator('#lt-now-playing').evaluate(n=>({opacity:getComputedStyle(n).opacity,transform:getComputedStyle(n).transform,rootAnimations:n.getAnimations().length,durations:n.querySelector('.lt-np-layout').getAnimations().map(a=>a.effect.getTiming().duration)}));
    assert.equal(result.opacity,'1');assert.equal(result.transform,'none');assert.equal(result.rootAnimations,0);assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().playerPhase),'opening');
    await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);
   }
   await page.locator('#lt-mini-open').tap();await page.waitForTimeout(300);assert.equal(await page.locator('#lt-now-playing').isVisible(),true);
   pass('rapid opening/closing leaves no invisible modal or delayed close callback; slower reveal settles without moving or fading the modal root',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{document.documentElement.requestFullscreen=async()=>{await new Promise(r=>setTimeout(r,350));__ltMock.log.push(['lateFullscreen']);};});
   await page.locator('#lt-mini-open').tap();await page.locator('#lt-now-playing').waitFor({state:'visible'});
   await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await page.waitForTimeout(400);
   assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),false);
   await page.locator('.lt-nav [data-action=search]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'search');
   pass('slow fullscreen completion cannot reopen a dismissed player or block page input',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{
    const get=Spicetify.CosmosAsync.get;Spicetify.CosmosAsync.get=async url=>{if(url.includes('/v1/search?'))throw new Error('Web search denied');return get(url);};
    Spicetify.GraphQL={Definitions:{searchDesktop:{name:'test'}},Request:async(def,v)=>{__ltMock.log.push(['clientSearch',v]);return {data:{searchV2:{tracksV2:{items:[{item:{data:{uri:'spotify:track:gql',name:'Client search song',albumOfTrack:{coverArt:{sources:[{url:LT_DEMO_COVERS[2]}]}},artists:{items:[{profile:{name:'Demo Artist'}}]}}}}]},artists:{items:[{data:{uri:'spotify:artist:gql',profile:{name:'Demo Artist'},visuals:{avatarImage:{sources:[{url:LT_DEMO_COVERS[2]}]}}}}]},albumsV2:{items:[]},playlists:{items:[]}}}};}};
   });
   await submitted(page,'Example');
   assert.equal(await page.locator('#lt-browse [data-lt-card="spotify:track:gql"]').isVisible(),true);
   assert.ok(await page.locator('#lt-browse .lt-card[data-uri="spotify:track:gql"] img').getAttribute('src'));
   await page.locator('#lt-browse [data-search-filter=artist]').tap();assert.equal(await page.locator('#lt-browse [data-lt-card="spotify:track:gql"]').count(),0);
   await page.locator('#lt-browse [data-lt-card="spotify:artist:gql"]').tap();await page.waitForFunction(()=>!LiquidTouch.diagnostics().cardTapPending);assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').at(-1)[1]),'spotify:artist:gql');
   assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='clientSearch').length),1);
   pass('submitted search uses the installed client query, renders nested artwork and artist/song cards, and supports filters/playback',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{Spicetify.GraphQL={Definitions:{searchDesktop:{}},Request:async()=>{throw new Error('Client query unavailable');}};});
   await submitted(page,'Blue');assert.equal(await page.locator('#lt-browse [data-lt-card="spotify:track:demo-1"]').isVisible(),true);
   assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().searchSource),'web-api');
   await page.evaluate(()=>{Spicetify.CosmosAsync.get=async()=>{throw new Error('Service unavailable');};});
   await submitted(page,'Uncached failure');assert.equal(await page.locator('#lt-browse [data-action=retrySearch]').isVisible(),true);assert.ok((await page.locator('.lt-result-status').textContent()).includes('unavailable'));
   await page.locator('#lt-browse [data-action=nativeSearch]').tap();assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().enabled),false);assert.equal(await page.locator('#lt-rescue').isVisible(),true);
   pass('search falls back between providers and exposes retry/desktop controls instead of a blank page when both fail',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.locator('.lt-nav [data-action=search]').tap();await page.evaluate(()=>__ltMock.setSearchDelay(450));
   await page.locator('#lt-search-input').fill('Blue');await page.waitForTimeout(120);await page.locator('#lt-search-input').press('Enter');
   await page.waitForFunction(()=>document.querySelector('#lt-browse [data-lt-card="spotify:track:demo-1"]'));
   assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='apiGet' && r[1].includes('/v1/search?')).length),1);
   await page.locator('.lt-nav [data-action=home]').tap();await page.waitForTimeout(200);assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'home');
   pass('preview and submitted search share one in-flight request; late completion does not replace another tab',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   const initial=await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length);
   await swipe(page,620,250,400,255);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'search');
   await swipe(page,650,300,430,305);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');
   await swipe(page,600,300,820,305);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'search');
   await swipe(page,85,250,240,255);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');
   assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').length),initial);
   await swipe(page,700,105,710,205);assert.equal(await page.locator('#lt-quick-search').isVisible(),true);
   await page.locator('#lt-quick-search [data-action=closeQuickSearch]').tap();
   for(let i=0;i<6;i++){await page.locator('.lt-nav [data-action=home]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'home');await page.locator('.lt-nav [data-action=library]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');}
   pass('trusted touch swipes work across page content and wider edge/header areas without accidental plays; first-tap navigation stays responsive',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await submitted(page,'Blue');await page.locator('.lt-nav [data-action=library]').tap();await page.locator('.lt-nav [data-action=home]').tap();
   await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');
   await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().route),'/search/Blue');assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'results');
   await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().route),'/search');
   await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'home');
   pass('Back visits Library, submitted results, search landing, and Home in exact reverse order',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{const push=Spicetify.Platform.History.push.bind(Spicetify.Platform.History);Spicetify.Platform.History.push=path=>setTimeout(()=>push(path),700);});
   await page.locator('.lt-nav [data-action=search]').tap();await page.waitForTimeout(550);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'search');
   await page.locator('.lt-nav [data-action=library]').tap();await page.waitForTimeout(250);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');
   await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'search');
   pass('an asynchronous Spotify route update and polling cannot erase the intended tab or local Library state',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>document.querySelectorAll('.lt-lyric-line').length===5);
   const art=await page.locator('#lt-art').boundingBox(),controls=await page.locator('.lt-np-controls').boundingBox(),lyrics=await page.locator('#lt-lyrics-panel').boundingBox();
   assert.ok(controls.y>=art.y+art.height-1);assert.ok(lyrics.x>art.x+art.width);
   await page.locator('[data-lyric-index="2"]').tap();assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='seek').at(-1)[1]),25000);
   await page.locator('#lt-now-playing [data-action=playerSettings]').tap();await revealSetting(page,'lyrics');await page.locator('#lt-settings [data-pref=lyrics]').tap();await page.locator('#lt-settings [data-action=closeSettings]').tap();
   assert.equal(await page.locator('#lt-lyrics-panel').isVisible(),false);assert.equal(await page.locator('#lt-art').isVisible(),true);
   await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await page.reload();await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().preferences.lyrics),false);
   pass('artwork remains visible above compact controls while active lyrics occupy the other column; timed seeking and saved Settings toggle work',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);let lookup;
   await page.route('https://lrclib.net/api/get?*',async route=>{lookup=route.request();await route.fulfill({contentType:'application/json',body:JSON.stringify({duration:238,syncedLyrics:'[offset:100]\n[00:01.20]An original test line\n[00:05.000][00:08.00]A second original line',plainLyrics:null})});});
   await page.evaluate(()=>{const get=Spicetify.CosmosAsync.get;Spicetify.CosmosAsync.get=async url=>{if(url.includes('color-lyrics'))throw new Error('No Spotify lyrics');return get(url);};});
   await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>document.querySelectorAll('.lt-lyric-line').length===3);
   assert.ok((await page.evaluate(()=>LiquidTouch.diagnostics().lyricsProvider)).includes('LRCLIB'));assert.equal(lookup.headers().authorization,undefined);assert.equal(lookup.headers().cookie,undefined);
   await page.locator('[data-lyric-index="0"]').tap();assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='seek').at(-1)[1]),1300);
   pass('Spotify lyric failure falls back to a plain public LRCLIB request and parses precise LRC offsets/multiple timestamps',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,800,480,{textScale:130,uiScale:120});
   await page.locator('#lt-mini-open').tap();await page.locator('#lt-now-playing').waitFor({state:'visible'});
   const controls=page.locator('#lt-now-playing .lt-caption-buttons');assert.equal(await controls.isVisible(),true);await controls.locator('[data-action=windowMaximize]').tap();assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='windowState').at(-1)[1]),2);
   assert.equal(await page.locator('.Root__globalNav').isVisible(),false);
   await page.locator('#lt-now-playing [data-action=playerSettings]').tap();assert.equal(await page.locator('#lt-settings .lt-caption-buttons').isVisible(),true);
   assert.equal(await page.locator('.lt-card').first().evaluate(n=>getComputedStyle(n).backdropFilter),'none');
   pass('custom window controls stay visible and operable in player/settings at 130% text and 120% interface, with cheaper card compositing',errors);await context.close();
  }
  console.log(passed+' release 1.4 suites passed. Spotify service/Windows bridge responses remain simulated.');
 }finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
