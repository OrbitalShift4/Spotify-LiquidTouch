'use strict';
// Exercises the production controller in an isolated simulated host. No Spotify
// account, network, browser installation or extracted copy of a method is used.
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../source/liquid-touch-app.js'),'utf8');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));let passed=0;
function environment(){
  const handlers=new Map(),observers=new Set(),window={},document={hidden:false};
  const context=vm.createContext({window,document,console,URL,URLSearchParams,AbortController,Event,setTimeout,clearTimeout,setInterval,clearInterval,performance,requestAnimationFrame:fn=>setTimeout(fn,0),MutationObserver:class{constructor(fn){this.fn=fn;}observe(){observers.add(this);}disconnect(){observers.delete(this);}}});
  vm.runInContext(source.slice(0,source.indexOf('\n  let cancelled'))+'\nwindow.TestController=LiquidTouchController;\n})();',context);
  const c=Object.create(window.TestController.prototype),elements={};
  Object.assign(c,{S:{},prefs:{keyboard:true},destroyed:false,enabled:true,timers:new Set(),searchCache:new Map(),searchFlights:new Map(),routeRequests:new Map(),getRoutePath:()=>'/search/test',searchInput:null,keyboardTarget:null,listen:(target,type,fn)=>{const key=(target===window?'window':target===document?'document':'keys')+':'+type;const list=handlers.get(key)||[];list.push(fn);handlers.set(key,list);},$:id=>elements[id]});
  function emit(target,type,extra={}){const e={target:null,button:0,isPrimary:true,pointerId:1,clientX:30,clientY:30,preventDefault(){this.defaultPrevented=true;},stopPropagation(){},stopImmediatePropagation(){},...extra};for(const fn of handlers.get(target+':'+type)||[])fn(e);return e;}
  function input(value=''){const i={value,isConnected:true,selectionStart:value.length,selectionEnd:value.length,focus(){document.activeElement=i;emit('document','focusin',{target:i});},setRangeText(text,start,end){i.value=i.value.slice(0,start)+text+i.value.slice(end);i.selectionStart=i.selectionEnd=start+text.length;},dispatchEvent(){i.events=(i.events||0)+1;}};return i;}
  elements['lt-keyboard']={hidden:false};elements['lt-key-rows']={};c.searchInput=input();elements['lt-quick-input']=input();elements['lt-history-search']=input();
  const mutate=()=>{for(const o of observers)o.fn([{target:{nodeType:1,closest:()=>null}}]);};
  return {c,window,document,elements,emit,input,mutate,observers};
}
async function test(name,run){await run();console.log('PASS '+name);passed++;}
const track=(id='test',name='Test song')=>({uri:'spotify:track:'+id,name,artists:[{name:'Artist'}]});
const plain=(id='test')=>({tracks:{items:[track(id)]},artists:{items:[]}});
(async()=>{
 await test('search tries the available client definition before a denied Web API',async()=>{
   const {c}=environment();let calls=0,web=0;
   c.S.GraphQL={Definitions:{searchDesktop:{name:'old'}},QueryDefinitions:{searchModalResults:{name:'modal'}},Request:async(def,args)=>{calls++;assert.equal(args.enableEntityExtensionData,false);if(def.name==='old')throw Error('Old operation removed');return {data:{searchModalResults:{tracksV2:{items:[{item:{data:track()}}]}}}};}};
   c.apiGet=async()=>{web++;throw Error('Denied');};const entries=await c.searchMusic('test');assert.equal(entries[0].uri,'spotify:track:test');assert.equal(calls,2);assert.equal(web,0);assert.equal(c.searchSource,'spotify-client');
 });
 await test('nested edges, response bodies and partial GraphQL results remain usable',async()=>{
   const {c}=environment();const result={errors:[{message:'An unrelated category failed'}],data:{searchV2:{tracksV2:{edges:[{node:{item:{data:track()}}},null]},tracks:{items:[track()]},artists:{items:[{data:{uri:'spotify:artist:test',profile:{name:'Artist'}}}]}}}};
   const rows=c.normalizeSearch({body:JSON.stringify(result)});assert.equal(rows.length,2);assert.equal(rows[0].title,'Test song');assert.equal(rows[1].title,'Artist');assert.throws(()=>c.normalizeSearch({errors:[{message:'Offline'}],tracks:{items:[]}}));assert.throws(()=>c.normalizeSearch({tracks:{items:[{unknown:true}]}}));
 });
 await test('valid empty results finish once, and failed searches retry and can recover',async()=>{
   const {c}=environment();let calls=0;c.apiGet=async()=>{calls++;return {tracks:{items:[]}};};assert.equal((await c.searchMusic('empty')).length,0);assert.equal(calls,1);
   c.apiGet=async()=>{calls++;if(calls===2)throw Error('Cold');return plain('recovered');};assert.equal((await c.searchMusic('recovered'))[0].uri,'spotify:track:recovered');assert.equal(calls,3);assert.equal(c.searchFlights.size,0);
 });
 for(const quick of [false,true])await test((quick?'Quick':'Full')+' search recovers from Spotify’s rendered view without changing the visible route',async()=>{
   const {c,document,mutate,observers,elements}=environment();const path=quick?'/':'/search/test';c.getRoutePath=()=>path;c.searchInput.value='test';elements['lt-quick-input'].value='test';c.quickOpen=quick;
   c.routePath=path;c.apiGet=async()=>{throw Error('Denied');};c.nativeNavAt=0;c.history={location:{pathname:'/'},replace(p){this.location.pathname=p;mutate();c.acceptHostRoute(p);}};
   document.body={};document.querySelector=()=>({querySelector:()=>null});c.collectNativeEntities=()=>new Map([['test',{uri:'spotify:track:native',type:'track',title:'Native result'}]]);
   const entries=await c.searchMusic('test');assert.equal(entries[0].uri,'spotify:track:native');assert.equal(c.routePath,path);assert.equal(c.searchSource,'spotify-view');assert.equal(observers.size,0);assert.equal(c.history.location.pathname,quick?'/':'/search/test');
   c.searchSource='other';await c.searchMusic('test');assert.equal(c.searchSource,'spotify-view');
 });
 await test('native recovery never returns the previous page as a result',async()=>{
   const {c,document,elements}=environment();c.searchInput.value='new';c.getRoutePath=()=>'/search/new';c.history={location:{pathname:'/'},replace(p){this.location.pathname=p;}};document.body={};document.querySelector=()=>({querySelector:()=>null});let collected=0;c.collectNativeEntities=()=>{collected++;return new Map();};
   const pending=c.searchNativeView('new','new|0');setTimeout(()=>{c.searchInput.value='newer';},100);await assert.rejects(pending,/superseded/);assert.equal(collected,0);
 });
 for(const field of ['normal','quick','history'])await test('backspace repeats for '+field+' search and release stops with no extra click deletion',async()=>{
   const {c,elements,emit,input}=environment();const target=input('abcdefghijklmno');c.searchInput=target;if(field==='quick'){c.quickOpen=true;elements['lt-quick-input']=target;}if(field==='history')elements['lt-history-search']=target;c.keyboardTarget=target;
   c.pressKeyFeedback=()=>{};c.releaseKeyFeedback=()=>{};c.clearKeyFeedback=()=>{};c.bindKeyFeedback();
   const button={dataset:{key:'Backspace'},isConnected:true,getBoundingClientRect:()=>({left:0,right:60,top:0,bottom:60}),closest:()=>button};
   emit('window','pointerdown',{target:button});assert.equal(target.value,'abcdefghijklmn');await sleep(560);assert.ok(target.value.length<=11);emit('window','pointerup');const value=target.value;await sleep(160);assert.equal(target.value,value);assert.ok(c.backspaceClickBlock);assert.equal(target.events,15-value.length);
 });
 await test('cancel, moving away, focus changes and hiding the keyboard stop repetition',async()=>{
   for(const reason of ['pointercancel','pointermove','blur','focus','hidden']){
     const {c,elements,emit,input,document}=environment(),target=input('abcdef');c.searchInput=target;c.keyboardTarget=target;c.pressKeyFeedback=()=>{};c.releaseKeyFeedback=()=>{};c.clearKeyFeedback=()=>{};c.bindKeyFeedback();const button={dataset:{key:'Backspace'},isConnected:true,getBoundingClientRect:()=>({left:0,right:60,top:0,bottom:60}),closest:()=>button};
     emit('window','pointerdown',{target:button});if(reason==='focus')emit('document','focusin',{target:input('other')});else if(reason==='hidden'){document.hidden=true;emit('document','visibilitychange');}else emit('window',reason,{clientX:100});const value=target.value;await sleep(420);assert.equal(target.value,value,reason);assert.equal(c.backspaceRepeat,null);
   }
 });
 await test('backspace respects selected text, Unicode and the start of the input',async()=>{
   const {c,input}=environment();c.searchInput=input('A🚀BC');c.searchInput.selectionStart=c.searchInput.selectionEnd=3;c.typeKey('Backspace');assert.equal(c.searchInput.value,'ABC');c.searchInput.selectionStart=1;c.searchInput.selectionEnd=3;c.typeKey('Backspace');assert.equal(c.searchInput.value,'A');c.searchInput.selectionStart=c.searchInput.selectionEnd=0;c.typeKey('Backspace');assert.equal(c.searchInput.value,'A');
 });
 await test('artwork drag is cancelled on holdable cards while unrelated drags remain available',async()=>{
   const {c,emit}=environment();const artwork={},unrelated={};c.cancelHold=()=>{};c.holdEntry=t=>t===artwork?track():null;c.bindHoldMenus();assert.equal(emit('document','dragstart',{target:artwork}).defaultPrevented,true);assert.equal(Boolean(emit('document','dragstart',{target:unrelated}).defaultPrevented),false);
 });
 console.log(passed+' revised v1.9.5 simulated-host regression suites passed.');
})().catch(error=>{console.error(error);process.exitCode=1;});
