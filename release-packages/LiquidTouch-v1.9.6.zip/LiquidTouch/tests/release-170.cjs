const {revealSetting}=require('./settings-navigation.cjs');
/* 1.7: tactile keyboard, queue artwork, coherent opacity, linked navigation, broader lyrics. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
let origin,passed=0;
async function open(browser,prefs={}){
 const context=await browser.newContext({viewport:{width:1024,height:600},hasTouch:true,reducedMotion:'no-preference'}),page=await context.newPage(),errors=[];page.setDefaultTimeout(7500);page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(p=>localStorage.getItem('liquid-touch.preferences.v1') || localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,...p})),prefs);
 await page.goto(origin);await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');return {context,page,errors};
}
function pass(name,errors){assert.deepEqual(errors,[]);passed++;console.log('PASS '+name);}
async function range(page,key,value){await revealSetting(page,key);await page.locator('#lt-'+key).evaluate((n,v)=>{n.value=String(v);n.dispatchEvent(new Event('input',{bubbles:true}));},value);}
async function settings(page){await page.locator('#lt-shell .lt-header [data-action=settings]').tap();}
async function closeSettings(page){await page.locator('#lt-settings [data-action=closeSettings]').tap();}
async function player(page){await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');}
async function touch(page,x,y){const s=await page.context().newCDPSession(page);await s.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y,id:1}]});return {async move(ex,ey){await s.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:ex,y:ey,id:1}]});await page.waitForTimeout(28);},async end(){await s.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await s.detach();},async cancel(){await s.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});await s.detach();}};}
async function json(route,body,status=200,extra={}){await route.fulfill({status,contentType:'application/json',headers:{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Lrclib-Client',...extra},body:JSON.stringify(body)});}
async function noSpotifyLyrics(page){await page.evaluate(()=>{const get=Spicetify.CosmosAsync.get;Spicetify.CosmosAsync.get=async url=>{if(url.includes('color-lyrics'))throw new Error('No Spotify lyrics');return get(url);};});}
async function lyricRoutes(page,handler){await page.route('https://lrclib.net/api/**',async route=>{if(route.request().method()==='OPTIONS')return json(route,{});return handler(route,new URL(route.request().url()));});}
async function main(){
 const server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(fs.readFileSync(path.resolve(__dirname,'../LiquidTouch-Preview.html')));});await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox']});
 try{
  {
   const {page,context,errors}=await open(browser,{keyboard:true});await page.locator('.lt-nav [data-action=search]').tap();const r=await page.locator('[data-key=q]').boundingBox();const t=await touch(page,r.x+r.width/2,r.y+r.height/2);
   assert.equal(await page.locator('.lt-key-popup').isVisible(),true);assert.equal(await page.locator('.lt-key-popup').textContent(),'q');assert.equal(await page.locator('[data-key=q]').evaluate(n=>n.classList.contains('lt-key-held')),true);assert.equal(await page.locator('#lt-search-input').inputValue(),'');
   assert.notEqual(await page.locator('[data-key=q]').evaluate(n=>getComputedStyle(n).transform),'none');await t.end();assert.equal(await page.locator('#lt-search-input').inputValue(),'q');await page.waitForTimeout(140);assert.equal(await page.locator('.lt-key-popup').isVisible(),false);
   pass('held keys enlarge and show a readable popup before release; release types exactly once and cleans up feedback',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{keyboard:true,reduceMotion:true});await page.locator('.lt-nav [data-action=search]').tap();const r=await page.locator('[data-key=a]').boundingBox();const t=await touch(page,r.x+20,r.y+20);
   assert.equal(await page.locator('.lt-key-popup').isVisible(),true);assert.equal(await page.locator('[data-key=a]').evaluate(n=>getComputedStyle(n).transform),'none');await t.cancel();assert.equal(await page.locator('.lt-key-popup').isVisible(),false);assert.equal(await page.locator('#lt-search-input').inputValue(),'');
   pass('reduced motion retains readable key feedback without movement; pointer cancellation does not type',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await player(page);const before=await page.locator('#lt-art').getAttribute('src');let t=await touch(page,245,180);await t.move(180,180);
   assert.equal(await page.locator('.lt-track-incoming').getAttribute('src'),await page.evaluate(()=>LT_DEMO_COVERS[1]));assert.equal(await page.locator('#lt-art').getAttribute('src'),before);assert.equal(await page.locator('#lt-np-title').textContent(),'Afterhours');await t.end();
   await page.waitForFunction(()=>!document.querySelector('.lt-track-incoming,.lt-track-outgoing'),null,{timeout:1000});assert.equal(await page.locator('#lt-np-title').textContent(),'Blue Hour');assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='next').length),1);
   t=await touch(page,245,180);await t.move(310,180);assert.equal(await page.locator('.lt-track-incoming').getAttribute('src'),before);await t.end();await page.waitForTimeout(180);assert.equal(await page.locator('#lt-np-title').textContent(),'Afterhours');
   pass('the actual next/previous queued cover follows the finger before playback, commits once on release, and cleans up both image layers',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await player(page);let t=await touch(page,245,180);await t.move(190,180);await t.move(232,180);await t.end();await page.waitForFunction(()=>!document.querySelector('.lt-track-incoming'),null,{timeout:1000});
   assert.equal(await page.locator('#lt-np-title').textContent(),'Afterhours');assert.equal(await page.locator('.lt-track-incoming').count(),0);assert.equal(await page.locator('#lt-art').evaluate(n=>n.style.transform),'');
   t=await touch(page,245,180);await t.move(300,180);await t.cancel();await page.waitForTimeout(170);assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='next'||r[0]==='back').length),0);
   await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);t=await touch(page,280,460);await t.move(180,460);assert.equal(await page.locator('.lt-mini-art-stage .lt-track-incoming').count(),1);await t.end();await page.waitForTimeout(170);assert.equal(await page.locator('#lt-mini-title').textContent(),'Blue Hour');
   pass('reversed/cancelled artwork drags do not play; the mini player also previews and commits the real queued cover',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.evaluate(()=>delete Spicetify.Queue);await player(page);const t=await touch(page,245,180);await t.move(180,180);assert.equal(await page.locator('.lt-track-incoming').count(),0);await t.end();assert.equal(await page.locator('#lt-np-title').textContent(),'Blue Hour');
   pass('missing queue data keeps track swipes functional without inventing an adjacent cover',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{sheetOpacity:0,sheetHeaderOpacity:90});await settings(page);
   const p=await page.evaluate(()=>LiquidTouch.diagnostics().preferences);assert.equal(p.settingsOpacity,0);assert.equal(p.historyOpacity,0);assert.equal(p.sheetHeaderOpacity,undefined);
   const state=await page.locator('#lt-settings .lt-sheet-header').evaluate(n=>({bg:getComputedStyle(n).backgroundColor,top:n.getBoundingClientRect().top}));assert.equal(state.bg,'rgba(0, 0, 0, 0)');assert.equal(await page.locator('[data-pref=sheetHeaderOpacity]').count(),0);
   await revealSetting(page,'opacity');await page.locator('.lt-opacity-options summary').tap();await range(page,'settingsOpacity',100);assert.ok((await page.locator('#lt-settings').evaluate(n=>getComputedStyle(n).backgroundColor)).startsWith('rgb('));
   const subTop=(await page.locator('#lt-settings .lt-sheet-header').boundingBox()).y;await page.locator('.lt-settings-content').evaluate(n=>n.scrollTop=n.scrollHeight);assert.equal((await page.locator('#lt-settings .lt-sheet-header').boundingBox()).y,subTop);
   pass('Settings migrates to one whole-window opacity, with a transparent fixed header and a separate content scroller rather than a second glass layer',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);assert.equal(await page.locator('.Root__main-view').evaluate(n=>getComputedStyle(n).opacity),'0');await settings(page);await revealSetting(page,'opacity');await page.locator('.lt-opacity-options summary').tap();await revealSetting(page,'opacity');await page.locator('[data-opacity-override=navOpacity]').tap();
   for(const [value,filter] of [[0,'none'],[50,'blur(9px) saturate(1.6)'],[100,'none']]){await range(page,'navOpacity',value);const s=await page.locator('.lt-nav').evaluate(n=>({opacity:n.style.getPropertyValue('--lt-surface-opacity'),filter:getComputedStyle(n).backdropFilter}));assert.equal(Number(s.opacity),value/100);assert.equal(s.filter,filter);}
   await range(page,'navOpacity',0);await closeSettings(page);await page.locator('.lt-nav [data-action=search]').tap();await page.waitForTimeout(180);assert.equal(await page.locator('.lt-nav [aria-current]').evaluate(n=>getComputedStyle(n).backgroundImage),'none');assert.equal(await page.locator('.lt-nav').getAttribute('data-lt-clear'),'true');
   pass('navigation opacity changes tint, blur, borders and selection effects at 0/50/100%, including after a tab animation',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.waitForTimeout(160);const start=await page.locator('.lt-nav-selection').evaluate(n=>n.style.transform);let t=await touch(page,620,260);await t.move(580,260);
   const middle=await page.locator('.lt-nav-selection').evaluate(n=>n.style.transform);assert.notEqual(middle,start);assert.equal(await page.locator('.lt-nav [data-action=search]').evaluate(n=>Number(n.style.getPropertyValue('--lt-nav-weight'))),.5);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'home');await t.end();await page.waitForTimeout(170);assert.equal(await page.locator('.lt-nav-selection').evaluate(n=>n.style.transform),start);
   t=await touch(page,620,260);await t.move(500,260);await t.end();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'search');const end=await page.locator('.lt-nav-selection').evaluate(n=>n.style.transform);assert.notEqual(end,start);
   await page.locator('.lt-nav [data-action=library]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');await page.waitForTimeout(140);
   t=await touch(page,600,550);await t.move(720,550);await t.end();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'search');
   pass('the floating selection follows page swipe progress, springs back on cancel, and stays linked for tab taps and navigation-bar swipes',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await player(page);await page.locator('[data-action=artworkSettings]').tap();assert.equal(await page.locator('#lt-artworkSize').isVisible(),true);assert.equal(await page.locator('#lt-artworkSize').getAttribute('min'),'60');assert.equal(await page.locator('#lt-artworkSize').getAttribute('max'),'200');
   await range(page,'artworkSize',60);await closeSettings(page);const small=(await page.locator('#lt-art').boundingBox()).width;await page.locator('[data-action=artworkSettings]').tap();await range(page,'artworkSize',180);await closeSettings(page);await page.waitForTimeout(170);assert.ok((await page.locator('#lt-art').boundingBox()).width>small*1.8);
   pass('the artwork has a direct size button, opens its prominent 60–200% setting and visibly changes the cover',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await noSpotifyLyrics(page);const calls=[];
   await lyricRoutes(page,async(route,url)=>{calls.push(url);if(url.pathname.endsWith('/get'))return json(route,{},404);return json(route,[{trackName:'Afterhours (Live)',artistName:'Solstice',duration:238,syncedLyrics:'[00:01.00]Wrong live version'},{trackName:'Afterhours',artistName:'Different Artist',duration:238,syncedLyrics:'[00:01.00]Wrong artist'},{trackName:'Afterhours',artistName:'Solstice Tribute',duration:238,syncedLyrics:'[00:01.00]Wrong tribute artist'},{trackName:'Afterhours',artistName:'Solstice',duration:400,syncedLyrics:'[00:01.00]Wrong duration'},{trackName:'Afterhours',artistName:'Solstice',albumName:'Original Album',duration:238.5,syncedLyrics:'[00:01.00]An original lookup test line'}]);});
   await page.evaluate(()=>{const item=Spicetify.Player.data.item;__ltMock.setMetadata({...item,name:'Afterhours - 2026 Remaster',artists:[{name:'Solstice'},{name:'Guest'}]});});await player(page);await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsState==='ready');
   assert.equal(await page.locator('.lt-lyric-line').textContent(),'An original lookup test line');assert.equal(calls.length,2);assert.equal(calls[1].searchParams.get('track_name'),'Afterhours');assert.equal(calls[1].searchParams.get('artist_name'),'Solstice');assert.equal(await page.locator('.lt-lyric-line').isDisabled(),false);
   pass('LRCLIB search recovers remasters/guest credits while rejecting different artists, live recordings and incompatible durations',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await noSpotifyLyrics(page);const calls=[];
   await lyricRoutes(page,async(route,url)=>{calls.push(url);return json(route,url.pathname.endsWith('/get') ? {} : [],url.pathname.endsWith('/get') ? 404 : 200);});
   let request;await page.route('https://api.lyrics.ovh/**',async route=>{request=route.request();await json(route,{lyrics:'A fictional text-only line\nAnother fictional line'});});await player(page);await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsState==='ready');
   assert.equal(await page.locator('.lt-lyric-line').count(),2);assert.equal(await page.locator('.lt-lyric-line').first().isDisabled(),true);assert.ok((await page.locator('#lt-lyrics-status').textContent()).toLowerCase().includes('text-only'));assert.equal(request.headers().authorization,undefined);assert.equal(request.headers().cookie,undefined);assert.equal(calls.length,3);
   pass('lyrics.ovh supplies labelled text-only lyrics after both LRCLIB searches miss, without credentials or invented seek times',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{lyricsTextFallback:false});await noSpotifyLyrics(page);let count=0;
   await lyricRoutes(page,async route=>{count++;return json(route,{},429,{'Retry-After':'20'});});await player(page);await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsState==='unavailable');await page.locator('[data-action=lyricsMenu]').tap();await page.locator('[data-action=retryLyrics]').tap();await page.waitForTimeout(400);assert.equal(count,1);
   pass('rate-limited lyric services honor Retry-After across search variants and an immediate Reload',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{lyricsFallback:false});await noSpotifyLyrics(page);let outside=0;await page.route(/https:\/\/(lrclib\.net|api\.lyrics\.ovh)\//,async route=>{outside++;return json(route,{},404);});await player(page);await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsState==='unavailable');assert.equal(outside,0);
   pass('disabling broader lookup prevents all public lyric requests',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);let pending;
   await page.evaluate(()=>{const get=Spicetify.CosmosAsync.get;Spicetify.CosmosAsync.get=async url=>{if(url.includes('color-lyrics') && url.includes('/demo0?'))throw new Error('No first-song lyrics');return get(url);};});
   await lyricRoutes(page,async(route,url)=>{if(url.pathname.endsWith('/get')){pending=route;return;}return json(route,[]);});
   await player(page);await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsState==='loading');for(let i=0;i<30 && !pending;i++)await page.waitForTimeout(20);assert.ok(pending);
   await page.locator('#lt-now-playing [data-action=next]').tap();await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsState==='ready');try{await json(pending,{duration:238,syncedLyrics:'[00:01.00]Obsolete fictional lyric'});}catch{}
   await page.waitForTimeout(150);assert.equal(await page.locator('.lt-lyric-line').count(),5);assert.equal(await page.locator('#lt-np-title').textContent(),'Blue Hour');assert.equal(await page.locator('#lt-lyrics-lines').textContent().then(s=>s.includes('Obsolete')),false);
   pass('a cancelled lookup for the previous song cannot overwrite the new song’s lyrics',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{Object.defineProperty(Spicetify,'Queue',{configurable:true,get:()=>({track:{uri:Spicetify.Player.data.item.uri},nextTracks:[{uri:'spotify:track:demo1'}],prevTracks:[]})});const get=Spicetify.CosmosAsync.get;Spicetify.CosmosAsync.get=async url=>{if(url.includes('/v1/tracks/'))await new Promise(r=>setTimeout(r,600));return get(url);};});
   await player(page);const t=await touch(page,245,180);await t.move(180,180);await page.waitForFunction(()=>{const n=document.querySelector('.lt-track-incoming');return n && !n.hidden;});assert.equal(await page.locator('.lt-track-incoming').getAttribute('src'),await page.evaluate(()=>LT_DEMO_COVERS[1]));assert.equal(await page.locator('#lt-np-title').textContent(),'Afterhours');await t.end();await page.waitForFunction(()=>!document.querySelector('.lt-track-incoming'),null,{timeout:1000});
   pass('URI-only queue entries hydrate missing cover art during the held swipe without starting playback early',errors);await context.close();
  }
  console.log(passed+' release 1.7 suites passed. Spotify, Windows and lyric responses are simulated.');
 }finally{await browser.close();await new Promise(r=>server.close(r));}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
