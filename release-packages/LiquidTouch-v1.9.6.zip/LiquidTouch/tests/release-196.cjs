'use strict';
// Browser contracts against the production runtime in the offline Spotify host.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
const {revealSetting}=require('./settings-navigation.cjs');
const base=path.resolve(__dirname,'..');let origin,passed=0;
async function open(browser,prefs={},viewport={width:1024,height:600},route='/'){
 const context=await browser.newContext({viewport,hasTouch:true}),page=await context.newPage(),errors=[];
 page.setDefaultTimeout(12000);page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(({p,seen})=>{
  if(!localStorage.getItem('liquid-touch.preferences.v1'))localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,updateChecks:false,reduceMotion:true,lyricsFallback:false,lyricsPolicy:2,...p}));
  localStorage.setItem('liquid-touch.seen-release',seen);
 },{p:prefs,seen:route==='/old' ? '1.9.5' : '1.9.6'});
 await page.goto(origin+route);await page.waitForFunction(()=>window.LiquidTouch?.diagnostics().phase==='mounted');
 await page.waitForFunction(()=>LiquidTouch.diagnostics().historyStorage!=='loading');
 return {page,context,errors};
}
async function player(page){await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');}
async function settings(page,key){await page.locator('#lt-shell .lt-header [data-action=settings]').tap();if(key)await revealSetting(page,key);}
async function swipe(page,x,y,dx,dy){
 const cdp=await page.context().newCDPSession(page);
 await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y,id:1}]});
 for(let i=1;i<=5;i++)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x+dx*i/5,y:y+dy*i/5,id:1}]});
 await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await cdp.detach();await page.waitForTimeout(200);
}
function pass(name,errors){assert.deepEqual(errors,[]);console.log('PASS '+name);passed++;}
async function deferredLyrics(page){await page.evaluate(()=>{
 const get=Spicetify.CosmosAsync.get;window.lyricJobs=[];
 Spicetify.CosmosAsync.get=url=>url.includes('color-lyrics') ? new Promise((resolve,reject)=>lyricJobs.push({url,resolve,reject})) : get(url);
 window.lyricResult=text=>({lyrics:{syncType:'LINE_SYNCED',lines:[{startTimeMs:'0',words:text}]}});
});}
(async()=>{
 const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end(fs.readFileSync(req.url==='/old' ? process.env.LT_OLD_PREVIEW : path.join(base,'LiquidTouch-Preview.html')));});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  {
   const {page,context,errors}=await open(browser,{lyrics:true});await deferredLyrics(page);await player(page);
   assert.equal(await page.locator('#lt-now-playing').getAttribute('data-lyrics'),'false');
   await page.waitForFunction(()=>lyricJobs.length===1);await page.evaluate(()=>lyricJobs[0].resolve(lyricResult('Current song lyrics')));
   await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsVisible);assert.ok((await page.locator('#lt-lyrics-lines').innerText()).includes('Current song lyrics'));
   await page.evaluate(()=>__ltMock.choose(1));assert.equal(await page.locator('#lt-now-playing').getAttribute('data-lyrics'),'false');
   await page.waitForFunction(()=>lyricJobs.length===2);await page.evaluate(()=>__ltMock.choose(2));await page.waitForFunction(()=>lyricJobs.length===3);
   await page.evaluate(()=>lyricJobs[1].resolve(lyricResult('Stale song lyrics')));await page.waitForTimeout(80);
   assert.equal(await page.locator('#lt-now-playing').getAttribute('data-lyrics'),'false');assert.ok(!(await page.locator('#lt-lyrics-lines').textContent()).includes('Stale'));
   await page.evaluate(()=>lyricJobs[2].reject(Error('Unavailable')));await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsState==='unavailable');
   assert.equal(await page.locator('#lt-now-playing').getAttribute('data-lyrics'),'false');
   await page.locator('#lt-now-playing [data-action=toggleLyrics]').tap();assert.equal(await page.locator('#lt-now-playing').getAttribute('data-lyrics'),'true');
   assert.ok((await page.locator('#lt-lyrics-status').innerText()).includes('No lyrics found'));
   await page.evaluate(()=>__ltMock.choose(3));assert.equal(await page.locator('#lt-now-playing').getAttribute('data-lyrics'),'false');
   pass('lyrics stay hidden while loading/unavailable; only current-song results auto-open; manual empty panel is per-song',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{lyrics:true});await deferredLyrics(page);await player(page);
   await page.locator('#lt-now-playing [data-action=toggleLyrics]').tap();await page.locator('#lt-now-playing [data-action=toggleLyrics]').tap();
   await page.evaluate(()=>lyricJobs[0].resolve(lyricResult('Do not reopen')));await page.waitForTimeout(100);
   assert.equal(await page.locator('#lt-now-playing').getAttribute('data-lyrics'),'false');
   assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('liquid-touch.preferences.v1')).lyrics),true);
   await page.evaluate(()=>__ltMock.choose(1));await page.waitForFunction(()=>lyricJobs.length>=2);
   await page.evaluate(()=>lyricJobs.at(-1).resolve(lyricResult('New song auto lyrics')));await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsVisible);
   pass('manual Off survives late results for that song without disabling automatic lyrics on the next song',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{lyrics:false});await player(page);assert.equal(await page.locator('#lt-now-playing').getAttribute('data-lyrics'),'false');
   await page.locator('#lt-now-playing [data-action=toggleLyrics]').tap();await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsState==='ready');
   assert.equal(await page.locator('#lt-now-playing').getAttribute('data-lyrics'),'true');await page.evaluate(()=>__ltMock.choose(1));
   assert.equal(await page.locator('#lt-now-playing').getAttribute('data-lyrics'),'false');
   pass('manual lyrics lookup works when automatic lyrics are disabled; the override resets on the next song',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{lyrics:false,lyricsPolicy:null});await deferredLyrics(page);await player(page);
   assert.equal(await page.locator('#lt-now-playing').getAttribute('data-lyrics'),'false');await page.waitForFunction(()=>lyricJobs.length===1);
   await page.evaluate(()=>lyricJobs[0].resolve(lyricResult('Migrated availability policy')));await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsVisible);
   pass('legacy global Lyrics Off migrates to availability-based lyrics; new explicit auto-Off remains supported',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{cardTapDelay:400,rounding:32,quickSearchBlur:14,backThreshold:80,textScale:130,uiScale:120});
   await settings(page,'touch');
   const sliders=await page.locator('#lt-settings input[type=range]').evaluateAll(nodes=>nodes.map(n=>({id:n.id,min:+n.min,max:+n.max,step:+n.step,value:+n.value,text:document.getElementById(n.id+'-value').textContent})));
   assert.ok(sliders.length>40);for(const n of sliders){assert.equal(n.step,5,n.id);assert.equal(n.min%5,0,n.id);assert.equal(n.max%5,0,n.id);assert.equal(n.value%5,0,n.id);assert.ok(n.text.endsWith('%'),JSON.stringify(n));}
   await page.locator('[data-adjust=cardTapDelay][data-delta="5"]').tap();assert.equal(await page.locator('#lt-cardTapDelay-value').innerText(),'105%');
   assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().preferences.cardTapDelay),420);
   await revealSetting(page,'gestures');await page.locator('[data-adjust=backThreshold][data-delta="5"]').tap();
   assert.equal(await page.locator('#lt-backThreshold-value').innerText(),'105%');assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().preferences.backThreshold),84);
   await revealSetting(page,'appearance');await page.locator('[data-adjust=rounding][data-delta="5"]').tap();assert.equal(await page.locator('#lt-rounding-value').innerText(),'105%');
   assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().preferences.rounding),33.6);
   assert.equal(await page.locator('#lt-quickSearchBlur-value').innerText(),'70%');
   await page.reload();await page.waitForFunction(()=>LiquidTouch?.diagnostics().phase==='mounted');
   const saved=await page.evaluate(()=>LiquidTouch.diagnostics().preferences);assert.equal(saved.cardTapDelay,420);assert.equal(saved.rounding,33.6);assert.equal(saved.backThreshold,84);assert.equal(saved.textScale,130);
   pass('every settings slider uses 5% steps, converts real units correctly, and preserves migrated/saved preferences',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.waitForFunction(()=>LiquidTouch.diagnostics().libraryItems>=100);
   await page.evaluate(()=>__ltMock.choose(2,'spotify:playlist:demo-2'));
   await page.waitForSelector('#lt-browse .lt-card-section:has(h2:text("Recently played")) [data-lt-card="spotify:playlist:demo-2"]');
   const section=page.locator('#lt-browse .lt-card-section').filter({has:page.locator('h2',{hasText:'Recently played'})});
   assert.equal(await section.locator('[data-lt-card]').first().getAttribute('data-lt-card'),'spotify:playlist:demo-2');
   await page.evaluate(()=>__ltMock.setMetadata({uri:'spotify:track:external',name:'External playback',album:{uri:'spotify:album:external',name:'Latest album'},artists:[{uri:'spotify:artist:external',name:'Latest artist'}]}));
   await page.waitForSelector('#lt-browse [data-lt-card="spotify:album:external"]');assert.equal(await section.locator('[data-lt-card="spotify:artist:external"]').count(),1);
   await page.evaluate(()=>__ltMock.choose(1,'spotify:playlist:demo-1'));await page.waitForFunction(()=>document.querySelector('#lt-browse .lt-card-section [data-lt-card]')?.dataset.ltCard==='spotify:playlist:demo-1');
   assert.equal(await section.locator('[data-lt-card="spotify:playlist:demo-2"]').count(),1);
   const before=await page.evaluate(()=>JSON.parse(localStorage.getItem('liquid-touch.home-recent.v1:demo') || '[]'));
   assert.ok(before.length<=12);assert.ok(before.some(r=>r.uri==='spotify:album:external'));
   pass('Home updates most-recent-first playlists/albums/artists during playback without navigating or duplicating cards',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.waitForSelector('#lt-browse [data-lt-card="spotify:album:demo-1"]');
   await page.evaluate(()=>{const grid=document.querySelector('#fixture-content .fixture-grid');grid.prepend(grid.lastElementChild);grid.querySelector('[data-uri="spotify:album:demo-1"]').remove();});
   await page.waitForFunction(()=>[...document.querySelectorAll('#lt-browse .lt-card-section')].find(n=>n.querySelector('h2')?.textContent==='Jump back in')?.querySelector('[data-lt-card]')?.dataset.ltCard==='spotify:album:demo-5');
   assert.equal(await page.locator('#lt-browse [data-lt-card="spotify:album:demo-1"]').count(),0);
   pass('native Home refreshes reordered recommendations and removes replaced cards instead of accumulating stale snapshots',errors);await context.close();
  }
  for(const lowMemory of [false,true]){
   const {page,context,errors}=await open(browser,{lowMemory,lyrics:false,reduceMotion:false});
   await page.waitForTimeout(120);await swipe(page,700,300,-160,0);await page.waitForFunction(()=>document.body.dataset.ltPage==='search');
   await swipe(page,700,300,-160,0);await page.waitForFunction(()=>document.body.dataset.ltPage==='library');
   await swipe(page,450,300,160,0);await page.waitForFunction(()=>document.body.dataset.ltPage==='search');
   await swipe(page,10,300,160,0);await page.waitForFunction(()=>document.body.dataset.ltPage==='library');
   await player(page);const before=await page.evaluate(()=>__ltMock.log.filter(x=>x[0]==='next').length);
   const titleRect=await page.locator('#lt-np-title').boundingBox();await swipe(page,titleRect.x+titleRect.width*.8,titleRect.y+titleRect.height/2,-160,0);assert.equal(await page.evaluate(()=>__ltMock.log.filter(x=>x[0]==='next').length),before+1);
   assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);
   await swipe(page,10,200,160,0);await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);
   await settings(page,'appearance');await swipe(page,220,250,160,0);await page.waitForFunction(()=>!document.querySelector('#lt-settings-categories').hidden);
   await swipe(page,220,250,160,0);await page.waitForFunction(()=>!document.querySelector('#lt-settings').open);
   pass('trusted touch tabs, edge Back, player track swipe and Settings Back share behavior in '+(lowMemory?'Low-RAM':'normal')+' mode',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{lowMemory:true});await page.waitForFunction(()=>LiquidTouch.diagnostics().libraryItems>=100);
   await page.locator('.lt-nav [data-action=library]').tap();let cards=await page.locator('#lt-browse .lt-card').count();assert.equal(cards,24);
   await page.locator('#lt-browse [data-grid-more]').tap();assert.equal(await page.locator('#lt-browse .lt-card').count(),48);
   await page.evaluate(()=>{window.countMotions=0;const a=Element.prototype.animate;Element.prototype.animate=function(...args){countMotions++;return a.apply(this,args);};});
   await player(page);await page.waitForTimeout(250);
   const d=await page.evaluate(()=>LiquidTouch.diagnostics()),startPaint=d.playerPaints;
   await page.evaluate(()=>{for(let i=0;i<20;i++)__ltMock.emit('onplaypause');});
   assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().playerPaints),startPaint);assert.equal(await page.evaluate(()=>countMotions),0);
   assert.equal(await page.locator('#lt-player-background').getAttribute('src'),null);
   assert.equal(await page.locator('#lt-now-playing').evaluate(n=>getComputedStyle(n).backdropFilter),'none');
   await page.locator('#lt-now-playing [data-action=togglePlay]').tap();assert.ok((await page.locator('#lt-now-playing [data-action=togglePlay]').getAttribute('aria-label')).includes('Play'));
   pass('Low-RAM renders 24 cards at a time, Show more remains usable, skips unchanged player paints and retains immediate playback controls',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,{lyrics:false,textScale:130,uiScale:120});await player(page);
   assert.equal(await page.locator('.lt-art-size-button,[data-action=artworkSettings]').count(),0);
   const r=await page.evaluate(()=>{const a=document.querySelector('.lt-art-frame').getBoundingClientRect(),c=document.querySelector('.lt-np-controls').getBoundingClientRect();return {a:a.y+a.height/2,c:c.y+c.height/2};});assert.ok(Math.abs(r.a-r.c)<4,JSON.stringify(r));
   await page.screenshot({path:path.resolve(base,'../qa/v196-player.png')});await page.locator('#lt-now-playing [data-action=closePlayer]').tap();
   await settings(page,'player');assert.equal(await page.locator('#lt-artworkSize').isVisible(),true);
   pass('artwork shortcut is removed, the centered player remains correct at 130%/120%, and artwork sizing stays in Settings',errors);await context.close();
  }
  for(const lowMemory of [false,true]){
   const {page,context,errors}=await open(browser,{lowMemory,lyrics:false});
   await page.locator('#lt-browse').evaluate(n=>n.scrollTop=0);await swipe(page,800,330,0,120);
   await page.waitForFunction(()=>document.body.dataset.ltQuick==='true');
   await swipe(page,800,350,0,-120);await page.waitForFunction(()=>document.body.dataset.ltQuick!=='true');
   await settings(page,'help');await page.locator('#lt-settings [data-action=playHistory]').tap();
   await page.locator('#lt-history-list').evaluate(n=>n.scrollTop=0);const r=await page.locator('#lt-history-list').boundingBox();
   await swipe(page,r.x+r.width*.7,r.y+15,0,120);await page.waitForFunction(()=>!document.querySelector('#lt-history').open);
   await page.locator('.lt-nav [data-action=library]').tap();await page.waitForFunction(()=>LiquidTouch.diagnostics().libraryItems>=100);
   await page.locator('#lt-browse').evaluate(n=>n.scrollTop=180);await swipe(page,800,260,0,100);
   assert.equal(await page.evaluate(()=>document.body.dataset.ltQuick==='true'),false);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');
   pass('pull gestures work below the toolbar and inside sheets while scrolled lists retain vertical scrolling in '+(lowMemory?'Low-RAM':'normal')+' mode',errors);await context.close();
  }
  if(process.env.LT_OLD_PREVIEW){
   const {page,context,errors}=await open(browser,{lyrics:false,lyricsPolicy:null,textScale:130,uiScale:120,cardTapDelay:425},{width:1024,height:600},'/old');
   assert.equal(await page.evaluate(()=>LiquidTouch.version),'1.9.5');await page.evaluate(()=>__ltMock.choose(2));
   await settings(page,'updates');await page.locator('#lt-update-file').setInputFiles(path.join(base,'LiquidTouch-Update-v1.9.6.json'));
   await page.waitForFunction(()=>document.querySelector('#lt-release').open);await page.locator('#lt-release [data-action=confirmUpdate]').tap();
   await page.waitForFunction(()=>LiquidTouch.version==='1.9.6' && LiquidTouch.diagnostics().phase==='mounted');
   await page.waitForFunction(()=>LiquidTouch.diagnostics().historyStorage!=='loading');
   const d=await page.evaluate(()=>LiquidTouch.diagnostics());assert.equal(d.preferences.textScale,130);assert.equal(d.preferences.uiScale,120);assert.equal(d.preferences.cardTapDelay,420);assert.equal(d.preferences.lyrics,true);assert.ok(d.historyItems>0);
   assert.equal(await page.locator('#lt-shell').count(),1);assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('liquid-touch.runtime.v1')).version),'1.9.6');
   await page.reload();await page.waitForFunction(()=>LiquidTouch.version==='1.9.6' && LiquidTouch.diagnostics().phase==='mounted');
   assert.equal(await page.locator('#lt-shell').count(),1);
   pass('the actual v1.9.6 runtime installs over revised v1.9.5, migrates settings, preserves listening history and survives reload',errors);await context.close();
  }
  console.log(passed+' v1.9.6 browser suites passed.');
 }finally{await browser.close();await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e);process.exitCode=1;});
