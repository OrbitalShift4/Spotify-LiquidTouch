"""Run the real .ps1 scripts against a fake CLI using PowerShell 7.
   Set LT_PWSH to the executable path. Windows COM/autostart needs Windows QA.
"""
import importlib.util
import os
from pathlib import Path
import subprocess
import unittest

source = Path(__file__).with_name("test_installer.py")
spec = importlib.util.spec_from_file_location("installer_tests", source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


@unittest.skipUnless(os.environ.get("LT_PWSH"), "Set LT_PWSH to PowerShell 7")
class PowerShellInstallerTests(module.InstallerTests):
    def run_action(self, action, apply=False):
        script = module.BASE / ("Install-Windows.ps1" if action == "install" else "Uninstall-Windows.ps1")
        command = [os.environ["LT_PWSH"], "-NoLogo", "-NoProfile", "-File", str(script)]
        if not apply:
            command.append("-NoApply")
        run = subprocess.run(command, env=self.env, capture_output=True, text=True)
        if run.returncode:
            self.fail(run.stdout + run.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
