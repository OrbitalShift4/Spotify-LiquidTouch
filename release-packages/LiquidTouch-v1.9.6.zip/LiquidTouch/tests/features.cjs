// Regressions for the live metadata issue and the requested 1.1.0 interaction changes.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const http=require('node:http');let previewURL;
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
const base=path.resolve(__dirname,'..');
const source=fs.readFileSync(path.join(base,'Extensions/liquid-touch.js'),'utf8');
let suites=0;
async function pageFor(browser,width=1024,height=600){
  const context=await browser.newContext({viewport:{width,height},hasTouch:true,reducedMotion:'reduce'});
  const page=await context.newPage();await page.addInitScript(()=>localStorage.getItem('liquid-touch.preferences.v1') || localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({playerFullscreen:false})));const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(previewURL);
  await page.waitForFunction(()=>LiquidTouch.diagnostics?.().enabled && LiquidTouch.diagnostics().windowControls==='custom');
  return{context,page,errors};
}
function pass(label,errors){assert.deepEqual(errors,[]);suites++;console.log('PASS '+label);}
async function setRange(page,id,value){await page.locator('#'+id).evaluate((node,v)=>{node.value=String(v);node.dispatchEvent(new Event('input',{bubbles:true}));},value);}
async function noHeaderOverlap(page,dialog=false){
  const root=dialog?'#lt-now-playing':'#lt-shell';
  const setting=await page.locator(root+(dialog?' [data-action="playerSettings"]':' .lt-header [data-action="settings"]')).boundingBox();
  const caption=await page.locator(root+' .lt-caption-buttons').boundingBox();
  assert.ok(setting&&caption);
  assert.ok(setting.x+setting.width<=caption.x || setting.y>=caption.y+caption.height, 'Settings must be clear of native-window control area');
}
async function run(){
  const html=fs.readFileSync(path.join(base,'LiquidTouch-Preview.html'));const server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(html);});await new Promise(r=>server.listen(0,'127.0.0.1',r));previewURL='http://127.0.0.1:'+server.address().port;
  const browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox'],headless:true});
  try{
    {
      const{page,context,errors}=await pageFor(browser);
      await page.evaluate(()=>__ltMock.setWrapperMissing(true));
      await page.locator('#lt-mini-open').click();
      assert.equal(await page.locator('#lt-np-title').textContent(),'Afterhours');
      assert.equal(await page.locator('#lt-np-artist').textContent(),'Solstice');
      assert.equal(await page.locator('#lt-art').isVisible(),true);
      assert.equal(await page.locator('#lt-now-playing [data-action="next"]').isEnabled(),true);
      await page.locator('#lt-now-playing [data-action="next"]').click();
      assert.equal(await page.locator('#lt-np-title').textContent(),'Blue Hour');
      assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().stateSource),'origin');
      pass('live player state supplies artwork, metadata, and controls when Player.data is missing',errors);
      await context.close();
    }
    {
      const{page,context,errors}=await pageFor(browser);
      await page.evaluate(()=>{
        const old=Spicetify.Player.data;Spicetify.Player.origin=undefined;
        Object.defineProperty(Spicetify.Player,'data',{configurable:true,get:()=>({track:old.item,duration:old.duration})});
        __ltMock.emit('songchange');
      });
      assert.equal(await page.locator('#lt-mini-title').textContent(),'Afterhours');
      await page.evaluate(()=>{
        Object.defineProperty(Spicetify.Player,'data',{configurable:true,get:()=>null});
        const region=document.querySelector('.Root__now-playing-bar');
        const title=document.createElement('a');title.dataset.testid='context-item-info-title';title.href='/track/native';title.textContent='Native player fallback';region.append(title);
        const image=document.createElement('img');image.dataset.testid='cover-art-image';image.src=LT_DEMO_COVERS[1];region.append(image);
        __ltMock.emit('songchange');
      });
      assert.equal(await page.locator('#lt-mini-title').textContent(),'Native player fallback');
      assert.equal(await page.locator('#lt-mini-art').isVisible(),true);
      pass('legacy track state and native player metadata fallback',errors);
      await context.close();
    }
    {
      const{page,context,errors}=await pageFor(browser);
      await page.evaluate(()=>{
        const snapshot=Spicetify.Player.data;
        Spicetify.Player.origin=undefined;Object.defineProperty(Spicetify.Player,'data',{configurable:true,get:()=>null});
        Spicetify.Platform.PlayerAPI={getState:async()=>snapshot};
      });
      await page.waitForFunction(()=>LiquidTouch.diagnostics().stateSource==='platform-getState');
      assert.equal(await page.locator('#lt-mini-title').textContent(),'Afterhours');
      pass('asynchronous platform state fallback',errors);
      await context.close();
    }
    {
      const{page,context,errors}=await pageFor(browser);
      await page.waitForFunction(()=>document.body.style.getPropertyValue('--lt-art-rgb').includes('70'));
      const before=await page.locator('body').evaluate(n=>n.style.getPropertyValue('--lt-bg'));
      await page.evaluate(()=>__ltMock.choose(1));
      await page.waitForFunction(()=>document.body.style.getPropertyValue('--lt-art-rgb')==='31, 98, 108');
      assert.notEqual(await page.locator('body').evaluate(n=>n.style.getPropertyValue('--lt-bg')),before);
      await page.locator('#lt-shell .lt-header [data-action="settings"]').click();
      await page.locator('#lt-settings [data-pref="lite"]').click();
      assert.equal(await page.locator('.lt-mini').evaluate(n=>getComputedStyle(n).backgroundColor.includes('0.35')),true);
      await page.locator('#lt-settings [data-action="closeSettings"]').click();
      await page.evaluate(()=>{Spicetify.colorExtractor=async()=>{throw new Error('Extractor unavailable');};__ltMock.choose(3);});
      await page.waitForFunction(()=>document.body.style.getPropertyValue('--lt-art-rgb')!=='31, 98, 108');
      pass('artwork atmosphere updates across tracks and samples pixels if extractor fails, including low-blur mode',errors);
      await context.close();
    }
    {
      const{page,context,errors}=await pageFor(browser);
      const album=page.locator('#lt-browse [data-lt-card="spotify:album:demo-1"]');
      await album.tap();
      assert.equal(await page.evaluate(()=>Spicetify.Platform.History.location.pathname),'/');
      await page.waitForFunction(()=>!LiquidTouch.diagnostics().cardTapPending);
      assert.equal(await page.locator('#lt-mini-title').textContent(),'Blue Hour');
      const plays=await page.evaluate(()=>__ltMock.log.filter(n=>n[0]==='playUri').length);
      await album.tap();await album.tap();
      assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().route),'/album/demo-1');
      assert.equal(await page.evaluate(()=>__ltMock.log.filter(n=>n[0]==='playUri').length),plays);
      await page.locator('#lt-shell [data-action="library"]').click();
      const playlist=page.locator('#lt-browse [data-lt-card="spotify:playlist:demo-4"]');
      await playlist.tap();await page.waitForFunction(()=>!LiquidTouch.diagnostics().cardTapPending);
      assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');
      assert.equal(await page.locator('#lt-mini-title').textContent(),'Night Drive');
      await playlist.tap();await playlist.tap();
      assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().route),'/playlist/demo-4');
      pass('first touch plays albums/playlists, second touch opens without starting playback again',errors);
      await context.close();
    }
    {
      const{page,context,errors}=await pageFor(browser);
      const card=page.locator('#lt-browse [data-lt-card="spotify:playlist:demo-2"]');
      await card.dispatchEvent('pointerdown',{pointerType:'touch',pointerId:9,clientX:500,clientY:350,button:0});
      await card.dispatchEvent('pointerup',{pointerType:'touch',pointerId:9,clientX:500,clientY:430,button:0});
      assert.equal(await page.evaluate(()=>__ltMock.log.some(n=>n[0]==='playUri')),false);
      await card.focus();await page.keyboard.press('Enter');
      assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().route),'/playlist/demo-2');
      pass('card scrolling does not start music, and keyboard activation opens the item directly',errors);
      await context.close();
    }
    for(const [width,height]of[[800,480],[480,800],[1920,1080]]){
      const{page,context,errors}=await pageFor(browser,width,height);
      await noHeaderOverlap(page);
      const fontBefore=await page.locator('#lt-mini-title').evaluate(n=>parseFloat(getComputedStyle(n).fontSize));
      await page.locator('#lt-shell .lt-header [data-action="settings"]').click();
      await setRange(page,'lt-textScale',200);await setRange(page,'lt-uiScale',140);await setRange(page,'lt-glassOpacity',20);
      assert.equal(await page.locator('#lt-textScale-value').textContent(),'200%');
      await page.keyboard.press('Escape');
      const fontAfter=await page.locator('#lt-mini-title').evaluate(n=>parseFloat(getComputedStyle(n).fontSize));
      assert.ok(fontAfter>fontBefore*1.5);
      await noHeaderOverlap(page);
      const content=await page.locator('[data-lt-native="main"]').boundingBox();const mini=await page.locator('.lt-mini').boundingBox();
      assert.ok(content.y+content.height<=mini.y+1,'Expanded footer cannot cover native content');
      assert.ok(content.height>30,'Content remains scrollable');
      assert.equal(await page.locator('.lt-mini').evaluate(n=>getComputedStyle(n).backgroundColor.includes('0.2')),true);
      await page.locator('#lt-mini-open').click();await noHeaderOverlap(page,true);
      const queue=page.locator('#lt-now-playing [data-action="queue"]');
      await queue.scrollIntoViewIfNeeded();
      const qr=await queue.boundingBox();assert.ok(qr.y>=0&&qr.y+qr.height<=height+1,'Bottom actions remain reachable at large scale');
      await page.reload();await page.waitForFunction(()=>LiquidTouch.diagnostics?.().enabled);
      const prefs=await page.evaluate(()=>LiquidTouch.diagnostics().preferences);
      assert.equal(prefs.textScale,200);assert.equal(prefs.uiScale,140);assert.equal(prefs.glassOpacity,20);
      pass(`200% type, 140% controls, 20% opacity, layout separation and persistence: ${width}×${height}`,errors);
      await context.close();
    }
    {
      const{page,context,errors}=await pageFor(browser);
      assert.equal(await page.locator('#fixture-native-chrome').isVisible(),false);
      await page.locator('#lt-shell [data-action="windowMaximize"]').click();
      await page.locator('#lt-shell [data-action="windowMaximize"]').click();
      await page.locator('#lt-shell [data-action="windowMinimize"]').click();
      await page.locator('#lt-shell [data-action="windowClose"]').click();
      assert.deepEqual(await page.evaluate(()=>__ltMock.log.filter(n=>n[0]==='windowState').map(n=>n[1])),[2,1,3]);
      assert.equal(await page.evaluate(()=>__ltMock.log.some(n=>n[0]==='closeWindow')),true);
      await page.evaluate(()=>__ltMock.failWindowActions(true));
      await page.locator('#lt-shell [data-action="windowMinimize"]').click();
      await page.waitForFunction(()=>LiquidTouch.diagnostics().windowControls==='native');
      assert.equal(await page.locator('#fixture-native-chrome').isVisible(),true);
      const header=await page.locator('.lt-header').boundingBox();assert.ok(header.y>=64,'Native controls fallback must reserve native hit-test region');
      pass('glass window buttons call desktop bridge and safely restore native controls if it rejects',errors);
      await context.close();
    }
    console.log(`${suites} new feature suites passed. Physical Spotify integration still requires a client check.`);
  }finally{await browser.close();await new Promise(r=>server.close(r));}
}
run().catch(error=>{console.error(error);process.exitCode=1;});
