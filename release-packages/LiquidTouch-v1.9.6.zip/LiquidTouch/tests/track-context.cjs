'use strict';
// Real Chromium, complete production extension, simulated Spotify services.
// No live account or public write. LT_CHROME may override the local executable.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
const base=path.resolve(__dirname,'..');let passed=0,origin;
async function host(browser,prefs={},old=false){
 const context=await browser.newContext({viewport:{width:1024,height:600},hasTouch:true}),page=await context.newPage(),errors=[];
 page.setDefaultTimeout(6000);page.on('pageerror',e=>errors.push(e.message));
 await context.route('**/*',route=>route.request().url().startsWith(origin)?route.continue():route.abort());
 await page.addInitScript(p=>{
  if(!localStorage.getItem('liquid-touch.preferences.v1'))localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,updateChecks:false,reduceMotion:true,lyricsFallback:false,lyricsTextFallback:false,lyricsPolicy:2,...p}));
  localStorage.setItem('liquid-touch.seen-release','1.9.6');
 },prefs);
 await page.goto(origin+(old?'/previous.html':'/LiquidTouch-Preview.html'));
 await page.waitForFunction(()=>window.LiquidTouch?.diagnostics().phase==='mounted');
 await page.evaluate(()=>{
  window.__lyricCalls=[];window.__pendingLyrics={};window.__response=id=>({lyrics:{syncType:'LINE_SYNCED',providerDisplayName:'Regression service',lines:[{words:'Lyrics for '+id,startTimeMs:'0'},{words:'Next line for '+id,startTimeMs:'1000'}]}});
  const get=Spicetify.CosmosAsync.get;
  Spicetify.CosmosAsync.get=async url=>{
   if(url.includes('color-lyrics')){
    const id=url.match(/\/track\/([^?]+)/)[1];__lyricCalls.push(id);
    if(window.__deferred?.includes(id))return new Promise(resolve=>__pendingLyrics[id]=resolve);
    if(window.__missing?.includes(id))throw Error('Unavailable');
    return __response(id);
   }
   return get(url);
  };
 });
 return {page,context,errors,async player(){await page.click('#lt-mini-open');await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');},async end(){assert.deepEqual(errors,[]);await context.close();}};
}
async function test(name,work){await work();passed++;console.log('PASS '+name);}
const atEnd=page=>page.evaluate(()=>__ltMock.setPosition(Spicetify.Player.getDuration()-10000));
const ready=page=>page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsPrefetchState==='ready');

const {contextService}=require('./helpers/track-tap-service.cjs');

(async()=>{
 const server=http.createServer((req,res)=>{
  const file=req.url==='/previous.html'?process.env.LT_PREVIOUS_PREVIEW:path.join(base,decodeURIComponent(req.url.split('?')[0]));
  try{res.setHeader('Content-Type','text/html');res.end(fs.readFileSync(file));}catch{res.statusCode=404;res.end();}
 });await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true,executablePath:process.env.LT_CHROME,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
 if(process.env.LT_PREVIOUS_PREVIEW)await test('v1.9.7 reproduces the tap failure when Web playback acknowledges without playing',async()=>{
  const h=await host(browser,{},true),p=h.page;await contextService(p,'playlist',[4,1,5,2]);await p.tap('[data-detail-track="1"]');
  await p.waitForFunction(()=>__webRequests.length===1);assert.equal(await p.evaluate(()=>Spicetify.Player.data.item.uri),'spotify:track:demo0');assert.equal(await p.evaluate(()=>__nativeRequests.length),0);await h.end();
 });
 for(const kind of ['playlist','album'])await test('a trusted '+kind+' row tap starts the native context at that song and Next follows its order',async()=>{
  const h=await host(browser),p=h.page;await contextService(p,kind,[4,1,5,2,0,3],{webMode:'hang'});await p.tap('[data-detail-track="1"]');
  await p.waitForFunction(()=>LiquidTouch.diagnostics().trackPlayback?.stage==='playing');assert.equal(await p.evaluate(()=>Spicetify.Player.data.item.uri),'spotify:track:demo1');
  const native=await p.evaluate(()=>__nativeRequests);assert.equal(native.length,1);assert.deepEqual(native[0].target,{uri:'spotify:'+kind+':selected'});assert.deepEqual(native[0].options.skipTo,{uri:'spotify:track:demo1',uid:'row-1'});assert.equal(await p.evaluate(()=>__webRequests.length),0);
  await p.evaluate(()=>Spicetify.Player.next());assert.equal(await p.evaluate(()=>Spicetify.Player.data.item.uri),'spotify:track:demo5');assert.equal(await p.evaluate(()=>Spicetify.Player.data.context.uri),'spotify:'+kind+':selected');await h.end();
 });
 await test('playlist duplicate recordings keep the tapped occurrence through its UID',async()=>{
  const h=await host(browser),p=h.page;await contextService(p,'playlist',[4,null,1,1,5]);await p.tap('[data-detail-track="2"]');await p.waitForFunction(()=>LiquidTouch.diagnostics().trackPlayback?.stage==='playing');
  assert.equal(await p.evaluate(()=>__position),3);assert.equal(await p.evaluate(()=>__nativeRequests[0].options.skipTo.uid),'row-3');await p.evaluate(()=>Spicetify.Player.next());assert.equal(await p.evaluate(()=>Spicetify.Player.data.item.uri),'spotify:track:demo5');await h.end();
 });
 await test('a native request with a delayed player event waits for the selected song',async()=>{
  const h=await host(browser),p=h.page;await contextService(p,'album',[4,1,5],{nativeMode:'delayed'});await p.tap('[data-detail-track="2"]');await p.waitForFunction(()=>LiquidTouch.diagnostics().trackPlayback?.stage==='playing');assert.equal(await p.evaluate(()=>Spicetify.Player.data.item.uri),'spotify:track:demo5');assert.equal(await p.evaluate(()=>__webRequests.length),0);await h.end();
 });
 await test('a rejected native call falls back to the complete Web context with its source index',async()=>{
  const h=await host(browser),p=h.page;await contextService(p,'playlist',[4,null,1,1,5],{nativeMode:'reject',webMode:'play'});await p.tap('[data-detail-track="2"]');await p.waitForFunction(()=>LiquidTouch.diagnostics().trackPlayback?.stage==='playing');
  assert.deepEqual(await p.evaluate(()=>__webRequests[0].body),{context_uri:'spotify:playlist:selected',offset:{position:3},position_ms:0});await p.evaluate(()=>Spicetify.Player.next());assert.equal(await p.evaluate(()=>Spicetify.Player.data.item.uri),'spotify:track:demo5');await h.end();
 });
 await test('a native no-op is not considered success and recovers through Web playback',async()=>{
  const h=await host(browser),p=h.page;await contextService(p,'album',[4,1,5],{nativeMode:'noop',webMode:'play'});await p.tap('[data-detail-track="1"]');await p.waitForFunction(()=>LiquidTouch.diagnostics().trackPlayback?.stage==='playing');assert.equal(await p.evaluate(()=>__webRequests.length),1);assert.equal(await p.evaluate(()=>Spicetify.Player.data.item.uri),'spotify:track:demo1');await h.end();
 });
 await test('acknowledged requests without playback produce a visible failure instead of false success',async()=>{
  const h=await host(browser),p=h.page;await contextService(p,'playlist',[4,1,5],{nativeMode:'noop',webMode:'noop'});await p.tap('[data-detail-track="1"]');await p.waitForFunction(()=>LiquidTouch.diagnostics().trackPlayback?.stage==='failed');assert.equal(await p.evaluate(()=>Spicetify.Player.data.item.uri),'spotify:track:demo0');assert.equal(await p.locator('#lt-toast').isVisible(),true);await h.end();
 });
 await test('repeat-one adjustment never blocks the track tap even when its API rejects',async()=>{
  const h=await host(browser),p=h.page;await contextService(p,'playlist',[4,1,5],{repeat:2,repeatFailure:true});await p.tap('[data-detail-track="1"]');await p.waitForFunction(()=>LiquidTouch.diagnostics().trackPlayback?.stage==='playing-repeat-unchanged');assert.equal(await p.evaluate(()=>Spicetify.Player.data.item.uri),'spotify:track:demo1');assert.equal(await p.evaluate(()=>__webRequests.length),0);await h.end();
 });
 await test('a newer row tap cancels the older request fallback',async()=>{
  const h=await host(browser),p=h.page;await contextService(p,'playlist',[4,1,5],{nativeMode:'noop',webMode:'play'});await p.tap('[data-detail-track="1"]');await p.tap('[data-detail-track="2"]');await p.waitForFunction(()=>LiquidTouch.diagnostics().trackPlayback?.stage==='playing');assert.equal(await p.evaluate(()=>Spicetify.Player.data.item.uri),'spotify:track:demo5');const offsets=await p.evaluate(()=>__webRequests.map(r=>r.body.offset.position));assert.deepEqual(offsets,[2]);await h.end();
 });
 if(process.env.LT_TEST_UPDATE)await test('Restore installed version replaces the higher test runtime with revised v1.9.6 and retains settings/history',async()=>{
  const h=await host(browser,{textScale:130,uiScale:120,historySongLimit:500}),p=h.page;
  const testBundle=JSON.parse(fs.readFileSync(process.env.LT_TEST_UPDATE,'utf8'));
  await p.evaluate(bundle=>localStorage.setItem('liquid-touch.runtime.v1',JSON.stringify(bundle)),testBundle);
  await p.reload();await p.waitForFunction(()=>LiquidTouch.version==='1.9.8'&&LiquidTouch.diagnostics().phase==='mounted');
  await p.evaluate(()=>__ltMock.choose(2));const history=await p.evaluate(()=>LiquidTouch.diagnostics().historyItems);
  await p.click('#lt-shell [data-action=settings]');await p.click('[data-settings-section=updates]');await p.click('[data-action=restoreRuntime]');
  await p.waitForFunction(()=>document.querySelector('#lt-release').open);await p.click('[data-action=confirmUpdate]');
  await p.waitForFunction(()=>LiquidTouch.version==='1.9.6'&&LiquidTouch.diagnostics().phase==='mounted');
  assert.equal(await p.evaluate(()=>LiquidTouch.diagnostics().preferences.textScale),130);assert.equal(await p.evaluate(()=>LiquidTouch.diagnostics().preferences.uiScale),120);
  assert.ok(await p.evaluate(n=>LiquidTouch.diagnostics().historyItems>=n,history));assert.equal(await p.evaluate(()=>localStorage.getItem('liquid-touch.runtime.v1')),null);
  await p.reload();await p.waitForFunction(()=>LiquidTouch.version==='1.9.6'&&LiquidTouch.diagnostics().phase==='mounted');await h.end();
 });

 console.log(passed+' track-tap Chromium suites passed, including the reproduced v1.9.7 regression. Live Spotify requires device verification.');
 }finally{await browser.close();await new Promise(r=>server.close(r));}
})().catch(error=>{console.error(error);process.exitCode=1;});
