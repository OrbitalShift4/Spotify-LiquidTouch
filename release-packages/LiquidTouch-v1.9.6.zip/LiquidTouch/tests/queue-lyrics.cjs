'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
const base=path.resolve(__dirname,'..');let origin,passed=0;
async function test(name,work){await work();passed++;console.log('PASS '+name);}
async function host(browser,options={}){
 const context=await browser.newContext({viewport:{width:1024,height:600},hasTouch:true}),page=await context.newPage(),errors=[],backupRequests=[];
 page.setDefaultTimeout(6000);page.on('pageerror',error=>errors.push(error.message));
 await context.route('**/*',route=>{
  const url=route.request().url();if(url.startsWith(origin))return route.continue();
  if(options.backup&&url.startsWith('https://lrclib.net/api/get')){
   backupRequests.push(url);return route.fulfill({json:{duration:204,trackName:'Blue Hour',artistName:'Luma & The Coast',syncedLyrics:'[00:00.00]Upcoming backup lyric',plainLyrics:'Upcoming backup lyric'}});
  }
  return route.abort();
 });
 await page.addInitScript(config=>{
  localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,updateChecks:false,reduceMotion:true,lyricsFallback:Boolean(config.backup),lyricsTextFallback:false,lyricsPolicy:2,lyrics:true,...config.prefs}));
  localStorage.setItem('liquid-touch.seen-release','1.9.6');
  window.__beforeRuntime=()=>{
   window.__lyricCalls=[];window.__pendingLyrics={};window.__queueReads=0;window.__deferred=config.deferred||[];window.__missing=config.missing||[];
   window.__response=id=>({lyrics:{syncType:'LINE_SYNCED',providerDisplayName:'Regression service',lines:[{words:'Lyrics for '+id,startTimeMs:'0'},{words:'Next line for '+id,startTimeMs:'1000'}]}});
   __ltMock.choose(0);
   if(config.paused)Spicetify.Player.pause();if(config.repeatOne)Spicetify.Player.getRepeat=()=>2;
   window.__queueRows=config.queueRows;
   window.__setQueueRows=rows=>{
    window.__queueRows=rows;
    Object.defineProperty(Spicetify,'Queue',{configurable:true,get:()=>({track:{uri:Spicetify.Player.data?.item?.uri},nextTracks:__queueRows})});
    __ltMock.emit('onplaypause');
   };
   if(config.queueRows)__setQueueRows(config.queueRows);
   if(config.webQueue)Object.defineProperty(Spicetify,'Queue',{configurable:true,get:()=>undefined});
   const get=Spicetify.CosmosAsync.get;
   Spicetify.CosmosAsync.get=async url=>{
    if(url.includes('color-lyrics')){
     const id=url.match(/\/track\/([^?]+)/)[1];__lyricCalls.push(id);
     if(__deferred.includes(id))return new Promise(resolve=>__pendingLyrics[id]=resolve);
     if(__missing.includes(id))throw Error('Unavailable');return __response(id);
    }
    if(url.endsWith('/v1/me/player/queue')){__queueReads++;return {currently_playing:{uri:Spicetify.Player.data?.item?.uri},queue:config.webQueue||[]};}
    return get(url);
   };
  };
 },options);
 await page.goto(origin+'/LiquidTouch-Preview.html');await page.waitForFunction(()=>window.LiquidTouch?.diagnostics().phase==='mounted');
 return {page,context,backupRequests,async player(){await page.tap('#lt-mini-open');await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');await page.waitForFunction(()=>LiquidTouch.diagnostics().lyricsState==='ready');},async end(){assert.deepEqual(errors,[]);await context.close();}};
}
const ready=(page,id='demo1')=>page.waitForFunction(id=>LiquidTouch.diagnostics().lyricsPrefetchURI==='spotify:track:'+id&&LiquidTouch.diagnostics().lyricsPrefetchState==='ready',id);
(async()=>{
 const server=http.createServer((req,res)=>{
  try{
   let html=fs.readFileSync(path.join(base,'LiquidTouch-Preview.html'),'utf8');const at=html.lastIndexOf('<script>');
   // Install test services after the fixture and before the unmodified runtime.
   html=html.slice(0,at)+'<script>window.__beforeRuntime?.();</script>'+html.slice(at);res.setHeader('Content-Type','text/html');res.end(html);
  }catch{res.statusCode=404;res.end();}
 });await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true,executablePath:process.env.LT_CHROME,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
 await test('next-song lyrics warm at position zero, without opening Now Playing or waiting for the final ten seconds',async()=>{
  const h=await host(browser),p=h.page;await ready(p);assert.equal(await p.evaluate(()=>Spicetify.Player.getProgress()),0);assert.deepEqual(await p.evaluate(()=>__lyricCalls),['demo1']);assert.equal(await p.evaluate(()=>LiquidTouch.diagnostics().playerOpen),false);await h.end();
 });
 await test('only the first queue item is prefetched and progress events never duplicate its lookup',async()=>{
  const h=await host(browser,{queueRows:[{uri:'spotify:track:demo1'},{uri:'spotify:track:demo2'},{uri:'spotify:track:demo3'}]}),p=h.page;await ready(p);
  await p.evaluate(()=>{for(let i=0;i<100;i++)__ltMock.emit('onplaypause');__ltMock.setPosition(1000);__ltMock.setPosition(Spicetify.Player.getDuration()-5000);});assert.deepEqual(await p.evaluate(()=>__lyricCalls),['demo1']);await h.end();
 });
 await test('manual Next keeps the lyrics panel open and immediately starts warming the following queue item',async()=>{
  const h=await host(browser),p=h.page;await ready(p);await h.player();
  const result=await p.evaluate(()=>{
   const panel=document.querySelector('#lt-lyrics-panel'),descriptor=Object.getOwnPropertyDescriptor(HTMLElement.prototype,'hidden'),states=[];
   Object.defineProperty(panel,'hidden',{configurable:true,get(){return descriptor.get.call(this);},set(value){states.push(Boolean(value));descriptor.set.call(this,value);}});
   Spicetify.Player.next();return {states,visible:LiquidTouch.diagnostics().lyricsVisible,text:document.querySelector('#lt-lyrics-lines').textContent};
  });assert.equal(result.visible,true);assert.ok(!result.states.includes(true));assert.match(result.text,/Lyrics for demo1/);await ready(p,'demo2');
  assert.equal(await p.evaluate(()=>__lyricCalls.filter(id=>id==='demo1').length),1);await h.end();
 });
 await test('a skip before prefetch completes adopts that request and advances to one-ahead after it finishes',async()=>{
  const h=await host(browser,{deferred:['demo1']}),p=h.page;await p.waitForFunction(()=>__pendingLyrics.demo1);await h.player();await p.evaluate(()=>Spicetify.Player.next());
  assert.equal(await p.evaluate(()=>__lyricCalls.filter(id=>id==='demo1').length),1);assert.equal(await p.evaluate(()=>__lyricCalls.includes('demo2')),false);
  await p.evaluate(()=>__pendingLyrics.demo1(__response('demo1')));await ready(p,'demo2');assert.match(await p.textContent('#lt-lyrics-lines'),/Lyrics for demo1/);assert.equal(await p.evaluate(()=>__lyricCalls.filter(id=>id==='demo1').length),1);await h.end();
 });
 await test('paused playback and Repeat one still warm the queued song for a manual skip',async()=>{
  for(const options of [{paused:true},{repeatOne:true}]){
   const h=await host(browser,options);await ready(h.page);assert.deepEqual(await h.page.evaluate(()=>__lyricCalls),['demo1']);await h.end();
  }
 });
 await test('queue changes replace an unfinished target without painting stale lyrics',async()=>{
  const h=await host(browser,{deferred:['demo1']}),p=h.page;await p.waitForFunction(()=>__pendingLyrics.demo1);await h.player();
  await p.evaluate(()=>__setQueueRows([{uri:'spotify:track:demo3'}]));await ready(p,'demo3');await p.evaluate(()=>{__pendingLyrics.demo1(__response('WRONG SONG'));__ltMock.choose(3);});
  assert.equal(await p.evaluate(()=>LiquidTouch.diagnostics().lyricsVisible),true);assert.match(await p.textContent('#lt-lyrics-lines'),/Lyrics for demo3/);assert.doesNotMatch(await p.textContent('#lt-lyrics-lines'),/WRONG SONG/);await h.end();
 });
 await test('Low-RAM mode stays one song ahead at the start of successive tracks with a bounded cache',async()=>{
  const h=await host(browser,{prefs:{lowMemory:true}}),p=h.page;await ready(p);await h.player();
  for(let i=0;i<8;i++){await p.evaluate(()=>Spicetify.Player.next());await ready(p,'demo'+((i+2)%6));assert.equal(await p.evaluate(()=>LiquidTouch.diagnostics().lyricsVisible),true);assert.ok(await p.evaluate(()=>LiquidTouch.diagnostics().memoryCaches.lyrics<=4));}await h.end();
 });
 await test('manual hiding affects only the current song and automatic-Off avoids all speculative requests',async()=>{
  const h=await host(browser),p=h.page;await ready(p);await h.player();await p.tap('[data-action=toggleLyrics]');assert.equal(await p.evaluate(()=>LiquidTouch.diagnostics().lyricsVisible),false);await p.evaluate(()=>Spicetify.Player.next());assert.equal(await p.evaluate(()=>LiquidTouch.diagnostics().lyricsVisible),true);await h.end();
  const off=await host(browser,{prefs:{lyrics:false}});assert.deepEqual(await off.page.evaluate(()=>__lyricCalls),[]);await off.page.tap('#lt-mini-open');await off.page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');assert.deepEqual(await off.page.evaluate(()=>__lyricCalls),[]);await off.end();
 });
 await test('an empty queue or podcast at its head does not prefetch farther into the queue',async()=>{
  for(const queueRows of [[],[{uri:'spotify:episode:podcast'},{uri:'spotify:track:demo1'}]]){const h=await host(browser,{queueRows});assert.deepEqual(await h.page.evaluate(()=>__lyricCalls),[]);await h.end();}
 });
 await test('a missing lyric result is not repeatedly fetched and manual display remains available',async()=>{
  const h=await host(browser,{missing:['demo1']}),p=h.page;await p.waitForFunction(()=>LiquidTouch.diagnostics().lyricsPrefetchState==='unavailable');
  await p.evaluate(()=>{for(let i=0;i<100;i++)__ltMock.emit('onplaypause');});assert.deepEqual(await p.evaluate(()=>__lyricCalls),['demo1']);await h.player();await p.evaluate(()=>Spicetify.Player.next());await p.waitForFunction(()=>LiquidTouch.diagnostics().lyricsState==='unavailable');assert.equal(await p.evaluate(()=>LiquidTouch.diagnostics().lyricsVisible),false);await p.tap('[data-action=toggleLyrics]');assert.equal(await p.evaluate(()=>LiquidTouch.diagnostics().lyricsVisible),true);await h.end();
 });
 await test('Web queue fallback starts immediately and is not re-requested on every render',async()=>{
  const h=await host(browser,{webQueue:[{uri:'spotify:track:demo1'}]}),p=h.page;await ready(p);await p.evaluate(()=>{for(let i=0;i<100;i++)__ltMock.emit('onplaypause');});assert.equal(await p.evaluate(()=>__queueReads),1);assert.deepEqual(await p.evaluate(()=>__lyricCalls),['demo1']);await h.end();
 });
 await test('backup sources warm the next recording using its own title, artist and duration',async()=>{
  const h=await host(browser,{backup:true,missing:['demo1']}),p=h.page;await ready(p);const query=new URL(h.backupRequests[0]).searchParams;assert.equal(query.get('track_name'),'Blue Hour');assert.equal(query.get('artist_name'),'Luma & The Coast');assert.equal(query.get('duration'),'204');await h.player();await p.evaluate(()=>Spicetify.Player.next());assert.match(await p.textContent('#lt-lyrics-lines'),/Upcoming backup lyric/);await h.end();
 });
 console.log(passed+' one-song-ahead Chromium regression suites passed. Live lyric-service availability still requires device testing.');
 }finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
})().catch(error=>{console.error(error);process.exitCode=1;});
