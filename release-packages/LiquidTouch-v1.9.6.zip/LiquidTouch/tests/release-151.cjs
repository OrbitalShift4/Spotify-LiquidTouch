const {revealSetting}=require('./settings-navigation.cjs');
/* 1.5.1: no swipe HUD, cached tab switching, live greetings, easier player gestures. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
let origin,passed=0;
async function open(browser){
 const context=await browser.newContext({viewport:{width:1024,height:600},hasTouch:true,reducedMotion:'no-preference',timezoneId:'Asia/Dubai'}),page=await context.newPage(),errors=[];page.setDefaultTimeout(7000);page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,playerFullscreen:false})));await page.goto(origin);await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');return {context,page,errors};
}
function pass(name,errors){assert.deepEqual(errors,[]);passed++;console.log('PASS '+name);}
async function drag(page,x,y,endX,endY,mid){const s=await page.context().newCDPSession(page);await s.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y,id:1}]});for(let i=1;i<=6;i++)await s.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x+(endX-x)*i/6,y:y+(endY-y)*i/6,id:1}]});await page.waitForTimeout(24);if(mid)await mid();await s.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await s.detach();}
async function player(page){await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');}
async function main(){
 const server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(fs.readFileSync(path.resolve(__dirname,'../LiquidTouch-Preview.html')));});await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;let browser;
 try{
  browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox']});
  {
   const {page,context,errors}=await open(browser);
   await drag(page,620,250,470,250,async()=>{assert.equal(await page.locator('#lt-gesture-cue,.lt-gesture-cue').count(),0);assert.notEqual(await page.locator('#lt-browse').evaluate(n=>n.style.transform),'');assert.equal(await page.locator('body').getAttribute('data-lt-page'),'home');});
   assert.equal(await page.locator('body').getAttribute('data-lt-page'),'search');await page.waitForTimeout(130);assert.equal(await page.locator('#lt-browse').evaluate(n=>n.getAnimations().length),0);
   pass('swipes keep finger-following motion without any progress HUD and settle the new page in 100 ms',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.waitForTimeout(500);
   await page.locator('.lt-nav [data-action=library]').tap();await page.waitForTimeout(150);await page.locator('.lt-nav [data-action=home]').tap();await page.waitForTimeout(150);
   await page.evaluate(()=>window.homeCard=document.querySelector('#lt-browse [data-lt-card]'));
   await page.locator('.lt-nav [data-action=library]').tap();await page.waitForTimeout(150);await page.evaluate(()=>{window.libraryCard=document.querySelector('#lt-browse [data-lt-card]');window.baseBuilds=LiquidTouch.diagnostics().browseBuilds;});
   for(let i=0;i<3;i++){
    await drag(page,500,250,640,250);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'search');
    await drag(page,500,250,640,250);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'home');assert.equal(await page.evaluate(()=>document.querySelector('#lt-browse [data-lt-card]')===homeCard),true);
    await drag(page,620,250,480,250);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'search');
    await drag(page,620,250,480,250);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');assert.equal(await page.evaluate(()=>document.querySelector('#lt-browse [data-lt-card]')===libraryCard),true);
   }
   assert.ok(await page.evaluate(()=>LiquidTouch.diagnostics().browseBuilds<=baseBuilds+1));assert.ok(await page.evaluate(()=>LiquidTouch.diagnostics().browseReuses>=9));
   pass('repeated trusted Home/Search/Library swipes reuse the same card nodes instead of rebuilding their grids',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{const push=Spicetify.Platform.History.push.bind(Spicetify.Platform.History);Spicetify.Platform.History.push=path=>{if(path==='/search')setTimeout(()=>push(path),450);else push(path);};});
   await page.locator('.lt-nav [data-action=search]').tap();await page.locator('.lt-nav [data-action=home]').tap();await page.locator('.lt-nav [data-action=library]').tap();await page.waitForTimeout(650);
   assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');assert.equal(await page.evaluate(()=>Spicetify.Platform.History.location.pathname),'/');
   await page.locator('.lt-nav [data-action=home]').tap();await page.waitForTimeout(150);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'home');
   pass('a late completion from Search cannot knock the latest Home/Library selection back to an older tab',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.locator('#lt-browse [data-open-uri="spotify:album:demo-1"]').tap();await page.locator('.lt-nav [data-action=home]').tap();
   await page.evaluate(()=>{const push=Spicetify.Platform.History.push.bind(Spicetify.Platform.History);Spicetify.Platform.History.push=path=>{push(path);if(path==='/queue')setTimeout(()=>push('/queue/canonical'),50);};});
   await page.locator('#lt-mini-open').tap();await page.locator('#lt-now-playing [data-action=queue]').tap();await page.waitForTimeout(160);
   assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().route),'/queue/canonical');
   await page.locator('#lt-shell [data-action=goBack]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'home');
   pass('completed old routes remain valid canonical redirect targets and Back still restores the preceding view',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{window.fakeHour=8;const NativeDate=Date;window.Date=class extends NativeDate{getHours(){return window.fakeHour;}};document.dispatchEvent(new Event('visibilitychange'));});assert.equal(await page.locator('.lt-home-hero h1').textContent(),'Good morning.');
   await page.evaluate(()=>{window.fakeHour=13;const now=Date.now;Date.now=()=>now()+31000;});await page.waitForFunction(()=>document.querySelector('.lt-home-hero h1').textContent==='Good afternoon.');
   await page.locator('#lt-shell .lt-header [data-action=settings]').tap();await revealSetting(page,'welcome');await page.locator('#lt-welcome').fill('Good morning, Saif.');await page.locator('#lt-settings [data-action=closeSettings]').tap();assert.equal(await page.locator('.lt-home-hero h1').textContent(),'Good afternoon, Saif.');
   await page.locator('#lt-shell .lt-header [data-action=settings]').tap();await revealSetting(page,'welcome');await page.locator('#lt-welcome').fill('{greeting}, Saif — {timeOfDay} music.');await page.locator('#lt-settings [data-action=closeSettings]').tap();await page.evaluate(()=>{fakeHour=19;document.dispatchEvent(new Event('visibilitychange'));});assert.equal(await page.locator('.lt-home-hero h1').textContent(),'Good evening, Saif — evening music.');
   pass('greetings update at the time boundary while Home stays open, on resume, and inside saved/custom welcome text',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await player(page);
   const title=await page.locator('#lt-np-title').textContent();await drag(page,245,185,212,185);assert.equal(await page.locator('#lt-np-title').textContent(),title);
   await drag(page,245,185,195,185);assert.equal(await page.locator('#lt-np-title').textContent(),'Blue Hour');assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='next').length),1);
   await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);await drag(page,350,460,300,460);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),false);assert.equal(await page.locator('#lt-mini-title').textContent(),'Blue Hour');
   pass('40 px artwork swipes skip once in the expanded player; smaller movements and short mini-player swipes do not',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   for(const x of [20,512,1004]){await player(page);await drag(page,x,110,x+2,210);await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),false);}
   await player(page);await drag(page,970,34,970,140);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='windowClose').length),0);
   await drag(page,740,350,742,450);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);
   pass('player pull-down works from the far left, center and far right of the generous top area while captions and lower lyric scrolling retain their behavior',errors);await context.close();
  }
  console.log(passed+' release 1.5.1 suites passed. Spotify services and Windows IPC remain simulated.');
 }finally{await browser?.close();await new Promise(r=>server.close(r));}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
