"""Exercise actual installer entry points against an isolated fake Spicetify CLI."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

BASE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("manage", BASE / "tools/manage.py")
manage = importlib.util.module_from_spec(spec)
spec.loader.exec_module(manage)


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="liquidtouch-test-")
        self.root = Path(self.temp.name)
        self.config = self.root / "config-xpui.ini"
        self.original = "# keep this comment\n[Setting]\ncurrent_theme = OldTheme\ncolor_scheme =\ninject_css = 0\nreplace_colors = 0\nspotify_path = /somewhere/Spotify\n\n[AdditionalOptions]\nextensions = alpha.js|beta.js\ncustom_apps = marketplace|lyrics-plus\n"
        self.config.write_text(self.original)
        bin_path = self.root / "bin"
        bin_path.mkdir()
        cli = bin_path / "spicetify"
        cli.write_text('#!/usr/bin/env python3\nimport os,sys\nif sys.argv[1:]==["-c"]: print(os.environ["LT_TEST_CONFIG"])\nelse:\n with open(os.environ["LT_TEST_LOG"],"a") as f: f.write(" ".join(sys.argv[1:])+"\\n")\n')
        cli.chmod(0o755)
        self.env = dict(os.environ, PATH=str(bin_path) + os.pathsep + os.environ["PATH"], LT_TEST_CONFIG=str(self.config), LT_TEST_LOG=str(self.root / "calls"))

    def tearDown(self):
        self.temp.cleanup()

    def run_action(self, action, apply=False):
        command = ["bash", str(BASE / ("install.sh" if action == "install" else "uninstall.sh"))]
        if not apply:
            command.append("--no-apply")
        subprocess.run(command, env=self.env, check=True, capture_output=True, text=True)

    def test_round_trip_and_repeated_install(self):
        self.run_action("install")
        state = json.loads((self.root / "liquid-touch-state.json").read_text())
        self.run_action("install")
        self.assertEqual(json.loads((self.root / "liquid-touch-state.json").read_text())["baseline_backup"], state["baseline_backup"])
        current = self.config.read_text()
        self.assertEqual(manage.get_value(current, "AdditionalOptions", "extensions"), "alpha.js|beta.js|liquid-touch.js")
        self.assertIn("# keep this comment", current)
        self.assertEqual(manage.get_value(current, "AdditionalOptions", "custom_apps"), "marketplace|lyrics-plus")
        self.assertTrue((self.root / "Themes/LiquidTouch/user.css").is_file())
        # Unrelated changes made after installation must survive removal.
        current = manage.set_value(current, "AdditionalOptions", "extensions", "alpha.js|beta.js|liquid-touch.js|new.js")
        current = manage.set_value(current, "Setting", "spotify_path", "/new/path")
        self.config.write_text(current)
        self.run_action("uninstall")
        restored = self.config.read_text()
        self.assertEqual(manage.get_value(restored, "Setting", "current_theme"), "OldTheme")
        self.assertEqual(manage.get_value(restored, "Setting", "color_scheme"), "")
        self.assertEqual(manage.get_value(restored, "Setting", "spotify_path"), "/new/path")
        self.assertEqual(manage.get_value(restored, "AdditionalOptions", "extensions"), "alpha.js|beta.js|new.js")
        self.assertFalse((self.root / "Themes/LiquidTouch").exists())
        self.assertFalse((self.root / "Extensions/liquid-touch.js").exists())

    def test_preexisting_liquidtouch_resources_restored(self):
        theme = self.root / "Themes/LiquidTouch"
        extension = self.root / "Extensions/liquid-touch.js"
        theme.mkdir(parents=True)
        extension.parent.mkdir(parents=True)
        (theme / "old.txt").write_text("original theme")
        extension.write_text("original extension")
        self.config.write_text(manage.set_value(self.original, "AdditionalOptions", "extensions", "alpha.js|liquid-touch.js"))
        self.run_action("install")
        self.run_action("uninstall")
        self.assertEqual((theme / "old.txt").read_text(), "original theme")
        self.assertEqual(extension.read_text(), "original extension")
        self.assertEqual(manage.get_value(self.config.read_text(), "AdditionalOptions", "extensions"), "alpha.js|liquid-touch.js")

    def test_apply_and_newer_theme_preserved(self):
        self.run_action("install", apply=True)
        self.config.write_text(manage.set_value(self.config.read_text(), "Setting", "current_theme", "NewerTheme"))
        self.run_action("uninstall", apply=True)
        self.assertEqual(manage.get_value(self.config.read_text(), "Setting", "current_theme"), "NewerTheme")
        self.assertEqual((self.root / "calls").read_text().splitlines(), ["backup apply", "apply"])

    def test_absent_sections_and_case_insensitivity(self):
        self.config.write_text("# bare configuration\n[setting]\nspotify_path = /app\n")
        self.run_action("install")
        self.run_action("uninstall")
        self.assertEqual(manage.get_value(self.config.read_text(), "Setting", "spotify_path"), "/app")
        self.assertIsNone(manage.get_value(self.config.read_text(), "Setting", "current_theme"))

    def test_api_exposure_is_enabled_and_original_setting_restored(self):
        self.config.write_text(self.original + "\n[Preprocesses]\nexpose_apis = 0\n")
        self.run_action("install")
        self.assertEqual(manage.get_value(self.config.read_text(), "Preprocesses", "expose_apis"), "1")
        self.run_action("uninstall")
        self.assertEqual(manage.get_value(self.config.read_text(), "Preprocesses", "expose_apis"), "0")

    def test_existing_native_backup_is_restored_before_preprocessing(self):
        backup = self.root / "Backup"
        backup.mkdir()
        (backup / "xpui.spa").write_bytes(b"fake native archive")
        self.config.write_text(self.original + "\n[Preprocesses]\nexpose_apis = 0\n")
        self.run_action("install", apply=True)
        self.run_action("uninstall", apply=True)
        self.assertEqual((self.root / "calls").read_text().splitlines(), ["restore backup apply", "restore backup apply"])

    def test_upgrade_from_100_preserves_original_api_preference(self):
        self.config.write_text(self.original + "\n[Preprocesses]\nexpose_apis = 0\n")
        self.run_action("install")
        state_path = self.root / "liquid-touch-state.json"
        state = json.loads(state_path.read_text())
        del state["apis_previous"]
        state_path.write_text(json.dumps(state))
        self.run_action("install")
        self.assertEqual(json.loads(state_path.read_text())["apis_previous"], "0")
        self.run_action("uninstall")
        self.assertEqual(manage.get_value(self.config.read_text(), "Preprocesses", "expose_apis"), "0")


if __name__ == "__main__":
    unittest.main(verbosity=2)
