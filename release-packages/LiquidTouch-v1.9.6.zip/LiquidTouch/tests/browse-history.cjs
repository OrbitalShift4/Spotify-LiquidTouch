// Behavior checks for 1.2 using trusted Chromium touch input and a simulated host.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
let url;
const html=fs.readFileSync(path.resolve(__dirname,'../LiquidTouch-Preview.html'));
let passed=0;
async function open(browser,w=1920,h=1080,prefs={}){
 const context=await browser.newContext({viewport:{width:w,height:h},hasTouch:true,timezoneId:'Asia/Dubai',reducedMotion:'reduce'});
 const page=await context.newPage();page.setDefaultTimeout(7000);const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(p=>localStorage.getItem('liquid-touch.preferences.v1') || localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,textScale:130,uiScale:120,...p})),prefs);
 await page.goto(url);await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted' && document.querySelector('#lt-browse .lt-card'));
 return{page,context,errors};
}
function pass(label,errors){assert.deepEqual(errors,[]);passed++;console.log('PASS '+label);}
async function main(){
 const server=http.createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(html);});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 url='http://127.0.0.1:'+server.address().port+'/LiquidTouch-Preview.html';
 const browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox']});
 try{
  {
   const {page,context,errors}=await open(browser);
   const card=page.locator('#lt-browse [data-lt-card="spotify:album:demo-1"]');await card.tap();await page.waitForFunction(()=>!LiquidTouch.diagnostics().cardTapPending);
   assert.equal(await page.evaluate(()=>Spicetify.Platform.History.location.pathname),'/');
   assert.equal(await page.locator('#lt-mini-title').textContent(),'Blue Hour');
   await card.tap();await card.tap();
   assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().route),'/album/demo-1');
   assert.equal(await page.evaluate(()=>__ltMock.log.filter(x=>x[0]==='playUri').length),1);
   await page.locator('.lt-nav [data-action=home]').tap();
   const before=await page.evaluate(()=>__ltMock.log.filter(x=>x[0]==='playUri').length);
   const scroll=page.locator('#lt-browse [data-lt-card="spotify:playlist:demo-0"]');
   await scroll.dispatchEvent('pointerdown',{pointerId:9,pointerType:'touch',clientX:120,clientY:250});
   await scroll.dispatchEvent('pointermove',{pointerId:9,pointerType:'touch',clientX:120,clientY:320});
   await scroll.dispatchEvent('pointerup',{pointerId:9,pointerType:'touch',clientX:120,clientY:250});
   assert.equal(await page.evaluate(()=>__ltMock.log.filter(x=>x[0]==='playUri').length),before);
   pass('trusted first-tap play, second-tap open, no duplicate playback, and no playback from a scroll gesture',errors);await context.close();
  }
  for(const [w,h] of [[1920,1080],[1024,600],[800,480],[480,800]]){
   const {page,context,errors}=await open(browser,w,h);
   await page.locator('.lt-nav [data-action=library]').tap();
   await page.waitForFunction(()=>document.querySelectorAll('#lt-browse .lt-card').length>=100);
   let layout=await page.locator('#lt-browse').evaluate(n=>({client:n.clientHeight,scroll:n.scrollHeight,columns:getComputedStyle(n.querySelector('.lt-card-grid')).gridTemplateColumns.split(' ').length}));
   assert.ok(layout.scroll>layout.client);assert.ok(layout.columns<=4);if(w===1920)assert.equal(layout.columns,4);
   await page.locator('#lt-browse').evaluate(n=>n.scrollTop=n.scrollHeight);
   await page.waitForFunction(()=>document.querySelectorAll('#lt-browse .lt-card').length>145);
   await page.locator('#lt-browse').evaluate(n=>n.scrollTop=n.scrollHeight);
   const bottom=await page.locator('#lt-browse .lt-card').last().boundingBox(),mini=await page.locator('.lt-mini').boundingBox();
   assert.ok(bottom.y+bottom.height<=mini.y,`Last card must scroll above footer ${JSON.stringify({bottom,mini})}`);
   const navSize=await page.locator('.lt-nav button').first().evaluate(n=>parseFloat(getComputedStyle(n).fontSize));
   assert.ok(navSize>=20);
   pass(`library scrolls through paginated results, last card clears footer, max four columns, larger navigation text: ${w}×${h}`,errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,1024,600);
   for(let i=0;i<4;i++){
    await page.locator('.lt-nav [data-action=library]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');
    await page.locator('.lt-nav [data-action=home]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'home');
    await page.locator('.lt-nav [data-action=search]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-custom-page'),'search');
   }
   // A synthetic compatibility click after touch must not invoke the action twice.
   await page.locator('.lt-nav [data-action=home]').tap();
   const before=await page.evaluate(()=>Spicetify.Platform.History.entries.length);
   await page.locator('.lt-nav [data-action=home]').tap();
   assert.equal(await page.evaluate(()=>Spicetify.Platform.History.entries.length),before);
   pass('navigation activates on every first touch, with no hover-only or duplicate action',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,1024,600);
   await page.locator('.lt-nav [data-action=search]').tap();await page.locator('#lt-search-input').fill('Blue');await page.locator('#lt-search-form').dispatchEvent('submit');
   await page.locator('#lt-browse [data-lt-card="spotify:track:demo-1"]').tap();await page.waitForFunction(()=>!LiquidTouch.diagnostics().cardTapPending);
   assert.equal(await page.locator('#lt-mini-title').textContent(),'Blue Hour');
   const nativeAlbum=page.locator('#lt-browse [data-lt-card="spotify:album:demo-1"]');await nativeAlbum.tap();
   assert.equal(await page.evaluate(()=>Spicetify.Platform.History.location.pathname),'/search/Blue');
   await nativeAlbum.tap();assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().route),'/album/demo-1');
   await page.locator('.lt-nav [data-action=search]').tap();await page.locator('#lt-search-input').fill('Blue');await page.locator('#lt-search-form').dispatchEvent('submit');
   await page.locator('#lt-browse [data-lt-card="spotify:playlist:demo-1"]').tap();
   await page.locator('#lt-browse [data-lt-card="spotify:playlist:demo-1"]').tap();
   await page.locator('.lt-nav [data-action=search]').tap();await page.locator('#lt-search-input').fill('Blue');await page.locator('#lt-search-form').dispatchEvent('submit');
   await page.locator('#lt-browse [data-lt-card="spotify:artist:demo-1"]').tap();
   await page.locator('.lt-nav [data-action=search]').tap();
   assert.ok(await page.locator('#lt-browse [data-lt-card="spotify:track:demo-1"]').count());
   assert.ok(await page.locator('#lt-browse [data-lt-card="spotify:album:demo-1"]').count());
   assert.ok(await page.locator('#lt-browse [data-lt-card="spotify:artist:demo-1"]').count());
   assert.ok(await page.locator('#lt-browse [data-lt-card="spotify:playlist:demo-1"]').count());
   assert.equal(await page.locator('#lt-browse [data-search-query=Blue]').count(),0);
   await page.reload();await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');await page.locator('.lt-nav [data-action=search]').tap();
   assert.equal(await page.locator('#lt-browse [data-lt-card="spotify:track:demo-1"]').count(),1);
   pass('recent song/playlist/album/artist cards persist and result cards use single/double taps',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   const stored=()=>page.evaluate(()=>JSON.parse(localStorage.getItem('liquid-touch.play-history.v1:demo') || '[]'));
   const start=(await stored()).length;
   await page.locator('.lt-mini [data-action=togglePlay]').tap();await page.locator('.lt-mini [data-action=togglePlay]').tap();
   assert.equal((await stored()).length,start);
   await page.evaluate(()=>{__ltMock.choose(1);__ltMock.choose(2);__ltMock.choose(3);});
   assert.equal((await stored()).length,start+3);
   const rows=await stored();assert.ok(rows.every(r=>r.at>0 && r.uri && r.title && !r.image.startsWith('data:')));
   await page.locator('#lt-shell .lt-header [data-action=settings]').tap();await page.locator('#lt-settings [data-action=playHistory]').click();
   assert.equal(await page.locator('#lt-history').evaluate(n=>n.open),true);
   assert.equal(await page.locator('.lt-history-row').count(),start+3);
   assert.ok(await page.locator('.lt-history-row time').first().getAttribute('datetime'));
   await page.locator('#lt-history-search').fill('Astra');assert.equal(await page.locator('.lt-history-row').count(),1);
   await page.locator('#lt-history-search').fill('missing entry');assert.equal(await page.locator('.lt-history-row').count(),0);
   await page.reload();await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');
   assert.ok((await stored()).some(row=>row.title==='In Orbit'));
   pass('local playback history records starts without pause/resume duplicates, searches artists, timestamps entries, and survives reload',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.locator('#lt-shell .lt-header [data-action=settings]').tap();
   await page.locator('#lt-rounding').evaluate(n=>{n.value='56';n.dispatchEvent(new Event('input',{bubbles:true}));});
   assert.equal(await page.locator('body').evaluate(n=>n.style.getPropertyValue('--lt-radius')),'56px');
   await page.locator('#lt-settings [data-action=closeSettings]').tap();
   const before=await page.locator('.lt-mini').evaluate(n=>getComputedStyle(n).backgroundColor);
   const rootBefore=await page.locator('body').evaluate(n=>n.style.getPropertyValue('--lt-bg'));
   await page.evaluate(()=>__ltMock.choose(1));await page.waitForFunction(()=>document.body.style.getPropertyValue('--lt-art-rgb')==='31, 98, 108');
   assert.notEqual(await page.locator('.lt-mini').evaluate(n=>getComputedStyle(n).backgroundColor),before);
   assert.notEqual(await page.locator('body').evaluate(n=>n.style.getPropertyValue('--lt-bg')),rootBefore);
   assert.equal(await page.locator('.lt-nav').evaluate(n=>getComputedStyle(n).backdropFilter.includes('blur')),true);
   assert.equal(await page.locator('.Root__globalNav').isVisible(),false);
   assert.equal(await page.locator('.Titlebar').isVisible(),false);
   await page.locator('#lt-mini-open').tap();assert.equal(await page.locator('#lt-now-playing').evaluate(n=>parseFloat(getComputedStyle(n).borderRadius)),0);
   pass('artwork changes global and floating glass colors, rounding applies to surfaces while the player remains fullscreen, and stock chrome stays hidden at 130/120',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,800,480,{textScale:200,uiScale:140,rounding:56});
   await page.locator('.lt-nav [data-action=library]').tap();
   assert.ok(await page.locator('#lt-browse').evaluate(n=>n.scrollWidth<=n.clientWidth+1));
   await page.locator('#lt-shell .lt-header [data-action=settings]').tap();await page.locator('#lt-settings [data-action=playHistory]').click();
   const input=await page.locator('#lt-history-search').boundingBox();assert.ok(input.x>=0 && input.x+input.width<=800);
   assert.ok(await page.locator('#lt-history').evaluate(n=>n.scrollWidth<=n.clientWidth+1));
   pass('maximum text, interface size, and rounding keep Library and history usable at 800×480',errors);await context.close();
  }

  {
   const {page,context,errors}=await open(browser,1024,600);
   await page.locator('.lt-nav [data-action=library]').tap();
   await page.evaluate(()=>{
    window.__ltLanes=[];
    Spicetify.Platform.LibraryAPI.getContents=async({filters,offset=0,limit=100})=>{
     if(!filters.length)throw new Error('This client requires a filter');
     __ltLanes.push(filters[0]);const type={2:'playlist',0:'album',1:'artist'}[filters[0]];
     const items=__ltMock.libraryItems.filter(row=>row.uri.startsWith('spotify:'+type+':'));
     return {items:items.slice(offset,offset+limit),totalLength:items.length};
    };
   });
   await page.locator('#lt-browse [data-action=refreshLibrary]').tap();
   await page.waitForFunction(()=>__ltLanes.length===3 && document.querySelectorAll('#lt-browse .lt-card').length>145);
   await page.evaluate(()=>{Spicetify.Platform.LibraryAPI=undefined;Spicetify.Platform.RootlistAPI={getContents:async()=>({items:[{type:'folder',items:[{uri:'spotify:album:root-fallback',name:'Rootlist album',images:[]}]}]})};});
   await page.locator('#lt-browse [data-action=refreshLibrary]').tap();
   await page.waitForFunction(()=>LiquidTouch.diagnostics().librarySource==='rootlist');
   assert.equal(await page.locator('#lt-browse [data-lt-card="spotify:album:root-fallback"]').count(),1);
   await page.evaluate(()=>{Spicetify.Platform.RootlistAPI=undefined;});
   await page.locator('#lt-browse [data-action=refreshLibrary]').tap();
   await page.waitForFunction(()=>LiquidTouch.diagnostics().librarySource==='native');
   assert.ok(await page.locator('#lt-browse [data-lt-card="spotify:playlist:demo-0"]').count());
   pass('library handles explicit filters, nested rootlist fallback, and sidebar-only clients without stale API items',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   const count=()=>page.evaluate(()=>JSON.parse(localStorage.getItem('liquid-touch.play-history.v1:demo') || '[]').length);
   await page.evaluate(()=>{__ltMock.setEmpty(true);Spicetify.Player.togglePlay();__ltMock.setEmpty(false);});
   const before=await count();
   await page.evaluate(()=>Spicetify.Player.togglePlay());assert.equal(await count(),before+1);
   await page.evaluate(()=>{__ltMock.setPosition(Spicetify.Player.getDuration()-600);__ltMock.setPosition(0);});
   assert.equal(await count(),before+2);
   await page.locator('#lt-mini-open').tap();
   await page.evaluate(()=>__ltMock.setPosition(Spicetify.Player.getDuration()-600));
   await page.locator('#lt-seek').evaluate(n=>{n.value='0';n.dispatchEvent(new Event('change',{bubbles:true}));});
   assert.equal(await count(),before+2);
   pass('history records a paused first track when it starts, records repeat loops, and does not count a manual seek as a new play',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.locator('.lt-nav [data-action=search]').tap();
   await page.evaluate(()=>{
    const section=document.createElement('section');section.dataset.testid='recent-searches';
    const heading=document.createElement('h2');heading.textContent='Recent searches';section.append(heading);
    const card=document.createElement('article');card.dataset.testid='card-container';
    const link=document.createElement('a');link.href='/album/native-recent';link.textContent='Native recent album';
    const img=document.createElement('img');img.src=LT_DEMO_COVERS[2];link.append(img);card.append(link);section.append(card);
    document.querySelector('#fixture-content').append(section);
   });
   await page.waitForFunction(()=>document.querySelector('#lt-browse [data-lt-card="spotify:album:native-recent"]'));
   pass('identifiable existing Spotify recent-search cards are adopted into the redesigned search landing page',errors);await context.close();
  }

  {
   const {page,context,errors}=await open(browser,1024,600);
   await page.evaluate(()=>{
    const rows=Array.from({length:230},(_,i)=>({uri:'spotify:track:archive'+i,title:'Archived song '+i,artist:'Archive artist',album:'Archive album',image:'',at:Date.now()-i*60000}));
    localStorage.setItem('liquid-touch.play-history.v1:demo',JSON.stringify(rows));
   });
   await page.reload();await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');
   await page.locator('#lt-shell .lt-header [data-action=settings]').tap();await page.locator('#lt-settings [data-action=playHistory]').click();
   assert.equal(await page.locator('.lt-history-row').count(),100);
   await page.locator('#lt-history [data-action=moreHistory]').click();assert.equal(await page.locator('.lt-history-row').count(),200);
   await page.locator('#lt-history-search').fill('Archived song 229');assert.equal(await page.locator('.lt-history-row').count(),1);
   await page.locator('.lt-history-row').tap();assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='playUri').at(-1)[1]),'spotify:track:archive229');
   pass('large listening history pages older plays, searches beyond the displayed page, and replays the selected URI',errors);await context.close();
  }
  console.log(`${passed} new browse/history suites passed. The host and native bridge are simulated.`);
 } finally {await browser.close();await new Promise(resolve=>server.close(resolve));}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
