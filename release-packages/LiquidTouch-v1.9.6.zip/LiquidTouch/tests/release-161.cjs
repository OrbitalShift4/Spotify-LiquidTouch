const {revealSetting}=require('./settings-navigation.cjs');
/* 1.6.1: app-window player lifetime, taller keyboard, visible artwork scaling. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
let origin,passed=0;
async function open(browser,width=1024,height=600,prefs={}){
 const context=await browser.newContext({viewport:{width,height},hasTouch:true,reducedMotion:'no-preference'}),page=await context.newPage(),errors=[];
 page.setDefaultTimeout(6500);page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(p=>{if(!localStorage.getItem('liquid-touch.preferences.v1'))localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,playerFullscreen:true,textScale:130,uiScale:120,...p}));},prefs);
 await page.goto(origin);await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');return {context,page,errors};
}
function pass(name,errors){assert.deepEqual(errors,[]);passed++;console.log('PASS '+name);}
async function range(page,key,value){await revealSetting(page,key);await page.locator('#lt-'+key).evaluate((n,v)=>{n.value=String(v);n.dispatchEvent(new Event('input',{bubbles:true}));},value);}
async function settings(page){await page.locator('#lt-shell .lt-header [data-action=settings]').tap();}
async function playerSettings(page){await page.locator('#lt-now-playing [data-action=playerSettings]').tap();}
async function closeSettings(page){await page.locator('#lt-settings [data-action=closeSettings]').tap();}
async function artwork(page){await page.waitForTimeout(180);return page.locator('#lt-art').evaluate(n=>n.getBoundingClientRect().width);}
async function main(){
 const server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(fs.readFileSync(path.resolve(__dirname,'../LiquidTouch-Preview.html')));});await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox']});
 try{
  {
   const {page,context,errors}=await open(browser);
   await page.evaluate(()=>{window.fsCalls=0;window.playerCloses=0;document.documentElement.requestFullscreen=()=>{fsCalls++;return new Promise(()=>{});};document.exitFullscreen=()=>{fsCalls++;return Promise.resolve();};const close=HTMLDialogElement.prototype.close;HTMLDialogElement.prototype.close=function(...args){if(this.id==='lt-now-playing')playerCloses++;return close.apply(this,args);};});
   await page.locator('#lt-mini-open').tap();await page.waitForTimeout(750);
   for(let i=0;i<4;i++)await page.evaluate(()=>{document.dispatchEvent(new Event('fullscreenchange'));window.dispatchEvent(new Event('resize'));});
   const r=await page.locator('#lt-now-playing').evaluate(n=>{const r=n.getBoundingClientRect();return {open:n.open,x:r.x,y:r.y,width:r.width,height:r.height,opacity:getComputedStyle(n).opacity,rootAnimations:n.getAnimations().length};});
   assert.deepEqual(r,{open:true,x:0,y:0,width:1024,height:600,opacity:'1',rootAnimations:0});assert.equal(await page.evaluate(()=>fsCalls),0);assert.equal(await page.evaluate(()=>playerCloses),0);
   assert.equal(await page.locator('[data-pref=playerFullscreen],[data-action=fullscreen]').count(),0);
   await page.locator('#lt-now-playing [data-action=next]').tap();assert.equal(await page.locator('#lt-np-title').textContent(),'Blue Hour');
   pass('legacy fullscreen settings cannot request display fullscreen or trigger a modal close/reopen; player covers the full app viewport and stays interactive',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   await page.locator('.lt-nav [data-action=library]').tap();await page.locator('#lt-browse').evaluate(n=>n.scrollTop=320);
   for(let i=0;i<8;i++){
    await page.locator('#lt-mini-open').tap();await playerSettings(page);await closeSettings(page);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);
    await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);
   }
   await page.waitForTimeout(450);assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),false);assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');assert.ok(await page.locator('#lt-browse').evaluate(n=>n.scrollTop>=300));
   await page.locator('#lt-mini-open').tap();await page.waitForTimeout(350);assert.equal(await page.locator('#lt-now-playing').isVisible(),true);
   pass('rapid trusted touch open/nested Settings/close cycles leave no delayed dismissal and preserve the Library tab and scroll',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,1920,1080);
   await page.locator('#lt-mini-open').tap();const grown=await artwork(page);assert.ok(grown>=480);
   await playerSettings(page);await range(page,'artworkSize',100);await closeSettings(page);const base=await artwork(page);assert.ok(grown>=base*1.34);
   await playerSettings(page);await range(page,'artworkSize',160);await range(page,'keyboardHeight',170);await closeSettings(page);assert.ok(await artwork(page)>grown);
   await page.reload();await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');const p=await page.evaluate(()=>LiquidTouch.diagnostics().preferences);assert.equal(p.artworkSize,160);assert.equal(p.keyboardHeight,170);assert.equal(p.playerFullscreen,undefined);
   await page.locator('#lt-mini-open').tap();assert.ok(await artwork(page)>=570);
   await page.locator('#lt-now-playing [data-action=toggleLyrics]').tap();assert.ok(await artwork(page)>=600);await page.locator('#lt-now-playing [data-action=toggleLyrics]').tap();assert.ok(await artwork(page)>=570);
   pass('artwork grows visibly, has working 100–180% adjustment in both lyric layouts, and persists with keyboard height while retiring the old fullscreen preference',errors);await context.close();
  }
  for(const [width,height] of [[800,480],[1024,600],[480,800]]){
   const {page,context,errors}=await open(browser,width,height);
   await page.locator('#lt-mini-open').tap();const larger=await artwork(page);await playerSettings(page);await range(page,'artworkSize',100);await closeSettings(page);const base=await artwork(page);assert.ok(larger>=base*1.28,`${width}: ${larger} vs ${base}`);
   await playerSettings(page);await range(page,'artworkSize',180);await closeSettings(page);await artwork(page);const queue=page.locator('#lt-now-playing [data-action=queue]');await queue.scrollIntoViewIfNeeded();const q=await queue.boundingBox();assert.ok(q.y>=0 && q.y+q.height<=height+1);
   pass(`artwork is visibly larger rather than capped at its previous size, with reachable controls at 180%: ${width}×${height}`,errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,1024,600,{keyboard:true,textScale:120,uiScale:100});await page.locator('.lt-nav [data-action=search]').tap();
   const tall=await page.locator('[data-key=q]').boundingBox(),keyboard=await page.locator('#lt-keyboard').boundingBox();assert.ok(tall.height>=63);assert.ok(keyboard.height>=330);
   await page.locator('[data-key=q]').tap();await page.locator('[data-key=w]').tap();await page.locator('[data-key=Backspace]').tap();assert.equal(await page.locator('#lt-search-input').inputValue(),'q');
   await settings(page);await range(page,'keyboardHeight',100);await closeSettings(page);await page.locator('#lt-shell [data-action=keyboard]').tap();const smaller=await page.locator('[data-key=q]').boundingBox();assert.ok(tall.height>=smaller.height*1.4);assert.ok(Math.abs(tall.width-smaller.width)<1);
   pass('keyboard keys are about 45% taller at default settings without changing their width, and trusted typing/backspace still work',errors);await context.close();
  }
  for(const [width,height] of [[800,480],[1024,600],[480,800]]){
   const {page,context,errors}=await open(browser,width,height,{keyboard:true,keyboardHeight:180,textScale:150,uiScale:140});await page.locator('.lt-nav [data-action=search]').tap();await page.waitForTimeout(180);
   const keys=await page.locator('#lt-keyboard [data-key]').evaluateAll(nodes=>nodes.map(n=>{const r=n.getBoundingClientRect();return {x:r.x,y:r.y,right:r.right,bottom:r.bottom,height:r.height};}));
   for(const k of keys)assert.ok(k.x>=-.5 && k.y>=0 && k.right<=width+.5 && k.bottom<=height+.5 && k.height>=44,JSON.stringify(k));
   const keyboard=await page.locator('#lt-keyboard').boundingBox(),field=await page.locator('#lt-search-input').boundingBox();assert.ok(field.y+field.height<=keyboard.y+1,JSON.stringify({keyboard,field}));
   await page.locator('[data-key=a]').tap();assert.equal(await page.locator('#lt-search-input').inputValue(),'a');await page.locator('#lt-keyboard [data-action=hideKeyboard]').tap();assert.equal(await page.locator('#lt-keyboard').isVisible(),false);
   pass(`maximum keyboard height respects the viewport and search field at 150% text/140% interface: ${width}×${height}`,errors);await context.close();
  }
  console.log(passed+' release 1.6.1 suites passed. Spotify and Windows APIs are simulated.');
 }finally{await browser.close();await new Promise(r=>server.close(r));}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
