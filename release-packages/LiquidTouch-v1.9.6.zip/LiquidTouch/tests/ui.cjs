/* Contract/UI tests against the offline host, not a claim of Spotify E2E testing.
   npm install --no-save playwright && npx playwright install chromium
   node tests/ui.cjs
   LT_CHROME=/path/to/chrome optionally selects an existing Chromium binary. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/playwright' : 'playwright');
const base = path.resolve(__dirname, '..');
const results = [];
const executablePath = process.env.LT_CHROME;
const screenshots = process.env.LT_SCREENSHOTS;
async function open(browser, width = 1024, height = 600, prefs) {
  const context = await browser.newContext({ viewport: { width, height }, hasTouch: true, reducedMotion: 'reduce' });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  if (prefs) await page.addInitScript(value => localStorage.setItem('liquid-touch.preferences.v1', JSON.stringify(value)), prefs);
  await page.goto(pathToFileURL(path.join(base, 'LiquidTouch-Preview.html')).href);
  await page.waitForFunction(() => window.LiquidTouch?.diagnostics);
  assert.equal(await page.evaluate(() => window.LiquidTouch.diagnostics().enabled), true);
  return { context, page, errors };
}
async function visibleTargets(page, selector) {
  return page.locator(selector).evaluateAll(nodes => nodes.filter(n => {
    const r = n.getBoundingClientRect(), s = getComputedStyle(n);
    return r.width && r.height && s.visibility !== 'hidden' && s.display !== 'none' && !n.closest('[hidden]');
  }).map(n => { const r = n.getBoundingClientRect(); return { label: n.getAttribute('aria-label') || n.textContent.trim(), width: r.width, height: r.height, x: r.x, y: r.y, right: r.right, bottom: r.bottom }; }));
}
function checkTargets(targets, width, height) {
  for (const t of targets) {
    assert.ok(t.width >= 43.9 && t.height >= 43.9, `${t.label}: target ${t.width}×${t.height}`);
    assert.ok(t.x >= -.5 && t.y >= -.5 && t.right <= width + .5 && t.bottom <= height + .5, `${t.label}: outside ${width}×${height} at ${JSON.stringify(t)}`);
  }
}
async function checkPlayerTargets(page,width,height){
  // Enlarged artwork may scroll the record column. Check every control at its
  // reachable position instead of treating clipped scroll content as on-screen.
  for(const target of await page.locator('#lt-now-playing button:not([data-lyric-index]), #lt-now-playing input').all()){
    if(!await target.isVisible())continue;
    await target.scrollIntoViewIfNeeded();
    const rect=await target.evaluate(n=>{const r=n.getBoundingClientRect();return {label:n.getAttribute('aria-label') || n.textContent.trim(),width:r.width,height:r.height,x:r.x,y:r.y,right:r.right,bottom:r.bottom};});
    checkTargets([rect],width,height);
  }
}
async function main() {
  const browser = await chromium.launch({ headless: true, executablePath, args: ['--no-sandbox'] });
  try {
    for (const [width, height] of [[800,480],[1024,600],[1280,720],[480,800],[600,1024]]) {
      const { page, context, errors } = await open(browser, width, height);
      checkTargets(await visibleTargets(page, '#lt-shell .lt-header button, #lt-shell .lt-footer button'), width, height);
      const main = await page.locator('[data-lt-native="main"]').boundingBox();
      const mini = await page.locator('.lt-mini').boundingBox();
      assert.ok(main.y + main.height < mini.y, 'Content must stop above mini player');
      if (screenshots) await page.screenshot({ path: path.join(screenshots, `home-${width}x${height}.png`) });
      await page.locator('#lt-mini-open').click();
      await checkPlayerTargets(page,width,height);
      if(width>700)assert.ok(await page.locator('#lt-now-playing').evaluate(n => n.scrollHeight <= n.clientHeight + 1), 'Landscape player should fit');
      if (screenshots) await page.screenshot({ path: path.join(screenshots, `player-${width}x${height}.png`) });
      await page.locator('#lt-now-playing [data-action="closePlayer"]').click();
      await page.locator('.lt-nav [data-action="search"]').click();
      await page.locator('#lt-keyboard').waitFor({ state: 'visible' });
      checkTargets(await visibleTargets(page, '#lt-keyboard button'), width, height);
      if (screenshots) await page.screenshot({ path: path.join(screenshots, `keyboard-${width}x${height}.png`) });
      assert.deepEqual(errors, []);
      results.push(`PASS layout, targets, player, keyboard: ${width}×${height}`);
      await context.close();
    }
    for (const [width, height] of [[800,480],[480,800]]) {
      const {page,context,errors}=await open(browser,width,height,{size:'large',palette:'graphite',lite:true});
      const primary=await visibleTargets(page,'#lt-shell .lt-header button, #lt-shell .lt-footer button');
      checkTargets(primary,width,height);
      assert.ok(primary.every(t=>t.width>=55.9&&t.height>=55.9),'Large primary controls must be at least 56 px');
      await page.locator('#lt-mini-open').click();
      await checkPlayerTargets(page,width,height);
      if(width>700)assert.ok(await page.locator('#lt-now-playing').evaluate(n=>n.scrollHeight<=n.clientHeight+1));
      await page.locator('#lt-now-playing [data-action="playerSettings"]').click();
      await page.keyboard.press('Tab');
      assert.equal(await page.evaluate(()=>document.querySelector('#lt-settings').contains(document.activeElement)),true);
      await page.keyboard.press('Escape');
      assert.equal(await page.locator('#lt-settings').evaluate(n=>n.open),false);
      assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);
      assert.deepEqual(errors,[]);
      results.push(`PASS large controls, low-blur layout, nested modal focus: ${width}×${height}`);
      await context.close();
    }
    {
      const { page, context, errors } = await open(browser);
      await page.locator('.lt-mini [data-action="togglePlay"]').click();
      assert.equal(await page.evaluate(() => Spicetify.Player.isPlaying()), false);
      await page.locator('.lt-mini [data-action="next"]').click();
      assert.equal(await page.locator('#lt-mini-title').textContent(), 'Blue Hour');
      await page.locator('#lt-mini-open').click();
      const np = page.locator('#lt-now-playing');
      await np.locator('[data-action="back"]').click();
      assert.equal(await page.locator('#lt-np-title').textContent(), 'Afterhours');
      await np.locator('[data-action="toggleHeart"]').click();
      assert.equal(await np.locator('[data-action="toggleHeart"]').getAttribute('aria-pressed'), 'true');
      await np.locator('[data-action="toggleShuffle"]').click();
      assert.equal(await page.evaluate(() => Spicetify.Player.getShuffle()), true);
      for (const mode of [1,2,0]) { await np.locator('[data-action="toggleRepeat"]').click(); assert.equal(await page.evaluate(() => Spicetify.Player.getRepeat()), mode); }
      await page.locator('#lt-seek').evaluate(n => { n.value = '500'; n.dispatchEvent(new Event('input', {bubbles:true})); n.dispatchEvent(new Event('change', {bubbles:true})); });
      assert.ok(await page.evaluate(() => Math.abs(Spicetify.Player.getProgress() - Spicetify.Player.getDuration() / 2) < 1500));
      await page.locator('#lt-seek').evaluate(n => { n.value = '1000'; n.dispatchEvent(new Event('change', {bubbles:true})); });
      assert.equal(await page.evaluate(() => __ltMock.log.filter(x=>x[0]==='seek').at(-1)[1]),238000);
      await page.locator('#lt-volume').evaluate(n => { n.value = '27'; n.dispatchEvent(new Event('input', {bubbles:true})); n.dispatchEvent(new Event('change', {bubbles:true})); });
      assert.equal(await page.evaluate(() => Spicetify.Player.getVolume()), .27);
      await np.locator('[data-action="toggleMute"]').click(); assert.equal(await page.evaluate(() => Spicetify.Player.getMute()), true);
      await np.locator('[data-action="queue"]').click();
      assert.equal(await page.evaluate(() => Spicetify.Platform.History.location.pathname), '/queue');
      await page.locator('#lt-shell [data-action="library"]').click();
      assert.equal(await page.locator('body').getAttribute('data-lt-page'), 'library');
      await page.locator('#lt-browse [data-lt-card="spotify:album:demo-1"]').dblclick();
      assert.equal(await page.locator('body').getAttribute('data-lt-page'), 'home');
      assert.equal(await page.evaluate(() => LiquidTouch.diagnostics().route), '/album/demo-1');
      // Keep the original native row-touch contract exercised on the queue.
      await page.locator('#lt-mini-open').click();await page.locator('#lt-now-playing [data-action=queue]').click();
      const target = page.locator('.fixture-row-title').first();
      const nativeTitle=await target.locator('a').textContent();await page.evaluate(()=>__ltMock.setPosition(90000));
      await target.dispatchEvent('pointerdown', {pointerType:'touch',isPrimary:true,pointerId:5,clientX:100,clientY:150});
      await target.dispatchEvent('pointerup', {pointerType:'touch',isPrimary:true,pointerId:5,clientX:102,clientY:152});
      assert.equal(await page.locator('#lt-mini-title').textContent(), nativeTitle);assert.ok(await page.evaluate(()=>Spicetify.Player.getProgress()<1500));
      const row = page.locator('.fixture-row-title').nth(1);
      await row.dispatchEvent('pointerdown', {pointerType:'touch',isPrimary:true,pointerId:6,clientX:100,clientY:150});
      await row.dispatchEvent('pointerup', {pointerType:'touch',isPrimary:true,pointerId:6,clientX:100,clientY:220});
      assert.equal(await page.locator('#lt-mini-title').textContent(), nativeTitle);
      assert.deepEqual(errors, []);
      results.push('PASS playback, seek, volume, library, queue, stationary touch versus scroll');
      await context.close();
    }
    {
      const { page, context, errors } = await open(browser, 480, 800);
      await page.locator('.lt-nav [data-action="search"]').click();
      for (const key of ['Shift','a','s','t','r','a']) await page.locator(`#lt-keyboard button[data-key="${key}"]`).click();
      assert.equal(await page.locator('#lt-search-input').inputValue(), 'Astra');
      await page.locator('#lt-keyboard button[data-key="Submit"]').click();
      assert.equal(await page.evaluate(() => Spicetify.Platform.History.location.pathname), '/search/Astra');
      assert.equal(await page.locator('#lt-keyboard').isHidden(), true);
      assert.equal(await page.locator('.fixture-row-title a').textContent(), 'In Orbit');
      await page.locator('#lt-search-input').fill('night / a&b ?');
      await page.locator('#lt-search-form').dispatchEvent('submit');
      assert.equal(await page.evaluate(() => Spicetify.Platform.History.location.pathname), '/search/night%20%2F%20a%26b%20%3F');
      await page.locator('#lt-shell [data-action="settings"]').click();
      await page.locator('#lt-settings [data-pref="keyboard"]').click();
      assert.equal(await page.locator('#lt-search-input').getAttribute('inputmode'), 'search');
      await page.locator('#lt-settings [data-pref="lite"]').click();
      await page.locator('#lt-palette').selectOption('ocean');
      await page.locator('#lt-size').selectOption('large');
      assert.equal(await page.locator('body').getAttribute('data-lt-palette'), 'ocean');
      assert.equal(await page.locator('body').getAttribute('data-lt-lite'), 'true');
      await page.reload(); await page.waitForFunction(()=>window.LiquidTouch?.diagnostics);
      const prefs = await page.evaluate(()=>window.LiquidTouch.diagnostics().preferences);
      assert.equal(prefs.size,'large'); assert.equal(prefs.keyboard,false); assert.equal(prefs.palette,'ocean');
      assert.deepEqual(errors, []);
      results.push('PASS local keyboard, encoded search, preferences, system keyboard option, persistence');
      await context.close();
    }
    {
      const { page, context, errors } = await open(browser);
      await page.locator('#lt-mini-open').click();
      await page.locator('#lt-art-swipe').dispatchEvent('pointerdown', {pointerType:'touch',isPrimary:true,pointerId:2,clientX:300,clientY:200});
      await page.locator('#lt-art-swipe').dispatchEvent('pointerup', {pointerType:'touch',isPrimary:true,pointerId:2,clientX:190,clientY:200});
      assert.equal(await page.locator('#lt-np-title').textContent(),'Blue Hour');
      await page.locator('#lt-np-header').dispatchEvent('pointerdown', {pointerType:'touch',isPrimary:true,pointerId:3,clientX:300,clientY:20});
      await page.locator('#lt-np-header').dispatchEvent('pointerup', {pointerType:'touch',isPrimary:true,pointerId:3,clientX:300,clientY:150});
      assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),false);
      await page.locator('#lt-mini-open').click();
      await page.locator('#lt-now-playing [data-action="devices"]').click();
      assert.equal(await page.evaluate(()=>window.LiquidTouch.diagnostics().enabled),false);
      assert.equal(await page.locator('#fixture-device').isVisible(),true);
      await page.locator('#lt-rescue').click();
      assert.equal(await page.evaluate(()=>window.LiquidTouch.diagnostics().enabled),true);
      await page.keyboard.press('Control+Alt+KeyT');
      assert.equal(await page.evaluate(()=>window.LiquidTouch.diagnostics().enabled),false);
      await page.locator('#lt-rescue').click();
      await page.evaluate(()=>__ltMock.setRestrictions({canSeek:false,canSkipNext:false,canToggleShuffle:false}));
      assert.equal(await page.locator('.lt-mini [data-action="next"]').isDisabled(),true);
      assert.equal(await page.locator('#lt-seek').isDisabled(),true);
      await page.evaluate(()=>__ltMock.setEmpty(true));
      assert.equal(await page.locator('.lt-mini [data-action="togglePlay"]').isDisabled(),true);
      assert.equal(await page.locator('#lt-mini-title').textContent(),'Your next good listen');
      await page.evaluate(()=>__ltMock.setEmpty(false));
      await page.evaluate(()=>__ltMock.setMetadata({uri:'spotify:track:unsafe',name:'<img src=x onerror="window.BAD=1">',metadata:{artist_name:'<script>bad()</script>',image_xlarge_url:'javascript:alert(1)'}}));
      assert.equal(await page.locator('#lt-mini-title img').count(),0);
      assert.equal(await page.evaluate(()=>window.BAD),undefined);
      assert.equal(await page.locator('#lt-art').getAttribute('src'),null);
      await page.evaluate(()=>LiquidTouch.destroy());
      assert.equal(await page.locator('#lt-shell').count(),0);
      assert.equal(await page.locator('body').evaluate(n=>n.classList.contains('lt-active')),false);
      assert.equal(await page.evaluate(()=>__ltMock.listenerCount()),0);
      assert.deepEqual(errors, []);
      results.push('PASS swipes, Connect desktop handoff, keyboard recovery, restrictions, empty state, metadata safety, clean teardown');
      await context.close();
    }
    // Hot reload must not duplicate listeners or controls.
    {
      const {page,context,errors}=await open(browser);
      const source=fs.readFileSync(path.join(base,'Extensions/liquid-touch.js'),'utf8');
      await page.evaluate(code=>{(0,eval)(code);},source);
      assert.equal(await page.locator('#lt-shell').count(),1);
      assert.equal(await page.evaluate(()=>__ltMock.listenerCount()),3);
      await page.evaluate(()=>document.querySelector('.Root__main-view').remove());
      await page.waitForFunction(()=>!LiquidTouch.diagnostics().enabled);
      assert.equal(await page.locator('#lt-rescue').isVisible(),true);
      assert.deepEqual(errors,[]);
      results.push('PASS extension reload deduplication and native-layout loss recovery');
      await context.close();
    }
    // Real-host startup conditions that the original happy-path fixture missed.
    {
      const {page,context,errors}=await open(browser);
      const source=fs.readFileSync(path.join(base,'Extensions/liquid-touch.js'),'utf8');
      await page.evaluate(code=>{
        LiquidTouch.destroy();
        Spicetify.Menu.Item=class {register(){throw new Error('Profile menu unavailable');} deregister(){}};
        const descriptor=Object.getOwnPropertyDescriptor(Spicetify.Player,'data');
        window.__restorePlayerData=()=>Object.defineProperty(Spicetify.Player,'data',descriptor);
        Object.defineProperty(Spicetify.Player,'data',{configurable:true,get(){throw new Error('Player not ready');}});
        (0,eval)(code);
      },source);
      assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().enabled),true);
      assert.equal(await page.locator('#lt-mini-title').textContent(),'Afterhours');
      await page.evaluate(()=>{__restorePlayerData();__ltMock.emit('songchange');});
      assert.equal(await page.locator('#lt-mini-title').textContent(),'Afterhours');
      await page.evaluate(code=>{
        LiquidTouch.destroy();
        Spicetify.Menu.Item=class {constructor(){throw new TypeError('ReactJSX is not ready');}};
        (0,eval)(code);
      },source);
      assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().enabled),true);
      await page.evaluate(()=>{LiquidTouch.destroy();Spicetify.Platform.History.listen=undefined;});
      await page.evaluate(code=>(0,eval)(code),source);
      await page.evaluate(()=>Spicetify.Platform.History.push('/search/Blue'));
      await page.waitForFunction(()=>document.body.dataset.ltPage==='search');
      assert.deepEqual(errors,[]);
      results.push('PASS delayed player state, optional profile-menu failure, router without listen');
      await context.close();
    }
    {
      const {page,context,errors}=await open(browser);
      const source=fs.readFileSync(path.join(base,'Extensions/liquid-touch.js'),'utf8');
      await page.evaluate(code=>{
        LiquidTouch.destroy();window.__savedHistory=Spicetify.Platform.History;delete Spicetify.Platform.History;(0,eval)(code);
      },source);
      await page.locator('#lt-startup-status').waitFor({state:'visible',timeout:7000});
      assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().navigation),false);
      assert.equal(await page.evaluate(()=>document.body.classList.contains('lt-active')),false);
      await page.evaluate(()=>{Spicetify.Platform.History=window.__savedHistory;});
      await page.locator('#lt-startup-status').getByRole('button',{name:'Retry',exact:true}).click();
      await page.waitForFunction(()=>LiquidTouch.diagnostics().enabled);
      assert.equal(await page.locator('#lt-startup-status').count(),0);
      assert.deepEqual(errors,[]);
      results.push('PASS missing navigation API leaves native UI available, shows diagnostics, and retries');
      await context.close();
    }
    {
      const {page,context,errors}=await open(browser);
      const source=fs.readFileSync(path.join(base,'Extensions/liquid-touch.js'),'utf8');
      await page.evaluate(code=>{
        LiquidTouch.destroy();
        const descriptor=Object.getOwnPropertyDescriptor(Element.prototype,'innerHTML');
        window.__restoreHTML=()=>Object.defineProperty(Element.prototype,'innerHTML',descriptor);
        Object.defineProperty(Element.prototype,'innerHTML',{configurable:true,get:descriptor.get,set(value){if(this.id==='lt-shell')throw new TypeError('Simulated HTML injection rejection');descriptor.set.call(this,value);}});
        (0,eval)(code);
      },source);
      assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().phase),'failed');
      assert.equal(await page.locator('#lt-startup-status').isVisible(),true);
      assert.match(await page.locator('#lt-startup-message').textContent(),/Simulated HTML injection rejection/);
      assert.equal(await page.evaluate(()=>document.body.classList.contains('lt-active')),false);
      await page.evaluate(()=>__restoreHTML());
      await page.locator('#lt-startup-status').getByRole('button',{name:'Retry',exact:true}).click();
      assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().enabled),true);
      assert.deepEqual(errors,[]);
      results.push('PASS actual startup exception remains inspectable and can be retried');
      await context.close();
    }
    {
      const {page,context,errors}=await open(browser);
      const source=fs.readFileSync(path.join(base,'Extensions/liquid-touch.js'),'utf8');
      await page.evaluate(code=>{LiquidTouch.destroy();document.querySelectorAll('style').forEach(n=>n.remove());(0,eval)(code);},source);
      assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().themeCSS),false);
      assert.equal(await page.locator('#lt-startup-status').isVisible(),true);
      assert.match(await page.locator('#lt-startup-message').textContent(),/CSS is missing/);
      assert.deepEqual(errors,[]);
      results.push('PASS missing CSS is reported by a diagnostic panel styled independently of the theme');
      await context.close();
    }
    console.log(results.join('\n'));
    console.log(`${results.length} suites passed. Host APIs are mocked; Spotify integration needs a live client check.`);
  } finally { await browser.close(); }
}
main().catch(error=>{console.error(error);process.exitCode=1;});
