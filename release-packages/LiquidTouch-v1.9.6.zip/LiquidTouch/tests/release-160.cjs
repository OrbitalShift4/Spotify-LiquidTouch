const {revealSetting}=require('./settings-navigation.cjs');
/* 1.6 regressions. 1.6.1 replaces automatic fullscreen with an app-viewport player. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
let origin,passed=0;
async function open(browser,width=1024,height=600,prefs={}){
 const context=await browser.newContext({viewport:{width,height},hasTouch:true,reducedMotion:'no-preference'}),page=await context.newPage(),errors=[];
 page.setDefaultTimeout(6500);page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(value=>{if(!localStorage.getItem('liquid-touch.preferences.v1'))localStorage.setItem('liquid-touch.preferences.v1',JSON.stringify({keyboard:false,playerFullscreen:false,...value}));},prefs);
 await page.goto(origin);await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');return {context,page,errors};
}
function pass(name,errors){assert.deepEqual(errors,[]);passed++;console.log('PASS '+name);}
async function range(page,key,value){await revealSetting(page,key);await page.locator('#lt-'+key).evaluate((n,value)=>{n.value=String(value);n.dispatchEvent(new Event('input',{bubbles:true}));},value);}
async function settings(page){await page.locator('#lt-shell .lt-header [data-action=settings]').tap();}
async function swipe(page,x,y,endX,endY){const s=await page.context().newCDPSession(page);await s.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y,id:1}]});for(let i=1;i<=8;i++)await s.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x+(endX-x)*i/8,y:y+(endY-y)*i/8,id:1}]});await s.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await s.detach();}
async function assertTint(page,selectors,value){
 const result=await page.evaluate(selectors=>selectors.map(selector=>{const n=document.querySelector(selector),s=getComputedStyle(n),match=s.backgroundColor.match(/rgba?\(([^)]+)\)/);return {selector,alpha:match ? Number(match[1].split(',')[3] ?? 1) : NaN,opacity:s.opacity};}),selectors);
 for(const r of result){assert.equal(r.alpha,value,r.selector+' tint');assert.equal(r.opacity,'1',r.selector+' content opacity');}
}
async function main(){
 const server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(fs.readFileSync(path.resolve(__dirname,'../LiquidTouch-Preview.html')));});await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:process.env.LT_CHROME,args:['--no-sandbox']});
 try{
  {
   const {page,context,errors}=await open(browser,1024,600,{playerFullscreen:true});
   await page.evaluate(()=>{window.fullscreenRequests=0;document.documentElement.requestFullscreen=()=>{fullscreenRequests++;return new Promise(()=>{});};});
   await page.locator('#lt-mini-open').tap();
   assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),true);assert.equal(await page.evaluate(()=>LiquidTouch.diagnostics().playerOpening),false);await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');
   assert.equal(await page.evaluate(()=>document.querySelector('#lt-now-playing').contains(document.elementFromPoint(500,300))),true);
   await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await page.locator('#lt-mini-open').tap();
   assert.equal(await page.evaluate(()=>fullscreenRequests),0);assert.equal(await page.locator('#lt-now-playing').isVisible(),true);
   pass('the first tap paints an interactive player without requesting fullscreen, even with a legacy saved fullscreen preference',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,1024,600,{playerFullscreen:true});
   await page.evaluate(()=>{const request=document.documentElement.requestFullscreen;window.finishFullscreen=null;document.documentElement.requestFullscreen=()=>new Promise(resolve=>{finishFullscreen=()=>Promise.resolve(request()).then(resolve);});});
   await page.locator('#lt-mini-open').tap();await page.locator('#lt-now-playing [data-action=playerSettings]').tap();
   await page.evaluate(()=>document.dispatchEvent(new Event('fullscreenchange')));await page.waitForTimeout(160);
   assert.equal(await page.evaluate(()=>document.querySelector('#lt-settings').contains(document.elementFromPoint(500,300))),true);
   await page.locator('#lt-settings [data-action=closeSettings]').tap();await page.locator('#lt-now-playing [data-action=next]').tap();assert.equal(await page.locator('#lt-np-title').textContent(),'Blue Hour');
   await page.locator('#lt-now-playing [data-action=closePlayer]').tap();assert.equal(await page.evaluate(()=>Boolean(document.fullscreenElement)),false);
   pass('external fullscreen notifications preserve the top Settings sheet and player input without a display-mode request',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,1024,600,{playerFullscreen:true});
   await page.evaluate(()=>{const request=document.documentElement.requestFullscreen;document.documentElement.requestFullscreen=()=>new Promise(resolve=>{window.finishFullscreen=()=>Promise.resolve(request()).then(resolve);});});
   await page.locator('#lt-mini-open').tap();await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await page.evaluate(()=>document.dispatchEvent(new Event('fullscreenchange')));await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);
   assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.open),false);assert.equal(await page.evaluate(()=>Boolean(document.fullscreenElement)),false);
   await page.locator('.lt-nav [data-action=library]').tap();assert.equal(await page.locator('body').getAttribute('data-lt-page'),'library');
   pass('external fullscreen notifications after dismissal cannot reopen the player or put the app into fullscreen',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,1024,600,{playerFullscreen:true});
   await page.evaluate(()=>{delete document.fullscreenElement;delete document.documentElement.requestFullscreen;delete document.exitFullscreen;});
   await page.evaluate(()=>{const b=document.createElement('button');b.id='test-fullscreen';b.style.cssText='position:fixed;inset:200px auto auto 300px;z-index:2147483000';b.textContent='Host fullscreen';b.onclick=()=>document.documentElement.requestFullscreen();document.body.append(b);});
   await page.locator('#test-fullscreen').tap();await page.waitForFunction(()=>document.fullscreenElement);await page.locator('#test-fullscreen').evaluate(n=>n.remove());
   for(let i=0;i<3;i++){
    await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open' && document.fullscreenElement);
    assert.equal(await page.evaluate(()=>document.querySelector('#lt-now-playing').contains(document.elementFromPoint(500,300))),true);
    assert.equal(await page.locator('#lt-now-playing').evaluate(n=>n.getAnimations().length),0);
    await page.locator('#lt-now-playing [data-action=closePlayer]').tap();await page.waitForFunction(()=>!document.querySelector('#lt-now-playing').open);assert.equal(await page.evaluate(()=>Boolean(document.fullscreenElement)),true);
   }
   await page.evaluate(()=>document.exitFullscreen());
   pass('repeated player open/close preserves a real preexisting host fullscreen session without invisible hit areas',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser,1920,1080,{textScale:130,uiScale:120});await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>LiquidTouch.diagnostics().playerPhase==='open');
   const r=await page.evaluate(()=>{const box=s=>{const r=document.querySelector(s).getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom};};return {art:box('#lt-art'),controls:box('.lt-np-controls'),play:box('.lt-play-large'),lyrics:box('#lt-lyrics-panel')};});
   assert.ok(r.art.width>=480 && r.art.width<=487);assert.ok(r.controls.width<=421);assert.ok(r.play.width<60 && r.play.width>=48);assert.ok(r.controls.y>=r.art.bottom);assert.ok(r.lyrics.x>=r.controls.x+r.controls.width);
   assert.equal(await page.locator('#lt-context-title').count(),0);assert.equal(await page.locator('#lt-np-header .lt-context').textContent(),'');
   assert.equal(await page.locator('#lt-now-playing').getAttribute('aria-labelledby'),'lt-np-title');
   await page.locator('#lt-now-playing [data-action=toggleLyrics]').tap();await page.waitForTimeout(180);assert.equal(await page.locator('#lt-lyrics-panel').isVisible(),false);
   await page.locator('#lt-now-playing [data-action=toggleLyrics]').tap();await page.waitForTimeout(180);assert.equal(await page.locator('#lt-lyrics-panel').isVisible(),true);
   pass('the lyric deck has larger artwork and smaller controls at 130% text/120% interface, with no repeated header title',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await settings(page);
   const selectors=['.lt-header','.lt-nav','.lt-mini','#lt-browse','.lt-card','.lt-search-form','.lt-quick-search','.lt-search-preview','.lt-keyboard','#lt-settings','#lt-history','#lt-now-playing .lt-np-header','#lt-lyrics-panel','#lt-lyric-timing'];
   for(const value of [0,63,100]){await range(page,'glassOpacity',value);await assertTint(page,selectors,value/100);assert.equal(await page.locator('#lt-glassOpacity-value').textContent(),value+'%');}
   await page.locator('#lt-settings [data-action=closeSettings]').tap();await page.locator('#lt-mini-open').tap();assert.equal(await page.locator('#lt-art').isVisible(),true);
   assert.equal(await page.locator('#lt-player-background').getAttribute('src'),await page.locator('#lt-art').getAttribute('src'));
   pass('0%, intermediate and 100% universal tint reach every major surface while text/artwork remain fully visible',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await settings(page);await revealSetting(page,'opacity');await page.locator('.lt-opacity-options summary').tap();
   for(const [key,value] of [['headerOpacity',0],['navOpacity',100],['miniOpacity',22],['playerHeaderOpacity',87],['lyricsOpacity',44],['settingsOpacity',70],['historyOpacity',95]]){
    await page.locator('[data-opacity-override='+key+']').tap();await range(page,key,value);
   }
   await range(page,'glassOpacity',61);
   for(const [selector,value] of [['.lt-header',0],['.lt-nav',1],['.lt-mini',.22],['#lt-now-playing .lt-np-header',.87],['#lt-lyrics-panel',.44],['#lt-settings',.7],['#lt-settings .lt-sheet-header',0],['#lt-history',.95],['#lt-history .lt-np-header',0]])await assertTint(page,[selector],value);
   await page.reload();await page.waitForFunction(()=>LiquidTouch.diagnostics().phase==='mounted');const prefs=await page.evaluate(()=>LiquidTouch.diagnostics().preferences);
   assert.equal(prefs.headerOpacity,0);assert.equal(prefs.navOpacity,100);assert.equal(prefs.glassOpacity,61);
   await settings(page);await revealSetting(page,'opacity');await page.locator('.lt-opacity-options summary').tap();await page.locator('[data-action=resetOpacity]').tap();
   await assertTint(page,['.lt-header','.lt-nav','.lt-mini','#lt-now-playing .lt-np-header','#lt-lyrics-panel','#lt-settings'],.61);
   assert.equal(await page.locator('#lt-headerOpacity').isDisabled(),true);await range(page,'glassOpacity',18);assert.equal(await page.locator('#lt-headerOpacity-value').textContent(),'18%');
   pass('seven independent overrides include true 0%/100%, persist, and reset to live universal inheritance',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);await page.waitForTimeout(550);await page.locator('#lt-mini-open').tap();await page.waitForFunction(()=>document.querySelectorAll('.lt-lyric-line').length===5);await page.locator('#lt-now-playing [data-action=playerSettings]').tap();
   const before=await page.evaluate(()=>({builds:LiquidTouch.diagnostics().browseBuilds,lyrics:document.querySelectorAll('.lt-lyric-line').length,requests:__ltMock.log.filter(r=>r[0]==='apiGet').length}));
   await page.locator('#lt-glassOpacity').evaluate(n=>{for(let i=0;i<=100;i++){n.value=String(i);n.dispatchEvent(new Event('input',{bubbles:true}));}});
   const after=await page.evaluate(()=>({builds:LiquidTouch.diagnostics().browseBuilds,lyrics:document.querySelectorAll('.lt-lyric-line').length,requests:__ltMock.log.filter(r=>r[0]==='apiGet').length}));assert.deepEqual(after,before);
   assert.equal(await page.locator('#lt-glassOpacity-value').textContent(),'100%');
   pass('live opacity scrubbing does not rebuild browsing, reload lyrics or issue extra Spotify requests',errors);await context.close();
  }
  {
   const {page,context,errors}=await open(browser);
   for(const x of [20,512,1004]){await swipe(page,x,175,x+1,260);assert.equal(await page.locator('#lt-quick-search').isVisible(),true);await page.locator('[data-action=closeQuickSearch]').tap();}
   await page.locator('#lt-browse').evaluate(n=>n.scrollTop=200);await swipe(page,20,90,21,185);assert.equal(await page.locator('#lt-quick-search').isVisible(),true);
   await page.locator('[data-action=closeQuickSearch]').tap();await swipe(page,970,32,970,130);assert.equal(await page.locator('#lt-quick-search').isVisible(),false);assert.equal(await page.evaluate(()=>__ltMock.log.filter(r=>r[0]==='windowClose').length),0);
   pass('quick search pulls work at both edges and deeper into the upper area, including the toolbar band on scrolled pages; captions stay protected',errors);await context.close();
  }
  for(const [width,height] of [[800,480],[1024,600],[480,800]]){
   const {page,context,errors}=await open(browser,width,height,{textScale:130,uiScale:120});await page.locator('#lt-mini-open').tap();await page.waitForTimeout(170);
   assert.equal(await page.locator('#lt-art').isVisible(),true);const art=await page.locator('#lt-art').boundingBox();assert.ok(art.width>=110 && art.x>=0 && art.x+art.width<=width);
   await page.locator('#lt-now-playing [data-action=queue]').scrollIntoViewIfNeeded();const queue=await page.locator('#lt-now-playing [data-action=queue]').boundingBox();assert.ok(queue.y>=0 && queue.y+queue.height<=height+1);
   pass(`larger lyric artwork and compact controls remain reachable at 130% text/120% interface: ${width}×${height}`,errors);await context.close();
  }
  console.log(passed+' release 1.6 suites passed. Spotify services and Windows IPC are simulated.');
 }finally{await browser.close();await new Promise(r=>server.close(r));}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
