/* Navigate the real Settings categories; older release fixtures keep their flat UI. */
const groups={
 accessibility:['textScale','uiScale','size','reduceMotion'],
 appearance:['quickSearchBlur','palette','glassOpacity','rounding','adaptive','windowControls','lite','headerOpacity','navOpacity','miniOpacity','playerHeaderOpacity','lyricsOpacity','settingsOpacity','historyOpacity','opacity'],
 player:['artworkSize','playerTextScale','playerControlScale','startPlayer'],
 lyrics:['lyrics','lyricsFallback','lyricsTextFallback','playerLyricsScale','openLyricTiming'],
 home:['welcome','welcomeSubtitle','homeClock','clockFormat'],
 touch:['cardTapDelay','keyboard','keyboardHeight'],
 animations:['motionSpeed','pageSpeed','navSpeed','surfaceSpeed','settingsPageSpeed','settingsBackSpeed','settingsCloseSpeed','springSpeed','playerOpenSpeed','playerCloseSpeed','trackSwipeSpeed','trackChangeSpeed','miniPlayerSpeed','lyricsShowSpeed','lyricsHideSpeed','lyricsLayoutSpeed','lyricLineSpeed','lyricScrollSpeed','keySpeed','buttonSpeed','toggleSpeed','windowSpeed','spinnerSpeed'],
 gestures:['backThreshold','settingsBackThreshold','settingsCloseThreshold','sheetCloseThreshold','playerOpenThreshold','playerCloseThreshold','playerTrackThreshold','miniTrackThreshold','quickOpenThreshold','quickCloseThreshold','tabThreshold'],
 updates:['update-feed','update-file','checkUpdates','importUpdate','releaseNotes','restoreRuntime'],
 help:['playHistory','desktop','historySongLimit','clearHistory']
};
async function revealSetting(page,key){
 const section=Object.keys(groups).find(id=>id===key || groups[id].includes(key));if(!section)throw Error('Unknown setting '+key);
 if(!await page.locator('#lt-settings').evaluate(n=>n.open))return;
 const entry=page.locator(`[data-settings-section="${section}"]`);if(!await entry.count())return;
 if(await page.locator(`[data-settings-page="${section}"]`).isVisible())return;
 const back=page.locator('#lt-settings [data-action=settingsBack]');if(await back.isVisible())await back.tap();
 await entry.tap();await page.locator(`[data-settings-page="${section}"]`).waitFor({state:'visible'});
}
module.exports={revealSetting};
