# LiquidTouch v1.9.6

A Spicetify theme and companion extension that gives Spotify desktop a mobile-style
interface for touchscreens, mini PCs and dedicated music panels. It combines
large controls, artwork-colored backgrounds, translucent glass surfaces and
responsive navigation. Spotify continues to handle audio, your account and the
music catalog. Install both the theme and extension to get the full interface.

Build: `2026-11-03-qol`. See [release notes](PATCHNOTES-v1.9.6.md) and
[validation](VALIDATION.md).

## What's new

- **Lyrics per song:** each song starts with lyrics hidden. When automatic lookup
  is enabled, actual lyrics appear after loading. Manual show/hide remains
  available even when no lyrics were found, and resets for the next song.
- **Consistent settings:** numeric Settings sliders, plus/minus buttons and
  accessible outputs use percentages in 5% steps. Existing values migrate to
  the nearest supported step; custom feeds and local history stay saved.
- **Fresh Home:** Recently played follows real playlist, album and artist
  contexts, keeps up to 24 deduplicated entities and survives restarts. Updates
  preserve the current route and scroll position.
- **Low-RAM improvements:** fewer full player-control paints and native scans,
  slower background polling, simpler effects, no animations/preloading or hidden
  page fragments, smaller supplied artwork and less image decoding. Actual total
  Spotify RAM and frame rate have not been measured on a real PC.
- **Clean artwork:** artwork sizing is in Settings → Now Playing. Holding the
  artwork still opens track options.
- **Shared gestures:** edge Back, browsing tabs, track swipes across the expanded
  player and downward sheet dismissal, while preserving ordinary scrolling.

## Demo and pictures

Open **LiquidTouch-Gallery.html** for the self-contained, offline interface with
real songs, artists, albums and cover artwork. Playback is simulated with no
audio or account connection. The separate **LiquidTouch-Preview.html** uses
fictional recordings for repeatable automated tests.

The [screenshot gallery and music credits](docs/screenshots/README.md) include
Home, Now Playing, Library, Search, history and context menus. The static pictures
are v1.9.5 reference captures; the interactive demo runs this release's code.

## Windows installation

Use Spotify desktop with an already working, compatible Spicetify installation.
Extract the **entire ZIP**. From PowerShell in the extracted LiquidTouch folder,
run as your normal Windows user:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-Windows.ps1
```

The installer finds the config with `spicetify -c`, backs up the existing config
and LiquidTouch resources, enables exposed APIs, copies the theme and extension,
and rebuilds Spicetify preprocessing. Existing extensions are preserved. Close
Spotify before installation, then reopen it after the installer finishes.

Optional flags:

```powershell
# Also create a Windows login shortcut that runs spicetify auto.
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-Windows.ps1 -AutoStart

# Copy/configure files without patching Spotify immediately.
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-Windows.ps1 -NoApply
```

After `-NoApply`, run `spicetify restore backup apply` if a native backup exists,
or `spicetify backup apply` for a fresh installation. Expanding the player fills
Spotify's app window without changing operating-system fullscreen mode.

## Linux/macOS and manual installation

The helper requires Python 3 and a working `spicetify` command:

```bash
bash install.sh
# Optional: bash install.sh --no-apply
```

For manual installation, run `spicetify -c` and use its parent directory. Copy
`Themes/LiquidTouch` into `Themes` and `Extensions/liquid-touch.js` into
`Extensions`, then run:

```text
spicetify config current_theme LiquidTouch color_scheme Glass inject_css 1 replace_colors 1 expose_apis 1
spicetify config extensions liquid-touch.js
spicetify backup apply
```

Use `spicetify restore backup apply` for the last step when a native backup
already exists. API exposure requires rebuilding preprocessing.

## Updates

Both original and revised v1.9.5 installations can update normally to v1.9.6.
Open **Settings → Updates → Check now**, review the offer and choose **Update**
or **Later**. You can also import the packaged LiquidTouch-Update-v1.9.6.json.
The loader validates a newer version and checksum before replacing runtime and
styles together, and rolls back if the new interface fails to mount.

The official feed is prefilled for newer installations:

```text
https://raw.githubusercontent.com/OrbitalShift4/Spotify-LiquidTouch/main/latest.json
```

Saved custom feeds remain intact. Automatic checks offer updates at startup and
about every six hours while Spotify is running; installation requires choosing
Update. **Restore installed version** returns to the package installed by the
normal installer. Runtime updates persist locally across restarts. Removing
Spotify profile data can remove them and local settings/history.

## Controls

| Action | Control |
| --- | --- |
| Expand Now Playing | Tap the mini player, or swipe it upward |
| Collapse Now Playing | Down arrow, Escape/Back, left-edge Back or downward swipe at the top of its scroll content |
| Next/previous track | Buttons or horizontal swipes across expanded-player artwork, track information, controls or lyrics; also supported on the mini player |
| Switch browsing tabs | Swipe horizontally across browsing or floating navigation |
| Go Back | Top-left button or a rightward swipe starting at the left edge |
| Dismiss a sheet | Downward swipe while the relevant scroll container is at the top |
| Play a playlist/album | Single tap its card |
| Explore a playlist/album | Double tap within the configured card-timing window |
| Context options | Hold a card or player artwork; right click or use the context-menu key |
| Search | Search tab or pull down near the upper page to open Quick Search |
| Erase continuously | Hold Backspace on the local on-screen keyboard |
| Show/hide lyrics | Lyrics in Now Playing; applies to the current song |
| Seek with lyrics | Tap a timed lyric line |
| Correct lyric timing | Lyrics ⋯ → Timing → Earlier/Later or Match a line |
| Artwork/control/text sizes | Settings → Now Playing; lyric size is in Lyrics |
| Queue/devices | Queue or Devices in expanded Now Playing |
| Listening history | Home shortcut or Settings → History & help |
| Desktop interface | Settings → History & help → Desktop interface |
| Return to touch UI | Floating Touch UI button or Ctrl + Alt + T |

Gestures keep fields, sliders, the keyboard and window buttons available.
Scrolling a sheet or the player while away from the top scrolls its content.
Small, cancelled and reversed swipes do not commit navigation. Reduce Motion
and Low-RAM mode keep gesture actions while skipping animated previews.

## Settings and performance

Settings is divided into Text & accessibility, Appearance & glass, Now Playing,
Lyrics, Home & clock, Touch & keyboard, Animation speeds, Swipe thresholds,
Updates and History & help.

Every numeric Settings slider uses **5% steps**. For relative controls, 100% is
the standard amount; motion speed at 200% is twice normal, and shorter timing
or swipe-distance percentages shorten the wait or gesture. Opacity is a direct
0–100% tint. Set a panel to Custom to override the universal opacity, or turn
Custom off to follow Universal. Blur can be set to 0%.

History limits are actual song counts, clock format is 12/24-hour, and lyric
timing corrections are measured time offsets. Playback seek/volume keep their
playback precision. These controls do not pretend that an exact count or time
is a percentage.

For a landscape touch panel, adjust Text size, Interface size and Touch control
size to suit its physical size and OS scaling. Larger settings may require
scrolling. A useful starting point is 130% text and 120% interface size.
Turn on **Low-RAM mode** under Appearance & glass for a constrained mini PC.
**Lighter glass** separately removes blur. Turn off the built-in English
keyboard to use your system keyboard, including other language layouts.

Lyrics depend on source availability. Optional fallback sources use recording
metadata to look up lyrics through LRCLIB and lyrics.ovh; no Spotify account is
sent. Plain lyrics can be read but cannot provide timed seeking. Source and
timing controls remain available when the panel is opened manually.

## Troubleshooting, removal and tests

Spotify internal APIs/layout can change independently of the theme. If controls
fail, use Desktop interface or Ctrl + Alt + T and include LiquidTouch, Spotify and
Spicetify versions, viewport, text/interface scales and reproduction steps in a
bug report. Devices, playlist operations and lyrics depend on the session APIs.

Windows removal:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Uninstall-Windows.ps1
```

Linux/macOS removal: `bash uninstall.sh`. Backups remain in the Spicetify config
directory. Installer state preserves the original theme/API preferences and
previous LiquidTouch resources where applicable.

Developer build scripts are under `tools/`; editable controller/loader source
is under `source/`, CSS under `Themes/LiquidTouch/`, and regression tests under
`tests/`. See [VALIDATION.md](VALIDATION.md) for reproducible current-release
checks and their limits. The complete extension was tested with a simulated DOM
host; live Windows Spotify, physical touch and real memory/frame times remain
unverified.

Original LiquidTouch code and fictional test artwork use the included MIT
license. Real gallery artwork belongs to its respective owners. LiquidTouch is
independent of Spotify and Apple. Feedback and suggestions are welcome at the
[repository](https://github.com/OrbitalShift4/Spotify-LiquidTouch).
